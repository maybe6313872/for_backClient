---
name: sdd-web-frontend
metadata:
  owner: envicool
  version: 2.1.0
  domain: web-frontend
  framework: SDD
  framework_baseline: sdd-skill-creator v2.3.0
  role: coding-skill
description: 'Spec-Driven Development + code-doc twin workflow for browser-side Web front-end single-page apps (React / Vue + TypeScript + SCSS + Vite). Mode A (forward): six gated stages (constitution→spec→design→tasks→test→deliver), every stage stops for approval and tasks must write real code; maintains specs/README, context/, task.md kanban. Mode B (twin): reverse-engineer legacy front-end code into source-equivalent docs for AI iteration and onboarding. Rigid rules (STATE/RENDER/ASYNC/TYPE/A11Y/PERF/SEC/STYLE/I18N/CMPX/PROC), L1-L5 evidence, archive-before-write specs lifecycle. Browser-side SPA only — NOT Svelte/Next.js/Nuxt/Astro/SolidJS/Electron/Webpack or SSR/SSG; distinct from sdd-pc (desktop). Interaction and deliverables in Simplified Chinese. 触发词：spec、规格驱动、需求规格、规格书、Web前端开发、前端开发流程、frontend、React、Vue、TypeScript、组件开发、页面开发、SPA、SCSS、Vite、pnpm、状态管理、TanStack Query、缓存失效、路由、API对接、API契约、i18n、国际化、多语言、复杂表单、表格、响应式设计、无障碍、WCAG、Core Web Vitals、INP、ESLint、Prettier、复盘、代码地图、知识地图、存量项目梳理、开始迭代。'
---

# SDD-Web-Frontend — Spec-Driven Development Workflow for browser-side Web front-end SPAs

A workflow for **browser-side Web front-end single-page apps (React / Vue + TypeScript + SCSS + Vite)**. Tech stack: React / Vue with TypeScript, SCSS, Vite; pnpm; ESLint/Prettier; Vitest/Jest/Playwright/Cypress. Typical architecture: **browser-side SPA (client-side rendering), layered `pages ← components ← hooks/composables ← services ← utils`**. Twin of `sdd-pc` (desktop) and the other domain skills: same SDD backbone, differing in tech-stack anchor, runtime, and deliverable shape.

## Domain routing signature (auto-routing guard)

This skill owns **browser-side Web front-end SPA** projects. **Fingerprint files: `package.json` + `vite.config.{ts,js,mjs}` + a `react` or `vue` dependency + `tsconfig.json`**. On receiving an `/sdd-*` project command (or a Chinese equivalent), scan fingerprints first: match ⇒ take over; another domain's project ⇒ politely hand over ("this looks like an X project; consider sdd-X"); no/multiple matches ⇒ ask the user in one line. **Focus**: browser-side SPA, React / Vue + TypeScript + SCSS + Vite. **Does not cover** Svelte / Next.js / Nuxt.js / Astro / SolidJS / Electron / Webpack / SSR-SSG. Design assumption (frozen): one engineer installs one sdd-xx, so identical command names across sdd-xx skills are not a conflict — never raise it.

## Two modes of use (mutually dependent)

| | **Mode A — forward spec-driven development** | **Mode B — code-doc twin** |
|---|---|---|
| Solves | Implementing new features (0→1) or evolving (1→100) with discipline | Reverse-engineering legacy front-end code into text docs equivalent to the source |
| Entry | `/sdd-iterate` (or 「开始新迭代」「实现/改某功能」) | `/sdd-init` (or 「梳理这个项目」「接手这个老项目」) |
| Main output | Six-stage specs/ docs + implementation code + maintained README/context/task.md | README + full context/ twin docs (five layers) + code map + knowledge map |

**How they depend on each other**: Mode B's output (project cognition + code map + knowledge map) is the "memory base" for every Mode A iteration; each Mode A iteration writes back to keep the twin fresh. **Inheriting a legacy project without specs/? Run `/sdd-init` (Mode B) first, then `/sdd-iterate` (Mode A).**

---

## 🚦 Gate system (hard rules · red lines · mandatory)

> These are this skill's most important constraints — the "ugly words" up front. **Violating any one is an error**, far worse than shipping fewer features.

**1. After every stage: stop, report, await user approval.**
Mode A has six stages; after completing each one you **must stop**: show the stage's gate checklist item-by-item status → tell the user "本阶段完成，请审阅" → **wait until the user explicitly says 通过/进入下一阶段**.
❌ Never chain-run from constitution to deliver. ❌ Never advance multiple stages on your own. ❌ Never skip a stage. Even when later stages look "obvious", advance **one stage at a time**.

**2. The tasks stage must produce real code **and the tests that go with it**, not just plans.**
tasks has two phases: ① planning (split into TODOs, **each TODO naming the tests it will land** → gate for user review) ② execution (**write real, runnable, verifiable code and, inside the same task, the necessary unit/automated tests**; for a defect fix, **write the reproducing test first** → gate for user confirmation).
❌ Stopping after a task list/plan and passing "to be implemented" off as delivery **is an error**. ❌ Pushing *all* test writing to the test stage and letting tasks ship code with no tests **is equally an error** — it hard-codes the "implement now, test later" habit and defers every testability problem (uninjectable dependencies, unconstructable states, side effects tangled with business logic) to the last stage, where the only options left are an expensive design flow-back or a manual-verification downgrade that cannot exceed L1. Once the plan is approved, both the code and its tests must actually land, run, and leave reproducible evidence.

> **tasks and test do not overlap and neither replaces the other**: **tasks guarantees "it is testable as it is written"; test guarantees "it holds up before delivery."** Tests written during tasks are *not* a reason to shorten or skip the test stage, and the test stage is *not* the place to retrofit the unit tests tasks owed. See [gate-and-stages.md](references/gate-and-stages.md).

**3. Never overwrite or delete anything under `specs/` — archive first, then write.**
Before updating `task.md` or any stage `current.md`: if the old content belongs to the previous iteration → archive first (`task.md` → `specs/task/YYYY-MM-DD-说明.md`; stage → `<stage>/history/YYYY-MM-DD-说明.md`), extract what the new workbench needs, then write.
❌ Overwriting current.md directly, ❌ wiping task.md — both destroy project history and **are errors**. See [specs-lifecycle.md](references/specs-lifecycle.md).

**4. `task.md` and `4-tasks/` are not the same thing — never conflate them.**
`task.md` = the global command deck (maintained for **any** task, coarse-grained checklist); `4-tasks/current.md` = the fine-grained construction plan **only** for six-stage iterations. See [Mode A](#mode-a-forward-spec-driven-development) and [task-kanban-protocol.md](references/task-kanban-protocol.md).

**5. No guessing external behavior; no unauthorized coding; no bare PASS.**
Never guess third-party interfaces / API response shapes / protocol fields / dependency behavior; every implementation starts with a plan awaiting user approval; test conclusions carry L1–L5 evidence levels, and delivery semantics never exceed the highest evidence. See [Core collaboration principles](#core-collaboration-principles) and `RULE-PROC-*` in [coding-rules.md](references/coding-rules.md).

**6. Personal preferences always rank below framework rules; the skill is read-only except the preference file.**
User preferences (`preferences/user-preferences.md` and `/sdd-custom`) tune only expression style/tone/habits and **never** change gates, tasks-must-code, archiving, evidence levels, or interviews. **Two frozen guards**: ① **precedence guard** — preferences rank below these red lines and all framework rules; conflicting entries are void and ignored at load; `/sdd-custom` **refuses to write** violating preferences (e.g. "skip gates / plan-only / no archiving / bare PASS / always comply"); when the user is factually wrong, **point it out and hold principles — no sycophancy**. ② **read-only guard** — only `preferences/` (and the project's `specs/retro/`) are writable; **SKILL.md/references/assets/scripts are read-only, never modified under any circumstances**; framework changes go through the mother skill's `/sdd-distill`+`/sdd-absorb`+`/sdd-evolve`. See [custom-protocol.md](references/custom-protocol.md).

**7. Language protocol (frozen): implementation in English, interaction in Simplified Chinese.**
This skill's implementation content (SKILL.md body, references/ protocols, scripts) is written in English for AI-execution reliability. But **everything user-facing defaults to Simplified Chinese**: conversation, gate reports, interview questions, all generated project documents (specs/, context/, docs/), and code comments in project code. Language-bound content stays Chinese by design: the Chinese trigger phrases, style-enum names, deliverable templates under `assets/templates/`, and the preference file. ❌ Replying to the user in English, ❌ generating an English spec/design doc for the project (unless the user explicitly asks) — both are errors.

---

## Entry behavior (every time this skill triggers, in order)

0. **Load user preferences**: read `preferences/user-preferences.md` (this skill's only routinely-writable file); apply its style/habits **only where they do not violate the red lines and framework rules**; empty file ⇒ default style = **「专业可靠」**, output language = Chinese. **Any preference conflicting with framework rules is void — ignore it** (precedence below framework, red line 6). If the user typed `/sdd-help` or `/sdd-custom` (or a Chinese equivalent) → run that skill meta-command (see [Command set](#command-set-sdd-)), no project needed.
1. **Read the current state**: read `specs/README.md` and `specs/task.md` first (the cross-session memory base). Neither exists → no cognition yet: **legacy code present** → `/sdd-init` first (Mode B); **brand-new 0→1 project** → enter Mode A from constitution.
1b. **Check the requirement inbox** (F33): look at `docs/requirements/` ([requirement-inbox-protocol.md](references/requirement-inbox-protocol.md)). Non-empty → a pending requirement (an upper-layer dispatch packet or a human-dropped spec): confirm with the user, then **claim it** — register into specs (task.md row + 2-spec entry), archive a copy under this project's specs area (e.g. `specs/2-spec/inputs/`), **then clear it from the inbox** (the emptied inbox tells the upper layer the requirement was received; a pickup signal, not a completion signal).
2. **Routing + command**: confirm ownership per [Domain routing signature](#domain-routing-signature-auto-routing-guard); if an `/sdd-*` command (or Chinese equivalent) was given → jump via [commands.md](references/commands.md); otherwise detect the mode.
3. **Pre-iteration inspection (archive hook + input freshness)**: before starting a new iteration/task, inspect `task.md` and every `current.md`; archive whatever belongs to the previous iteration first (red line 3, specs-lifecycle.md). Also verify every external input copy against its `sources.md` registration (stale → report, re-copy on approval; see the "External input copies" section of specs-lifecycle.md).
4. **Handle docs/**: if `docs/` contains binary documents (xlsx/pdf/docx), textualize first per [docs textualization](#docs-textualization-summary), then cite.
5. **Enter the mode**: Mode A runs the six stages with scenario-clarifying interviews first; Mode B runs the twin workflow.

---

## Command set `/sdd-*`

> Slash commands are hard to memorize; each has **Chinese natural-language equivalents** (frozen, F9) that trigger the same action. Commands are never used before this skill is in context, so the description does not list them — this table is the authoritative reference.

| Command | Chinese equivalents (also trigger it) | Duty | Lands in |
|---|---|---|---|
| `/sdd-init` | 「梳理这个项目」「接手这个老前端项目」「建立项目认知」 | **Build/rebuild project cognition** for legacy code (Mode B); also creates `docs/` + the `docs/requirements/` requirement inbox (F33) | Mode B |
| `/sdd-update` | 「规整工作台」「归档文档」「清理 specs」 | **Workbench maintenance**: inspect & archive `task.md`, every `current.md` | specs lifecycle |
| `/sdd-docs` | 「整理文档」「把 docs 文本化」 | **Docs governance**: inspect `docs/`, textualize as needed, maintain the index | docs adapter |
| `/sdd-iterate` | 「开始新迭代」「实现××功能」「按规格做需求」 | **Forward iteration**: six stages with per-stage gates | Mode A |
| `/sdd-tidy` | 「规整项目目录」「收拾项目结构」「整理目录结构」 | **Structure tidy-up**: gated scan→plan→execute against this domain's `structure.md`; moves/archives only, never deletes, never touches source code (F35) | [tidy-protocol.md](references/tidy-protocol.md) |
| `/sdd-retro` | 「复盘本次对话」「总结这次的教训」「这次做得好记一下」 | **Retrospective**: structure this round's mistakes/wins into `specs/retro/` (reads code only) | retro loop |
| `/sdd-help` | 「怎么用这个 skill」「使用帮助」 | **Onboarding** (skill meta-command): interactive usage guidance, read-only, no workflow started | [help-protocol.md](references/help-protocol.md) |
| `/sdd-custom` | 「设置我的偏好」「记住我的习惯」 | **Personalization** (skill meta-command): interactively set style & habits, written to the only writable preference file | [custom-protocol.md](references/custom-protocol.md) |

> **Two command classes**: **project commands** `/sdd-init|update|docs|iterate|tidy|retro` are handled by this skill only when the current project matches this domain's signature (see routing); **skill meta-commands** `/sdd-help`, `/sdd-custom` are about "how to use this skill / use it my way" — **no project needed, not signature-restricted**. Full definitions: [commands.md](references/commands.md).

### Mode detection rules

- `/sdd-iterate` or 「实现/新增/修改/修复/优化某功能」 → **Mode A**. README missing with legacy code present → suggest `/sdd-init` first; a pure new project starts at constitution.
- `/sdd-init` or 「给项目做文档/接手老项目/梳理代码/生成代码地图」 → **Mode B**.
- `/sdd-update` → workbench maintenance; `/sdd-docs` → docs governance.
- `/sdd-tidy` or 「规整/收拾/整理项目目录结构」 → **structure tidy-up** (gated plan; moves/archives only; see [tidy-protocol.md](references/tidy-protocol.md)).
- `/sdd-retro` or 「复盘这次/总结教训/这次做得好」 → **retro loop**: structured write into `specs/retro/`, reads code without changing it (see [retro-protocol.md](references/retro-protocol.md)).
- Pure tool request → use the tool directly; do not start the full workflow.
- Unsure → ask in one line: 新做/改功能（A），还是把现有代码整理成文档（B）？

---

## Core collaboration principles

> They run through both modes. Understand the why and you will act correctly even where no clause covers it. Details: [collaboration-protocol.md](references/collaboration-protocol.md).

- **Interview first — clarify the scenario before acting**. Web front-end requirements hide heavy implicit context (browser matrix, API contracts, state ownership, i18n scope). Entering a stage, ask 3–5 structured questions (in Chinese) to close the scenario; before it closes, output only clarification questions or drafts. Priority: multiple choice > fill-in with suggested value > confirmation > open question.
- **Plan before code; never write code unauthorized**. Every implementation first outputs a plan (problem understanding, impact scope, files/functions to change, risks, verification) and waits for the user's explicit 同意/实施 (RULE-PROC-01/02).
- **Documentation first**. Code rots; documents are the only persistent cross-session memory. Doc sync at deliver is a hard gate.
- **Iteration-boundary doc gates (mandatory)**. Before a new iteration pass the **entry gate** (read task.md / archive previous iteration / write the new iteration header / check the retro ledger); before delivery pass the **exit gate** (task.md updated + archived / history appended / open-issues closed / retro judgment). See [gate-and-stages.md](references/gate-and-stages.md).
- **Retro & local reuse**. On mistakes or wins run `/sdd-retro` to structure lessons/highlights into `specs/retro/` (no guessed root causes, blameless, record both); check the ledger before related iterations. See [retro-protocol.md](references/retro-protocol.md).
- **Never guess external behavior**. Third-party interfaces / API response shapes / browser-compat range / dependency versions / auth scheme / CORS config require grounding (docs/source/user confirmation); otherwise mark `⚠️ 待确认` and ask — never pad with "usually/by default".
- **Minimal change**. Prefer small diffs reusing existing logic/structure; no incompatible heavyweight dependencies. **Package manager follows engineering facts**: read the lockfile/`packageManager` to identify the real one (legacy follows the existing single lockfile; brand-new defaults to pnpm); never hard-force pnpm or introduce a second lockfile — migration is an explicit, independent decision.
- **Evidence levels; no bare PASS**. Test conclusions carry L1–L5 (see [evidence-gate-protocol.md](references/evidence-gate-protocol.md)); delivery semantics never exceed the highest evidence.
- **Self-check before and after output**. See [self-check.md](references/self-check.md).
- **Transparent progress, no exaggeration**. Before each gate output developed/undeveloped/blocked/next and sync task.md (see [development-progress-protocol.md](references/development-progress-protocol.md)); never call "builds OK" "feature done".
- **Diagrams on demand, focused, text-consistent**. See [diagram-guidelines.md](references/diagram-guidelines.md).
- **Simplified Chinese by default for user-facing output; files UTF-8** (red line 7). Node.js/pnpm/Vite toolchain; write files as UTF-8, confirm before writing.

---

## Mode A: forward spec-driven development

Six stages; on discovering risks/inconsistencies you may flow back to spec/design (announce the reason and sync task.md). **A gate follows every stage — stop and await approval (red line 1).**

```
[project cognition README + context/ + task.md]
        ↓
constitution → spec → design → tasks → test → deliver
     ↑           (every → carries a gate: stop · report · await approval)
     └────────── flow back (risk/inconsistency found) ──────────┘
```

Each stage **produces only its own content**; stop at the boundary. Self-check mantra: *"Which stage does this content belong to? Not this one — move it."*

| Stage | Duty (one line) | Minimal output | Gate keys (details in gate-and-stages.md) |
|---|---|---|---|
| constitution | Project-level engineering constraints, few but binding | `1-constitution/current.md` | generic protocol (decision priority, style-follow, minimal change) + project-specific: **target browsers (default Chrome latest 2 stable), framework version, Node version, build tool, CSS scheme, deployment, forbidden zones**; package manager identified from the lockfile/`packageManager`; conditional capabilities stance (routing / responsive-mobile / observability / i18n: hit→must-do or miss→N/A with reason+confirmer+residual risk) |
| spec | Define the "what", acceptable | `2-spec/current.md` | every requirement has acceptance criteria (testable/observable/evidenced), covers edges/errors (offline / API timeout / empty data / large data / concurrency / insufficient permission / invalid input), evidence caliber explicit (screenshot/screencast/test report/Lighthouse), key clarifies closed |
| design | Define the "how" | `3-design/current.md` | `<pm> install && <pm> build` reproducible; key component interfaces/Props/Events defined; **state classification & selection (RULE-STATE-04)** six categories server/UI/form/flow/persistence/shared; **cache model (RULE-ASYNC-05)** owner + key & freshness + write-path→invalidation-key mapping (if shared/polling/offline/write-then-refresh); **per-request async matrix (RULE-ASYNC-04)**; **API contract boundary graded (RULE-TYPE-04)** stable-internal=types vs external-high-risk=runtime schema; **complexity reviewed (RULE-CMPX)**; conditional capabilities each "design or N/A" (routing/responsive/observability); (if i18n enabled) i18n design (RULE-I18N) |
| tasks | Split tasks **and write the code** | `4-tasks/current.md` | ① plan gated → ② code really implemented & self-verified gated; each task maps acceptance points, tags RULE-*; progress table before gate |
| test | Reproducible tests & evidence | `5-test/current.md` | build/lint/typecheck each **derived** status (P0-02, not a blanket "pass"); unit-test status derived (missing/configured-not-run/ran-but-zero-tests/passed/failed); E2E (Playwright/Cypress) if triggered else N/A; per-request async chain verified line by line (RULE-ASYNC-04); (if i18n) `check_i18n.py` + language-switch regression; API contract exception cases (field missing/type change/error response/non-JSON); every conclusion tagged L1–L5; key-page Lighthouse/axe, thresholds LCP<2.5s/INP<200ms/CLS<0.1, browser = Chrome latest 2 stable; evidence archived |
| deliver | Change/release/rollback | `6-deliver/current.md` | changelog/release-note updated; build-artifact path recorded (hash/version); **deploy strategy executable (CDN/static hosting / Docker image / rollback)**; docs fully synced (README eagle-eye + code map, context/modules + features + environment + architecture + history, and if enabled api-contracts/performance-budget/browser-compat/design-tokens/i18n); task.md archived to `specs/task/` and emptied for the next iteration; semantics within evidence |

### tasks = two phases (follow strictly — the highest-frequency failure point)

- **Phase ① planning**: from design+spec split executable TODOs (each mapping R*/AC*, listing files to change, verification & evidence, RULE-* tags) into `4-tasks/current.md`, with coarse progress reflected in `task.md`. **🚦 Gate ①**: show the list, await plan approval, **no code before approval**.
- **Phase ② execution**: after approval **implement each item with real code, run it, keep evidence**. ⚠️ **Stopping at the plan is an error** — this phase's duty is the code itself. **🚦 Gate ②**: after implementation & self-verification show the evidence, await confirmation before test.
- **Specs-first at every grain (G5) + specs–code pairing (G6)**: any code fix or small increment, no matter how small, first registers in `specs/` (task.md row + spec entry + context mapping updates), then touches business code; before delivery, business-code changes and specs changes must **appear in pairs** (`git status` check) — code-without-specs = incomplete: block, report, backfill the specs (or obtain the user's explicit waiver); never auto-revert — ask the user for disposition.
- **Gate ID vocabulary (universal G1–G6, frozen and identical across every sdd-xx)**: G1 stage responsibility boundary · G2 archiving discipline · G3 evidence grading · G4 progress transparency · G5 specs-first at every grain · G6 claim↔git pairing. In daily terms: any code fix or small increment, no matter how small, first registers in `specs/` (task.md row + spec entry + context mapping) and only then touches business code, and every business-code change pairs with a specs change (G5); before delivery `git status` must also match what the delivery claims (G6) — code-without-specs or claim-without-change = incomplete: block, report, backfill (or obtain the user's explicit waiver); never auto-revert — ask the user for disposition. Definitions and enforcement points: [gate-and-stages.md](references/gate-and-stages.md) §Gate numbering namespace. **This skill's own domain gates take the `FE` prefix and never consume a `G` number.**

### `task.md` vs `4-tasks/` (red line 4 expanded)

- **`task.md`** = global command deck: maintained for **any** task (iteration/bugfix/docs/context rebuild), coarse-grained checklist, cross-iteration, user-visible.
- **`4-tasks/current.md`** = single-iteration construction plan: used **only** in six-stage iterations, fine-grained split & tracking.
- ✅ "rebuild context/" → update task.md only, **no 4-tasks**.　✅ "add feature X per spec" → coarse progress in task.md **and** fine split in 4-tasks.
- ❌ Stuffing T1.1/T1.2 sub-tasks into task.md.　❌ Creating 4-tasks for a non-six-stage task. Details: [task-kanban-protocol.md](references/task-kanban-protocol.md).

Per-stage detailed requirements, interview examples, recommended diagrams, self-checks: **[gate-and-stages.md](references/gate-and-stages.md)**; coding rules: **[coding-rules.md](references/coding-rules.md)**.

---

## Mode B: code → cognition layer (incl. code twin)

Goal: reverse legacy front-end code + scattered materials into a structured **`specs/context/` cognition layer**, used to reverse-derive SRS/high-level/detailed designs/test cases and to ground later iterations. **`context/` is a bridge, not a destination; success = "can it support downstream doc completion", not specs/ size.** The code twin (modules/architecture/data-model) is one layer and stays; the code graph is an **optional aid**, not the core.

`context/` is organized in **five layers: project cognition / architecture / modules / scenarios / evidence** (not a flat mirror of source dirs). Twin granularity still lands as L0–L4 (details: [mode-b-twin.md](references/mode-b-twin.md)): L0 `README.md` / L1 `context/architecture.md` / L2 `context/modules.md` / L3 per-component/function entries within modules / L4 `context/code-map.md` (**optional** source index, madge / ts-morph / @vue/compiler-sfc or AI manual). **The scenario layer `context/scenarios/` is a first-class citizen** — cross-module business chains (a page's data flow, a form's submit path) get their own files.

**Three iron rules (inlined)**: ① **document purity** — `context/` records only closed facts; doubts/conflicts go to `specs/open-issues.md` (global governance inbox); in-flight work goes to `task.md`; never mixed. ② **no guessing** — on material-vs-source conflict write per source and log the divergence in open-issues; never pad with "usually/should/by convention"; record evidence provenance in `context/evidence-trace.md`. ③ **machine artifacts separated** — auto indexes to `_generated/`, scripts to `_tools/`, never inside `context/`.

**Workflow summary**: ① detect encoding (UTF-8; front-end sources are UTF-8, watch for BOM/CRLF) ② structure scan (optionally generate the source index) ③ write cognition L0→L3 layer by layer, tagging evidence strength per entry (statically visible / corroborated / runtime-verified) ④ map scenario chains ⑤ coverage self-check ⑥ confirm with the user ⑦ incremental sync. Full standard: **[mode-b-twin.md](references/mode-b-twin.md)**.

**Reverse-deriving upstream docs (detailed design / high-level design / SRS drafts)**: the cognition layer can further reverse-derive the missing upstream docs of a legacy project, landing in `docs/reverse/*.draft.md` (isolated from the forward six stages, pending human confirmation). **First principle (inlined red line)**: reverse-derivation power **decays by nature** (detailed design > high-level design > SRS); **source usually lacks complete requirement scenarios / non-functional thresholds / business motivation / acceptance criteria, so a "complete SRS" cannot be reverse-derived**. Handle by reachability: derivable → write directly; partially derivable → emit `[草稿:]`; **non-derivable → emit only `[待澄清:]`/`[缺口:]`, never guess**, each linked to `open-issues.md`. With gaps present **never call it a "complete SRS"** — call it 草稿（含 N 处待澄清/缺口）. Full protocol: **[mode-b-reverse.md](references/mode-b-reverse.md)**.

---

## specs lifecycle & archiving discipline (summary)

`specs/` is the project's long-term memory: "workbench current / history separated", auto-archived by hooks at key moments. **Iron rule: never overwrite or delete — archive first, then write** (red line 3). Every `current.md` and `task.md` carries a three-field date header `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->`, whose `状态` holds exactly one value of the frozen set (`就绪` / `进行中` / `已交付待归档`) defined in specs-lifecycle.md §3 — never an inline enumeration, since `|` is the field separator. Archive destinations: `task.md` → `specs/task/`; stages → `<stage>/history/`. External input copies are registered in `sources.md` and freshness-checked before consumption. Full mechanism: **[specs-lifecycle.md](references/specs-lifecycle.md)**.

---

## docs textualization (summary)

`docs/` holds the user's original input documents (SRS, UI design notes, API docs — often xlsx/pdf/docx). Textualization is driven by `/sdd-docs`, **following the contract of [docs-binarification-adapter.md](references/docs-binarification-adapter.md), currently carried by the zero-dependency `scripts/xlsx_to_csv.py` (xlsx→CSV) plus the built-in pdf/docx skills**. Products go to `docs/converted/`, and the reference index in `specs/README.md` records both the original path and the converted path. **The converter is infrastructure-dependent and swappable** — changes touch the adapter file only.

---

## Project cognition base (shared by both modes)

| File | Role | When to read |
|---|---|---|
| `specs/README.md` | Project-wide view & module/code index | every session start, mandatory |
| `specs/context/*` | Detailed cognition (features/architecture/data-model/state-model/modules/scenarios/evidence-trace/code-map/knowledge-map, plus on-demand api-contracts/performance-budget/browser-compat/design-tokens/i18n) | as needed |
| `specs/context/scenarios/` | Scenario chains (cross-module, first-class) | mandatory for cross-module work |
| `specs/context/knowledge-map.md` | Knowledge map (navigation console: topic → where to look) | when unsure which file to read |
| `specs/open-issues.md` | Global governance inbox: doubts/conflicts/to-verify (purity rule) | before Mode B reverse work & deliver |
| `specs/task.md` | Global task kanban | step 2 of every session; updated throughout |
| `specs/task/` | task.md archive directory | archive on task/iteration switch |
| `specs/retro/` | Retro ledger + topic files (lessons/wins; local reuse & harvest) | check before related iterations; write during retro |
| `specs/_generated/`, `specs/_tools/` | Machine index products / project scripts (rebuildable, discardable) | aids only, never a source of truth |

task.md protocol: [task-kanban-protocol.md](references/task-kanban-protocol.md).

---

## Tools & runtime environment

Node.js + pnpm (or the project's real package manager) + Vite toolchain; parsers madge / ts-morph / @vue/compiler-sfc are optional aids. Tools follow **capability detection + degradation**: zero-dependency first → script fallback → AI manual.

| Task | Preferred | Fallback |
|---|---|---|
| Initialize specs/ skeleton | AI creates files directly | `scripts/init-spec.{sh,ps1,mjs}` |
| Detect the current stage | list directories, judge manually | `scripts/detect-phase.{sh,ps1}` |
| Generate the source index (optional) | madge / ts-morph / @vue/compiler-sfc / `assets/tools/build_source_index.py` | AI builds it manually per code-map convention (equivalent) |
| Derive test-Gate status | `assets/tools/derive_gate_status.py` (from package.json/lockfile/exit code/tests found) | AI derives manually per evidence facts |
| i18n consistency check | `assets/tools/check_i18n.py` (zero-dependency) | AI checks keys/params/switch residue manually |
| docs textualization | `scripts/xlsx_to_csv.py` (xlsx) / pdf/docx skills | AI implements per adapter contract |

Details: [environment-and-tools.md](references/environment-and-tools.md).

---

## Rigid coding rules (summary)

Applied against design / tasks / test; full text with anti/good examples in **[coding-rules.md](references/coding-rules.md)**.

- **RULE-STATE** — state six-category classification (server / UI / form / flow / persistence / shared) + dependency-signal-driven selection (RULE-STATE-04); choosing native over a library must justify the four-state/race/cache-identity/dedup/cleanup edges.
- **RULE-RENDER** — keys, list stability, controlled/uncontrolled, effect discipline, avoid derived-state duplication.
- **RULE-ASYNC** — per-request state matrix idle/loading/success-nonempty/success-empty/error/stale-refresh-fail/cancel (RULE-ASYNC-04); cache domain model owner/key/**write-path→invalidation mapping**/focus-poll-resume sync/concurrent write (RULE-ASYNC-05); commands include dedup.
- **RULE-TYPE** — strictness; API contract boundary grading (RULE-TYPE-04): stable-internal=types/generated vs external-high-risk=runtime schema + non-JSON/exception branches; declared drift check.
- **RULE-A11Y** — semantic HTML, keyboard, focus, ARIA, WCAG/axe as a first-class constraint.
- **RULE-PERF** — Core Web Vitals budget (LCP<2.5s/INP<200ms/CLS<0.1), bundle-size ceiling, code-splitting, no premature optimization.
- **RULE-SEC** — XSS / `dangerouslySetInnerHTML` / `v-html` discipline, token storage, CORS/CSRF, dependency audit.
- **RULE-STYLE** — style isolation (CSS Modules / scoped / token scheme), naming, no global leakage.
- **RULE-I18N** — (conditional quality domain) resource ownership / dynamic text / interpolation & plural / locale formatting / switch regression; single-language ⇒ N/A.
- **RULE-CMPX** — component/form/table complexity trigger-based review (by responsibility coupling & interaction complexity signals, not line count): split or adopt a library and record the trade-off.
- **RULE-PROC** — process rules: plan before code (PROC-01), no unauthorized coding (PROC-02), no guessing external behavior, no bare PASS.

**Conditional capabilities & the N/A mechanism**: routing / responsive-mobile / observability / i18n are enabled by trigger conditions; when a trigger is not hit, mark **N/A with three elements (reason + confirmer + residual risk)** — never fake-check and never over-engineer a single-shell SPA with unneeded routing/mobile/monitoring.

> **React/Vue best-practice ideas** are indexed separately in [frontend-best-practices.md](references/frontend-best-practices.md) — a **non-gate, trimmable, non-mandatory** reference orientation that always yields to RULE-* and existing project constraints.

---

## References & templates

| Document | Content |
|---|---|
| [collaboration-protocol.md](references/collaboration-protocol.md) | interview templates, gate ceremony, unified self-check entry |
| [commands.md](references/commands.md) | `/sdd-*` command set + Chinese equivalents + routing signature |
| [help-protocol.md](references/help-protocol.md) | `/sdd-help` interactive onboarding protocol (skill meta-command, no info-dumping) |
| [custom-protocol.md](references/custom-protocol.md) | `/sdd-custom` preference mechanism + style enum + precedence/read-only double guard |
| [specs-lifecycle.md](references/specs-lifecycle.md) | **must-read**: specs domain model, lifecycle, archive hooks, external input copies |
| [gate-and-stages.md](references/gate-and-stages.md) | Mode A per-stage requirements (two-phase tasks, per-stage gates, entry/exit gates, G5/G6) |
| [task-kanban-protocol.md](references/task-kanban-protocol.md) | task.md global kanban vs 4-tasks (pro/anti examples) |
| [mode-b-twin.md](references/mode-b-twin.md) | Mode B cognition five layers, purity, scenarios, evidence strength, optional source index, downstream mapping |
| [mode-b-reverse.md](references/mode-b-reverse.md) | Mode B upstream reverse-derivation: reachability, gap markers, completeness declaration, self-check (no guessing) |
| [retro-protocol.md](references/retro-protocol.md) | retrospectives: `/sdd-retro` + `specs/retro/`, schema, local reuse, harvest, domain seeds |
| [coding-rules.md](references/coding-rules.md) | all RULE-* rigid coding rules (STATE/RENDER/ASYNC/TYPE/A11Y/PERF/SEC/STYLE/I18N/CMPX/PROC) + conditional capabilities & N/A |
| [frontend-best-practices.md](references/frontend-best-practices.md) | **React/Vue best-practice ideas (non-gate · trimmable · non-mandatory)** reference orientation |
| [evidence-gate-protocol.md](references/evidence-gate-protocol.md) | L1–L5 evidence levels (Web wording) & deliver release constraint |
| [self-check.md](references/self-check.md) | pre-output chain-of-thought + post-output checklist |
| [diagram-guidelines.md](references/diagram-guidelines.md) | diagram guidelines + per-stage examples (component tree / data flow / state machine) |
| [knowledge-map.md](references/knowledge-map.md) | knowledge map purpose, format, maintenance |
| [code-map.md](references/code-map.md) | source coverage index (madge / ts-morph / @vue parsers + script + AI fallback) |
| [detection.md](references/detection.md) | mode & stage detection (incl. routing signatures, task.md pre-check) |
| [structure.md](references/structure.md) | specs/ & docs/ standard layout and naming (incl. task.md, on-demand context, docs/requirements) |
| [requirement-inbox-protocol.md](references/requirement-inbox-protocol.md) | `docs/requirements/` requirement inbox: claim = register → archive a copy → clear (F33) |
| [tidy-protocol.md](references/tidy-protocol.md) | `/sdd-tidy` structure tidy-up: gated scan→plan→execute, never delete, never touch source (F35) |
| [development-progress-protocol.md](references/development-progress-protocol.md) | progress clarification (developed/undeveloped/blocked/next) |
| [troubleshooting.md](references/troubleshooting.md) | Web front-end troubleshooting + Chinese/long-path direct-creation-first |
| [environment-and-tools.md](references/environment-and-tools.md) | capability detection & degradation; versioned baseline table; package-manager identification |
| [docs-binarification-adapter.md](references/docs-binarification-adapter.md) | docs textualization contract + current implementation (swappable) |
| [document-tools.md](references/document-tools.md) | docs/ handling & document-conversion tool usage |
| [web-frontend-checklist.md](references/web-frontend-checklist.md) | Web front-end checklist (browser compat / performance / accessibility / security / SEO) |

Templates in `assets/templates/` (kept in Chinese — they seed Chinese deliverables): the six stage current.md files (with date headers), global task.md + task-archive.md, knowledge map, project README, context-* (including api-contracts/state-model/performance-budget/browser-compat/design-tokens/i18n), reverse drafts, retro ledger, sources.md. Zero-dependency tools live in `assets/tools/` and `scripts/`.
