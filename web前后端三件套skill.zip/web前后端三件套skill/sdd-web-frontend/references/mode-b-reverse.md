# Mode B: Reverse-Deriving Upstream Documents from the Cognition Layer (Detailed Design / High-Level Design / SRS Drafts)

> This is the **upstream extension** of the cognition layer: taking the `specs/context/` cognition layer and further reverse-deriving it into the **detailed design, high-level design, and SRS** drafts that a legacy project is missing.
>
> **First principle (frozen · must-know)**: source code's power to reverse-derive upstream documents **naturally decreases** — detailed design > high-level design > SRS. **Source code usually does not contain complete requirement scenarios, non-functional thresholds, business motivations, or acceptance criteria, so source code cannot reverse-derive a "complete SRS" (完整需求规格书).** Reverse-derived artifacts **must honestly mark their gaps, provide placeholders/drafts, and never guess**.

## 1. Outputs and placement
Reverse-derived artifacts are **reverse drafts, pending human confirmation**. They all land in `docs/reverse/`, **isolated** from the forward six-stage workbench (`2-spec/`, `3-design/`) to avoid polluting the forward source of truth (per the language protocol, the generated drafts themselves are written in Simplified Chinese):
```
docs/reverse/
  README.md                  ← index + reverse-derivation date + overall reachability distribution + open gap count
  detailed-design.draft.md   ← detailed design draft (mainly from context/modules*, code-map)
  high-level-design.draft.md ← high-level design draft (mainly from architecture/data-model/state-model/scenarios)
  srs.draft.md               ← SRS draft (Requirement+Scenario; must contain a gap list)
```
> File names always carry `.draft`; every file header carries a "reverse-derivation completeness declaration" (§4). If a requirements baseline is introduced later, these may serve as seeds for `spec-baseline/`, but **an unconfirmed draft must never be treated as the source of truth**.

## 2. Reverse-derivation mapping (context → upstream documents, continuing mode-b-twin §9)

| Upstream document | Main context inputs it relies on | Reverse-derivation nature |
|---|---|---|
| Detailed design | `modules/*.md`, key interfaces/types/data structures, code-map | Mostly **derivable** |
| High-level design | `architecture.md`, `data-model.md`, `state-model.md`, `modules.md`, `scenarios/*.md` | Structure **derivable**; intent/trade-offs **partially derivable** |
| SRS | `features.md`, `domain-model.md`, `scenarios/*.md`, `evidence-trace.md`, `open-issues.md` | Feature skeleton **partially derivable**; complete scenarios/non-functional/acceptance **non-derivable** |

## 3. Three reachability levels of reverse-derivation (frozen · the core honesty mechanism)
Judge the reachability of **every section** of a reverse-derived document, and take the corresponding action:

| Reachability | Typical content | Action |
|---|---|---|
| **Derivable** (source suffices) | Most of the detailed design; the high-level design's structure/interfaces/data flow/module split | Write it directly, labeling evidence strength (静态可见/资料互证) |
| **Partially derivable** (needs material corroboration) | The high-level design's intent/trade-offs; the **skeleton** of the SRS's functional requirements | Produce a **draft**; hang gap markers wherever materials are missing |
| **Non-derivable** (source inherently lacks it) | The SRS's **complete requirement scenarios, non-functional thresholds, business motivations, acceptance criteria** | **Placeholders/gap markers only — guessing is forbidden** |

**This domain's (Web front-end) section reachability** (confirmed in S6):

| Upstream section | Domain reachability |
|---|---|
| Component tree / component responsibility and Props interface | derivable |
| Routing table / guards / lazy loading | derivable |
| Global state structure / state flow | derivable |
| Backend API call contracts (endpoint/method/request·response types) | derivable (response semantics partly need cross-checking with materials) |
| Build config (Vite/tsconfig/aliases/env variables) | derivable |
| Interaction-flow completeness / boundary-handling intent | partially derivable (needs PRD/design-draft corroboration) |
| Source of the performance budget (e.g. the basis for "first screen ≤2s") | partially derivable → mostly a gap |
| Complete business requirement scenarios / acceptance criteria | **non-derivable** (mark `[缺口]`) |
| Non-functional thresholds / product motivation | **non-derivable** (mark `[缺口]`) |

## 4. Gap markers + reverse-derivation completeness declaration (frozen)
**Gap markers** (written into the body of reverse-derived documents; each occurrence is also filed in `specs/open-issues.md`):
```text
[待澄清: <specific question>]   ← source cannot answer it; must confirm with the user/materials (= Spec Kit's NEEDS CLARIFICATION)
[草稿: <initial wording based on source>]   ← source supports a first draft; pending human confirmation
[假设: <assumption + explicit basis, e.g. src/api/auth.ts:30>]   ← use only with an explicit basis, which must be cited
[缺口: <source inherently lacks this kind of information>]   ← structural gap; fabrication forbidden (e.g. complete business operating scenarios, acceptance criteria)
```
**Reverse-derivation completeness declaration** (at the head of every reverse-derived document, borrowing Superpowers' "verification as honesty + output provenance"; written verbatim in Simplified Chinese in generated documents):
```markdown
<!-- 反推完整度声明
来源: <哪些 context 文档 + 证据强度>
可达性分布: 可反推 N 节 / 部分 M 节 / 不可反推 K 节
未闭合缺口: <待澄清 a 处, 缺口 b 处> → 见 open-issues
产出溯源: 逆向草稿 · 未经人类确认 · 不得当真相源
-->
```
(Gloss: 来源 = which context docs + evidence strength; 可达性分布 = derivable N sections / partial M / non-derivable K; 未闭合缺口 = a clarifications pending, b gaps → see open-issues; 产出溯源 = reverse draft · not human-confirmed · must not be treated as the source of truth.)

## 5. Reverse-derivation red lines (anti-rationalization · frozen)
- **No guessing**: at non-derivable spots give only `[缺口]/[待澄清]`; never fabricate requirements, scenarios, thresholds, or acceptance criteria with 「通常/应该/按经验」 ("usually / should / by experience").
- **No deleting markers to slip through**: never delete gap markers, and never use smooth prose to make a gap read like a seemingly complete requirement.
- **No inflated claims**: while gaps remain, it is **forbidden to call the artifact a 「完整需求规格书」** (complete SRS); it must be phrased as 「需求规格书**草稿**（含 N 处待澄清/缺口）」 (SRS **draft**, with N clarifications/gaps pending).
- When materials conflict with source code, write per the source and file the divergence in `open-issues.md`.

## 6. Reverse-derivation consistency self-check (read-only · frozen, borrowing Spec Kit's /analyze idea)
Before delivering a reverse draft, cross-check item by item (do not modify context; read-only comparison):
- Every component/function/interface in the detailed design — can a counterpart be found in `context/modules*` or the code-map? If not → mark `[待澄清]`; do not fabricate one.
- The data flows/data models/state flow in the high-level design — traceable back to `architecture.md`/`data-model.md`/`state-model.md`?
- Every Requirement in the SRS draft — traceable to some scenario or source-code behavior? A purely inferred requirement → must be marked `[缺口]`.
- Do the completeness declaration's "reachability distribution / open gaps" match the marker counts in the body?

## 7. Interfacing with Mode A / other documents
Once a reverse draft has been user-confirmed and its gaps closed, it can serve as input to the forward spec/design or as the seed of a future requirements baseline; **before confirmation it is only a draft**. Whenever a Mode A deliver round changes the implementation, the affected reverse drafts are simultaneously marked 「需复核」 ("needs re-review").
