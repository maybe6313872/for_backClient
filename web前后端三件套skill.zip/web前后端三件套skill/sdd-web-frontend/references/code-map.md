# Code Map / Source Coverage Index (Optional)

> **An optional auxiliary tool — not a prerequisite for Mode B, and not an arbiter of facts.** The core of Mode B is the `specs/context/` cognition layer; this index only helps the AI inventory source files, entry points, dependencies, and potential omissions. **Its purpose and how to read it are frozen by the framework; how it is generated (the parser) is a domain slot.** Name the directory `source-index`; do not default to `code-graph`.

## 1. It answers only three questions
1. Which source files / entry points / components / symbols / dependencies exist in the project;
2. Which source objects are already covered by `context/`, and which may have been missed (the "denominator" of the coverage self-check);
3. Which source evidence to revisit when reverse-deriving a given component/scenario.

Interactive graphs, graph databases, HTML workbenches, and MCP services beyond these three questions **do not enter this framework's default practice**.

## 2. Generation (Web · capability detection + degradation, consistent with environment-and-tools.md)
- **Preferred ecosystem tools**:
  - `madge` (dependency graph / circular dependencies): `npx madge --json src` → dependency relationships
  - `ts-morph` (TS/TSX AST): parse components, exported symbols, types, function signatures
  - `@vue/compiler-sfc` (Vue SFC): parse the script/template/style blocks and component interface of `.vue` files
- **Second choice — script**: the bundled zero-dependency `assets/tools/build_source_index.py` (copy it into the project's `specs/_tools/` and run; scanning `.ts .tsx .js .jsx .vue .scss`; output lands in `specs/_generated/source-index/`).
- **Fallback**: with no Node/Python tools available, **the AI builds it manually per §4**, with equivalent effect.
> Hard boundaries: ① optional — Mode B works fine without tools; ② lightweight — JSON/Markdown, no SQLite; ③ does not arbitrate facts; ④ machine artifacts go into `_generated/` and are never mixed into `context/`.

## 3. Reading the output (the Web index contains)
- File inventory (layered by `src/`: pages/components/hooks|composables/services/stores/router/utils);
- Component/symbol index (name / file / location / Props or exported signature);
- import dependency relationships, circular-dependency warnings;
- Entry-point leads (`main.ts`/`main.tsx`, `App.vue`/`App.tsx`, `vite.config.*`, route registration sites);
- Route index (path → component), API endpoint index (service function → URL/method);
- Coverage hints (which files/components do not appear in `context/`).

## 4. Manual fallback
When the script cannot run, the AI builds a lean inventory while reading, structured as "file → external components/exported symbols → import dependencies"; covering the external component interfaces (Props/Emits) and the logic-bearing hooks/services is enough — trivial private helpers may be skipped. At the same time, manually list the "possibly uncovered files" to serve as the denominator.

## 5. Maintenance
Update incrementally as the code changes (see mode-b-twin.md §10): re-run/re-scan → diff → update only the affected components/scenarios → record in history. The index can be rebuilt or discarded at any time and should never become a long-term maintenance burden.
