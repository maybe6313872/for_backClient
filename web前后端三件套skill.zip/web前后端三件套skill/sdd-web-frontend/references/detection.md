# Mode & Stage Detection Logic

> Two detection layers: first **which mode** (forward development / code-doc twin), then within Mode A **which stage**. Do the **routing decision** first (does this project belong to this domain — see the SKILL.md routing section).

## 0. Routing + mode detection (do first)

**Routing**: scan the project for fingerprint files **`package.json` + `vite.config.{ts,js,mjs}` + a `react` or `vue` dependency + `tsconfig.json`**. Match ⇒ this skill takes over; another domain ⇒ politely hand over; no/multiple matches ⇒ ask the user.

This domain focuses on browser-side SPAs locked to **React / Vue + TypeScript + SCSS + Vite**. When Svelte / Next.js / Nuxt.js / Astro / SolidJS / Electron / Webpack / SSR-SSG fingerprints match, **do not claim** the project — tell the user this skill does not cover that shape.

**Mode** (after the domain matches). Chinese natural-language equivalents count exactly like their commands (F9):

| Signal | Decision |
|---|---|
| `/sdd-iterate`, or 「开始新迭代」「实现/新增/修改/修复/优化某功能」「按这个需求做」 | **Mode A** (six stages) |
| `/sdd-init`, or 「梳理这个项目」「接手这个老项目」「给项目做文档」「生成代码地图」 | **Mode B** (code-doc twin) |
| `/sdd-update`, or 「规整工作台」「归档文档」 | workbench maintenance (pre-iteration inspection hook) |
| `/sdd-docs`, or 「整理文档」「把 docs 文本化」 | docs governance & textualization |
| `/sdd-tidy`, or 「规整项目目录」「收拾项目结构」「整理目录结构」 | structure tidy-up (gated plan; moves/archives only, never deletes — see tidy-protocol.md) |
| `/sdd-retro`, or 「复盘本次对话」「总结这次的教训」 | retro loop (write `specs/retro/` only) |
| `/sdd-help`, `/sdd-custom`, or 「怎么用这个 skill」「设置我的偏好」 | **skill meta-commands**: no fingerprint scan, work without a project (help = interactive usage; custom = personal preferences). Multiple sdd-xx installed & ownership unclear → ask in one line |
| Pure tool request | use the tool directly, no full workflow |
| Mode A but `specs/README.md` missing, legacy code present | run Mode B first (`/sdd-init`), then back to Mode A |
| Mode A but README missing, brand-new 0→1 project | enter Mode A directly from constitution |
| Undecidable | ask in one line: 新做/改功能（A），还是把现有代码整理成文档（B）？ |

`specs/README.md` and `specs/task.md` are the shared memory base of both modes — read them at every session start.

## 1. Stage detection (inside Mode A)

Fixed-order detection, README first:
1. `specs/README.md` missing → prompt "project cognition must be built first"
2. constitution → enter if not ready
3. spec → 4. design → 5. tasks → 6. test → 7. deliver (in order; enter the first not-ready stage)
8. All ready → complete

**Readiness**: the stage directory contains `current.md` or any substantive `.md`. design counts as ready in any of `preliminary/`, `overall/`, `detailed/`.

**Hollow state (not "stage not entered")**: a stage directory holding a `history/` but no `current.md` is **not** evidence that the stage was never entered — it is a hollow state left by an incomplete archive. Report and repair it per specs-lifecycle.md §4 **before** inferring the current stage, and never conclude from it that the stage's work must be redone.

**task.md pre-check**: if `specs/task.md` exists, prefer the stage status it records — locate the stage marked `🔄 active`; if none is marked active, fall back to file-existence detection and reconcile any mismatch in favor of task.md, then backfill the missing files.

**Fallback**: AI lists `specs/` directly and matches the table above on each stage's `current.md` existence and substance to conclude the current stage.
