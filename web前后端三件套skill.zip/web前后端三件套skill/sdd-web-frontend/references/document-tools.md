# Document Tools and Auxiliary Commands

> **Script location convention (the only one)**: Scripts shipped with the skill live in the skill package's `scripts/` (init/detect/document conversion) and `assets/tools/` (lifecycle/Gate/i18n checks). `/sdd-init` can copy the deterministic check tools into the project's `specs/_tools/` for in-place execution — the paths `assets/tools/xxx.py` and `specs/_tools/xxx.py` are **equivalent**. All `*.py` are **zero-dependency (Python standard library)**; no `pip install` needed.

## Phase Detection

Use the `detect-phase` script to automatically detect the SDD phase the project is currently in (phase directories = 1-constitution / 2-spec / 3-design / 4-tasks / 5-test / 6-deliver).

### Windows PowerShell 5.1 (powershell.exe)
```powershell
powershell.exe -ExecutionPolicy Bypass -File .\scripts\detect-phase.ps1
powershell.exe -ExecutionPolicy Bypass -File .\scripts\detect-phase.ps1 -Json
```
> `.ps1` is saved as **UTF-8 with BOM**, ensuring Windows PowerShell 5.1 parses Chinese correctly (the script already forces UTF-8 output).

### PowerShell 7+ (pwsh)
```powershell
pwsh -File ./scripts/detect-phase.ps1
pwsh -File ./scripts/detect-phase.ps1 -Json
```

### Bash (Linux / macOS / WSL)
```bash
bash scripts/detect-phase.sh
bash scripts/detect-phase.sh --json
```

## Project Initialization

Use the `init-spec` script to initialize the specs/ directory structure.

### PowerShell
```powershell
# Basic initialization
.\scripts\init-spec.ps1

# Specify root directory
.\scripts\init-spec.ps1 -Root "C:\projects\my-app"

# Include template files
.\scripts\init-spec.ps1 -WithTemplates

# Include optional context files
.\scripts\init-spec.ps1 -WithOptional
```

### Bash
```bash
# Basic initialization
bash scripts/init-spec.sh

# Specify root directory
bash scripts/init-spec.sh --root /path/to/project

# Include template files
bash scripts/init-spec.sh --with-templates

# Include optional context files
bash scripts/init-spec.sh --with-optional
```

### Node.js (cross-platform)
```bash
node scripts/init-spec.mjs
node scripts/init-spec.mjs --root /path/to/project
node scripts/init-spec.mjs --with-templates --with-optional
```

## Document Templates

Template files live in the `assets/templates/` directory; during initialization you can choose whether to copy them into the project.

Template list:
- `readme-project.md` — project cognition document template
- `task.md` — progress kanban template
- `task-archive.md` — archiving **convention note** template only (explains how archiving works and points at the archive root); it is **never** an archive destination — every iteration's `task.md` archives as its own file under `specs/task/YYYY-MM-DD-<说明>.md` (task-kanban-protocol.md §4)
- `constitution.current.md` — constitution template
- `spec.current.md` — requirement spec template
- `design.current.md` — design outline template
- `design.overall.current.md` — overall design template
- `design.detailed.current.md` — detailed design template
- `tasks.current.md` — task list template
- `test.current.md` — test document template
- `deliver.current.md` — delivery document template
- `context-*.md` — templates for each context file (including `context-i18n.md`)

## docs Binary-to-Text Conversion (xlsx → CSV)

`scripts/xlsx_to_csv.py` (zero-dependency, Python standard library only; contract in [docs-binarification-adapter.md](docs-binarification-adapter.md)):

```bash
# One workbook to one CSV (split by sheet); default output docs/converted/<workbook-name>/
python scripts/xlsx_to_csv.py "docs/需求规格书.xlsx"

# Specify output directory
python scripts/xlsx_to_csv.py "docs/需求规格书.xlsx" --output-dir "docs/converted/需求规格书"
```
The output is UTF-8 (with BOM) CSV, convenient to open directly in Excel. **No `pip install` needed.** pdf/docx go through the built-in pdf/docx skills.

## Deterministic Check Tools (Gate Backstop · Zero-Dependency)

| Tool | Purpose | Usage |
|---|---|---|
| `assets/tools/derive_gate_status.py` | Derive the real test Gate status from package.json + lockfile (P0-02) | `python .../derive_gate_status.py --root . [--ran run.json]` |
| `assets/tools/check_i18n.py` | i18n consistency (missing keys/params/orphans/hardcoding, P1-07) | `python .../check_i18n.py --root .` |
| `assets/tools/check_iteration_docs.py` | Iteration boundary/lifecycle discipline (archiving/tidiness, P1-11) | `python .../check_iteration_docs.py --root .` |

When Python is unavailable, verify manually against each corresponding Gate item; the criteria are identical (capability probe + graceful degradation, see environment-and-tools.md).
