# Evidence Levels and Delivery Gate Protocol

> Goal: fix the problem of build pass / unit-test pass / integration pass all being blurred into a bare `PASS`. **The ladder — its five level names AND their order — is frozen by the framework and is identical in every sdd-xx. Exactly one column is tuned per domain: "Domain evidence", filled here with the Web front-end's proofs.**

## 1. L1–L5 evidence levels (frozen ladder · the domain-evidence column is the only slot)

| Level | Name (frozen, language-bound) | Domain evidence (Web front-end) | May claim (frozen) |
|---|---|---|---|
| L1 | 构建通过/静态可见 | component/type/route exists, `tsc` / `vue-tsc` type check has no errors; `pnpm build` passes, artifact hash is reproducible, `pnpm lint` has no errors; consistent with `spec` / `design` / the API contract document, diff/review passed (a **precondition** of L1, not a rung of its own) | it builds; the artifact/structure exists and is type-self-consistent |
| L2 | 单元测试通过 | Vitest/Jest unit tests pass with a discovered count > 0 — pure logic, hooks/composables, stores/reducers, utils and formatters | the unit-level logic is verified by executable tests |
| L3 | 受控集成通过 | the full flow runs against a mock server (MSW / mock API); Playwright/Cypress E2E pass on the core paths, local run screenshot/recording | the components integrate and behave correctly in a controlled environment |
| L4 | 预生产环境验证 | pre-release build deployed to staging/pre-production, verified against the target browser-compatibility matrix + real-device regression, smoke run on the pre-production URL | it passes in a near-real environment |
| L5 | 生产环境验证 | production ramp-up with Lighthouse / axe accessibility thresholds met on production URLs; CI pipeline report plus RUM / error-monitoring records from real traffic | it passes in the real production environment |

> **Single source of truth (frozen)**: this table is the **only** definition of the L1–L5 ladder. No other file — in this skill or in any skill that consumes its reports — may restate the ladder as an inline shorthand, an abbreviated list, or a parenthetical gloss (e.g. "L1 build / L2 review / L4 joint debugging"). A shorthand that drifts is indistinguishable from a redefinition, and readers obey whichever copy they hit first. Where another document must mention the ladder, it **links here** and names levels by ID only.
>
> **Frozen items (never changed by a child skill)**: the five level **names**, their **order**, and the "May claim" column. The five names are Chinese language-bound literals (F32) and are reproduced byte for byte; translating them is a violation, not a localisation. A child skill that wants different wording has misread the slot — the slot is the **Domain evidence** column, nothing else.
>
> **Why frozen**: orchestration-class skills (F34) aggregate the L values reported by every sub-project into one checkpoint table **with no conversion layer**. A per-domain ladder makes `L3` mean "it builds" in one sub-project and "front and back are integrated" in another, systematically overstating readiness and breaking the deliver exit gate.
>
> **Review/lint is not a level.** Static review, lint and diff review are a **mandatory precondition of L1**, not a rung: a reviewed-but-unbuilt change claims nothing. Do not re-introduce a "review passed" level under any number.
>
> **Domain evidence may not weaken a level.** Each **Domain evidence** cell lists what *this domain* accepts as proof **of that level's frozen meaning**; it may not redefine the meaning. Filling L3 with "the build passes" is a violation — that is L1 evidence.
>
> **Mode B is a separate system — see §5 and the Mode B annotation clause later in this file (the "do not reuse the L1–L5 numbers" constraint).** Mode B conclusions use the textual strength labels 静态可见 / 资料互证 / 运行佐证 and **never** reuse the L1–L5 numbers. That clause is unchanged by this section and is not superseded by the table above; the two annotation systems stay disjoint.

---

## 2. deliver semantic constraints (frozen)

| Highest evidence | Allowed delivery semantics | Forbidden semantics |
|---|---|---|
| L1/L2 | development draft, candidate for testing | formal delivery, releasable |
| L3 | interim reference package | field-stable, batch release |
| L4 | test-passed candidate package | no monitoring needed, finally complete |
| L5 | releasable delivery package | — |

---

## 3. Gate requirements (frozen)

- The test stage must tag every test conclusion with an evidence level.
- deliver cites the highest evidence level from the test stage; **06 deliver must not be higher than the highest evidence level of 05 test**.
- Untested boundaries (e.g. an uncovered browser, un-load-tested concurrency, unverified weak network) must be written into the deliver risks; they must not be hidden.

---

## 4. Traceability matrix

| REQ | DESIGN | TASK | TEST | Evidence level | Status |
|---|---|---|---|---|---|
| REQ-001 | DES-001 | T-001 | TC-001 | L1/L2/L3/L4/L5 | not started / in progress / passed / blocked |

---

## 5. Mode B evidence-strength labels (kept separate from L1–L5 to avoid number confusion)

When Mode B reverse-derives cognition, conclusions are labeled with **textual** evidence-strength labels; **do not reuse the L1–L5 numbers** (L1–L5 carry Mode A delivery-gate semantics):

| Label | Meaning | Web example |
|---|---|---|
| 静态可见 (statically visible) | statically visible in the current source code | component definitions, Props types, routing config, store slices, API call sites |
| 资料互证 (corroborated by materials) | statically visible + cross-checked with project materials | PRD, Figma/design mockups, Swagger/OpenAPI, requirement documents |
| 运行佐证 (backed by runtime evidence) | statically visible + materials + run/test evidence | build logs, Vitest/E2E records, Lighthouse/axe reports |

**Conflict and no-speculation rules (frozen)**: when materials conflict with the source code, the `context/` body text is **written from the source-code facts**, and the divergence goes into `open-issues.md`; it is **forbidden** to fill in behavior that has no evidence with 「通常 / 应该 / 按经验」 ("usually / should / by experience"). Labeling something 运行佐证 requires a real log/record as backing. Evidence provenance is consolidated into `context/evidence-trace.md`.

## 6. Mode B upstream reverse-derivation reachability (frozen; works with mode-b-reverse.md)

When reverse-deriving upstream documents (detailed design / high-level design / requirements spec) from the cognition layer, the source code's reverse-derivation power **naturally decreases**; use three reachability levels to decide the wording:

| Reachability | Meaning | Allowed wording | Forbidden wording |
|---|---|---|---|
| Reverse-derivable | static visibility in the source suffices (component tree / routing / state / API contract / build config) | write directly + evidence-strength label | — |
| Partially reverse-derivable | needs corroborating materials (interaction completeness / boundary intent / source of the performance budget) | `[草稿:…]` + `[待澄清:…]` wherever materials are missing | writing inference as established fact |
| Not reverse-derivable | the source inherently does not contain it (complete requirement scenarios / non-functional thresholds / business motivation / acceptance criteria) | `[缺口:…]`/`[待澄清:…]` | **speculative fill-in**, deleting markers to slip through, calling it a 「完整需求规格书」 (complete requirements spec) |

When gaps exist, the delivery semantics **must not claim "完整需求规格书"** (a complete requirements spec); it must be "需求规格书**草稿**（含 N 处待澄清/缺口）" (a requirements-spec **draft**, containing N to-clarify items/gaps). Full rules and the gap-marking method are in [mode-b-reverse.md](mode-b-reverse.md).

## 7. Evidence single landing point (frozen meta-rule)

Evidence rots into "several copies, none authoritative" when every stage keeps its own duplicate. The framework freezes the **meta-rule, not the paths** — concrete directories belong to this domain's `structure.md`.

1. **One authoritative landing point per evidence class.** Each evidence class (test execution records, build artifacts, coverage/benchmark/audit reports, screenshots and captures, machine-generated indexes) has exactly one authoritative location in the project. Two locations for one class is a defect, not a choice.
2. **Landing points MUST be declared explicitly.** This domain's `structure.md` carries an "evidence landing points" table — one row per class: class · authoritative path · who writes it · archive/retention rule. An evidence class not declared there MUST NOT be written anywhere: declare first, then write. Silence is not permission.
3. **Conclusions link back to evidence.** Every conclusion entry in `5-test/current.md` — and every stage that cites evidence — MUST carry a project-relative path to its evidence file at the declared landing point. **A conclusion with no resolvable evidence path MUST NOT be tagged with an L1–L5 level**, and the deliver stage MUST NOT cite it as the highest level.
4. **No duplicate copies.** The same evidence file MUST NOT exist in two locations. When another document needs it, write the path — never copy the file. (Copies of *external inputs* are a different mechanism and remain governed by specs-lifecycle.md §9 `sources.md`.)
5. **Archiving moves evidence, never clones it.** When a stage `current.md` is archived, iteration-scoped evidence moves with it and the conclusion links are rewritten to the archived location; project-scoped evidence stays put and the links keep pointing at it. Either way exactly one copy remains.

**Enforcement**: `/sdd-tidy` reports duplicated evidence files and broken conclusion→evidence links as tidy-plan rows (move/archive only — a broken link is reported, never auto-repaired); post-output self-check item 13 checks the same three points before every stage output.
