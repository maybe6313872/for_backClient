# docs Textualization Adapter (standalone · swappable)

> **This module is deliberately standalone**: it isolates the capability of turning "binary input documents (requirement-spec xlsx, protocol pdf, mind-map emmx…) → text" — a capability that is **tightly coupled to company infrastructure and subject to change** — from the rest of the framework. Every sdd-xx **references only the contract defined in this file** and never hard-codes converter details into its own body. **When infrastructure changes (service address / tool replacement), change only this one place and every sdd-xx follows automatically.**
>
> Business slot S8's converter slot is filled by the company "binary-doc-converter" (in-domain fallback: `scripts/xlsx_to_csv.py`); this file is where it lands.

---

## 1. Adapter contract (framework-level, stable)

Every textualization implementation must satisfy this contract; a child skill's docs flow depends only on the contract, never on a concrete implementation:

| Contract item | Requirement |
|---|---|
| Input | Any binary/text input document under `docs/` |
| Detection | Can determine which documents need conversion and which are already text and directly readable |
| Conversion | Binary → text (xlsx→CSV/MD, one file per workbook; pdf/docx→MD/text; mind map→hierarchical CSV) |
| Artifact destination | Everything goes into `docs/converted/`: files needing conversion go into `<same-name folder>/`; files needing none become a same-name file |
| Index | Maintain `docs/converted/README.md` (source↔artifact mapping + per-file SHA-256/date + aggregate hash) + `manifest.json` |
| Quick check | Supports `--check` to report "which source documents changed and need reconversion" and `--write` to book the change and refresh the index |
| Idempotence | Skip when a source document's hash is unchanged, guaranteeing artifacts map one-to-one to sources |

> `specs/README.md` and the knowledge map's "reference document index" should both point to `docs/converted/README.md`.

---

## 2. Current company implementation (⚠️ infrastructure-bound, will change — edits touch this section only)

> Below is the **current** implementation. When company infrastructure changes (e.g. converter service migration, tool replacement), **modify only this section**; the contract (§1) and every sdd-xx reference remain untouched.

**Capability priority (detection + degradation)**:
1. **First choice: the company `binary-doc-converter`** — the internal capability dedicated to textualizing binary documents.
   - Currently hosted at: internal service **`192.168.1.39`** (placeholder — confirm against reality whether it is an HTTP service / shared script / standalone skill).
   - Invocation: `<to be confirmed · fill in per actual infrastructure: skill invocation / HTTP API / command line>`.
2. **Second choice: in-domain built-in scripts** — this skill carries the zero-dependency `scripts/xlsx_to_csv.py` (**Python standard library only, no `pip install` needed**; xlsx→CSV, one file per workbook, artifacts are UTF-8 CSV); for pdf call the built-in pdf/pdf-reading skill; for docx call the docx skill. Usage: see [document-tools.md](document-tools.md).
3. **Fallback: the AI textualizes on demand by itself** — not forbidden, but prefer reusing the capabilities above to avoid reinventing wheels and creating inconsistency.

**Index & quick-check tool (current)**: the `docs_index.py` (zero-dependency) or `docs_index.ps1` (PowerShell fallback) shipped with the child skill:
```bash
python scripts/docs_index.py docs --check   # exit code 1 = something needs conversion
python scripts/docs_index.py docs --write    # book and refresh README.md/manifest.json
```

Detailed script usage: see [document-tools.md](document-tools.md).

---

## 3. `/sdd-docs` standard flow (contract-driven, implementation-agnostic)

```
Inspect docs/ → docs_index --check to find what needs conversion → call the current converter (§2 priority order) to textualize
→ artifacts go into docs/converted/<same-name folder>/ (one file per workbook) → docs_index --write to book
→ report: added / changed / needs-reconversion list
```

---

## 4. How to fill this in when "building a skill" (S8)

- In the child skill's SKILL.md / document-tools chapter, **write only one sentence**: "docs textualization follows the contract in [docs-binarification-adapter.md], currently hosted by the company binary-doc-converter." Then copy this file into that child skill's references/ (or reference it uniformly from a team-shared location).
- Do **not** scatter `192.168.1.39` or concrete invocation details into the child skill's body — that would force N skills to be edited whenever the infrastructure changes (the leave-blank risk of business-slots S8).

---

## 5. Maintenance notes

- Changes to this section (§2) should be recorded in this skill's README iteration log (noting "S8 adapter: old → new").
- If the company standardizes the conversion capability into a stable interface, §2 can be collapsed into a one-line interface note, further reducing coupling.
- `192.168.1.39` is currently a **placeholder pending confirmation** — verify the real address/form on first use of this skill and update it here.
