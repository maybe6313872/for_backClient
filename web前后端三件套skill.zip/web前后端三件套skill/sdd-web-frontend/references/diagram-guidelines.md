# Mermaid Diagram Usage Guidelines

> This file defines the usage rules for mermaid diagrams in the spec workflow, the recommended diagram types per stage, and anti-example notes. Diagram labels in generated project documents are written in Simplified Chinese for the user; code identifiers (component names, routes, store symbols) stay in their literal English form, as the examples below illustrate.

---

## Core principles

1. **Focused**: each diagram shows exactly one topic; you MUST NOT draw a "big and complete" whole-system diagram
2. **Lean**: a single diagram SHOULD NOT exceed 15 nodes; when it does, split it into multiple diagrams
3. **Consistent**: a diagram MUST match the body text exactly, with no extra or missing nodes
4. **Titled**: every diagram MUST have a title (a markdown heading or a diagram caption) stating the scope of what it shows
5. **Auxiliary**: diagrams assist the textual description; they cannot replace it

---

## Supported diagram types (in-domain)

| Type | Tool | Purpose |
|------|------|---------|
| Component tree | Mermaid graph | Component hierarchy relationships |
| Data flow | Mermaid flowchart | State-management data flow direction |
| Routing graph | Mermaid graph | Page routing structure |
| Sequence diagram | Mermaid sequence | API request/response flow |
| State machine | Mermaid stateDiagram | Component/page state transitions |
| ER diagram | Mermaid erDiagram | Data-model relationships |

---

## Recommended diagrams per stage

### spec stage

**Recommended**: use-case diagrams, scenario flowcharts
**Purpose**: show "what to do" — actor-to-feature relationships, business scenario flows
**Forbidden**: showing "how to do it" — component partitioning, module calls, state machines

Example (use-case diagram):
```mermaid
flowchart LR
    User([用户/浏览器]) --> F1[浏览列表]
    User --> F2[提交表单]
    Admin([管理员/运维]) --> F3[配置管理]
    Admin --> F4[数据导出]
```

Example (scenario flowchart):
```mermaid
flowchart TD
    A[用户提交表单] --> B{字段校验通过?}
    B -->|是| C[调用提交API]
    B -->|否| D[高亮错误并提示]
    C --> E[显示成功反馈/跳转]
```

### design stage

**Recommended**: component tree diagrams, data flow diagrams, routing graphs, state machine diagrams, sequence diagrams
**Purpose**: show "how to do it" — component structure, state transitions, data flow chains, page routing
**Forbidden**: showing concrete code logic (pseudocode is fine; a full implementation is not)

Example (component tree):
```mermaid
graph TD
    App --> Layout
    Layout --> Header
    Layout --> Sidebar
    Layout --> MainContent
    MainContent --> RouterView
    RouterView --> HomePage
    RouterView --> UserPage
    UserPage --> UserList
    UserPage --> UserDetail
```

Example (data flow):
```mermaid
flowchart LR
    Component -->|dispatch| Action
    Action -->|commit| Store
    Store -->|state| Component
    Action -->|request| API
    API -->|response| Action
```

Example (routing graph):
```mermaid
graph TD
    Root["/"] --> Home["/home"]
    Root --> Auth["/auth"]
    Auth --> Login["/auth/login"]
    Auth --> Register["/auth/register"]
    Root --> Dashboard["/dashboard"]
    Dashboard --> Profile["/dashboard/profile"]
    Dashboard --> Settings["/dashboard/settings"]
```

Example (state machine — async request / form submission):
```mermaid
stateDiagram-v2
    [*] --> IDLE
    IDLE --> SUBMITTING : 提交表单
    SUBMITTING --> SUCCESS : 请求成功
    SUBMITTING --> ERROR : 请求失败
    ERROR --> SUBMITTING : 重试
    SUCCESS --> [*]
```

Example (sequence diagram — API request/response):
```mermaid
sequenceDiagram
    participant C as 组件
    participant S as Service层
    participant API as 后端API

    C->>S: 调用 fetchUsers()
    S->>API: GET /api/users
    API-->>S: 200 + 用户列表JSON
    S-->>C: 返回类型化数据(User[])
```

### tasks stage

**Recommended**: dependency graphs
**Purpose**: show the execution order and blocking relationships between tasks

Example:
```mermaid
flowchart TD
    T0[T0.1 环境确认] --> T1[T1.1 路由骨架]
    T0 --> T2[T1.2 API Service层]
    T1 --> T3[T1.3 页面组件]
    T2 --> T3
    T3 --> T4[T1.4 状态接入]
    T4 --> T5[T2.1 E2E测试]
    T5 --> T6[T2.2 更新deliver文档]
```

### test stage

**Recommended**: coverage matrix (a table works better than mermaid)
**Purpose**: show the mapping between spec requirement items and test cases

Example (table form):

| Requirement | TC1 | TC2 | TC3 | TC4 |
|------|-----|-----|-----|-----|
| R1/AC1 | ✓ | | | |
| R1/AC2 | | ✓ | | |
| R2/AC1 | | | ✓ | ✓ |

### deliver stage

Usually no diagrams are needed. A complex release process may be shown with a `flowchart` (nodes ≤8).

---

## Anti-examples and corrections

### Anti-example 1: the whole-system mega-diagram

❌ Drew a whole-system architecture diagram with 30+ nodes in the spec stage, covering every component and every route

✅ Correction: split into multiple focused diagrams — one use-case diagram for the actor-to-feature relationships, one flowchart for the key business scenario

### Anti-example 2: a state machine drawn in spec

❌ Drew a form-submission state machine (IDLE → SUBMITTING → ERROR) in the spec stage

✅ Correction: state machines belong to design content. The spec stage only states "系统应支持表单提交，包含字段校验与错误提示" (the system shall support form submission, including field validation and error prompts)

### Anti-example 3: text-diagram inconsistency

❌ The body text describes 5 data-flow steps, but the mermaid diagram only draws 3, omitting "缓存失效" (cache invalidation) and "错误处理" (error handling)

✅ Correction: the diagram must correspond to the body text exactly — check item by item and fill in the gaps

### Anti-example 4: the diagram replaces the text

❌ Only a mermaid diagram was drawn, with no accompanying textual explanation

✅ Correction: every diagram must have an accompanying text paragraph explaining its meaning and key details

---

## Self-check list (diagram-specific)

After each use of a mermaid diagram, confirm item by item:

- [ ] Does this diagram focus on a single topic?
- [ ] Is the node count ≤15?
- [ ] Does every node in the diagram have a corresponding description in the body text?
- [ ] Is every key point in the body text shown in the diagram?
- [ ] Is this diagram a type allowed in the current stage?
- [ ] Is there a title stating the scope the diagram shows?
- [ ] Does the diagram reflect the current actual architecture rather than an idealized state?
