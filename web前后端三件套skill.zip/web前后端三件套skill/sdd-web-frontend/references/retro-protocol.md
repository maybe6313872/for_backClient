# Retrospective and Experience Consolidation Protocol (/sdd-retro + specs/retro/)

> **Positioning**: capture "what was learned from real mistakes / real wins" as normative documents **local to the project**, accumulating a corpus of experience that is reusable, harvestable by colleagues, and feedable back into the framework. It is the **front-end intake** of the SDD self-evolution loop (the back end is the mother skill's `/sdd-distill` → `/sdd-absorb`).
>
> **Zero blast radius**: `/sdd-retro` only reads code and outputs, and **only writes `specs/retro/`** — it never touches business code and never modifies other specs artifacts. Retro documents are written in Simplified Chinese for the user.

## 1. Command `/sdd-retro`
- **Triggers**: ① the user explicitly orders it at a "这次错了/这次做得好" (this went wrong / this went well) moment; ② the iteration exit gate (deliver) auto-suggests it (see gate-and-stages, exit-gate item ⑤); ③ periodic retrospectives.
- **Action**: drive the AI through the structured retrospective of §3 → produce/append one `specs/retro/retro-YYYY-MM-DD-<topic>.md` → update the `specs/retro/README.md` ledger.
- **Consumption (local value reuse)**: when starting a related task/iteration, first read the `specs/retro/README.md` ledger; on hitting a relevant lesson → remind to avoid repeating the mistake, and reuse the highlights. This turns the retrospective from a "write-only, never-read log" into a minimal local loop.

## 2. Folder structure (README plus per-topic files, mandatory)
```
specs/retro/
  README.md                       ← ledger/index (see the retro-readme template)
  retro-YYYY-MM-DD-<topic>.md      ← one file per topic (see the retro-entry template)
```
Ledger fields: `| 编号 | 日期 | 主题 | 类型(教训/亮点) | 严重度 | 标签 | 泛化性 | 状态 | 关联任务 |` (No. | Date | Topic | Type (lesson/highlight) | Severity | Tags | Generality | Status | Linked task).

## 3. Retrospective schema (frozen)
Write every retro entry to this fixed structure — **facts first, no guessed root causes, and record the wins too**:

| Section | Requirement |
|---|---|
| Meta info (元信息) | Date / trigger / type (教训 lesson \| 亮点 highlight) / **severity** CRITICAL·HIGH·MEDIUM·LOW / tags / **generality** / linked task (task.md) / linked iteration |
| 1 What happened (发生了什么) | Facts + evidence strength (静态可见 statically visible / 资料互证 cross-verified by documents / 运行佐证 runtime evidence). If it is a mistake/excuse, **record the AI's statement at the time verbatim** (to build an anti-rationalization table later) |
| 2 What was expected (期望是什么) | The correct/expected outcome |
| 3 Root cause analysis (根因分析) | 5 whys or single-hypothesis verification; **no evidence → mark `[待确认]`; guessing root causes is forbidden** |
| 4 Which rule/gate should have caught it (哪条规则/门禁本应拦住) | Map to F#/RULE-#/Gate; **no corresponding constraint in the framework/rules = a gap** |
| 5 Improvement actions (改进动作) | Within this project: …; `[框架候选]` (framework candidate): … (**explicit tagging** of what may rise to the framework, for harvest) |
| 6 Generality verdict (泛化性判定) | 项目专属 (project-specific) \| 本域通用 (domain-general) \| 跨域通用 (cross-domain general) |
| 7 Status (状态) | 待沉淀 (pending consolidation) \| 已沉淀 (consolidated) (→ experience-package / framework version) |

**Severity determination (borrowed from Spec Kit)**: violating a constitution/RULE-* MUST, or causing a functional/safety failure = CRITICAL; conflicts / untestable / vague safety-performance statements = HIGH; terminology drift / under-specified boundaries = MEDIUM; formatting/naming = LOW.

## 4. Discipline (frozen)
- **Purity**: the retro body contains only closed, established retrospective facts; unresolved doubts go into the same project's `specs/open-issues.md`, never mixed into the retro body.
- **No guessed root causes**: a root cause must have evidence or be marked `[待确认]`; hard-coding a root cause with "usually / should / probably is" wording is forbidden.
- **Record both sides**: highlights (things done well) and lessons (things done badly) are recorded in equal measure; positive feedback reinforces good practice — this is not an errors-only log.
- **No personal blame**: retrospectives address the matter, not the person — focus on "rule/gate gaps", not "whose fault it was".

## 5. Harvest → absorb (the harvest bridge)
- Once enough has accumulated locally / a cycle completes, gather multiple projects' / colleagues' `specs/retro/` into one place.
- The mother skill's `/sdd-distill` can read this batch of retros and distill those tagged `[框架候选]` with generality = 本域通用/跨域通用 into a schema-conformant `experience-package.md` (with a "source retro list" for traceability) → open a new conversation and `/sdd-absorb` to upgrade the framework.
- The loop: `project retro (frequent · cheap · local) → harvest → /sdd-distill → experience-package (rare · framework-level) → /sdd-absorb → framework upgrade`.
- The framework/business boundary follows the mother skill's discipline: only what is **better for all domains** rises into the framework core F; what holds **only in this domain** lands in the domain retro seeds or the business slots.

## 6. Domain retro seeds (filled via the S19 interview at assembly time)
List this domain's **high-frequency pitfalls and good-practice seeds**, so the AI does not miss the domain's typical issues during retrospectives:

| Common domain pitfall / good practice | Type | Typical severity |
|---|---|---|
| Rendering untrusted content with raw v-html / dangerouslySetInnerHTML (XSS) | 教训 | CRITICAL |
| Mutating state directly, so the view does not update | 教训 | HIGH |
| Not cancelling rapid repeated requests, causing race-condition stale data | 教训 | HIGH |
| Missing/incorrect useEffect deps, infinite loops, uncleaned side effects | 教训 | HIGH |
| Using array index as list key, causing render glitches | 教训 | MEDIUM |
| Overusing `any`, masking type errors | 教训 | MEDIUM |
| Bundle over budget, no route-level lazy loading | 教训 | MEDIUM |
| Missing accessibility (semantics / aria / keyboard reachability) | 教训 | MEDIUM |
| Defining component Props/Emits contracts before implementing | 亮点 | — |
| Centralized global state, single-responsibility slices | 亮点 | — |
| E2E (Playwright/Cypress) covering key business flows | 亮点 | — |
