# Runtime Environment and Tools

> Web front-end project runtime environment: Node.js + pnpm (or the project's real package manager) + Vite, with sources in UTF-8 without BOM. All tools are designed around "capability detection + degradation": zero-dependency / most-stable first; step down level by level when no suitable runtime exists.

## 0. Package-manager identification (P0-03 · identify the existing facts first, then discuss defaults and migration)

**Priority (high to low)**, the higher wins on conflict:

1. **The project's existing unique lockfile** (highest): `pnpm-lock.yaml`→pnpm, `yarn.lock`→yarn, `package-lock.json`→npm, `bun.lockb`→bun. A legacy project **follows its unique lockfile**.
2. **The `packageManager` field of `package.json`**: when explicitly declared, it governs (it should match the lockfile; a mismatch = tech debt that must be clarified).
3. **Organization default (pnpm)**: used **only** as the default choice for a **brand-new project** (no lockfile, no `packageManager`).
4. **Environment degradation**: only when the identified package manager is unavailable in the current environment, as a **temporary** fallback, and it **must not** produce a second lockfile as a result.

> **Multiple lockfiles = an anomaly**: a repo containing several kinds of lockfiles at once should be treated as tech debt — clarify it in the constitution and converge to one.
> **Migration is an explicit decision**: migrating an npm/yarn project to pnpm is a **standalone constitution decision + standalone task** (updating the lockfile, CI, docs); it is **forbidden** to run a casual `pnpm install` in an unrelated iteration and introduce a second lockfile that breaks reproducibility.
> The identification result can be read automatically via `python specs/_tools/derive_gate_status.py --root .` (the `package_manager` field). **In the text below and in every Gate, `pnpm ...` should be replaced by "the project's identified package manager".**

## 1. Capability detection (before starting work)

Determine which runtimes are at hand (Node / package manager / Vite-related); before running any script/tool, detect first — infer from error messages or have the user run one line in a terminal to confirm:
- Node version: `node -v` (version baseline in §3)
- Package manager: identify per §0 first, then confirm availability with `<pm> -v`
- Build tool: `npx vite --version`
- Parser tools (for the code map): `npx madge --version` / whether `ts-morph` or `@vue/compiler-sfc` is installed

## 2. Degradation chain per tool

| Task | First choice | Second choice | Fallback |
|---|---|---|---|
| Initialize the specs/ skeleton | AI creates files directly (most stable) | `scripts/init-spec.*` (if bundled) | — |
| Detect the current stage | AI lists the `specs/` directory and judges manually | `scripts/detect-phase.*` (if bundled) | — |
| Generate the source coverage index (optional) | madge / ts-morph / @vue/compiler-sfc / `_tools/build_source_index.py` | other TS/Vue symbol tools | AI builds the source inventory by hand per code-map.md (equivalent result) |
| Type checking | `pnpm tsc --noEmit` / `vue-tsc --noEmit` | `npx tsc` | AI static review (label L1 statically visible) |
| Build | `pnpm build` (Vite) | `npx vite build` | — |
| Unit test / E2E | `pnpm test` (Vitest/Jest) / Playwright/Cypress | `npx vitest` | — |
| docs binary textification | `scripts/xlsx_to_csv.py` (zero-dependency stdlib; see docs-binarification-adapter.md) | built-in pdf/docx skills | AI implements it itself as needed |
| docs hash quick-check / index | `docs_index` (if bundled) | — | AI fills in converted/README.md by hand |
| Gate-status derivation (P0-02) | `assets/tools/derive_gate_status.py` (reads package.json + lockfile + `--ran`) | AI derives manually per the test Gate status table | — |
| i18n consistency check (P1-07) | `assets/tools/check_i18n.py` (missing keys / extra keys / params / orphans / hardcoding) | AI checks manually per RULE-I18N | — |
| Iteration-boundary / lifecycle check (P1-11) | `assets/tools/check_iteration_docs.py` (date-header status / archiving / tidiness) | AI checks manually per specs-lifecycle | — |
| Source encoding handling | Default UTF-8 without BOM, no special handling needed | — | Occasional non-UTF-8 file → convert to UTF-8 before processing |

> The `assets/tools/*.py` and `scripts/*.py` above are all **zero-dependency (Python standard library)** — no `pip install` needed; `/sdd-init` can copy them into the project's `specs/_tools/` for in-place running (the `assets/tools/` and `specs/_tools/` paths are equivalent).

## 3. Versioned baseline table (P2-02 · single value · with applicable scope and verification date · needs periodic external verification)

> **This table is the single source of this skill's versioned knowledge.** For any browser/performance/tool version appearing in any section, **this table governs on conflict**; ambiguous/stale values in old docs such as "Chrome ≥80/≥100", "FID<100ms", "Vite 5 Node≥18" are void. Rows marked 🔄 are "externally evolving" knowledge — **each skill iteration must re-verify the official source and update the verification date**; if a project has frozen its own compatibility matrix, the project's frozen value governs (declared in the constitution), and on conflict with this table's default the project's frozen value wins.

| Baseline item | Single value (this skill's default) | Applicable scope | Verification date / source |
|---|---|---|---|
| 🔄 Vite | **8.x** (current stable line) | default for new/upgraded projects; legacy projects follow their `package.json` | 2026-07-14 · vite.dev |
| 🔄 Node (with Vite 8/7) | **20.19+ or 22.12+** | Vite 8 and 7 share this baseline; lower Node is unsupported | 2026-07-14 · vite.dev/blog/announcing-vite8 |
| 🔄 Core Web Vitals ("good" thresholds) | **LCP < 2.5s · INP < 200ms · CLS < 0.1** | acceptance of performance-sensitive projects; **FID was replaced by INP in 2024-03, do not use it anymore** | 2026-07-14 · web.dev |
| 🔄 Default browser target | **Chrome, latest 2 stable versions** | the single default when nothing special is declared; multi-browser / lower versions / mobile are declared explicitly by the user and trigger conditional capabilities | 2026-07-14 |
| Minimum touch-target size | **44×44px** | when there are touch/responsive requirements | WCAG/platform HIG |
| Accessibility level | **WCAG 2.1 AA** | recommended default | — |
| Source encoding | **UTF-8 without BOM · LF** | whole project (PowerShell scripts excepted, see below) | — |
| PowerShell script encoding | **UTF-8 with BOM** | `.ps1` only: Windows PowerShell 5.1 needs a BOM to parse Chinese correctly | — |

**Maintenance mechanism**: 🔄 rows are re-verified against the official baseline and get a refreshed "verification date" on each `/sdd-evolve` iteration; if verification finds a change, update the single value and note it in the README iteration log.

## 4. Host environment differences (local vs Claude.ai)

Local: direct read/write access to the project directory, can run the package manager / Vite / tests and static analysis. Claude.ai: usually an ephemeral sandbox with no persistent project directory and a restricted network (dependency installation may be unavailable) → prefer AI direct processing, and deliver artifacts as downloadable files for the user to land locally. When the environment cannot be determined, start with "AI does it directly"; only when batch processing is needed, try scripts and degrade per the error messages.
