# Unified Self-Check Protocol (pre-output chain of thought + post-output checklist)

> Shared by both modes. Both the "core collaboration principles" in SKILL.md and collaboration-protocol.md point here. Run the "chain of thought" before producing a stage output, and go through the "checklist" item by item before handing anything to the user.

## Pre-output chain of thought (run before producing any stage output)

(Displayed verbatim to the user in Chinese:)

```
## 🧠 开始前梳理
- 当前阶段/模式：{阶段名 或 模式B 的哪一步}
- 输入依据：用户采访要点 / README / task.md 当前状态 / docs 参考 / 上一阶段产出
- 本次产出目标：{一句话}
- 内容边界：本阶段允许 {…}；本阶段禁止 {…}
- 风险/不确定项：{列举，标"待确认"；无则写"暂无"}
```

## Post-output checklist

After writing is done and before handing to the user, verify item by item:

### 1. Overreach check
- Compare paragraph by paragraph against the current stage's "content boundary". Content that belongs to another stage → move it out and mark it "此内容属于 {阶段}，后续处理" (this content belongs to {stage}; to be handled later).
- High-frequency overreach: spec contains implementation solutions → move to design; design contains task breakdown → move to tasks; tasks redefines requirements → flow back to spec.

### 2. Text-figure consistency check
- Every figure's node names/arrow directions match the body text; no node in a figure that the text never mentions; ≤15 nodes per figure, split if exceeded.

### 3. Hallucination check
- Does every technical detail (interface signature, protocol field, dependency behavior, numeric parameter) have an explicit source (user docs / project code / interview replies / README)? No source → mark "**待确认**" (to be confirmed) and ask.

### 4. Reference check
- Does it contradict anything already known in `specs/README.md`? Are existing modules/styles/features referenced correctly?

### 5. Alignment check
- Did it respond to every answer from the user interview? Was any requirement/constraint missed? Does anything the user explicitly said "不做" (won't do) appear in the output?

### 6. Scenario closure check
- Are the trigger scenario, inputs, outputs, success criteria, and exception boundaries recorded? Were the user's documents turned into confirmation questions and confirmed? If the scenario is unclear, was coding paused while clarification continued?

### 7. Coding and consistency check (when code is modified)
- Do the changed files conform to this domain's coding rule set (see coding-rules.md)? Are files saved as UTF-8 (front-end sources are UTF-8; watch for stray BOM/CRLF), with lint/typecheck clean?

### 8. Development progress check
- Are developed / not developed / blocked / next step listed? Written into `specs/task.md`? Was the user informed with a summary of at most 5 lines?

### 9. Mode B reverse-derivation self-check (when producing docs/reverse/ drafts)
- Can every function/interface/data flow in the reverse-derived document be found in `context/modules*`, `code-map`, `architecture/data-model`? Not found → mark `[待澄清]`; **never fabricate**.
- Purely inferred requirements/scenarios/thresholds/acceptance criteria → must be marked `[缺口]`/`[待澄清]`; it is **forbidden** to render them in smooth prose as seemingly complete requirements.
- When gaps exist, it is **forbidden to claim "完整需求规格书"** (a complete requirements spec); it must be "草稿（含 N 处待澄清/缺口）" (a draft, containing N to-clarify items/gaps); do the reachability distribution and unclosed gaps in the "反推完整度声明" (reverse-derivation completeness statement) match the marker counts in the body?
- Does every gap marker have a corresponding entry in `specs/open-issues.md`? Full rules: [mode-b-reverse.md](mode-b-reverse.md).

### 10. Iteration boundary and retro self-check
- Before opening a new iteration: did you pass the **iteration entry gate** (read task.md / archive the previous iteration first / write the new iteration header / read the retro ledger)? See [gate-and-stages.md](gate-and-stages.md).
- Before delivery: did you pass the **iteration exit gate** (task.md updated + archived / history appended / open-issues closed out / retro judgment)?
- Did you check the `specs/retro/README.md` ledger and, when a relevant lesson matched, reuse/avoid accordingly? If this iteration had mistakes or highlights → did you run `/sdd-retro`? See [retro-protocol.md](retro-protocol.md).
- Date header integrity: does every workbench document written this session start with the canonical header, using exactly `迭代标识` / `迭代日期` / `状态` and a single in-set `状态` value? If any project script (phase detection, index generation, gate backstop) reads the header, does its pattern match these three literals? A renamed field fails **silently** — check the pattern, not the script's exit code. `check_iteration_docs.py` grades this: an out-of-set `状态` is a critical failure, a legacy 4-field split is a warning.
- Stage presence: after any archive performed this session, does the stage still have a `current.md` with a valid date header? Did the archive and the replacement happen in **one** action? Is there any stage with `history/` but no `current.md` (hollow state → repair per specs-lifecycle §4, reconstructing from the newest archive, never inventing content)?

### 11. User preference guard self-check (every output)
- Has this output's wording been adjusted per the style/habits in `preferences/user-preferences.md` (default 「专业可靠」 when empty)?
- Did you hold the **preference precedence guard** — no gate/evidence/interview/archiving discipline was weakened to please a preference? When the user's claim was wrong, did you stick to principles instead of blindly complying?
- Did you hold the **read-only guard** — apart from `preferences/` (and the project's `specs/retro/`), **no** skill file was modified this time? See [custom-protocol.md](custom-protocol.md).

### 12. Requirement-inbox & pairing self-check (F33 / G5 / G6)
- If `docs/requirements/` was non-empty this session: was the requirement claimed per [requirement-inbox-protocol.md](requirement-inbox-protocol.md) — registered into specs, a copy archived locally, **then cleared from the inbox**? (Never start coding straight from an inbox file; never leave a claimed packet in the inbox.) **And did the clear touch nothing outside `docs/requirements/`** — `docs/product-specs/`, `docs/iterations/`, `docs/decisions/` must be byte-identical before and after the claim (F37).
- For any code fix or small increment: was it registered in `specs/` first, and does every business-code change have a paired specs change in `git status` (G5)? Does the working tree match what this delivery *claims* — claimed artifacts and test-evidence files present, no unregistered incidental changes (G6)? On a mismatch: block, report, and ask the user for disposition — never auto-revert. Gate IDs follow the frozen namespace in [gate-and-stages.md](gate-and-stages.md) §Gate numbering namespace; a domain gate never borrows a `G` number.
- Were all external input copies consumed this session verified against their `sources.md` registration (stale → reported, re-copied on approval)?

### 13. Evidence landing-point self-check (F7 §7)
- Does every evidence file produced this session sit at the **single authoritative landing point** declared in this skill's `structure.md`? Was any evidence class written to a location the table does not declare (→ declare it first, do not improvise)?
- Does every conclusion in `5-test/current.md` carry a resolvable project-relative path to its evidence file? Any conclusion tagged L1–L5 **without** such a path → strip the level and fix the link before output.
- Was any evidence file **copied** into a second location this session (forbidden — reference the path instead)? External input copies are exempt and follow `sources.md` (specs-lifecycle.md §9).

### 14. In-stage increment self-check (specs-lifecycle.md §12)
- Did any small increment appear this session (hotfix note, corrected acceptance point, inserted small requirement, re-run case)? If yes: is it registered in **both** this stage's increment container **and** `specs/task.md`? An increment living only in the conversation, or in a file outside `specs/`, is unregistered → register it before output (G5).
- Does every increment's content actually belong to **this** stage? Anything belonging elsewhere → move it out / flow it back; the container is not a place to park out-of-stage content.
- Does any registered increment touch an acceptance point, an interface, or a test conclusion? If yes, was the corresponding gate item re-opened rather than left ticked?

## Flow-back protocol
When a flow-back (fixing spec/design) is needed: stop the current output → explain the flow-back reason to the user → wait for confirmation → flow back and fix → re-run the target stage's gate → after it passes, return to the original stage and continue.
