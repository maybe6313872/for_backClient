# Troubleshooting

> Framework-level reusable troubleshooting principles (frozen) + domain-specific tool checks (Web front-end).

## 1. Paths and file creation (frozen principle)
**Prefer "AI creates files directly" over command-line tools**: project paths may contain Chinese characters or be very long, and command-line tools break easily on such paths. Writing files directly auto-creates directories and has the best compatibility — it is the **first choice** for initializing the specs/ skeleton and the various current.md files; scripts are the fallback option for batch/offline scenarios.
- Chinese-path/long-path errors → switch to "create files directly"; or migrate to a short English path; or (Windows) enable long-path support.
- Remember to also create each stage's `history/` and the `specs/task/` archive directory.

## 2. Capability detection and degradation (frozen principle)
When a script will not run, step down one level along the degradation chain in environment-and-tools.md: zero-dependency → domain ecosystem tools → AI by hand. Do not assume a runtime exists; detect first (relevant to `React / Vue with TypeScript, SCSS, Vite; pnpm; ESLint/Prettier; Vitest/Jest/Playwright/Cypress`) or infer from the error message.

## 3. Code map limitations (frozen principle)
Code maps are mostly heuristic extraction, not a full language parser: they may miss things (macros / dynamically generated code / special syntax), and call relationships are approximated by name. Treat the map as a navigation clue, not a verdict; confirm critical paths against the source code; for anything missed, manually add an entry in the twin document.

## 4. docs textification issues (see the adapter)
Conversion failures, encoding mojibake, incompatible formats, etc.: handle them along the degradation chain in docs-binarification-adapter.md.

## 5. Domain-specific checks (Web front-end common pitfalls)

### 5.1 Vite dev-server / HMR
**Q: The Vite dev server won't start or the port is already in use.**
A: Check Node.js version (Vite 5+ needs Node >= 18); free or reassign the port (`server.port` / `--port`); on a fresh clone run `pnpm install` first; if a stale cache is suspected, delete `node_modules/.vite` and restart.

**Q: HMR does not pick up changes.**
A: Confirm the file is actually inside Vite's watched root and imported through the module graph (edits to files loaded outside the graph don't hot-reload); check for a case-mismatched import path (case-sensitive on Linux/CI, tolerant on macOS/Windows); verify no proxy/file-watcher limit (`fs.inotify` limits in containers) is dropping events; a full page reload loop usually means a module has no valid HMR boundary — accept the reload or add one.

### 5.2 Dependencies / lockfile (pnpm)
**Q: Install fails or the app behaves differently between machines/CI.**
A: This domain standardizes on **pnpm**; commit and honor `pnpm-lock.yaml`, install with `pnpm install --frozen-lockfile` in CI. Peer-dependency errors → inspect the `pnpm why <pkg>` tree; a mixed lockfile (npm/yarn artifacts left behind) → delete `package-lock.json`/`yarn.lock` and reinstall with pnpm only.

### 5.3 TypeScript / type errors
**Q: The editor is clean but `tsc`/build reports type errors (or vice versa).**
A: Vite transpiles without type-checking, so type errors surface only at `vue-tsc`/`tsc --noEmit` or in the IDE — run a real type-check in the pipeline. Version-skew between the IDE's bundled TS and the project's TS → pin the workspace TS version; missing types → add the `@types/*` package or a local `*.d.ts`; path-alias resolution failures → keep `tsconfig.json` `paths` and Vite `resolve.alias` in sync.

### 5.4 Browser console / CORS
**Q: API calls fail with a CORS error in the browser but work in curl/Postman.**
A: CORS is a browser-enforced policy; the backend must return the right `Access-Control-Allow-Origin`/credentials headers. For local dev, prefer Vite's `server.proxy` to route API calls through the same origin instead of hitting the API host directly; watch for credentialed requests (`withCredentials`) requiring an explicit origin (not `*`) and `Access-Control-Allow-Credentials: true`.

### 5.5 Build / bundle
**Q: The build fails or the production bundle misbehaves while dev works fine.**
A: Check for env vars that must be prefixed (`VITE_*`) to be exposed to client code; dynamic `import()` paths that can't be statically analyzed; assets referenced by a wrong `base`/public-path for the deploy target; and tree-shaking side-effects (mark side-effectful modules in `package.json` `sideEffects`). Inspect bundle size regressions with `rollup-plugin-visualizer` before blaming Vite.

### 5.6 Multi-framework / monorepo / rendering shape
**Q: The project uses several frameworks at once (e.g. a React + Vue micro-frontend).**
A: Record the multi-framework architecture explicitly in the constitution. Each sub-app may have its own design document, but they share one constitution and one spec.

**Q: The project is a monorepo (pnpm workspace / Turborepo / Nx).**
A: Put the `specs/` directory at the monorepo root. If a sub-package needs to iterate independently, create a dedicated `specs/` under that sub-package, but it must be indexed from the root `specs/README.md`.

**Q: SSR/SSG-specific handling.**
A: SSR/SSG projects fall outside this skill's browser-side SPA scope — hand them to the matching domain skill. If a page nonetheless mixes rendering modes, make the design stage state explicitly which pages are SSR / SSG / CSR, the data-fetch strategy, and the hydration strategy (full / partial / islands).

### 5.7 Stage flow
**Q: The interview has too many questions and the user is impatient.**
A: Interview questions split into required and optional. Confirmation questions must be answered; choice/fill-in questions can offer defaults for a quick OK. Open questions can be marked "skippable if no special need."

**Q: The user wants to skip a stage.**
A: Of the six stages, constitution and spec cannot be skipped (they are the basis for later stages). design/tasks/test may be merged in a small iteration but not fully skipped. deliver may be simplified for an informal release.

**Q: A stage document needs rework.**
A: Use the 🔁 rework status marker. On rework: 1) archive the current version; 2) record the rework reason in task.md; 3) re-enter that stage's interview; 4) re-pass the Gate checklist after updating.

### 5.8 Tooling
**Q: The init-spec script fails to run.**
A: Check: 1) Node.js version >= 18 (ESM support); 2) execute permission (Linux/Mac needs `chmod +x`); 3) write permission on the target directory.

**Q: detect-phase results are inaccurate.**
A: First check whether the stage status in task.md matches the actual files. On a mismatch, trust task.md and backfill the missing files.

### 5.9 context/ files
**Q: When are context/ files created?**
A: Required files (modules/architecture/features/environment/history) are created at the init or constitution stage. Recommended files (api-contracts/data-model) are created on demand at the spec or design stage. Optional files (performance-budget/browser-compat/design-tokens) are created when needed.

**Q: How do context/ files differ from stage documents?**
A: Stage documents (1-constitution/ through 6-deliver/) are process documents within an iteration and are archived each iteration. context/ files are cumulative cross-iteration knowledge, continuously updated and never archived.
