# Usage Guidance Protocol (/sdd-help · F29)

> **Positioning**: `/sdd-help` is this skill's **skill meta-command** — it targets no particular project; it addresses **the user themselves**, interactively explaining "how to use this skill" and answering, step by step, any question that comes up during use. It lets newcomers / occasional users get started without reading through SKILL.md and the references.
>
> **Zero side effects**: `/sdd-help` is **read-only, never writes** — it changes no project file, changes no skill file, and never launches the six stages / twin flow; it only converses.

## 1. Core principles (frozen) — interactive, no info-dumping

- **Ask before explaining**: on entering `/sdd-help`, first use **a one-sentence welcome + one multiple-choice question** to locate what the user wants to learn; you must **not** open with a wall of explanation or a recitation of SKILL.md.
- **One question at a time, one answer at a time**: each round focuses on a single topic; explain it clearly, then ask "what else would you like to know", handing the pace to the user. Follow the framework interview priority (F6): **multiple-choice > fill-in with suggested value > confirmation > open-ended**.
- **Go deep on demand**: answer exactly what the user asks; link to the corresponding reference only when it is needed, avoiding information overload.
- **Use in-domain examples**: prefer **in-domain** scenarios for examples (see §4 in-domain guidance seeds) so explanations feel tangible.
- **Acknowledge boundaries**: for questions beyond this skill's scope (e.g. pure business implementation), say so honestly and route to the correct entry point (e.g. straight to `/sdd-iterate`).

❌ Anti-example: the user types `/sdd-help` and the AI immediately outputs a long article covering the six stages + mode B + all commands.
✅ Good example: the AI says "想先了解哪块？① 怎么从零做需求 ② 怎么梳理老项目 ③ 命令速查 ④ 门禁/归档为什么这么严 ⑤ 设置我的使用偏好 ⑥ 其它" (Which part first? ① requirements from scratch ② untangling a legacy project ③ command quick reference ④ why gates/archiving are so strict ⑤ set my usage preferences ⑥ other), and expands a topic only after the user has chosen it.

## 2. Guidance flow

```
/sdd-help
  → ① One-sentence welcome + multiple-choice to locate the topic (offer 4–6 common topic options + "other")
  → ② User picks / asks → explain that topic concisely (add 1 in-domain example when useful)
  → ③ Closing question: "这块清楚了吗？还想了解：[adjacent topic options] / 没有了" (Clear on this? Want more on: … / all done)
  → ④ Loop ②③ until the user ends; on ending, close with a line like "随时再 /sdd-help" (come back to /sdd-help anytime)
```

## 3. Guidable topic list (expand per the user's choice; never dump all at once)

| Topic | One-sentence key points | Deep-dive pointer |
|---|---|---|
| The two modes | Mode A forward development (`/sdd-iterate`) / Mode B code twin (`/sdd-init`); for legacy projects do B first, then A | SKILL.md §Two usage modes |
| Requirements from scratch | Six stages: constitution→requirements→design→tasks→test→deliver; stop after each stage and wait for clearance | references/gate-and-stages.md |
| Untangling a legacy project | `/sdd-init` reverse-engineers a `context/` cognition layer + code/knowledge maps, and can back-derive upstream document drafts | references/mode-b-twin.md / mode-b-reverse.md |
| Command quick reference | Project commands init/update/docs/iterate/retro + skill meta-commands help/custom | references/commands.md |
| Why the gates are strict | Prevent the AI from running stages back-to-back / skipping stages / planning without coding / overwriting history / speculating / writing bare PASS | SKILL.md §Gate system |
| Archiving discipline | specs: no overwrite — archive first; current/history; date headers | references/specs-lifecycle.md |
| Retro distillation | `/sdd-retro` writes lessons/highlights into `specs/retro/`, which can be aggregated and fed back into the framework | references/retro-protocol.md |
| Set personal preferences | `/sdd-custom` sets style, tone and habits (default 「专业可靠」 (professional & reliable)) | references/custom-protocol.md |
| What to do on errors | Troubleshooting; for Chinese/long paths prefer direct creation; capability degradation | references/troubleshooting.md |

## 4. In-domain guidance seeds (filled via the S20 interview at assembly time; optional)

> List the **in-domain** getting-started essentials and high-frequency questions most worth covering first, so `/sdd-help`'s examples and answers fit the domain closely. If left empty, use the generic topic list.

In-domain (browser-side Web front-end SPA) getting-started essentials and high-frequency questions worth covering first:
- How one and the same skill handles both the React and Vue stacks (the same SDD skeleton; the routing signatures + interviews follow the framework actually in use).
- How to untangle a legacy front-end project with `/sdd-init`: first build the `context/` cognition layer (component tree / route table / state structure / API call graph / build config), then back-derive upstream drafts as needed.
- Why the tasks stage must write real code rather than merely give a plan (gate red line 2).
- The browser default supports only Chrome ≥80/100 — how to explicitly declare support for more browsers / older versions in the constitution/spec.
- At which stage the state library (Zustand / Pinia / Vuex) is chosen (the design stage; written into `context/state-model.md`).

## 5. Relationship with /sdd-custom
`/sdd-help` explains "how to use it"; `/sdd-custom` sets "use it my way". When the "set personal preferences" topic comes up inside `/sdd-help`, you may route the user to `/sdd-custom`, but both are bound by the same gate red lines and read-only guard (see custom-protocol.md).
