# Collaboration Protocol (Detailed)

> Expansion of the "core collaboration principles" in SKILL.md. The interview's **structure, priorities, and skip conditions are frozen by the framework**; the **concrete questions per stage are the domain question bank (Web front-end)**.

## 1. Interview protocol

### Scenario clarification first (mandatory)
Before development, the interview must first reconstruct the business scenario in the user's mind, and only then move to technical breakdown. The AI must not develop directly from the literal wording of the requirement.

| Question type | Must ask |
|---|---|
| Scenario | In which business scenario does the user expect this feature/page to trigger |
| Role/object | Which page, component, hook/composable, service, or external object (API/third-party lib) participates |
| Input | Trigger conditions, parameters, sources of state (server/UI/form/URL) |
| Output | What result the user expects to see on screen |
| Success criteria | How to judge it was done right |
| Exception boundary | Which situations must never cause spurious action (race, empty data, API error) |

**Mandatory rules**:
- SCENE-01: before development, confirm the scenario with 3–5 questions.
- SCENE-02: when the user provides documents (PRD / design mockups / Swagger / OpenAPI), first turn the document content into confirmation questions.
- SCENE-03: while the scenario is not closed, output only clarification questions or drafts; never code directly.
- SCENE-04: interview conclusions must be written into spec or task; they must not stay only in the conversation.

### Interview execution flow
```
Enter stage → read existing outputs → clarify the user's scenario → identify information gaps → ask structured questions (3–5) → wait for replies → confirm understanding → write into spec/task → start writing
```

### The four question types (Web front-end examples)
| Type | Description | Example |
|---|---|---|
| Confirmation | Extract a fact from the code scan and ask the user to confirm | "Confirming the current stack is React 18 + TypeScript — correct?" |
| Multiple choice | Offer a list of options for the user to pick | "CSS scheme? □ Tailwind □ CSS Modules □ SCSS" |
| Fill-in | Offer a suggested value for the user to fill or edit | "Deployment (suggested: Vercel): ______" |
| Open-ended | No preset answer, the user describes freely | "Any special browser-compatibility needs?" |

### Design principles
- **Concrete**: avoid "还有什么要补充？" ("anything else to add?"); ask specific questions the user can answer directly.
- **Focused on the current stage**: spec asks "做什么" (what to build); design asks "怎么做" (how to build it).
- **Has defaults**: for non-critical questions, propose a suggested default and let the user confirm.
- **Priority**: multiple-choice > fill-in with a suggested value > confirmation > open-ended.

### Skip conditions
When the user has already provided sufficient information (documents/specs), questions already covered may be skipped, but you MUST: ① state "从您提供的文档提取了以下信息" ("I extracted the following information from the documents you provided") ② list a summary of the key information ③ confirm "以上理解是否正确？有遗漏吗？" ("Is this understanding correct? Anything missing?")

### Forbidden behavior
- No stage document may be produced before the interview.
- Do not assume the user's intent (it must be explicitly confirmed).
- Do not skip confirmation questions and use scan results directly.
- Do not mix another stage's content into the current stage.

---

## 2. Per-stage interview question banks (Web front-end)

> Keep 3–5 questions per stage, scenario clarification first; question types tagged [confirmation]/[multiple choice]/[fill-in]/[open-ended], asked in priority order (multiple-choice > fill-in > confirmation > open-ended).

### constitution stage
- [confirmation] "The scan shows React/Vue + TypeScript + SCSS + Vite — is this the locked stack?"
- [confirmation] "The lockfile / `packageManager` field shows the package manager is <pnpm/yarn/npm/bun> — confirm we follow this existing fact (rather than forcing pnpm)?"
- [fill-in] "Node version (suggested: the project's `.nvmrc` / `engines` value): ______"
- [multiple choice] "Target browser range? □ default latest 2 stable Chrome □ multiple browsers □ lower versions □ mobile (non-default needs an explicit declaration)"
- [open-ended] "No-go zones, minimal-change scope, decision-precedence — anything to add?"

### spec stage
- [confirmation] "In which business scenario do you expect this feature/page to be used, and by whom?"
- [multiple choice] "Language scope? □ single-language (i18n → N/A) □ multi-language (enables the RULE-I18N family)"
- [multiple choice] "Responsive scope? □ fixed single size (responsive → N/A) □ desktop only □ desktop+tablet □ fully responsive □ mobile-first"
- [fill-in] "Key performance thresholds (suggested: LCP<2.5s, INP<200ms, CLS<0.1; FID is deprecated): ______"
- [multiple choice] "Accessibility level? □ WCAG 2.1 AA (recommended) □ other □ none"; and [open-ended] "Boundaries and exceptions (network drop / API timeout / empty data / large data / concurrency / insufficient permissions / illegal input) — any to add?"

### design stage
- [confirmation] "Is this component tree accurate (pages ← components ← hooks/composables ← services ← utils)?"
- [multiple choice] "For each piece of state, which of the six categories (server/UI/form/process/persisted/shared) and native vs library? (RULE-STATE-04)"
- [multiple choice] "API contract-validation strength? □ hand-written types □ contract-generated types □ runtime schema (external high-risk boundary) (RULE-TYPE-04)"
- [fill-in] "If there is sharing/polling/offline/refresh-after-write, the cache model (owner / key & freshness / write-path→invalidated-key mapping) is (RULE-ASYNC-05): ______"
- [multiple choice] "Is there routing? □ yes (guards/lazy-loading) □ no (N/A)"; and [open-ended] "Responsive breakpoints (suggested sm:640 md:768 lg:1024 xl:1280) / observability — designed or N/A?"

### tasks stage
- [confirmation] "The task breakdown below maps each item to R*/AC* and tags RULE-* — is the mapping correct?"
- [multiple choice] "Task sequencing? □ by dependency order □ by page/module □ by risk priority"
- [open-ended] "Any files/functions that must not be touched, or a preferred order of change?"
- (before the Gate, output the development-progress clarification table: developed / not developed / blocked / next step)

### test stage
- [confirmation] "Is the test coverage sufficient against the spec acceptance points?"
- [multiple choice] "E2E scope? □ core flows □ all pages □ regression only □ not needed (N/A + rationale)"
- [multiple choice] "For key pages, run Lighthouse/axe? □ yes □ N/A (rationale)"
- [open-ended] "Is missing test infrastructure backfilled this iteration, or recorded as N/A + residual risk?"

### deliver stage
- [confirmation] "Is the delivery evidence complete and are its semantics not higher than the highest test evidence level?"
- [multiple choice] "Rollback strategy? □ build-artifact path with hash/version □ previous release tag □ other"
- [confirmation] "Are changelog / release-note / README architecture diagram / code map / context all synchronized?"
- [open-ended] "Any residual risk (N/A conditional capabilities, Gate missing/N/A items) to record in delivery risks? Anything worth a retro?"

---

## 3. Gate ritual and 4. Unified self-check
For gates see [gate-and-stages.md](gate-and-stages.md); for pre- and post-output self-checks see [self-check.md](self-check.md).
