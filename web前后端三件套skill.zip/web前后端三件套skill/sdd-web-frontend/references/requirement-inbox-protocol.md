# Requirement inbox protocol (`docs/requirements/`) — F33

> Every sdd-xx project keeps a **requirement inbox** at `docs/requirements/`. Upper-layer orchestration skills (e.g. a full-stack orchestrator like sdd-web-fullstack) land dispatch packets here; humans may also drop requirement specs or materials here. This file defines the inbox convention, the claim protocol, and the acknowledgment signal. The inbox is a **frozen framework mechanism (F33)** — every sdd-xx inherits it.

---

## 1. Why an inbox

Requirements arrive from two directions: an upper-layer AI orchestrator that splits a bigger requirement and hands this project its slice, or a human dropping a requirement spec. Both need ① one standard, predictable landing place, and ② one unambiguous signal that the requirement was picked up. Without the convention, packets scatter across `docs/` and nobody can tell "received" from "ignored".

## 2. The convention

- **Location**: `<project>/docs/requirements/` (files typically named `dispatch-YYYYMMDD-<slug>.md` when dispatched by an orchestrator, or any requirement spec a human drops in). Legacy requirement files directly under `docs/` stay readable; do not force-migrate.
- **`docs/requirements/` is a RESERVED directory name (F37)**: within any repository governed by an sdd-xx skill, this exact path may carry **inbox semantics only** — a short-lived queue that gets cleared on claim. **Never** use it to store long-lived requirement specifications, product baselines, or anything else that must survive a claim. Long-lived requirement artifacts belong in `docs/product-specs/` (see structure.md). Rationale: the claim protocol below **deletes** whatever sits in the inbox; a directory that means two things means the AI cannot tell which files are safe to delete.
- **Claim boundary**: "clear the inbox" removes **only** the claimed packet files inside `docs/requirements/`. It never touches `docs/product-specs/`, `docs/iterations/`, `docs/decisions/`, or any other `docs/` subtree.
- **Created at init**: `/sdd-init` creates `docs/` and `docs/requirements/` alongside the `specs/` structure, so the inbox exists before anyone needs it.
- **One-way**: the inbox is an intake, never a status board — this skill never writes progress back into it. Upper layers read progress from `specs/task.md` instead (see task-kanban-protocol.md).

## 3. Entry-behavior hook

On every trigger, after reading `specs/README.md` + `specs/task.md`, **check the inbox**. Non-empty → there is a pending requirement: summarize it to the user in one line and confirm claiming it (a dispatched packet that names this project is normally claimed directly; an ambiguous drop-in gets one clarifying question).

## 4. Claim protocol (register → archive a copy → clear)

Claiming a requirement is a three-step hard action:

1. **Register into specs**: append a `task.md` row and create/extend the `2-spec` entry from the requirement content (then run the normal six-stage workflow from the appropriate stage).
2. **Archive a copy inside this project**: preserve the requirement content under this project's own specs area (e.g. `specs/2-spec/inputs/`), so clearing the inbox loses nothing even when no upper-layer authoritative copy exists. (Orchestrators keep their own authoritative copy at the root; the local copy makes this project self-sufficient either way.)
3. **Clear the claimed item from the inbox.** An emptied inbox is the **acknowledgment signal** to the upper layer: "requirement received, iteration started." It is a **pickup signal, NOT a completion signal** — completion is still judged by gates and evidence.

❌ Anti-patterns: starting to code from an inbox file without registering it into specs; clearing the inbox without archiving a local copy; leaving the claimed packet in the inbox "for reference" (the upper layer will read it as not-yet-received); writing status notes into the inbox.

## 5. Working with dispatch packets from an orchestrator

A dispatch packet is written against the assumption that this session **cannot see the upper-layer project folder**. It carries the requirement slice, acceptance points, integration conventions, and a restrained list of **absolute paths** to parent files this project should read or co-maintain (interface/contract documents above all). Treat those downlinked paths as read-only references (or co-maintained files when so marked); on a broken/unreachable path, mark `⚠️ 待确认` into `open-issues.md` and ask — never guess the missing content.
