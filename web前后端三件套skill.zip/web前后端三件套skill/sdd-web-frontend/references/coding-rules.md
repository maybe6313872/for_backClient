# Web Front-end Rigid Coding Rules

> This file defines the coding rules the AI must obey in browser-side Web front-end single-page app (React / Vue + TypeScript + SCSS + Vite) development. **These rules originate from high-frequency bugs and design flaws in real projects of this domain** and are mandatory constraints for the design / tasks / test stages. Each rule is named `RULE-{topic}-{number}`, tagged during the tasks stage, and verified rule by rule during the test stage.
>
> Typical architecture: browser-side SPA (client-side rendering), layered `pages ← components ← hooks/composables ← services ← utils`, tech stack React/Vue + TypeScript + SCSS + Vite.
>
> **This document holds the "must obey" rigid rules**; there is a separate **non-gating, tailorable** index of ideological best practices (state / zod / hooks / styling / component idioms) in [frontend-best-practices.md](frontend-best-practices.md) — that one is reference orientation only, does not enter the Gate, and is not mandatory.

---

## RULE-STATE (state management)
- **RULE-STATE-01**: Never mutate state directly (React `setState`/store must return a new reference; mutate Vue reactive objects per the framework's rules). Mutating the original object in place, causing the view not to update, is a high-frequency pitfall.
- **RULE-STATE-02**: `useEffect`/`watch` dependencies must be complete; side effects (subscriptions, timers, event listeners, `AbortController`) must be released in the cleanup function to prevent memory leaks and duplicate bindings.
- **RULE-STATE-03**: Cross-component shared state goes through a global store (Zustand/Pinia/Vuex); do not prop-drill through many layers; each store slice has a single responsibility.
- **RULE-STATE-04 (classify state before choosing tooling · mandatory in design · abstraction applies to both React Hooks and the Vue Composition API)**: Before writing any state, first place the state into one of **six categories**, then decide whether to bring in a third-party capability; you **must not** freeze one sample project's "all native Hooks" or "must install library X" as the default answer.
  - **Six categories of state**: ① **server state** (comes from the backend, needs caching/invalidation/refetch, e.g. lists, details, status polling); ② **UI state** (dialog open/close, selection, tabs); ③ **form state** (field values, validation, dirty checking, submission); ④ **process/machine state** (long flows idle→running→done, steps, progress); ⑤ **persisted state** (restored from sessionStorage/localStorage/URL); ⑥ **cross-component shared state** (read/written in many places, with mismatched lifecycles).
  - **Dependency-evaluation trigger signals** (if any appears, you must evaluate whether to bring in the corresponding capability in design, and record the conclusion and rationale): cross-component sharing + caching/dedup/invalidation/polling/concurrent writes → evaluate a **server-state library (TanStack Query / SWR / Pinia Colada, etc.)**; multi-layer prop drilling or multi-slice sharing → evaluate a **global store (Zustand / Pinia / Vuex)**; field interdependencies + async validation + multi-step → evaluate a **form library (React Hook Form / VeeValidate / FormKit, etc.)**; many rows/columns + sorting/filtering/pagination/virtualization → evaluate a **table library (TanStack Table / AG Grid, etc.)**; URL deep links / back-forward navigation / route-level permissions → evaluate a **router library** (see RULE-CMPX and the conditional Gate when there is no such need).
  - **Burden of proof when choosing a native implementation (no library)**: in design, explicitly write out "which boundaries this scenario already covers" — the four states loading/error/empty/success, race conditions and cancellation, cache identity and invalidation, duplicate-submission protection, cleanup/release; mark uncovered items `[缺口]`. **"Not installing library X" is not a defect in itself; "choosing native but being unable to prove these boundaries" is.**
  - ❌ Anti-example: piling twenty-odd `useState` in the app shell to hand-maintain session/polling/cache/module orchestration, with no classification and no boundary proof.
  - ✅ Good example: design states "service-status polling = server state → use Query's `refetchInterval`; dialog open/close = UI state → local `useState`; rationale and boundaries as follows…".

## RULE-RENDER (rendering)
- **RULE-RENDER-01**: Use a stable unique `key` for list rendering; **the array index is forbidden as a key** (add/remove/reorder will scramble rendering).
- **RULE-RENDER-02**: Hooks must be called unconditionally at the top level of the component, in a fixed order; never place them inside conditionals/loops.
- **RULE-RENDER-03**: Avoid needless re-renders (sensible `memo`/`useMemo`/`useCallback`, Vue `computed`), but do not over-optimize.

## RULE-ASYNC (async and data requests)
- **RULE-ASYNC-01**: Requests that can be triggered rapidly and repeatedly must handle race conditions (`AbortController` cancellation, or discard stale responses) to prevent dirty data from overwriting fresh data.
- **RULE-ASYNC-02**: Every async data state must explicitly handle the four states `loading / error / empty / success`; leave no bare blank or freeze.
- **RULE-ASYNC-03**: Promises must have error handling (`.catch`/`try-catch`/error boundary); uncaught rejections are forbidden.
- **RULE-ASYNC-04 (per-request state matrix · land the four states onto every path · verified row by row in test)**: The four states are a principle; this rule requires turning it into **per-query / per-command acceptance evidence**. In design, fill one row of the state matrix for each async path; in test, verify each row and tag its L level:
    | Path | Not queried (idle) | Querying (loading) | Success non-empty | Success empty (empty) | Failure (error) | Stale-data refresh failed | Cancelled/stale response |
  - **Query type** must be able to reliably distinguish the seven cases above; **it is forbidden to fold the failure state into the empty state** (`catch { setData([]) }` is an anti-example — failure treated as "no data").
  - **Command/write type** additionally distinguishes: submitting, success, failure, **duplicate-submission protection** (button disabled / idempotency key), retryable or not.
  - ❌ Anti-example: `catch { setHistory([]) }` in `loadHistory`, so the UI shows "the API is down" as "no history yet".
  - ✅ Good example: distinguish `status: 'error'` from `status: 'success' && items.length===0`, rendering different UI for each; test cases cover both and keep evidence.
- **RULE-ASYNC-05 (cache domain model · mandatory answer in design when there is sharing/polling/offline/refresh-after-write · abstraction applies to both self-built caches and Query libraries)**: Writing only "the cache strategy is defined" is not enough. **A self-built short-lived cache is not wrong in itself**; the wrong part is when cache semantics are not written down and invalidation relies on the developer's memory. Whenever it involves shared server data, polling, offline recovery, or refresh-after-write, design must answer each of the following point by point and turn them into verifiable design items:
  - **Owner**: which layer owns the cache — component / service / global store / query client? (a given piece of data can have only one owner)
  - **Identity (key) and freshness**: for parameterized queries, how is the cache key (parameter identity) defined? What is the TTL / stale time?
  - **Write-back sync (invalidation)**: which mutations invalidate which keys? **You must list the "write path → invalidated key" mapping**; "the developer remembers to clear the cache when adding a write operation" is not allowed.
  - **Recovery/refresh timing**: how do reconnect-after-drop, manual refresh, window re-focus, and polling each synchronize?
  - **Concurrent writes**: how are in-flight request dedup, write-write conflicts, and optimistic-update rollback handled?
  - ✅ When using a Query library, most of the above are built-in capabilities (`queryKey`/`staleTime`/`invalidateQueries`/`refetchOnWindowFocus`); design just records the configuration. When using a self-built cache, you must fill this whole table and keep evidence in test.

## RULE-TYPE (types)
- **RULE-TYPE-01**: Do not use `any` as a fallback to mask types; when an escape is truly needed, use `unknown` + narrowing.
- **RULE-TYPE-02**: Use non-null assertion `!` and type assertion `as` sparingly; prefer type guards; enable and honor `strict`/`strictNullChecks`.
- **RULE-TYPE-03**: External interfaces (Props/Emits, API request·response) must have explicit type definitions, with the source annotated (Swagger/contract).
- **RULE-TYPE-04 (runtime boundary for API-contract consumption · graded by risk · abstraction applies to both hand-written DTOs and generated types)**: Compile-time types ≠ runtime correctness. A `as ApiEnvelope<T>` assertion passing compilation proves nothing about whether the backend actually returned that structure. In design, choose the validation strength by boundary risk and record the rationale:
  - **Stable internal interfaces**: hand-written types or **contract-generated types** (OpenAPI→TS) alone are acceptable; at minimum guarantee "contract document ↔ front-end type" consistency.
  - **External/unstable/high-risk boundaries** (third-party APIs, cross-team, auth, payment, frequently changing fields): **runtime parsing is mandatory** (a zod / valibot / io-ts schema validates at the boundary before entering business logic), with branches for abnormal responses and **non-JSON responses**.
  - **Contract-drift check**: if an interface contract document already exists, try to form a "contract doc → type definition → real response" generation or comparison chain (generate types, record real responses and compare against the schema), turning drift into a discoverable item; when automation is impossible, record the manual-verification conclusion in test and tag its L level.
  - **Classification**: missing fields / type changes / changed error-response format / non-JSON responses belong to the "exception and contract" test cases; do not test only the happy path.
  - ❌ Anti-example: `(await res.json()) as ApiEnvelope<T>` and then directly reading `payload.data`; a backend field rename surfaces only when the business page goes white.

## RULE-A11Y (accessibility)
- **RULE-A11Y-01**: Use semantic tags (`button`/`nav`/`main`/`label`…) rather than piling up bare `div`s; interactive elements must be keyboard-reachable.
- **RULE-A11Y-02**: Add `aria-*`/`alt`/visible focus styles for non-text interactions; associate form controls with a `label`.

## RULE-PERF (performance)
- **RULE-PERF-01 (conditionally applicable)**: **When routing exists**, do route-level code splitting / lazy loading (dynamic `import()`), so the first screen loads only the necessary chunk. For projects that are a **fixed single-shell SPA / have no routing**, this rule is judged **N/A** (record the N/A rationale in design); such projects should still evaluate **component-level lazy loading** for heavy modules, on-demand overlays, charts, etc. See "Conditional capabilities and the N/A mechanism".
- **RULE-PERF-02**: Memoize heavy computations / large lists or use virtual scrolling; load images on demand.
- **RULE-PERF-03**: Honor the performance budget (Core Web Vitals / bundle size, see performance-budget); exceeding the budget requires evaluation.

## RULE-SEC (security)
- **RULE-SEC-01**: Do not use bare `dangerouslySetInnerHTML` / `v-html` to render untrusted content; it must be sanitized first (DOMPurify, etc.) to prevent XSS.
- **RULE-SEC-02**: Keys/tokens/sensitive config are not hard-coded into front-end source or the repo; use environment variables + a backend proxy.
- **RULE-SEC-03**: External links with `target="_blank"` must add `rel="noopener noreferrer"`.

## RULE-STYLE (SCSS / styling)
- **RULE-STYLE-01**: Isolate component styles (CSS Modules / `scoped`); forbid global-selector pollution; avoid deep descendant selectors and `!important`.
- **RULE-STYLE-02**: Colors/spacing/font sizes/breakpoints use design tokens (see design-tokens); **no scattered magic values**.

## RULE-I18N (internationalization · **conditional rule family: mandatory only when the project enables multiple languages; single-language is explicitly judged N/A**)

> i18n is an **independent architecture and quality dimension**, not a sub-problem of "is there hard-coding". Once enabled, the same set of criteria must be maintained across spec/design/tasks/test/deliver (see the per-stage i18n items in gate-and-stages and `context/i18n.md`). **It does not fix a specific library/directory/key format** — the choice (i18next / vue-i18n / self-built, etc.) just needs to be justified. Repeatable verification is carried by `assets/tools/check_i18n.py`.

- **RULE-I18N-01 (resource ownership and registration consistency)**: A business module owns its own module's language resources; `common` / `validation` / `glossary` (terminology) each independently own their shared copy. **Do not** flatten all keys into one giant object. When adding/removing/lazy-loading a module, the module's **registration metadata, menus, permissions, and display-name translation keys** must stay in sync with the language resources — scattered mappings (registered in one place, translated in another, display name in a third) are the root cause of missing keys and orphan keys.
- **RULE-I18N-02 (visible-text classification and boundary)**: Distinguish "must be translated" from "must be shown as-is". **Must be translated**: static copy, backend enum display, user-readable presentation of API errors, ARIA/`placeholder`/`title`/notifications. **May be kept as-is** (declared in design): device codes, user input, business entities that must be shown verbatim (order numbers, etc.). **Do not** write user-visible text directly into components.
- **RULE-I18N-03 (dynamic text / interpolation / plurals / locale formatting)**: Interpolation parameters and keys need a convention and must be checkable; a missing parameter must not leak an unsubstituted interpolation placeholder (the mustache double-brace marker) to the UI; when there is quantity semantics, use **plural/select rules** rather than manual concatenation; date/time/number/currency/unit all go through a **locale-aware formatting** entry point (`Intl.*` or a library capability), **forbidding** each component doing its own `toLocaleString`/hand-rolled formatting and producing locale inconsistency.
- **RULE-I18N-04 (semantic messages over translated strings · no residue when switching language)**: Long-lived state, runtime logs, notifications, and errors **store a "semantic message" (key + params + timestamp) rather than a translated string**, translating only at render time. Otherwise, after switching language, historical logs/notifications/errors retain the old language. After switching locale, state, logs, notifications, errors, and date/number formatting must all be recomputed.
  - ❌ Anti-example: `setLogs(x => [...x, t("moduleA.success")])` bakes the translated text into state; after switching to English, the Chinese log stays on screen.
  - ✅ Good example: `setLogs(x => [...x, { key: "moduleA.success", params, at }])`, and at render time `t(log.key, log.params)`.
- **RULE-I18N-05 (unreferenced keys and dynamic keys)**: An "unreferenced key" found by static scanning may be a **false positive** caused by a dynamically concatenated key — establish an **explainable registration/review mechanism** (record the dynamic-key rules in `context/i18n.md`) rather than blindly deleting.

## RULE-CMPX (component / form / table complexity review · trigger-based, **line count is not the only threshold**)

> File length by itself is not judged wrong. The criterion is **responsibility coupling and interaction complexity**: when the signals below appear, trigger an architecture review in design, evaluate splitting or bringing in a third-party capability, and prove the trade-off.

- **RULE-CMPX-01 (responsibility-coupling review trigger)**: When one component simultaneously carries **≥2 independent async flows**, or has **cross-field interdependency/reset branches**, or has **strongly coupled states that need manual synchronization**, trigger a review: evaluate extracting a **hook/composable, service, reducer, or state machine**. The goal is to give each unit a single responsibility, unit-testable.
- **RULE-CMPX-02 (form complexity)**: multi-step, field interdependency, async validation, draft recovery — any one → evaluate a **form library**; a simple form may be native. Choosing native must be proven in design: validation, dirty checking, submit-dedup, error focus and other boundaries are covered.
- **RULE-CMPX-03 (table complexity)**: many rows/columns, sorting/filtering/pagination, row selection, virtual scrolling — any one → evaluate a **table library**; a small static table may be native. Choosing native must prove: selection, pagination, sorting, performance (virtualization) boundaries are covered.
  - ❌ Anti-example: a single `ModulePage` cramming form validation + queries + a long flow + history + progress + table selection + offline recovery, with thirty-odd `useState`, no review.
  - ✅ Good example: extract the query path into a `useQueryX` composable, use a state machine for the long flow, hand table interaction to a table library; design records each trade-off and the boundaries covered.

## Conditional capabilities and the N/A mechanism (routing / responsive / observability / i18n · frozen common mechanism)

> **Legitimate single-shell SPAs, embedded Web, and closed-environment projects** may genuinely not need routing / mobile adaptation / external monitoring. These capability items are **not unconditionally mandatory** — handle them as "trigger condition → if hit, mandatory / if not hit, judge N/A", eliminating both "over-engineering to pass the template" and "fake check-off".

| Capability | Trigger condition (if hit, mandatory) | Not hit → N/A (record rationale + residual risk) |
|---|---|---|
| Router library | URL deep link / browser back-forward / route params / route-level permissions | fixed single shell, registry + internal-key module switching → N/A |
| Responsive / mobile adaptation | must cover tablet/phone or multiple sizes | fixed-size terminal (industrial screen / all-in-one) → N/A |
| Observability / external monitoring | must have online error monitoring / performance telemetry / behavior tracking | closed intranet, no external monitoring platform → N/A |
| i18n (RULE-I18N family) | must have ≥2 languages | single language → N/A |

**Three elements of N/A (none may be missing)**: ① why the trigger condition was not hit (factual basis); ② who confirmed it (the user confirms in constitution/spec); ③ residual risk (the cost of adding the capability later if needed). N/A is recorded in design and the corresponding file under `context/`; **do not** leave an empty check or a fake pass.

---

## Process discipline (RULE-PROC · framework built-in, common to all domains, do not delete)

### RULE-PROC-01: No coding without user authorization
For any implementation-type task, first output a plan (problem understanding, impact scope, which files/functions to change, risk points, verification approach), and only lay down code after the user explicitly says "同意/实施/写入" (agree / implement / write it in).

### RULE-PROC-02: Never skip plan/test/review/gates
Stop after each of the six stages to pass the Gate and wait for clearance; the tasks stage must actually write code rather than merely produce a plan; running straight from constitution through deliver is forbidden.

### RULE-PROC-03: No speculating about external behavior, no bare PASS
Third-party interfaces / protocol fields / dependency semantics / browser compatibility range, CORS / API response contracts, third-party library versions, auth scheme, global store shape must be backed by evidence; test conclusions are graded L1–L5, never blurred into a bare PASS.

### RULE-PROC-04: specs — no overwrite; archive first, then write
Before updating current.md/task.md, first archive the old version per specs-lifecycle.
