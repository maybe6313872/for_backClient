# Development Progress Clarification Protocol

> Goal: after every completed stage, let the user clearly see what has been developed, what has not, what is blocked, and the next step — avoiding "lots of documents but unclear status".

## 1. Trigger points

| When | Action |
|---|---|
| Before a stage gate | draft the development progress table |
| After a stage gate passes | write into `specs/task.md` and show a summary in the development interface |
| When a blocker is found | immediately update Blockers and the not-yet-developed content |
| When a flow-back happens | mark the flow-back reason and the affected modules |
| Before deliver | verify that all developed/not-developed content is consistent with the test evidence |

## 2. Standard table

(This table is written verbatim into the Chinese-language `specs/task.md`, so its content stays in Chinese.)

| 模块 | 状态 | 已开发内容 | 未开发内容 | 阻塞 | 下一步 |
|---|---|---|---|---|---|
| 模块名 | 已完成/进行中/未开始/阻塞/回流中 | 文件、函数、文档、测试证据 | 具体缺口 | 责任人与原因 | 下一步动作 |

## 3. Development-interface summary

When replying to the user, show at most 5 lines (verbatim, in Chinese):

```text
开发进度：
- 已完成：...
- 未完成：...
- 阻塞：...
- 下一步：...
- 已同步：specs/task.md
```

## 4. Chart suggestion

(Node labels stay in Chinese — the chart appears in Chinese-language documents.)

```mermaid
flowchart LR
    A[已开发] --> B[已完成文件/文档/测试证据]
    C[未开发] --> D[缺口与原因]
    E[阻塞] --> F[待澄清/待外部依赖/待测试]
    F --> G[下一步动作]
```

## 5. Prohibitions

- Do not write only "已完成" (done) without listing the not-yet-developed content.
- Do not write "编译通过" (build passed) as "功能完成" (feature complete).
- Do not show lengthy details in the development interface; the details belong in the stage files.
- Do not omit the `task.md` sync status.
