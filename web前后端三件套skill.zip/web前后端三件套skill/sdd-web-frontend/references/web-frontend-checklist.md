# Web Front-end Quality Checklist

> **Browser default (this domain's convention · the authoritative value is in [environment-and-tools.md](environment-and-tools.md) §versioned baseline table)**: unless otherwise specified, the **target = the latest 2 stable Chrome versions**; lower versions are not supported, and compatibility with other browsers is not considered by default. Multi-browser / lower-version / mobile support must be explicitly declared by the user in the constitution/spec (triggering conditional capability, see coding-rules "Conditional Capability and N/A Mechanism"). The 'Responsive' and 'Browser Compatibility' items below **are expanded only when the corresponding trigger condition is hit**; otherwise mark N/A (record reason + residual risk).


## Build and Engineering

- [ ] `pnpm install` runs without errors
- [ ] `pnpm build` builds successfully
- [ ] `pnpm lint` has no errors (warnings need evaluation)
- [ ] `pnpm typecheck` (if present) passes type checking
- [ ] Build artifact size is within budget
- [ ] No unused dependencies (`depcheck`)
- [ ] No known security vulnerabilities (`pnpm audit`)

## Code Quality

- [ ] TypeScript strict mode has no errors
- [ ] No `any` type escapes (use `unknown` when necessary)
- [ ] Component Props have complete type definitions
- [ ] No hardcoded magic numbers/strings
- [ ] Error boundaries are set up (React ErrorBoundary / Vue errorCaptured)
- [ ] Async operations have loading/error state handling
- [ ] Forms have input validation

## Performance

- [ ] Route-level code splitting (lazy/dynamic import)
- [ ] Images use modern formats (WebP/AVIF) + responsive sizes
- [ ] Large lists use virtual scrolling
- [ ] Avoid unnecessary re-renders (React.memo / computed / $derived)
- [ ] Core Web Vitals meet targets (**LCP < 2.5s, INP < 200ms, CLS < 0.1**; INP has replaced FID, the authoritative value is in the versioned baseline table)
- [ ] Font loading strategy (font-display: swap / preload)

## Accessibility (WCAG 2.1 AA)

- [ ] Semantic HTML (header/nav/main/footer/article/section)
- [ ] Images have alt attributes
- [ ] Form controls have associated labels
- [ ] Color contrast meets targets (4.5:1 body text / 3:1 large text)
- [ ] Fully keyboard-operable (Tab/Enter/Escape/Arrow)
- [ ] Focus indicator is visible
- [ ] ARIA attributes used correctly
- [ ] Screen reader testing passes

## State and Requests (RULE-STATE-04 / ASYNC-04 / ASYNC-05 / TYPE-04)

- [ ] State is placed into the six categories (server/UI/form/flow/persistence/shared), with evidence-based selection; where native is chosen, boundary coverage is evidenced
- [ ] Every async chain has its four states + race + cancellation verified item by item (idle/loading/success-non-empty/success-empty/error/stale-data-refresh-failure/cancellation), **failure state not merged into empty state**
- [ ] Command/write operations have duplicate-submission protection
- [ ] (When there is sharing/polling/offline/refresh-after-write) the cache owner, key, **write-path → invalidation mapping**, and focus/polling/resume sync are documented and verified
- [ ] API contract boundaries are graded by risk; external high-risk boundaries have runtime validation; abnormal/non-JSON responses have branches

## Internationalization (i18n · **Conditional: check when multi-language is enabled; mark the whole section N/A for single-language**)

- [ ] `check_i18n.py` passes: no missing/extra keys across languages, interpolation params consistent
- [ ] Orphan/unreferenced keys have been reviewed (dynamic keys are registered, not blindly deleted)
- [ ] No user-visible text written directly into components (backend enums / API errors are categorized and translated)
- [ ] Long-lived state/logs/notifications/errors store "semantic messages" rather than already-translated strings
- [ ] Date/time/number/currency/unit go through a unified locale-aware formatting entry point
- [ ] Language-switch regression: state/logs/notifications/errors/formatting leave no residual old language
- [ ] Module registration metadata, menus, permissions, and language resources are consistent (added/removed/lazy-loaded modules are synced)

## Responsive (**Conditional: expand when the trigger condition is hit; mark the whole section N/A for a fixed single-size terminal**)

- [ ] Mobile layout works (from 320px)
- [ ] Tablet layout works (768px)
- [ ] Desktop layout works (1024px+)
- [ ] Touch targets >= 44x44px
- [ ] No horizontal scrollbar
- [ ] Images/videos don't overflow their containers

## Browser Compatibility (**Conditional: by default only the latest 2 stable Chrome versions; the items below are expanded only after multi-browser is explicitly declared**)

- [ ] Latest 2 stable Chrome versions (**default sole target**)
- [ ] Latest 2 Firefox versions (only when multi-browser is required)
- [ ] Latest 2 Safari versions (only when multi-browser is required)
- [ ] Latest 2 Edge versions (only when multi-browser is required)
- [ ] iOS Safari (only when mobile is required)
- [ ] Android Chrome (only when mobile is required)

## Security

- [ ] No XSS risk (user input is escaped)
- [ ] No sensitive information hardcoded (API Key/Secret)
- [ ] HTTPS enforced
- [ ] CSP header configured (if applicable)
- [ ] Dependencies have no known vulnerabilities
