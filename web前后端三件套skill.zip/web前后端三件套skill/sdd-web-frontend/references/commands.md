# Command Set (`/sdd-*`) + Chinese Equivalents + Routing

> Project commands `/sdd-init|update|docs|iterate|tidy|retro` are handled by this skill **only when the current project matches this domain's signature** (`package.json` + `vite.config.{ts,js,mjs}` + a `react` or `vue` dependency + `tsconfig.json`, see detection.md and the SKILL.md routing section). Commands are entry points that land in Mode A/B and the specs lifecycle hooks. **Every command has Chinese natural-language equivalents (frozen, F9)** — slash commands are hard to memorize; the equivalents below trigger the identical action and are the authoritative list (keep them consistent with SKILL.md and detection.md).

| Command | Chinese equivalents | One-line duty | Lands in |
|---|---|---|---|
| `/sdd-init` | 「梳理这个项目」「接手这个老项目」「建立项目认知」 | Build/rebuild project cognition (README + context/ + code map + knowledge map); also creates `docs/` + the `docs/requirements/` requirement inbox (F33) | Mode B |
| `/sdd-update` | 「规整工作台」「归档文档」「清理 specs」 | Workbench maintenance: inspect & archive `task.md`, every `current.md` | specs lifecycle "pre-iteration inspection" hook |
| `/sdd-docs` | 「整理文档」「把 docs 文本化」 | Docs governance: inspect `docs/`, textualize as needed, maintain `docs/converted/README.md` | docs adapter |
| `/sdd-iterate` | 「开始新迭代」「实现××功能」「按规格做需求」 | Forward iteration: six stages, per-stage gates | Mode A |
| `/sdd-tidy` | 「规整项目目录」「收拾项目结构」「整理目录结构」 | Structure tidy-up: gated scan→plan→execute against this domain's structure.md; moves/archives only, never deletes | tidy protocol (F35) |
| `/sdd-retro` | 「复盘本次对话」「总结这次的教训」「这次做得好记一下」 | Retrospective: structure mistakes/wins into `specs/retro/` (reads code only) | retro loop |
| `/sdd-help` | 「怎么用这个 skill」「使用帮助」 | Onboarding (skill meta-command): interactive guidance, step-by-step Q&A | onboarding protocol |
| `/sdd-custom` | 「设置我的偏好」「记住我的习惯」 | Personalization (skill meta-command): interactively set style & habits | preference protocol |

## `/sdd-init`
Precondition: source-encoding check (UTF-8 — front-end sources are UTF-8; watch for stray BOM/CRLF); does a README already exist (if so, self-check & update rather than rebuild from zero).
Actions: structure scan → generate/refresh the code map (madge / ts-morph / @vue/compiler-sfc) → write the twin L0–L4 → generate/refresh the knowledge map → **ensure `docs/` and the `docs/requirements/` requirement inbox exist (create if missing — F33, see [requirement-inbox-protocol.md](requirement-inbox-protocol.md))** → coverage self-check, report gaps.

## `/sdd-update`
Workbench maintenance, **not forward development itself** (that is `/sdd-iterate`). Actions: inspect date headers & status → archive whatever is "已交付待归档" or belongs to the previous iteration per specs-lifecycle → extract essentials into a clean current.md → report.

## `/sdd-docs`
Follows the [docs-binarification-adapter.md](docs-binarification-adapter.md) contract: `--check` finds what needs converting → textualize with the zero-dependency `scripts/xlsx_to_csv.py` (xlsx→CSV) plus the built-in pdf/docx skills → products into `docs/converted/` → `--write` records → report. Usage: see [document-tools.md](document-tools.md).

## `/sdd-iterate`
Precondition: read README+task.md first; README missing with legacy code → suggest `/sdd-init` first. Start triggers the "pre-iteration inspection". Actions: strictly constitution→spec→design→tasks→test→deliver, **stop at each gate for approval**; the tasks stage must write real code, not just a plan. See [gate-and-stages.md](gate-and-stages.md).

## `/sdd-tidy`
Structure tidy-up (F35, full protocol: [tidy-protocol.md](tidy-protocol.md)). Three gated steps: **scan** (read-only diff of the actual layout vs this domain's structure.md, plus archive-state / sources.md / inbox checks) → **plan** (tidy plan table: current path → target → reason → risk; unclassifiable = ⚠️ 待确认, never guessed) → 🚦 gate, then **execute approved rows only** and report before/after. Safety: never delete, never touch business source code, archive-first on any overwrite, pending inbox requirements left alone.

## `/sdd-retro`
Trigger: the user says 「复盘这次」「总结教训」「这次做得好」, or the deliver exit gate suggests it, or periodic retro.
**Reads code and outputs only; writes only `specs/retro/`** (zero blast radius). Actions: ① run the structured retro schema (what happened [record excuses verbatim] → expected → root cause [no guessing] → which gate should have caught it → improvement actions [mark [框架候选]] → generalizability → status) → ② write/append `specs/retro/retro-YYYY-MM-DD-<topic>.md` → ③ update the `specs/retro/README.md` ledger. Full protocol: [retro-protocol.md](retro-protocol.md).

## `/sdd-help` (skill meta-command, not signature-restricted)
Trigger: the user says 「怎么用」「帮我介绍下这个 skill」「有什么命令」「这个门禁啥意思」 or `/sdd-help`.
**Read-only, pure conversation**: changes no project or skill files, starts no six-stage/twin workflow. Actions: interactive onboarding — a one-line welcome + a multiple-choice question to locate the user's interest, then one topic per turn on demand; **never dump a wall of text or recite the whole SKILL.md**. Full protocol: [help-protocol.md](help-protocol.md).

## `/sdd-custom` (skill meta-command, not signature-restricted)
Trigger: the user says 「设置我的偏好」「自定义风格」「记住我的习惯：……」 or `/sdd-custom`.
Actions: interactively set the base style tone (5-tier enum, default 「专业可靠」) and usage habits → run the **pre-write compliance check** on every entry (conflicts with the framework ⇒ refuse and explain) → user confirms → **write only** `preferences/user-preferences.md`. **Two guards (red line 6)**: preferences always rank below framework rules; the skill is read-only except the preference file/retro folder. Full protocol: [custom-protocol.md](custom-protocol.md).

## Commands and natural language
Commands are shortcuts; without one, SKILL.md mode detection routes natural language (including the Chinese equivalents above) to the same flows. **Project commands** (init/update/docs/iterate/tidy/retro) are bound by routing signatures, lifecycle hooks and gates; **skill meta-commands** (help/custom) need no project and ignore signatures; if ownership is unclear with multiple skills installed, ask the user in one line.

## Out of this domain
This skill focuses on browser-side SPAs locked to **React / Vue + TypeScript + SCSS + Vite**. It explicitly does **not** claim (nor force-fit) Svelte, Next.js, Nuxt.js, Astro, SolidJS, the Electron renderer process, Webpack projects, or SSR/SSG server-side-rendering projects. When those fingerprints match, tell the user this skill does not cover that shape.
