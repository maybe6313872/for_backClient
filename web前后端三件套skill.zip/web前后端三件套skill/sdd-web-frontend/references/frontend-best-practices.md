# Front-end Best-Practice Ideas (guidance · **non-gate · trimmable · non-mandatory**)

> **Positioning**: This is an **index of ideas and methods**, provided for design/tasks to reference and weigh. **It is not a hard rule, does not enter any Gate, and is not a checklist item.** The rigid constraints live only in the RULE-\* of [coding-rules.md](coding-rules.md); this document gives only "the usually-better default leanings" and "when they don't apply", to avoid dogma.
>
> React uses Hooks, Vue uses the Composition API; the ideas below apply equally to both. **Whenever they conflict with the project's existing style, an explicit requirement, or an evidence-based technical decision, the project always wins** — you must not use this document to demand that the user switch to a particular library, directory layout, or style.

## State Management
- **Think of server state and client state separately**: hand remote data to the Query ecosystem (TanStack Query / SWR / Pinia Colada) to manage caching, invalidation, and refetching; use local state for local interaction state. *Doesn't apply*: a one-off request with no sharing and no caching — native is enough.
- **Derived state over stored state**: if it can be computed from existing state, don't store a second copy (avoid desync). Compute during render / `useMemo` in React; `computed` in Vue.
- **Colocation**: put state in the smallest scope that actually needs it; lift it up or move it into a store only when sharing is needed — don't globalize from the start.
- **Global store (Zustand / Pinia)** is for genuinely cross-domain sharing; for a single local layer with a consistent lifecycle, props / context are enough.

## Data Fetching and Validation
- **Validate at the boundary with a schema**: `parse` external/unstable responses with `zod`/`valibot` before they enter the business logic; derive the type via `z.infer`, so "runtime validation + static type" is defined in one place. *Doesn't apply*: a stable internal API can use only generated types.
- **Prefer handing request side effects to the Query ecosystem** rather than hand-writing `useEffect`; when hand-writing is genuinely required, handle the four states + race conditions + cancellation (see RULE-ASYNC).

## hooks / composition
- **Extract reusable logic into a `use*` custom hook / composable**: prefixed with `use`, single responsibility, returning a stable interface.
- **"You might not need useEffect"**: if it can be computed during render or in an event callback, don't cram it into an effect; effects are only for syncing with external systems (subscriptions, DOM, network, timers).
- **Use `useReducer` / a state machine for complex interrelated state** instead of a pile of mutually-entangled `useState` (echoing RULE-CMPX).
- Follow the rules of hooks (top level, not in conditions/loops, see RULE-RENDER-02).

## Style Management
- **Isolation first**: pick CSS Modules / `<style scoped>` / another explicitly-scoped approach, to avoid global-selector pollution and deep descendant selectors.
- **Tokenize**: colors/spacing/font-sizes/breakpoints go through design tokens; don't scatter magic values.
- **The approach is not mandatory**: CSS Modules / CSS-in-JS / atomic (Tailwind, etc.) each have trade-offs; pick per the team's existing style — don't switch stacks just to be "trendier".

## Types
- **Schema-first**: what can be defined once with zod and `infer`-red into a type shouldn't be hand-written as a duplicate type.
- Explicit types for external interfaces; let TS infer internally as much as possible; replace `any` with `unknown` + narrowing (see RULE-TYPE).

## Components
- **Composition over configuration**: compose with children / slots; don't pile a single component up to 20 boolean props.
- **Think through controlled vs uncontrolled**: for forms/inputs, be clear who holds the source of truth.
- **Error boundaries + Suspense** (React) / async component boundaries (Vue) to catch loading and failure states.
- Use stable keys for lists; using `key` to force-reset a subtree is a legitimate technique.

## Performance (good enough is enough; don't optimize prematurely)
- **Measure before optimizing**: apply `memo`/`useMemo`/`useCallback` and `computed` where proven necessary; don't wrap mindlessly.
- Virtualize large lists, lazy-load routes/heavy modules (when there's routing), load images on demand.

---

> To reiterate: the above are **default leanings, not checklist items**. Evidence-based different choices in a project are entirely legitimate; this document always yields to the RULE-\* of coding-rules and the project's existing constraints.
