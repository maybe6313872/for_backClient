# Mode B: Code → Cognition Layer (with Code-Doc Twin)

> **Positioning (frozen)**: the core of Mode B is **not** mechanically converting source code into Markdown, and **not** piling up a code graph. The core is:
>
> ```text
> legacy code + scattered materials
>   → specs/context/ structured cognition layer
>   → reverse-derived SRS, high-level design, detailed design, test cases, and the basis for subsequent iterations
> ```
>
> `context/` is a **bridge layer**, not the endpoint; its success criterion is "whether it can reliably support the downstream backfilling of formal documents", not how large `specs/` is. The code-doc twin (the implementation facts of modules/architecture/data-model) is one layer inside the cognition layer — it is **kept**; the code graph is an **optional auxiliary tool**, see §7.
>
> **Twin granularity L0–L4, the coverage self-check, and incremental sync are frozen by the framework; the "keep/omit" focus, the domain global state model, scenario-chain seeds, and evidence cross-check material sources are domain slots (see business-slots S6).**

## 1. What to omit, what to keep (Web front-end)
The twin is not pasted source code: it re-expresses intent, structure, and behavior in structured text, so that a person who has never read the source (or a fresh AI session) can safely continue the work from it.

- **Keep**: each component/module's responsibility and boundary; the component public interface (**Props / Emits / Slots**); the signatures, purpose, and side effects of hooks/composables; state slice structure and state flow; **the routing table and guards**; API service functions (endpoint/method/request·response types); the contracts of key util pure functions; cross-component data flow; external touchpoints (see below).
- **Omit**: JSX / template line by line, local variables, pure style details, import lists the code map can derive mechanically, boilerplate.
- **External touchpoints (EXTERNAL_TOUCHPOINTS, the focus of evidence-strength labeling)**: backend API, browser API (`fetch`/`WebSocket`/`localStorage`/`IndexedDB`), third-party SDKs, route navigation, global store reads/writes.

## 2. Five-layer organization of the cognition layer `context/` (frozen)
`context/` **is organized by "project cognition / architecture / modules / scenarios / evidence", not flattened along the source directory tree**. (Per the language protocol, the generated `context/` documents themselves are written in Simplified Chinese for the user.)

| Layer | Question it answers | Typical artifacts |
|---|---|---|
| Project level | What the project is, feature scope, domain terminology | `features.md`, `domain-model.md` |
| Architecture level | How it is layered, how data flows, the rendering/routing model | `architecture.md`, `data-model.md` |
| Module level | How a single component/page/service works | `modules.md`, `modules/*.md` |
| Scenario level | How multiple modules chain into a business flow | `scenarios/*.md` |
| Evidence level | Which source/materials/tests the conclusions come from | `evidence-trace.md` |

> **The scenario layer is a first-class citizen**: module docs explain "how one piece is implemented"; scenario docs explain "how the real business chain actually runs". Cross-component chains (such as the auth flow or the form-submit flow) are where maintenance problems cluster, so a component description alone is not enough. `scenarios/` template: `assets/templates/context-scenarios.md`.

Twin granularity still lands as L0–L4:
- **L0 project level → `specs/README.md`**: overview, tech stack (React/Vue + TS + SCSS + Vite), build & run, **inventory of implemented features**, component/context index, coding style, reference-document index.
- **L1 architecture level → `context/architecture.md` (+ `data-model.md`)**: layer responsibilities (pages ← components ← hooks/composables ← services ← utils), the SPA rendering/routing model, main data flows, stable design constraints.
- **L2 module level → `context/modules.md` (+ `modules/*.md`)**: per-component/module responsibility, public interface table (Props/Emits/Slots/exported functions), key types, dependencies, internal-logic narrative, known limitations.
- **L3 function/component level → per-entry inside module docs**: signature, purpose, parameters, returns/errors, side effects, callers/callees, key branches and states, touched external touchpoints.
- **L4 code map / source index → `context/code-map.md` (optional, see §7)**.

The domain **global state/data model** lands in two files (S6 option B):
- `context/state-model.md`: the six-category state classification + cache model, store slice structure + state flow (action/mutation → store → view); state library **Zustand (React) / Pinia·Vuex (Vue)**;
- `context/data-model.md`: DTO / entity types / API response models.

## 3. Document purity rules (frozen · the focus of this revision)
The body of `context/` **contains only closed facts** — never process language. Three kinds of content must be kept apart:

| Type | Where it goes |
|---|---|
| Confirmed project facts, design facts, source-code behavior | `specs/context/` |
| Conflicts, doubts, items pending verification, material inconsistencies | `specs/open-issues.md` |
| Tasks currently in progress, next steps, TODOs | `specs/task.md` |

This rule matters more than formatting: the most common Mode B failure is mixing "what I am currently analyzing / what is still missing / what might be risky" into the deliverable body, which leads later AI sessions to treat unconfirmed content as fact and keep expanding on it. `open-issues.md` is the **global governance inbox** — template: `assets/templates/context-open-issues.md`; its 「处理口径」 (handling guidance) field must state clearly how the body should phrase the matter and what is left unwritten for now — never just write 「待确认」 ("to be confirmed").

## 4. Evidence-strength labels + conflict rule (frozen)
Mode B must distinguish the evidence strength of its conclusions. **To avoid confusion with the delivery gate's L1–L5 numbers, Mode B uses textual labels, not numeric codes** (these Chinese labels are written verbatim into the generated documents):

| Label | Meaning | Web example |
|---|---|---|
| **静态可见** (statically visible) | Statically visible in the current source code | component definitions, Props types, route config, store slices, API call sites |
| **资料互证** (cross-checked with materials) | Statically visible + cross-checked against project materials | PRD, Figma/design drafts, Swagger/OpenAPI, requirement docs |
| **运行佐证** (runtime-corroborated) | Statically visible + materials + run/test evidence | build logs, Vitest/E2E test records, Lighthouse/axe reports |

**Conflict rule**: when materials conflict with source code, the `context/` body **is written per the source-code facts**, and the conflict goes into `open-issues.md`. It is **forbidden** to fill in unevidenced behavior with 「通常 / 应该 / 按经验」 ("usually / should / by experience") — for example, guessing an API's error codes or a state's default value. The consolidated evidence sources land in `context/evidence-trace.md`.

## 5. Workflow (frozen)
Step0 encoding check (Web sources are uniformly UTF-8 without BOM, generally no mojibake — keep it brief) → Step1 structure scan (optionally generate the source index) → Step2 component/module identification and boundaries → Step3 layered cognition writing (label evidence strength on every technical detail; anything uncertain goes into open-issues, not the body) → Step4 scenario-chain mapping → Step5 coverage self-check → Step6 confirm with the user → Step7 incremental sync.

## 6. Coverage self-check (quantified, frozen)
- Component coverage = documented components ÷ total components in the source index; module coverage and type coverage likewise. Without a source index, use a manual component inventory as the denominator.
- Produce an **uncovered list**; for each item choose one of two: ① fill it in, or ② explicitly mark 「暂不展开+原因」 ("not expanded for now + reason"). **Silent omission is not allowed.**
- Consistency self-check: spot-check whether the component Props / API endpoints / types in the docs match the source; mismatches go into `open-issues.md`.

## 7. Code graph = optional source coverage index (its "optional" nature is frozen)
> The source coverage index is Mode B's **optional** auxiliary tool, used to help the AI inventory the source stock, entry points, dependencies, and potential omissions. It is **not deliverable body text, not an arbiter of facts, requires no database, requires no visualization, is not required for every project, and can be rebuilt or discarded at any time**.

**Hard boundaries**: ① **optional** — Mode B works just fine without a Python/tooling environment; ② **lightweight** — prefer JSON/Markdown; do not make SQLite the default; ③ **auxiliary** — it only helps the AI miss fewer files/entry points/impact areas; ④ **does not arbitrate facts** — conclusions are decided by the source code, original materials, test evidence, and human review; ⑤ **no pursuit of visualization** — humans read `context/`, not graph pages. Name the directory `source-index`; do **not** default to `code-graph` (the word `graph` easily tempts expansion into a heavyweight platform).

It answers only three questions: which source files/entry points/symbols exist in the project; which are already covered by `context/` and which may be missed; and which source evidence to revisit when reverse-deriving a given module/scenario. Interactive graphs, graph databases, HTML workbenches, and MCP services beyond these three questions do not enter this framework's default practice.

**Generation (capability detection + degradation, consistent with environment-and-tools.md)**: prefer the ecosystem tools **madge** (dependency graph) / **ts-morph** (TS AST) / **@vue/compiler-sfc** (Vue SFC parsing), or the bundled zero-dependency script `assets/tools/build_source_index.py` (copy it into the project's `specs/_tools/` and run; scanning `.ts .tsx .js .jsx .vue .scss`); with no Node/Python tools available, **the AI builds the source inventory and coverage table manually per code-map.md**, with equivalent effect. Machine artifacts go into `specs/_generated/source-index/` and are **never mixed into the `context/` body**.

## 8. Separation of machine artifacts and human-authored body (frozen)
Anything auto-generated goes into `specs/_generated/` — rebuildable / cleanable / optionally uncommitted; project-level scripts go into `specs/_tools/`; the human-deliverable body goes into `specs/context/` and must be readable/reviewable/citable. `context/` may reference `_generated/` as an "auxiliary index entry point", but the sources of fact remain the source code, materials, and test records.

## 9. Reverse-derivation relationship to downstream formal documents (success criterion)
The granularity of `context/` is judged by **whether the downstream documents can be reverse-derived from it**:

| Downstream document | Main context inputs it relies on |
|---|---|
| SRS | `features.md`, `domain-model.md`, `scenarios/*.md`, `evidence-trace.md`, `open-issues.md` |
| High-level design | `architecture.md`, `data-model.md`, `state-model.md`, `modules.md`, `scenarios/*.md` |
| Detailed design | `modules/*.md`, key interface/type/data-structure contracts, code-map |
| Test cases | `scenarios/*.md`, `open-issues.md`, evidence-strength labels |

> **Actually reverse-deriving these documents** (detailed design / high-level design / SRS drafts) follows [mode-b-reverse.md](mode-b-reverse.md): source code's reverse-derivation power decreases up the chain; the SRS is **inevitably incomplete**; gaps get placeholders/drafts, and **guessing is forbidden**; artifacts land in `docs/reverse/`.

## 10. Incremental sync (anti-rot, frozen)
Triggers: legacy code was changed / one Mode A deliver passed. Steps: re-run the source index (or manual diff) → locate the affected components/scenarios → update only the affected spots → append one line to `context/iteration-log.md` → unclosed items go into `open-issues.md`. Check coverage once against the docs before each deliver round.

## 11. Interfacing with Mode A
Switching from B to A: once the cognition layer covers "external interfaces (Props/API) + key logic + main scenario chains", Mode A iteration may begin, completing the rest as you iterate. A writes back to B: the deliver Gate's "doc sync" means incrementally writing this round's results back into README/context and closing out the resolved open-issues. If the docs are not updated, the Gate does not pass.
