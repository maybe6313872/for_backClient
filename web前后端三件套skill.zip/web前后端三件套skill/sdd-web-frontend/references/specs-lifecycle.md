# specs Lifecycle and Archiving Mechanism (Required Reading)

> This is a **required module**. It defines the domain model of the `specs/` workspace, the lifecycle of its documents, the archiving discipline, and which actions fire at which moments (hooks). The core iron rule: **no document under `specs/` may ever be directly overwritten or deleted — to update, archive the old version first, then write the new workbench version.** Violating this rule loses the project's evolution history and is a severe error.

---

## 1. Why this mechanism exists

`specs/` is the project's long-term memory. If the AI directly overwrites `2-spec/current.md` in a new iteration, or clears `task.md` when switching tasks, the history is gone — nobody can trace back "what the previous version's requirements were, and why they were changed this way". So we model `specs/` as a **stateful workspace with archiving discipline**: every document class is split into a "workbench (current/active)" side and a "history (archive)" side; updates follow "archive first, then create anew"; and fixed hooks automatically perform archiving and refresh at the key moments.

---

## 2. Domain model: workbench vs history

Every document class has **one workbench version** (currently active, readable and writable) and **a set of history versions** (read-only, archived by date).

| Workbench (active document) | History archive location |
|---|---|
| `specs/task.md` | `specs/task/YYYY-MM-DD-<说明>.md` |
| `specs/1-constitution/current.md` | `specs/1-constitution/history/YYYY-MM-DD-<说明>.md` |
| `specs/2-spec/current.md` | `specs/2-spec/history/YYYY-MM-DD-<说明>.md` |
| `specs/3-design/current.md` | `specs/3-design/history/YYYY-MM-DD-<说明>.md` |
| `specs/4-tasks/current.md` | `specs/4-tasks/history/YYYY-MM-DD-<说明>.md` |
| `specs/5-test/current.md` | `specs/5-test/history/YYYY-MM-DD-<说明>.md` |
| `specs/6-deliver/current.md` | `specs/6-deliver/history/YYYY-MM-DD-<说明>.md` |

> Note the naming difference (consistent with the established convention): `task.md` archives into the **`specs/task/`** directory; the six stages' `current.md` files archive into their own **`history/`** subdirectories. **`<说明>` is NOT free text**: it MUST begin with an entry from the controlled archive-description vocabulary declared in this skill's `structure.md`, optionally followed by a hyphen and a free qualifier — `YYYY-MM-DD-<词表条目>[-<自由补充>].md`. ✅ `2026-06-02-需求澄清-新功能X`、`2026-06-15-测试验收`。❌ `2026-06-15-登录重构`（迭代名不是词表条目）、`2026-06-20-2026-06-19`（日期）、`2026-07-02-归档`（零信息量）。The vocabulary is language-bound and stays Chinese.
>
> If the design stage's optional subdirectories (`preliminary/`, `overall/`, `detailed/`) are used, their history likewise goes into their own `history/`; `current.md` always remains the stage's minimal workbench entry point.

---

## 3. Date header (mandatory · frozen field set · basis for staleness detection and archive naming)

**All seven workbench documents — the six stages' `current.md` and `specs/task.md` — MUST carry exactly one date header as their first line.** It is the machine-readable handle on the workbench: §5 composes the archive filename from it, the pre-iteration inspection judges staleness from it, the entry and exit gates check it, and archive `INDEX.md` rows copy two of its fields. A workbench document without a valid date header is a defect: fix it before any stage work continues (§4).

**Canonical form (language-bound literal — copy byte for byte, never translate):**

```
<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
```

**Frozen field set — exactly these three names, in this order, no synonyms, no extras:**

| Field | Meaning | Value rules |
|---|---|---|
| `迭代标识` | the task this workbench currently serves | short Chinese phrase, e.g. `新功能X`; identical across all seven documents of one iteration |
| `迭代日期` | the start date of this iteration | `YYYY-MM-DD`; used verbatim as the archive filename prefix at §5 |
| `状态` | workbench state | **exactly one** member of the frozen set below — never free text, never an enumeration |

**Status enumeration (frozen closed set):**

| `状态` value | Meaning | Set by |
|---|---|---|
| `就绪` | Ready: the workbench is clean and can receive a new iteration's input | after an archive completes, or at `/sdd-init` scaffolding |
| `进行中` | In progress: being filled by the current iteration | when a new iteration starts |
| `已交付待归档` | Delivered, pending archive: content belongs to a completed iteration | after the deliver Gate passes |

**This table is the single definition site of the status enumeration.** No other file may restate the set of legal values; every other file references this table.

**Parsing contract (frozen):** the separator between fields is ` | ` (space, vertical bar, space); the separator between a field name and its value is `: ` (colon, space); the `状态` value is a **single** enum member. Consequently the header splits into **exactly three** segments — `header.strip('<!- >').split('|')` yields 3, and `segments[2].split(':', 1)[1].strip()` yields one member of the frozen set.

**Value rule for a concrete header (this is where the old defect lived):** a real header records **the document's current state only**. Writing `状态: 进行中|已交付待归档` — an enumeration of the alternatives — is non-conforming. The alternatives are documented in the table above and nowhere else; no example header anywhere in this framework may show more than one status value, because `|` is the field separator and an inline enum makes a three-field header parse as four. Both trailing fragments then look like legal status values, so the parse does not fail — it silently yields a wrong one, which is strictly worse than a crash.

**Hard rules:**

1. **No renaming.** `迭代编号`, `迭代ID`, `日期`, `iteration-id` and every other spelling are **non-conforming**. A child skill may not redefine these names — this is framework-frozen, language-bound literal content (F32), not a business slot.
2. **No extra fields.** Extra metadata belongs in the document body or in `task.md`, never in the header — appending a fourth field breaks every consumer's positional assumptions.
3. **Scripts grep the literals.** Any detector, gate script or index generator MUST match the three names above verbatim. A script grepping any other name is a defect whatever it appears to return: it fails **silently**, matching nothing and falling back to a default. Verify a script's pattern against this table whenever it is written or reviewed.
4. **`状态` transitions.** `就绪` → `进行中` when a new iteration starts; `进行中` → `已交付待归档` once the deliver Gate passes (the signal that archiving is due before the next round of work, §4/§6); `已交付待归档` → `就绪` only through a completed §5 archive, which writes a fresh header. A header whose `状态` is missing, empty, or outside the frozen set is treated as **not ready** and reported to the user — never guessed, never defaulted.

> The seven seeds under `assets/templates/` — the six stages' `current.md` plus `task.md` — each carry this canonical header as their **first line**, in the single-value form, seeded with `状态: 就绪`: an untouched template is scaffolding, not work in progress (§3 status table; the §4 `就绪` determination explicitly covers "contains only template placeholders"). They are the alignment target — copy the shape from them rather than re-deriving it. **Documented exception:** the `context-*.md` cognition seeds are **not** workbench documents and carry no three-field header — `context-i18n.md` and `context-state-model.md` use a deliberate two-field comment (`<!-- <文档名> | 更新日期: YYYY-MM-DD -->`), the remaining ones carry a `> 最后更新：` body line or no date marker at all. A detector must therefore scope itself to the seven workbench documents named above; one that walks every `.md` under `specs/` will flag the whole cognition layer as defective.

---

## 4. Document lifecycle states

A `current.md` moves between the three states of the frozen set defined in §3:

```
就绪 / Ready (empty / brand-new, able to receive a new iteration's input)
   │  new iteration input + user go-ahead
   ▼
进行中 / In progress (being filled by this iteration)
   │  this iteration's deliver passes
   ▼
已交付待归档 / Delivered, pending archive (content belongs to a completed iteration)
   │  pre-iteration inspection / user explicitly confirms the iteration is done
   ▼
(archive into history/, extract the essential information → write a fresh header with 状态: 就绪)
```

**`就绪` determination**: current.md is empty, or contains only template placeholders, or its date header `状态` reads `就绪`. Any other in-set value (`进行中` / `已交付待归档`) means **not ready** while a new iteration is about to start → archive first (see §5).

**Out-of-set handling (frozen).** A header whose `状态` field is **missing, empty, unparseable, or outside the frozen set of §3** is judged **not ready**, and the condition is **reported to the user with the file path**. Never guess the value, never default it to `就绪`, and never proceed as if the workbench were clean — an unreadable status is exactly the case where the archive filename cannot be safely composed either (§5 step 1).

**Presence rule (frozen).** While an iteration is in flight:

1. **Every stage this iteration has already entered MUST have its `current.md`.** "Entered" = the stage was worked on in this iteration, or its gate was passed — regardless of whether its content was later archived. A stage with a `history/` but no `current.md` is a **hollow state**: an illegal, transient-only condition, never a resting shape of the workspace.
2. **Stages not yet reached MUST NOT be faked.** Do not pre-create empty `current.md` files for stages this iteration has not started: absence is the honest signal that the stage has not been entered, and detection (detection.md) reads it that way. Creating them would make detection report progress that does not exist.
3. **Archiving is atomic with respect to presence.** The §5 archive is not complete until the replacement `current.md` exists with a valid date header (§3). "Moved the old content into `history/`" and "wrote the new `current.md`" are one indivisible action; never end a turn, a session, or a gate between them.
4. **Repairing a hollow state.** On finding a stage with `history/` but no `current.md`: report it, read the newest archive in that `history/` (its date-header `迭代标识` tells which iteration it served), and reconstruct a minimal `current.md` — **date header + a carry-forward section holding the still-valid conclusions extracted from that archive, plus an explicit line stating it was reconstructed from `history/<file>` on `<date>`**. Never silently invent stage content, and never re-run the stage as if it had never been done: what actually happened is recorded in the archive, and open questions go to `open-issues.md`. A placeholder-only reconstruction (header + `[待澄清] 本阶段结论待从归档回填`) is acceptable and honest; a fabricated one is not.
5. `specs/task.md` follows the same rule: it always exists while an iteration is in flight, is archived per §5, and its replacement is written in the same action.

---

## 5. Archive operation (standard actions)

When a workbench document must make way for a new iteration, or is asked to update existing content, perform the following steps (**never overwrite directly**):

1. **Read the date header** to obtain the `迭代日期` (iteration date) and `迭代标识` (iteration identifier), and compose the archive filename `YYYY-MM-DD-<说明>.md`. **Then check the archive directory (all levels, §10) for that name and disambiguate per §11** — collision → append the smallest unused two-digit ordinal from `-02`; never overwrite, never use time-of-day, never improvise a suffix.
2. **Move** the current `current.md` content to the corresponding history location (stage → `<stage>/history/`, task → `specs/task/`). That is, create that file in the history directory and write the old content into it (preserve the full original text, no trimming).
3. **Extract the essential information into a new, clean `current.md` — mandatory, in the same action**: the archive is incomplete until this file exists. Distill the conclusions that remain valid and that the next iteration must carry forward (stable constraints, unclosed items pending confirmation, the current state of external interfaces) into the new current.md, and write a proper new date header (§3) — status `就绪` until the new iteration actually starts, then `进行中`; all other detail stays in the history file, retrievable when needed. If there is genuinely nothing to carry forward, still create the file with its date header plus a one-line placeholder — **never leave the stage without a `current.md`** (§4 presence rule).
4. **Keep the workbench tidy**: the new current.md holds only "content relevant to the current iteration" — do not pile history into it.

> How much information to extract is an engineering judgment: the principle is "the next iteration should be able to start correctly without digging through history", but do not copy whole chunks of history into the new current.md.

---

## 6. Hooks: trigger moment → action

This is the executive core of the mechanism. At the following moments, perform the corresponding actions per the table. The `/sdd-*` commands are the explicit entry points for these hooks (see commands.md).

| Hook | Trigger moment | Action |
|---|---|---|
| **Pre-iteration inspection** | The user raises a new requirement to start a new iteration; or `/sdd-update` is run; or `/sdd-iterate` starts | Inspect `task.md` and every `current.md`: for any with status=`已交付待归档`, or content clearly belonging to the previous iteration → first perform the §5 archive; archive the old `task.md` into `task/` and create this iteration's kanban; **run the external-input-copy freshness check (§9)**; only start work after confirming all workbenches are "ready" |
| **Input-copy freshness** | Pre-iteration inspection; or before any stage consumes an external-copy file | Compare each copy against its `sources.md` registration per §9; stale → report to the user and re-copy on approval — never proceed silently with a stale copy |
| **Stage gate passed** | The user explicitly says "passed / proceed to the next stage" | Finalize that stage's `current.md` (update the date header); update the coarse-grained progress checklist in `task.md`; provide a development-progress clarification |
| **Iteration delivered** | The user explicitly says "this iteration is done"; or the deliver Gate passes (gate-and-stages exit gate) | Archive this iteration's `task.md` into `task/` and prepare/clear the kanban; mark/archive each stage's `current.md` as needed; **refresh the code map and knowledge map**; append one iteration record line to `context/iteration-log.md` |
| **No-overwrite interception** | Any action that would overwrite or delete an existing document under `specs/` — including the routine case "this stage's `current.md` still belongs to the previous iteration and I am about to write the new one" | **Archive in place, then continue — do not stop and report an error.** Sequence: ① read the existing document's date header → ② perform the full §5 archive (compose `YYYY-MM-DD-<说明>.md`, move the content into the archive location at its currently deepest level per §10, resolve any name collision per §11, write the `INDEX.md` row) → ③ create the clean `current.md` with the new date header and the extracted carry-forward conclusions → ④ write the intended new content → ⑤ tell the user, in one line, what was archived and where. Only stop and ask when the date header is missing or unreadable and the archive name cannot be determined (§4). ❌ Never report "cannot overwrite" and leave the archiving to the user; ❌ never append the new iteration's content below the old content in the same file |
| **Structure tidy-up** | `/sdd-tidy` runs (F35) | Within the approved plan: archive any workbench document found stale (status `已交付待归档` or belonging to a previous iteration) per §5; restratify archive directories that crossed a §10 threshold; create/refresh every level's `INDEX.md`. **Plan-gated and move-only** — nothing is archived or moved before the user approves, and nothing is ever deleted (tidy-protocol.md) |
| **docs changed** | `docs/` has additions/updates; or `/sdd-docs` | Recompute source-document hashes/dates, compare against `docs/converted/README.md`, re-textify as needed and update the index (see document-tools.md) |
| **Code structure changed** | Code changes; or a Mode A deliver | Re-run the code map (codemap), diff out the changes, update the twin documents and knowledge map of the affected modules (see code-map.md, mode-b-code-twin.md) |

**Archive trigger whitelist (frozen, closed).** Archiving fires at exactly these five moments and nowhere else: ① pre-iteration inspection (incl. `/sdd-iterate` kickoff) · ② `/sdd-update` invoked directly · ③ `/sdd-tidy`, inside its approved plan · ④ **a no-overwrite interception hit** · ⑤ the deliver exit gate / "iteration delivered". **Map to the table above**: ① and ② are the two entry points of the same first table row (Pre-iteration inspection), which is why five whitelist moments come from eight table rows; ③ is **Structure tidy-up**; ④ is **No-overwrite interception**; ⑤ is **Iteration delivered**. The remaining three rows (Input-copy freshness, Stage gate passed, docs/code changed) are hooks that do **not** archive. Two consequences follow. **No other moment archives spontaneously** — an archive firing outside this list is an unrequested side effect. And **every moment on this list archives without being asked** — encountering one of these five and not archiving is the omission this whitelist exists to prevent. Trigger ④ is the one most often skipped: it is a normal, expected, in-flow action, not an error path.

---

## 7. Relation to commands and to the two modes

- `/sdd-update` = explicit trigger of the "**pre-iteration inspection**" hook (workbench maintenance: inspection + archiving + tidiness), see commands.md.
- `/sdd-init` = rebuild project cognition (Mode B); refresh the code map and knowledge map when done.
- `/sdd-docs` = trigger the "docs changed" hook.
- `/sdd-iterate` = start the Mode A full workflow; internally it triggers the "pre-iteration inspection" at kickoff, "stage gate passed" at each stage, and "iteration delivered" at the end.

Whichever mode or command is taken, **the no-overwrite rule is always in force**.

---

## 8. Anti-examples and corrections

**Anti-example 1: direct overwrite**
❌ A new iteration arrives, and the requirements are rewritten directly in `2-spec/current.md`.
✅ First archive the old `current.md` to `2-spec/history/2026-06-02-旧需求.md`, extract the still-valid constraints into the new current.md, write a new date header, and only then start writing the new requirements.

**Anti-example 2: clearing task.md when switching tasks**
❌ The previous bug is fixed, and `task.md` is cleared and directly rewritten with the new task.
✅ Archive the old `task.md` to `specs/task/2026-06-02-修复某缺陷.md`, then create this task's kanban anew.

**Anti-example 3: starting work without the pre-iteration inspection**
❌ The previous iteration's `4-tasks/current.md` is still full of last time's tasks, and new tasks are added straight into it.
✅ The pre-work inspection finds its status = 已交付待归档 → archive first → do this iteration's breakdown in a clean current.md.

**Anti-example 4: hauling all the history into the new current.md when archiving**
❌ After archiving, the old content is copied wholesale into the new current.md, so the workbench stays bloated.
✅ Extract only the conclusions the next iteration must carry forward; leave the rest in the history file, retrievable when needed.

**Anti-example 5: archiving task.md by appending into one rolling file**
❌ The iteration ends, and a summary of `task.md` is appended to `specs/task-archive.md`; the next iteration appends after it, and so on.
✅ Archive the whole `task.md` to `specs/task/2026-06-02-任务执行-新功能X.md` (full original text, no trimming), then create the new kanban. The archive destination is a **directory, one file per iteration** — there is no single-file form (task-kanban-protocol.md §4). A file named `task-archive.md`, if present at all, is a convention note, never a destination.

---

## 9. External input copies: `sources.md` registry + freshness check

Directories holding **copies of external materials** (e.g. `specs/2-spec/inputs/`, `docs/requirements/<迭代>/inputs/` — requirement-spec snapshots, script copies, protocol excerpts) sit outside the archive discipline above but have their own staleness failure: the source updates and the copy silently rots, then a stage consumes the stale copy.

**Registry**: each such directory keeps a `sources.md` (template: `assets/templates/sources.md`) with one row per copy: copy filename · source path/URL · capture time · source version/mtime/content-hash at capture · notes.

**Freshness check (hard action at pre-iteration inspection, and before any stage consumes a copy)**:
1. For every row in `sources.md`, compare the source's current mtime / version / content hash against the recorded capture values (read-only).
2. Mismatch → **report the stale copies to the user and re-copy on approval** (then update the registry row); an unreachable source → mark `⚠️ 待确认` into `open-issues.md`.
3. ❌ Never carry a known-stale copy into spec/design silently; ❌ never add a copy without registering it in `sources.md`.

---

## 10. Archive directory stratification (F36)

Archive directories only ever grow — the no-overwrite iron rule guarantees it. Left flat, an archive root eventually holds hundreds of same-shaped filenames and stops being readable, which silently kills the long-term memory this whole mechanism exists to protect. The rules below are **frozen meta-rules**: they fix the mechanism, the thresholds and the mandatory index, **not** any domain's path names, level-naming format or index layout style — those stay in this skill's `structure.md`.

**R1 — every archive directory must carry a stratification rule.** In scope: `specs/task/`, every `<stage>/history/` (including the design stage's optional `preliminary|overall|detailed/history/`), and any additional archive directory this domain declares in `structure.md`. A directory with no declared rule is a defect, reported by `/sdd-tidy`.

**R2 — thresholds (counted per directory, archive `.md` files only; `INDEX.md` is never counted):**

| Situation | Layout |
|---|---|
| ≤ 30 archive files | flat, directly under the archive root |
| > 30 archive files | one subdirectory per year: `<archive-root>/YYYY/` |
| any single year > 60 archive files | one subdirectory per month inside that year: `<archive-root>/YYYY/MM/` |

`YYYY` and `MM` are taken from the archive filename's own date prefix (`YYYY-MM-DD-<说明>.md`), never from the filesystem mtime. Crossing a threshold does not trigger an immediate move: it marks the directory **due for stratification**, executed per R5. Restratify only the directory that crossed the threshold; sibling directories keep their current shape. Once stratified, a directory never falls back to flat, even if files are later consolidated.

**R3 — year and month only; never per-week, never per-day.** Per-day directories reproduce the flat problem one level down — one file per directory is not a layer. Per-week directories are ambiguous across month/year boundaries (ISO week 1 can hold December dates) and unreadable to humans, who cannot map a date to a week number by inspection. Any other granularity (per-quarter, per-iteration, per-author) is out of contract.

**R4 — every level carries an `INDEX.md`.** The archive root always has one; after stratification each `YYYY/` (and each `YYYY/MM/`) has its own. Field set (the table header is language-bound and stays Chinese):

```
| 文件名 | 迭代标识 | 日期 | 一句话摘要 | 状态 |
```

- **文件名**: the archive filename, as a relative link.
- **迭代标识 / 日期**: copied from that file's date header (§3); an unreadable header → `⚠️ 待确认` plus an `open-issues.md` entry, never a guess.
- **一句话摘要**: one line stating what this version settled — written when archiving, not reconstructed later.
- **状态**: `已归档` by default; `已废弃` for a version superseded without ever being delivered.

Rows are sorted by date, newest first. A parent level's `INDEX.md` does not repeat its children's rows — it lists each child directory with its date range and file count. Writing the `INDEX.md` row is **part of the §5 archive action**: an archived file with no index row is an incomplete archive.

**Grandfathering (frozen)**: files archived **before** this rule landed are `pre-R4` legacy and are **never retroactively judged incomplete** — the "incomplete archive" verdict applies only to archive actions performed **after** the rule is in force. On its first run in a project, `/sdd-tidy` proposes back-filling the missing `INDEX.md` rows **inside the plan gate**, row by row, approved by the user; it never reports a pre-R4 archive root as a defect and never writes an index row without approval. A directory that has been through one approved back-fill leaves legacy status permanently.

**R5 — stratification is executed by `/sdd-tidy` as a plan, never silently.** The scan reports stratification debt, the plan table shows every `current path → target path` move, the 🚦 gate waits for approval, and only approved rows execute (tidy-protocol.md). Constraints: **move only — never delete, never rename** (the `YYYY-MM-DD-<说明>.md` filename is preserved verbatim; only its directory changes); `INDEX.md` files are created/refreshed inside the same approved plan; a move that would overwrite an existing file reroutes through the §5 archive discipline and the §11 collision rule. The routine §5 archive action always writes into the archive root's **currently deepest applicable level** — it never creates a new level on its own.

---

## 11. Archive filename collisions (same-day, same-description)

Same-day collisions are routine, not exceptional: `迭代日期` is the iteration's **start** date and `迭代标识` is stable across the iteration, so every archive of one iteration composes the same name. A mid-iteration flow-back, a second `/sdd-update`, or a repeated no-overwrite interception (§6 trigger ④) all reach §5 step 1 with a name that already exists in the archive directory.

**Rule (frozen, deterministic).** Before writing an archive file, check whether the composed name already exists — **at any level of the archive directory** (§10: the root, `YYYY/`, `YYYY/MM/`); a stratified sibling counts as a collision.

- No existing file → write `YYYY-MM-DD-<说明>.md` unchanged. **The first archive of a name never carries a suffix.**
- Collision → append a two-digit ordinal, starting at `02`: `YYYY-MM-DD-<说明>-02.md`, then `-03`, `-04`, …
- The ordinal is the **smallest unused** two-digit number ≥ 02 for that `YYYY-MM-DD-<说明>` stem; gaps left by earlier moves are refilled rather than skipped. Beyond `-99` (never observed in practice), stop and ask the user — do not widen to three digits silently.
- The pattern stays `YYYY-MM-DD-<说明>[-NN].md`. `<说明>` remains a short Chinese description and the date prefix keeps its exact position, so §10 stratification and `INDEX.md` generation continue to parse it.

**Prohibitions:**
- ❌ **Never overwrite an existing archive file.** An archive directory is append-only; this is the no-overwrite iron rule applied to the archive itself, and violating it here destroys history in the very act of "archiving" it.
- ❌ **Never use time-of-day in the filename** (`-1432`, `-143207`, ISO timestamps). It is unreadable, breaks the established date-prefix pattern, and encodes a moment nobody needs — what distinguishes two same-day archives is their order, not their clock time.
- ❌ **Never improvise** `-v2` / `-new` / `-final` / `-old` / `-fix` or English suffixes. Two files with the same stem differ only by ordinal.
- ❌ **Never rename or renumber an existing archive file** to make room. Existing names are immutable, including during §10 stratification moves.

**`INDEX.md` (§10)** lists suffixed files as ordinary rows; their 一句话摘要 should state what distinguished this archive from the same day's earlier one (e.g. `回流修正后二次归档`).

---

## 12. In-stage increments: the increment container (frozen meta-rule)

§2's model has two slots — workbench and history. Real iterations produce a third kind of content: **in-stage small increments** arriving mid-flight (a hotfix note, a corrected acceptance point, an inserted small requirement, one re-run test case). With nowhere to put them they either get appended into the stage `current.md` until the workbench no longer describes one coherent iteration (violating §5.4), or they live outside `specs/` entirely — in chat, or a stray root file — and disappear at the next session.

The framework freezes the mechanism, **not its shape**:

1. **Every stage MUST provide an increment container.** A declared place, belonging to that stage, where in-stage small increments land. Its concrete form — a subdirectory, a fixed section inside `current.md`, or a separate file — is defined by this domain's `structure.md`. What is not optional: it exists, and `structure.md` names it. An undeclared container means the stage cannot accept increments.
2. **Registration is mandatory; nothing floats outside specs.** Landing an increment means **both**: one entry in the container (date · trigger/source · one-line content · which stage owns it · status) **and** one coarse row in `specs/task.md`. An increment discussed only in conversation, or dropped in a file outside `specs/`, is **not registered** and counts as an incomplete change under G5 — the same standing as business code with no specs entry.
3. **A container never moves a stage boundary.** An increment is admitted only if its content is already allowed in that stage (see the per-stage allowed/forbidden table in gate-and-stages.md). Content belonging to another stage is **still moved or flowed back** to that stage — the container is not a loophole around stage boundaries, the flow-back protocol, or the gates. ❌ "It is small, so it can stay in test" is exactly the failure this rule blocks.
4. **Containers archive with their stage.** At archive time the container's content archives together with that stage's `current.md` (§5), preserving the full text. Entries still open at archive time are carried into the new iteration's container **or** raised into `open-issues.md` — never silently dropped, never left orphaned in a stale archive.
5. **Increments are re-checked at the gate.** Accumulated increments are reviewed when that stage's gate runs; an increment that touches an acceptance point, an interface, or a test conclusion **re-opens** the corresponding gate item. Increments do not bypass gates by being small.

> Relation to §9: `sources.md` governs *copies of external inputs* (freshness). The increment container governs *this project's own mid-iteration deltas* (registration). They are different mechanisms — do not merge them.
