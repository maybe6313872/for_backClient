# `/sdd-tidy` — project structure tidy-up protocol (F35)

> **Origin (why this command exists)**: field experience shows AI coding tools — when taking over a project, or through their own long maintenance — leave the file/directory structure non-standard: docs scattered at the root, specs artifacts in wrong folders, stale copies nobody registered, inbox misuse, archive discipline violated, orphan temp files. `/sdd-tidy` is the standard, gated way to clean this up. It is a **frozen framework mechanism (F35)**: the command's semantics, gates, and safety rules below are inherited by every sdd-xx; **the domain's target layout itself is NOT defined here** — it comes from this skill's own `structure.md` (the domain best-practice layout each sdd-xx fills in), which `/sdd-tidy` enforces.

---

## 1. Scenario and scope

Use `/sdd-tidy`（or 「规整项目目录」「收拾项目结构」「整理目录结构」）when:
- taking over a project whose docs/specs layout does not match this domain's `structure.md`;
- after long iteration drift: files landed in the wrong folders, temp/experiment files accumulated, archives were skipped;
- an AI session (this one or a previous one) made a mess and the user asks to clean it up.

**Scope**: `specs/`, `docs/`, and stray project-management files (README fragments, loose requirement docs, temp notes) at the project root. **Out of scope**: business source code layout (that is a refactoring task for Mode A, never done silently by tidy), build outputs governed by the toolchain, and anything under `.git/`.

## 2. Three-step flow (gated, plan before touch)

1. **Scan (read-only)** — run the whole checklist below; every item is read-only, nothing is moved, renamed or written in this step:
   - **Layout & lifecycle baseline**: diff the actual layout against this domain's `structure.md`; also check date headers/archive states (specs-lifecycle), unregistered external copies (`sources.md`), inbox misuse (`docs/requirements/` holding non-requirement junk), machine artifacts mixed into `context/` (belong in `_generated/`/`_tools/`).
   - **Reserved-name and same-name violations (F37)**: long-lived specifications parked in `docs/requirements/` — the next claim clears that directory and destroys them, so propose moving them to `docs/product-specs/`; plus any two directories that share one name while carrying different semantics, lifetimes or naming rules anywhere in the repo.
   - **Archive stratification debt (specs-lifecycle §10)**: for every archive directory (`specs/task/`, each `<stage>/history/`, any archive root declared in `structure.md`) count its archive files against the §10 thresholds, and check that every level carries an `INDEX.md` covering all of its entries.
   - **Evidence single landing point**: the same evidence file present in two locations, or an evidence class written outside the `structure.md` landing-point table; plus broken conclusion→evidence links in `5-test/current.md` (evidence-gate-protocol.md §7).
   - **Archive filename vocabulary**: archive filenames whose `<说明>` prefix misses the archive-description vocabulary declared in this domain's `structure.md` (reported only — never renamed).
2. **Plan**: produce a **tidy plan table** — one row per item: current path → target path (or "archive to …") → reason (which convention it violates) → risk. Unclassifiable files get `⚠️ 待确认` rows with a question, **never a guessed destination**. **🚦 Gate**: show the full plan and wait for the user's explicit approval; partial approval is allowed (execute approved rows only).
3. **Execute + report**: perform the approved moves/archives, then re-scan and show the before/after summary. Log the tidy as a coarse `task.md` entry. `/sdd-tidy` is trigger ③ of the specs-lifecycle §6 archive whitelist: archiving stale workbenches and restratifying archive directories happen **here**, inside the approved plan — never as an improvised side effect during the scan.

## 3. Safety rules (frozen, each violation is an error)

- **Never delete**: tidy only moves, renames, or archives. Content that looks obsolete is archived per specs-lifecycle (archive-first), never removed.
- **Never touch business source code**: moving/renaming source files is refactoring, not tidying — propose it as a separate Mode A task instead.
- **No guessing destinations**: a file whose correct home is not determined by `structure.md` or by asking → stays put, listed as `⚠️ 待确认`.
- **Archive discipline holds**: any move that would overwrite an existing file reroutes through archive-first-then-write; if the collision is between two archive filenames, resolve it with the specs-lifecycle §11 ordinal suffix — **never** overwrite, and never rename the file already in place.
- **Respect the inbox**: pending requirement files in `docs/requirements/` are never "tidied away" — they are claimed per requirement-inbox-protocol.md or left alone.
- **One gated plan, no silent side-effects**: nothing moves before the plan gate passes; anything discovered mid-execution goes into a follow-up plan, not an improvised move.
- **Evidence: consolidate, never repair silently**: duplicated evidence is consolidated to the declared landing point by *moving* the authoritative copy and archiving the rest (never deleting); a **broken conclusion→evidence link is reported only** — tidy never rewrites a conclusion's evidence path, because deciding which file a conclusion meant is a judgment for the test stage, not for tidy.
- **Archive filenames: report, never rename**: an archive file whose `<说明>` misses the controlled vocabulary is listed as a `⚠️ 待确认` row together with the suggested entry — `/sdd-tidy` **MUST NOT rename it**. Renaming an archived file breaks every inbound link (task.md, history.md, knowledge-map, retro entries), and re-authoring someone else's archive label is a judgment call, not a tidy-up. The user renames it, or leaves it; either is acceptable.
- **Stratification moves preserve names**: when executing archive stratification (specs-lifecycle §10), files move between levels only — the `YYYY-MM-DD-<说明>.md` filename is never rewritten, files are never merged, and the level's `INDEX.md` is refreshed in the same approved plan. A stratification plan that also renames or prunes files is rejected and re-planned.

## 4. Division of labor with the mother skill (for sdd-xx maintainers)

This protocol (command semantics, three-step flow, safety rules) is frozen and identical across all sdd-xx. What each sdd-xx supplies is the **target layout**: its own `structure.md` (and any domain-specific "known junk patterns" worth adding to the scan, e.g. build leftovers typical of the stack — an optional prose seed). When the mother skill's blueprint `structure.md.tmpl` evolves, `/sdd-tidy` automatically enforces the new layout after backfill — no change to this file is needed.
