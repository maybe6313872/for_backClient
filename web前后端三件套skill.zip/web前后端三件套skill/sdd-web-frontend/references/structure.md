# Standard Directory Structure and Naming Conventions

> The standard structure of `specs/` and `docs/`. Core: each stage has `current.md` + a `history/` archive; `task.md` archives into `specs/task/`; `context/` is organized by the **five-layer cognition** (not flattened by source directory); textualized `docs/` artifacts go into `docs/converted/`, and Mode B reverse drafts go into `docs/reverse/`. Archiving discipline is in [specs-lifecycle.md](specs-lifecycle.md) — **direct overwriting/deletion is forbidden**.

## specs/ standard structure

```
specs/
├── README.md                  ← project cognition document (L0, shared by both modes, the information base for all stages)
├── task.md                    ← global task kanban (must-read as step 2 of every session; carries a date header)
├── task/                      ← archive directory for task.md history (YYYY-MM-DD-<说明>.md)
├── open-issues.md             ← global governance inbox: doubts/conflicts/pending verification (purity rules; template context-open-issues.md)
├── retro/                     ← retrospectives and experience distillation (written by /sdd-retro)
│   ├── README.md              ←   retro ledger/index (template retro-readme.md)
│   └── retro-YYYY-MM-DD-<主题>.md ← one entry per topic (template retro-entry.md)
├── context/                   ← project cognition layer (five layers: project cognition/architecture/modules/scenarios/evidence)
│   ├── features.md            ← project level: inventory of implemented features
│   ├── domain-model.md        ← project level: domain terminology/model (as needed)
│   ├── architecture.md        ← architecture level: layering / SPA rendering·routing model / data flow (L1)
│   ├── data-model.md          ← architecture level: DTO/entity types/API response models
│   ├── state-model.md         ← architecture level: global state slices and state flow (Zustand/Pinia/Vuex)
│   ├── environment.md         ← architecture level: runtime environment and dependencies (Node/pnpm/Vite/deploy)
│   ├── modules.md             ← module level: component/module index and public interfaces (L2/L3)
│   ├── modules/               ← module level: single-component/module detail docs (as needed, 00-xxx.md)
│   ├── scenarios/             ← scenario level (first-class citizen): cross-component business chains
│   │   ├── README.md          ←   scenario index (one sentence / one line per chain)
│   │   └── <xxx-chain>.md     ←   a single chain (template context-scenarios.md)
│   ├── evidence-trace.md      ← evidence level: source/material/test provenance and evidence strength for key conclusions
│   ├── code-map.md            ← code map / source index entry point (optional, Mode B's L4)
│   ├── knowledge-map.md       ← knowledge map (navigation desk: topic → where to look)
│   ├── iteration-log.md       ← append-only iteration log: one line per delivered iteration (a FILE, not an archive directory — see F37; formerly context/history.md)
│   ├── api-contracts.md       ← Web recommended: backend API interface contracts + runtime boundary/contract drift (RULE-TYPE-04)
│   ├── performance-budget.md  ← Web as-needed: performance budget (LCP<2.5s/INP<200ms/CLS<0.1/Bundle)
│   ├── browser-compat.md      ← Web as-needed: browser compatibility matrix (default only Chrome latest 2 stable)
│   ├── design-tokens.md       ← Web as-needed: design tokens
│   └── i18n.md                ← Web as-needed (multi-language): languages/resource ownership/dynamic text/formatting/validation (RULE-I18N)
├── _tools/                    ← project-level scripts (optional); deterministic check tools (check_iteration_docs / derive_gate_status / check_i18n / build_source_index) can be copied here from the skill's assets/tools, zero-dependency
├── _generated/                ← machine artifacts (rebuildable/cleanable), e.g. source-index/; never mix into context/
├── 1-constitution/  current.md + history/ + <increment container>
├── 2-spec/          current.md + history/ + <子功能>/ + clarify-log.md(optional) + <increment container>
├── 3-design/        current.md + history/ + preliminary|overall|detailed/(optional) + <increment container>
├── 4-tasks/         current.md + history/      ← two-phase: plan → gate → execute → gate; + <increment container>
├── 5-test/          current.md + history/ + records/ + reports/ + captures/ + <increment container>
└── 6-deliver/       current.md + history/ + <increment container>
```

## docs/ structure (user input documents and artifacts)

```
docs/
├── <original input documents: SRS/protocols/design-draft exports, possibly binary>
├── requirements/              ← requirement inbox (F33, created by /sdd-init) — RESERVED NAME, inbox semantics ONLY: upper-layer dispatch packets / human-dropped requirement specs; claim = register into specs → archive a copy (e.g. specs/2-spec/inputs/ or docs/product-specs/) → clear the inbox (see requirement-inbox-protocol.md)
├── product-specs/             ← long-lived requirement specifications / product baselines (survive claims, never cleared). NEVER store these in requirements/ — that directory is emptied on claim (F37)
├── converted/                 ← textualized artifacts (see docs-binarification-adapter.md)
│   ├── README.md              ←   index and mapping + hash/date
│   ├── manifest.json          ←   machine-readable verification ledger
│   └── <same-name folder>/    ←   binary → a folder of the same name, one file per workbook
└── reverse/                   ← Mode B upstream reverse drafts (reverse-derived from source, isolated from the forward six stages)
    ├── README.md              ←   index + reverse-derivation date + reachability distribution + open gap count
    ├── detailed-design.draft.md
    ├── high-level-design.draft.md
    └── srs.draft.md
```
> Reverse drafts always carry `.draft` and a "reverse-derivation completeness declaration" header; **before user confirmation they are drafts and must not be treated as the source of truth**. Protocol: [mode-b-reverse.md](mode-b-reverse.md).

## Naming conventions

| Type | Naming rule | Example |
|------|---------|------|
| Current version | `current.md` (with a date header) | `specs/2-spec/current.md` |
| Stage history | `history/YYYY-MM-DD-<描述>.md` | `2-spec/history/2026-06-15-用户登录.md` |
| task history | `specs/task/YYYY-MM-DD-<描述>.md` | `specs/task/2026-06-15-登录重构.md` |
| Detailed/overall design | `3-design/detailed|overall/` (optional) | — |

- **Workbench vs history**: each stage's workbench is `current.md` (with a date header); history goes into that stage's `history/YYYY-MM-DD-<说明>.md` (`<说明>` = a short Chinese description); `task.md` history goes into `specs/task/`. **Overwriting/deleting is forbidden — archive first, then write.** Archive directories are themselves stratified once they grow (≤30 flat / >30 by year / a year >60 by month, each level carrying an `INDEX.md`) — see specs-lifecycle.md §10; `/sdd-tidy` executes the moves under a plan gate. Same-day, same-description collisions are disambiguated by a two-digit ordinal from `-02` (`YYYY-MM-DD-<说明>-02.md`; the first file stays unsuffixed) — see specs-lifecycle.md §11.
- **The name `history` is reserved for stage date-archives only (F37)**: `<stage>/history/` holds `YYYY-MM-DD-<说明>.md` snapshots of a workbench document, and nothing else in the repository may share that name with a different meaning. Two neighbours that are deliberately NOT called `history`: the append-only iteration log is `context/iteration-log.md` (a file, not an archive), and version-indexed contract snapshots live in `contracts/openapi/versions/v<version>/` (indexed by semantic version, not by date — orchestration-class only). Rule of thumb: **date-indexed archive → `history/`; version-indexed snapshot → `versions/`; append-only running record → `*-log.md`.**
- **Stage workbench presence**: every stage the current iteration has entered has its `current.md`; stages not yet reached have none (absence is the honest "not entered" signal — never pre-create empty stage files). A stage holding a `history/` but no `current.md` is a hollow state and must be repaired per specs-lifecycle.md §4.
- **Date header**: the top of every current.md and task.md carries `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->` (iteration id | iteration date | status) — **exactly three ` | `-separated fields**, the third holding **exactly one** value of the frozen closed set (`就绪` / `进行中` / `已交付待归档`) defined in specs-lifecycle.md §3. **Never write the enumeration inline**: inside the header `|` is the field separator and nothing else, so an inline enum makes a three-field header parse as four and silently breaks every parser. The three field names are frozen; scripts must grep these literals. Basis for archive naming and staleness detection.
- **README/context**: read `specs/README.md` before entering any stage; `context/` splits out overlong content and contains the two navigation maps — the **code map** and the **knowledge map**.
- **Document purity (Mode B)**: the `context/` body contains only closed facts; doubts/conflicts go into `open-issues.md`; in-flight tasks go into `task.md`. The three must never be mixed (see mode-b-twin.md §3).
- **Machine-artifact separation**: auto-generated artifacts go into `_generated/` (rebuildable/discardable), project scripts go into `_tools/`, and they are **never mixed into the `context/` body**; `context/` may reference `_generated/` as an auxiliary index entry point, but the sources of fact remain the source code, materials, and test records.
- **Increment container (F4/F19 meta-rule)**: each stage declares where its **in-stage small increments** land — `a fixed 「本迭代增量」 section at the tail of each stage's `current.md` (front-end iterations are small-grained and frequent; a separate subdirectory would fragment the workbench)` (e.g. an `increments/` subdirectory per stage, or a fixed 「本迭代增量」 section at the tail of each `current.md`). Every increment is registered **both** in the container and as a coarse row in `specs/task.md`; increments never carry content belonging to another stage (that flows back); the container archives together with its stage. Full protocol: specs-lifecycle.md §12.

## Evidence landing points (F7 meta-rule — this table is REQUIRED)

Each evidence class has **exactly one** authoritative location. Fill every row for this domain; add domain-specific rows as needed; leaving the table unfilled is an assembly defect (red line 2). Conclusions reference these paths — evidence files are never duplicated across locations.

| Evidence class | Authoritative path | Written by | Archive / retention |
|---|---|---|---|
| Test execution records | `specs/5-test/records/` (Vitest/Jest/Playwright/Cypress run logs) | test stage | archives with 5-test |
| Build artifacts / build logs | `specs/_generated/build-logs/` (`pnpm build` output, bundle stats) | tasks / deliver stage | rebuildable, never archived |
| Coverage / benchmark / audit reports | `specs/5-test/reports/` (Lighthouse / axe / coverage / CI reports) | test stage | archives with 5-test |
| Screenshots and captures | `specs/5-test/captures/` (browser screenshots / screen recordings) | test / deliver stage | archives with 5-test |
| Machine-generated indexes | `specs/_generated/` | tools (`specs/_tools/`) | rebuildable, never archived |

Rules: ① a class absent from this table MUST NOT be written anywhere — declare it here first; ② the same evidence file MUST NOT be stored twice (reference the path instead); ③ every `5-test/current.md` conclusion carries a project-relative path into one of these locations. Full protocol: evidence-gate-protocol.md §7.

## Archive description vocabulary (`<说明>` controlled list — REQUIRED)

Archive filenames are `YYYY-MM-DD-<说明>.md`. `<说明>` MUST start with one entry from the table below, optionally followed by `-<自由补充>` for specificity. This makes `specs/task/` and every `history/` directory searchable by semantics instead of by opening each file. The entries are **language-bound content and stay Chinese verbatim** (F32) — never translate them.

**Common entries (frozen — every sdd-xx inherits all of them; a domain MAY append rows, MUST NOT delete any):**

| 词条 | 适用场景 |
|---|---|
| `需求澄清` | 需求访谈、澄清轮次、验收点确认的归档 |
| `设计定稿` | 概要/详细设计定稿、架构决策的归档 |
| `任务执行` | 任务拆解与编码执行过程的归档 |
| `测试验收` | 测试用例、执行记录、证据与验收结论的归档 |
| `交付发布` | changelog/release-note/回滚方案、发布记录的归档 |
| `复盘` | 复盘结论、经验沉淀的归档 |
| `契约变更` | 接口/协议/契约版本变更的归档 |
| `派单` | 需求投放、任务派发、跨项目交接的归档 |
| `缺陷修复` | bug 修复迭代的归档 |
| `结构规整` | `/sdd-tidy` 整理动作产生的归档 |

**Domain entries (this skill's additions — appended, never replacing a common entry):**

| 词条 | 适用场景 |
|---|---|
| `界面走查` | 设计稿对齐、视觉与交互走查、UI 缺陷清单整改的归档 |
| `设计令牌` | design tokens、主题变量、样式体系调整的归档（对应 `context/design-tokens.md`） |
| `性能优化` | 首屏/LCP/INP、包体与产物拆分等性能预算基线与优化的归档（对应 `context/performance-budget.md`） |
| `可访问性` | a11y 专项排查与整改（键盘可达、语义标签、对比度）的归档 |
| `国际化` | i18n 文案抽取、语言包与本地化格式调整的归档（对应 `context/i18n.md`） |
| `浏览器兼容` | 兼容性矩阵、polyfill 与降级方案的归档（对应 `context/browser-compat.md`） |
| `依赖升级` | Vite / React / TypeScript 等构建链与依赖大版本升级的归档 |

Deliberately **not** given their own entry — a common entry plus `-<自由补充>` already says it, and a bloated vocabulary loses its discriminating power: new page/component and state-management or routing refactors → `任务执行-<模块>`; front/back interface alignment → `契约变更-<接口>`; test back-filling → `测试验收-<范围>`; bug fixes → the common `缺陷修复`.

Rules: ① the prefix before the first hyphen after the date MUST match one entry exactly; ② `-<自由补充>` is optional and free (iteration name, module, defect id); ③ `/sdd-tidy` reports filenames that miss the vocabulary but **never renames them** — renaming an archived file is the user's call (tidy-protocol.md §3).

## context/ file load timing

| File | Load timing |
|------|---------|
| features.md / domain-model.md | before adding a feature (avoid duplication), when understanding the domain |
| architecture.md | when layering/routing/rendering decisions are involved |
| data-model.md / state-model.md | when types/state management are involved |
| modules.md / modules/*.md | when a specific component/module is involved |
| scenarios/*.md | when a cross-component business chain is involved |
| evidence-trace.md | when reverse-deriving downstream docs, reconciling with the user |
| code-map.md | when inventorying source coverage, locating evidence |
| api-contracts.md | when API integration, contract-boundary grading is involved |
| performance-budget.md / browser-compat.md / design-tokens.md | when performance/compatibility/design-system is involved |
| i18n.md | when multi-language (i18n enabled) is involved; not created for single-language |
| environment.md | when dependencies/versions/deployment are involved |
| iteration-log.md | when syncing at the deliver stage |
