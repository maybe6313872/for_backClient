# Mode A Stage-by-Stage Requirements and Gates

> Expansion of Mode A in SKILL.md. For each stage: responsibility → **content boundary (allowed/forbidden)** → overreach examples (bad and good) → interview points → Gate items (including Web-domain items) → self-check. **After every stage you MUST stop, run the Gate, and await user approval (gate red line 1).** The two-phase tasks stage is a high-frequency failure point, so it gets its own section.
>
> **Browser default (this domain's convention · the single source of truth is the version-baseline table)**: unless otherwise specified, the **target = the latest 2 stable versions of Chrome** (roughly "the newest version and the one before it", rolling with the verification date, see [environment-and-tools.md](environment-and-tools.md) §versioned baseline table). Lower versions and other-browser compatibility are not considered by default; if multiple browsers / lower versions / mobile are needed, the user must **explicitly declare** it in constitution/spec (trigger conditions are in coding-rules "Conditional capabilities and the N/A mechanism"). **Ambiguous/stale values in old documents ("Chrome ≥80/≥100", "FID<100ms", etc.) all defer to the version-baseline table.**

## Gate execution flow (common to every stage)
```
Output done → run the self-check.md self-check → present an output summary → present the Gate checklist with item-by-item status → wait for the user to confirm "通过" (pass) → enter the next stage
```
Gate display format (shown to the user verbatim, in Chinese):
```
## Gate 检查 — {阶段名称}
- [x] 条目1：已通过
- [ ] 条目2：部分通过（说明原因）
以上为本阶段 Gate 检查结果。请确认是否通过，或指出需修正的问题。
```

## Gate numbering namespace (frozen)

Gate IDs are a **shared vocabulary across every sdd-xx**: an orchestrator writes a gate ID into a dispatch packet and the executor — running a different skill, in a different window, with no shared context — must resolve it to the same obligation. That only works if the numbering is governed. Two frozen rules:

1. **The bare `G1`–`Gn` segment is reserved for cross-skill universal gates.** Every sdd-xx, whatever its domain or class, defines these identically, byte for byte. A skill may not add to, remove from, renumber, or locally reinterpret this segment. Changing it is a mother-skill action (`/sdd-distill` → `/sdd-absorb` → `/sdd-evolve`), never a local edit.
2. **A domain-specific or class-specific gate MUST take its own prefix and MUST NOT consume a `G` number.** A new domain registers its prefix in the table below when its skill is created. ❌ Writing a domain gate as `G7` is an error. ❌ Reusing a `G` number with a different local meaning is an error.

> **Why**: `G6` once meant "code↔specs pairing" in the orchestrator and "claim↔git pairing" in the executor. A packet saying "comply with G6" made the two sides verify different things, and the union of what neither checked shipped.

> **Scope of this namespace**: it governs **gate IDs only**. Question numbers in an interview/profile question bank (`G1 Which converter? …`) are ordinals of a questionnaire, not gates; they live outside this namespace and are neither renumbered nor prefixed by this rule.

### The universal segment (frozen — identical in every sdd-xx)

| ID | Gate | Obligation | Where it is enforced |
|---|---|---|---|
| G1 | Stage responsibility boundary | Content belongs to exactly one stage; the allowed/forbidden table of the current stage governs. Out-of-stage content flows back (spec/design) instead of being written here. | Every stage gate (F19) |
| G2 | Archiving discipline | Nothing under `specs/` is overwritten or deleted; the previous iteration is archived first (`task.md` → `specs/task/YYYY-MM-DD-说明.md`; stage → `<stage>/history/YYYY-MM-DD-说明.md`), then written. | Iteration entry gate + every write (F4, red line 3) |
| G3 | Evidence grading | Every test/run conclusion carries an L1–L5 level bound to a reproducible asset; delivery semantics never exceed the highest level reached in test. | test gate + deliver gate (F7) |
| G4 | Progress transparency | Before each gate, output the developed / not-developed / blocked / next-step clarification table and sync `task.md`; "it builds" is never reported as "it works". | Every stage gate (F16) |
| G5 | specs-first at every grain | Any code fix or small increment, however small, registers in `specs/` (task.md row + spec entry + context mapping) **before** business code is touched, and every business-code change of this iteration has a paired specs change. Fix-scale work is not exempt. | tasks + deliver gate (F2/F5) |
| G6 | Claim↔git pairing | Before delivery, verify against `git status` that the claimed artifacts and test evidence match the actual working tree — no "claimed changed but no change present", no unregistered incidental changes; the `docs/requirements/` inbox is cleared per claim (acknowledgment, not completion). | deliver gate (F5/F33) |

> G1–G4 give IDs to mechanisms that were already frozen (F19 / F4 / F7 / F16); they introduce **no new obligation**. G5 and G6 keep their existing meanings and are here separated for the first time: G5 is "specs paired with code", G6 is "claims paired with the working tree" — two different checks that must both run.

### Registered domain/class prefixes

| Prefix | Owner | Scope |
|---|---|---|
| `ORCH-*` | orchestration-class skills (F34) | root-side dispatch/checkpoint gates; never appear in a single-stack skill |
| `FE-*` | `sdd-web-frontend` | web front-end domain gates |
| `BE-*` | `sdd-web-backend-python` | web back-end domain gates |

This skill's own domain gates are defined in this file under its registered prefix and never consume a `G` number.

## Iteration entry gate (before substantive work on a new iteration · frozen)
Must be completed **before** starting the substantive work of any new iteration/task; otherwise do not start:
- [ ] Read `specs/task.md` (mandatory step 2 of every session)
- [ ] **Archive first**: archive the previous iteration's task state to `specs/task/YYYY-MM-DD-<说明>.md` (archive before write, never overwrite; see specs-lifecycle.md)
- [ ] Write the new iteration header (iteration ID / goal / scope / linked requirements / start date) into `task.md`
- [ ] Facts the previous iteration failed to write back must be written back into `README`/`context` first; never start a new iteration on top of stale documents
- [ ] Read the `specs/retro/README.md` ledger; when a relevant lesson matches → remind yourself to avoid repeating it and to reuse highlights (skip if there is no retro/)
> Optional deterministic backstop: `python specs/_tools/check_iteration_docs.py --root .` (the tool ships with the skill under `assets/tools/`; `/sdd-init` can copy it into the project's `specs/_tools/`; the two paths are equivalent). **This checker can already recognize current.md date-header status, history-archive correspondence, workbench tidiness, and deliver archiving** (see specs-lifecycle §lifecycle check). Without Python, verify this checklist manually.

---

> **Core anti-overreach self-check mantra**: "Which stage does this content belong to? If it does not belong to the current stage, move it out." Every stage below lists allowed/forbidden; after producing output, compare paragraph by paragraph.

---

## 1. constitution (project-level engineering constraints, few and precise)
| Allowed | Forbidden |
|---|---|
| Engineering constraint items, decision precedence, no-go-zone list, reference-document index, freezing the target browser/framework/build tool | Concrete requirement descriptions, design solutions, code, task breakdown, test cases |

**Interview points**:
- Confirm the tech stack: React/Vue + TypeScript + SCSS + Vite, Node version?
- **Package-manager identification (P0-03 · identify the existing fact first, do not blindly force pnpm)**: read the lockfile and the `packageManager` field of `package.json` to determine the project's **real** package manager — `pnpm-lock.yaml`→pnpm, `yarn.lock`→yarn, `package-lock.json`→npm, `bun.lockb`→bun. An existing project **follows its single lockfile**; the org default (pnpm) is the default **only** for a **brand-new project**; if migrating the package manager is truly needed, treat it as an **explicit constitution decision** (a standalone task; do not casually introduce a second lockfile in some other iteration). Run `python specs/_tools/derive_gate_status.py --root .` to read out the identification result.
- Target browser range? **Default: the latest 2 stable versions of Chrome** (see the version-baseline table); if other browsers / lower versions / mobile are needed, note it explicitly.
- No-go zones / minimal-change / decision-precedence and other general-protocol items.

**Gate**:
- [ ] Contains general-protocol items (decision precedence, follow existing coding style, minimal change, etc.)
- [ ] Contains project-specific protocol items (**target browser: default latest 2 stable Chrome**, tech stack locked to React/Vue+TS+SCSS+Vite, Node version, **the identified package manager (source: lockfile/packageManager, not blindly forced pnpm)**, no-go zones)
- [ ] **Package manager identified from engineering facts**; if it differs from the org default, "follow the existing fact" or "explicit migration decision" — one of the two — has been recorded
- [ ] **Conditional capabilities have a stated position**: routing / responsive mobile / observability / i18n each either "trigger condition hit → mandatory" or "not hit → N/A (with rationale + confirmer + residual risk)" (see coding-rules "Conditional capabilities and the N/A mechanism")
- [ ] Items are few and precise; no requirements/design/implementation mixed in
- [ ] task.md updated to constitution-stage-complete

**Self-check**: any requirements/technical solutions mixed in? Are items executable and verifiable? Any unconfirmed assumptions?

## 2. spec (defines "what to build", acceptance-testable)
| Allowed | Forbidden |
|---|---|
| Requirements (What/Why), acceptance criteria, boundaries and exceptions, Clarify Q/A, non-functional requirements (performance/accessibility/compatibility) | Concrete technical solutions (How), component interfaces, module partitioning, task breakdown, test cases |

**Overreach examples**: ❌ 「用 Zustand store 管理登录态，含 IDLE/AUTHED 状态」 (manage login state with a Zustand store, states include IDLE/AUTHED) → design; ❌ 「修改 `src/pages/Login.tsx`」 (modify `src/pages/Login.tsx`) → tasks; ✅ 「系统应在 token 过期时跳转登录页并提示」 (the system shall redirect to the login page with a prompt when the token expires) → spec.

**Interview points**: is the feature list complete? **Language scope (single-language / multi-language — multi-language enables the i18n rule family, see RULE-I18N and `context/i18n.md`; single-language is judged N/A)**? Responsive scope (fixed single size / desktop only / desktop+tablet / fully responsive / mobile-first — a fixed single size may judge responsive N/A)? Accessibility level (WCAG 2.1 AA recommended)? Key performance metrics (default thresholds **LCP<2.5s, INP<200ms, CLS<0.1**, single source of truth in the version-baseline table; FID was replaced by INP in 2024-03, do not use it again)? Compatibility needs (**default latest 2 stable Chrome**, note any exceptions)? Observability / external monitoring needed (a closed environment may be N/A)?

**Clarify loop**: at most 5 clarification points per round, each recorded as "question + answer/decision"; **MUST NOT enter design before key ambiguities are closed** (record in `2-spec/clarify-log.md` or merge into the spec).

**Gate**:
- [ ] Every requirement has acceptance criteria (checklist / Given-When-Then / EARS)
- [ ] Boundaries and exceptions are covered (network drop / API timeout / empty data / large data volume / concurrency / insufficient permissions / illegal input)
- [ ] Every requirement has an explicit evidence definition (screenshot / screen recording / test report / Lighthouse / axe)
- [ ] Key Clarify items are closed
- [ ] task.md updated

**Self-check**: any technical solution mixed in? Does every requirement have acceptance criteria? Are boundaries and exceptions complete? Any unconfirmed requirement assumptions?

## 3. design (defines "how to build it")
| Allowed | Forbidden |
|---|---|
| Component architecture, Props/Events interfaces, state-management scheme, routing design, API layer, responsive strategy, accessibility scheme, observability | Task breakdown, full function-body code, test cases, new requirements |

**Interview points**: is the component tree accurate? **How is state classified** (the six categories server/UI/form/process/persisted/shared, RULE-STATE-04) and the tooling per category (native vs Query/store/form/table library)? API encapsulation (interceptor / fetch wrapper / TanStack Query·SWR) and **contract-validation strength** (hand-written types / generated types / runtime schema, RULE-TYPE-04)? **Cache model** (owner / key / invalidation mapping, RULE-ASYNC-05, if there is sharing/polling/offline/refresh-after-write)? Is there routing (if so, guards/lazy-loading; if not, N/A)? Responsive breakpoints (when there is a responsive need, suggested sm:640 md:768 lg:1024 xl:1280; fixed single size N/A)?

**Gate**:
- [ ] `<project package manager> install && <project package manager> build` is reproducible (package manager = the value identified in constitution, not blindly forced pnpm)
- [ ] Key component interfaces/Props/Events are defined
- [ ] **State classification and tooling defined (RULE-STATE-04)**: the six categories each in their place; the dependency-evaluation trigger signals are judged; where native is chosen, the covered boundaries are proven (four states / race / cache identity / dedup / cleanup)
- [ ] **Cache model written down (RULE-ASYNC-05, condition: shared server data / polling / offline recovery / refresh-after-write)**: owner, key and freshness, **write-path → invalidated-key mapping**, recovery/focus/polling sync, concurrent-write semantics; purely local one-off data may be simplified and noted
- [ ] **Per-request async state matrix listed (RULE-ASYNC-04)**: one row per query/command path, covering idle / loading / success-non-empty / success-empty / error / stale-data-refresh-failed / cancelled; command type includes dedup
- [ ] **API contract boundary graded (RULE-TYPE-04)**: stable internal = types/generated; external high-risk = runtime schema + exception/non-JSON branches; the contract-drift check method is declared
- [ ] **Component/form/table complexity reviewed (RULE-CMPX)**: where responsibility-coupling / interaction-complexity signals are hit, splitting or bringing in a library has been evaluated and the trade-off recorded
- [ ] **Conditional capabilities stated item by item (P1-10)**: routing / responsive mobile / observability — trigger condition hit → designed (route table·guards·lazy-loading / breakpoints·adaptation / error monitoring·performance telemetry); not hit → **N/A (rationale + confirmer + residual risk)**, no fake check-off or over-engineering
- [ ] **(if i18n enabled) i18n design items defined (RULE-I18N)**: supported languages and default/fallback, module resource ownership and registration consistency, dynamic text/interpolation/plurals/locale-formatting entry, semantic messages vs translated strings, switch-regression scope; single-language → this item N/A
- [ ] Every technical solution traces back to the spec; no requirements "added on your own"
- [ ] task.md updated

**Self-check**: any code implementation mixed in? Are component interfaces complete (Props/Events/Slots)? Are the six state categories placed and the tooling justified? Is the cache-invalidation mapping written in full? Is every conditional capability either designed or N/A (no fake checks)? Any unconfirmed technical assumptions (API format / library version)?

## 4. tasks (break down tasks **and write the code**) = two phases
| Allowed | Forbidden |
|---|---|
| Task breakdown, writing real code per the plan, keeping verification evidence, updating progress | New requirements (→ flow back to spec), new design decisions (→ flow back to design), writing test cases (→ test) |

> **Follow this to the letter. Producing only a plan without writing code is wrong (gate red line 2).**

- **Phase ① Planning**: from design+spec, break down the TODOs (each item maps to R*/AC*, lists the files to change, states the verification and evidence, tags `RULE-*`, see [coding-rules.md](coding-rules.md)) and write them into `4-tasks/current.md`; task.md reflects coarse progress. **🚦Gate ①**: present the list and wait for user approval; do not write code before approval.
- **Phase ② Execution**: once the plan is approved, write real code item by item, get it running, keep evidence. **🚦Gate ②**: after implementing and self-verifying, present the evidence and wait for user confirmation before entering test.
- **Overreach examples**: ❌ 「新增一个导出功能」 (add a new export feature) → flow back to spec; ❌ 「把状态库从 Zustand 换 Redux」 (swap the state library from Zustand to Redux) → flow back to design; ✅ 「T1.2 修改 `src/features/auth/useLogin.ts`，实现 R3/AC1，遵循 RULE-ASYNC-01，证据：build 通过 + 运行截图」 (T1.2 modify `src/features/auth/useLogin.ts` to implement R3/AC1, following RULE-ASYNC-01; evidence: build passed + runtime screenshot).
- **Progress clarification**: before this stage's Gate you must output the development-progress clarification table (developed / not developed / blocked / next step), see [development-progress-protocol.md](development-progress-protocol.md).

**Gate**:
- [ ] Every task maps to a spec acceptance point, lists the files to change, tags RULE-*
- [ ] Gate ① plan approved; Gate ② code written and self-verified with evidence kept
- [ ] Development-progress clarification table output
- [ ] task.md updated

## 5. test (reproducible tests with evidence)
| Allowed | Forbidden |
|---|---|
| Test cases, execution records, evidence, missed-coverage risks | Changing requirements (→ flow back to spec), changing the design (→ flow back to design), adding features |

**Interview points**: is the test coverage sufficient? E2E scope (core flows / all pages / regression only / not needed)? Is missing test infrastructure backfilled this iteration, or recorded as N/A + residual risk?

**Gate status derivation (P0-02 · each item's status must be derived from engineering facts; do not write "build succeeded" as "tests complete")**:
Each check item takes one of the following five states; the source = whether the script exists + command exit code + number of discovered tests + evidence file (auto-derivable with `python specs/_tools/derive_gate_status.py --root . [--ran run.json]`):

| Status | Determination |
|---|---|
| `passed` | command actually ran, exit code 0, (for test type) discovered count > 0, evidence file present |
| `failed` | command ran but exit code ≠ 0 |
| `ran-but-zero-tests` | the test command ran but discovered count = 0 — **must not be recorded as passed** |
| `configured-not-run` | script/framework is configured but was not run this time — must explain why it was not run |
| `missing` | no corresponding script and (for unit/E2E) no framework dependency |
| `N/A` | confirmed not applicable (allowed for prototype/legacy projects, but must state rationale + confirmer + residual risk) |

> **Prototype/legacy projects** may have `missing`/`N/A`, but must explicitly state the reason and residual risk; **you cannot use a document check-off to impersonate a real check**; continuously iterating projects must not stay `missing` long-term. The deliver evidence semantics must not exceed the real status derived here.

**Gate**:
- [ ] `build` / `lint` / `typecheck` each derive their own status (passed/failed/missing/N-A), not a blanket "passed"
- [ ] **Unit test** status derived: `missing` (no framework) / `configured-not-run` / `ran-but-zero-tests` / `passed` / `failed`; `ran-but-zero-tests` and `failed` **must not** be upgraded to passed
- [ ] **E2E** (Playwright/Cypress): if the trigger condition is hit, derive the status; may be N/A when there is no critical end-to-end path (record the rationale)
- [ ] **Per-request async path verification (RULE-ASYNC-04)**: verify the design's state matrix row by row — idle / loading / success-non-empty / success-empty / error / stale-data-refresh-failed / cancelled (command type includes dedup); keep evidence per row and tag its L level
- [ ] **(if i18n enabled) i18n invariant check**: `python specs/_tools/check_i18n.py --root .` passes — cross-language missing/extra keys, interpolation-parameter consistency, direct-written visible text, orphan-key review; plus a minimal **language-switch regression** (state/logs/notifications/errors/date-number formatting leave no old-language residue); single-language → N/A
- [ ] **API contract exception cases**: missing fields / type change / error response / non-JSON response are covered (corresponding to the RULE-TYPE-04 grading)
- [ ] Test cases cover the spec acceptance points
- [ ] **Key pages meet Lighthouse/axe (if applicable); performance thresholds LCP<2.5s/INP<200ms/CLS<0.1; browser target = default latest 2 stable Chrome**
- [ ] Every test conclusion is tagged with an L1–L5 evidence level (see evidence-gate-protocol.md)
- [ ] When code was modified, the domain coding-consistency self-check (coding-rules RULE-*, including STATE-04/ASYNC-04/05/TYPE-04/CMPX/I18N) is done
- [ ] Execution records and evidence archived; task.md updated

## 6. deliver (change / release / rollback)
| Allowed | Forbidden |
|---|---|
| changelog / release-note / rollback, delivery evidence, documentation sync | New requirements/design/features; claiming semantics above the evidence level |

**Gate (iteration exit gate · frozen)**:
- [ ] changelog updated
- [ ] release-note updated
- [ ] Rollback strategy is executable (build-artifact path contains hash/version)
- [ ] Delivery evidence is complete; the full document set is synchronized (README architecture diagram/code map + full context + twin write-back)
- [ ] Delivery semantics are not higher than the highest evidence level from test
- [ ] `task.md` updated (done / not done / blocked / next step) + a 5-line summary, and archived per the lifecycle **into `specs/task/`** (never overwrite directly)
- [ ] `context/iteration-log.md` has this iteration's one-line entry appended
- [ ] `open-issues.md`: closed items are closed out; unclosed items go into delivery risks
- [ ] **G5 — specs-first pairing**: every business-code change this iteration has a paired specs change (task.md row / spec entry / context mapping); code-without-specs = incomplete → block, report, backfill specs or obtain the user's explicit waiver; **fixes and small increments included**; never auto-revert — ask the user for disposition
- [ ] **G6 — claim↔git pairing**: `git status` verified against what this delivery *claims* — every claimed artifact and test-evidence file actually exists in the working tree, and no unregistered incidental change is present; the `docs/requirements/` inbox is cleared per claim
- [ ] **Retro judgment**: did this iteration have mistakes/highlights worth a retrospective? If yes → run `/sdd-retro` and write into `specs/retro/` (see [retro-protocol.md](retro-protocol.md))

**Documentation-sync special items**:
- [ ] README architecture diagram / code map reflects the current state
- [ ] context/modules covers all current components/modules; features covers implemented features; environment dependencies and the **package manager** are updated; architecture new decisions recorded; state-model/data-model synchronized
- [ ] context/iteration-log appended; knowledge-map entries refreshed
- [ ] (if enabled) api-contracts / performance-budget / browser-compat / design-tokens / **i18n** synchronized
- [ ] **Residual risk of N/A conditional capabilities** (routing/responsive/observability/i18n) recorded in delivery risks; **the reason and residual risk of Gate `missing`/`N/A` items** kept on file with the delivery note

---

## Flow-back
Any stage discovers a risk/inconsistency → stop → explain the flow-back reason → wait for user confirmation → go back to spec/design and fix → re-run the Gate → return to the original stage after it passes. A flow-back must also update task.md and mark the affected modules.
