# task.md Protocol: Global Kanban, Lifecycle, and the Difference from 4-tasks

> `specs/task.md` is the **project's command deck**: maintain it for **every task** — iterations, bug fixes, writing docs, rebuilding context/, and so on — across sessions, across tasks, across iterations, visible to the user. It answers "what is being done now, how is progress, what comes next", and it **always uses a coarse-grained checklist**. Its content is written in Simplified Chinese for the user. It is also the project's **machine-readable progress surface**: upper-layer orchestrators/AIs (e.g. a full-stack orchestration skill) read progress from `specs/task.md` read-only instead of asking — keep it current for them too.

---

## 1. What task.md is and what it looks like

task.md serves the "overall task situation visible to the user", so its **granularity is coarse**:

| Section | Content |
|---|---|
| Date header | `<!-- 迭代标识: <简短说明> \| 迭代日期: YYYY-MM-DD \| 状态: 进行中 -->` — three frozen fields, `状态` carrying exactly one current value (specs-lifecycle.md §3); the basis for archive naming and staleness detection |
| Current task | coarse-grained description (e.g. "迭代：新功能X" (iteration: new feature X) / "修复：某缺陷 bug" (fix: some defect) / "重建：context/" (rebuild: context/)), type, one-sentence goal, start date |
| Progress (coarse-grained checklist) | a handful of big steps as `- [ ]` checkboxes; a six-stage iteration may use the stages as the big steps |
| Current status / next step | what is being done now, the next step, blockers |
| Notes | risks, external dependencies, items pending user confirmation |

Do **not** pile fine-grained subtasks or detailed requirements/design/test cases into task.md — those are other documents' responsibilities.

---

## 2. The difference between task.md and `specs/4-tasks/` (memorize this, never confuse them)

This is a high-frequency point of confusion and must be nailed down:

| | `specs/task.md` | `specs/4-tasks/current.md` |
|---|---|---|
| Positioning | **Command deck**: overall task + progress, visible to the user | **Construction blueprint**: fine-grained task breakdown and execution tracking inside a single iteration |
| Scope of use | Maintained for **every task** | Exists/used **only** when iterating through the six spec stages |
| Granularity | Coarse (iteration name, a few big steps) | Fine (T1.1, T1.2, …, each task mapped to acceptance points / files / evidence) |
| Lifecycle | Long-lived; archived to `specs/task/` as tasks turn over | Created per single iteration; goes into `4-tasks/history/` when the iteration is archived |

**Decision rule**: every task must update `task.md`; **only when** the current work is a "six-stage spec iteration" do you additionally do the fine-grained breakdown and execution in `4-tasks/current.md`.

### Pro examples

- ✅ User: "帮我重建 context/" (rebuild context/ for me) → this is not a six-stage iteration → **update task.md only** (task = "重建：context/", coarse-grained checklist: scan → generate code map → write twins → coverage self-check), and **do not create 4-tasks**.
- ✅ User: "修复某缺陷这个 bug" (fix this defect bug) → usually not the full six stages → update task.md (task = "修复：某缺陷", a few big steps), take the streamlined flow as needed, **no need to touch 4-tasks**.
- ✅ User: "按 spec 迭代加新功能X功能" (add new feature X via a spec iteration) → run the six stages → task.md records the coarse-grained progress of "迭代：新功能X", **and at the same time** do the fine-grained task breakdown and execution tracking in `4-tasks/current.md`.

### Anti-examples

- ❌ Stuffing fine-grained tasks like T1.1/T1.2, or detailed file lists, into `task.md` (they belong in 4-tasks).
- ❌ Creating `4-tasks/current.md` for a non-six-stage task like "rebuild context/" (4-tasks serves six-stage iterations only).
- ❌ Putting a coarse-grained iteration name like "迭代：加新功能X" in as the content of 4-tasks (4-tasks wants fine-grained tasks).
- ❌ Forcing the full 4-tasks workflow for a small bug fix (streamline as needed — but task.md must still be updated).

---

## 3. Lifecycle trigger points (aligned with the specs-lifecycle.md hooks)

| Trigger point | Action |
|---|---|
| New task / new iteration starts | If the previous task.md is not archived (status = 已交付待归档 or it belongs to an old task) → first archive it to `specs/task/YYYY-MM-DD-<说明>.md`, extract the essential information, then write the new kanban |
| Task advances / a stage Gate passes | Update the coarse-grained checklist ticks, the current status, and the next step |
| A blocker is found | Note the blocker and its unblocking condition under "current status / next step" |
| Task/iteration complete (user explicit) | Archive the current task.md to `specs/task/` and prepare to receive the next task |
| An in-stage small increment lands (hotfix note / corrected acceptance point / inserted small requirement) | Register it in that stage's increment container **and** add one coarse row here (what · why · which stage owns it). An increment registered in only one of the two places is not registered (specs-lifecycle.md §12, G5) |

> `/sdd-update` is the explicit trigger for this inspection + archiving routine (see commands.md).

---

## 4. Archiving requirements

When archiving to `specs/task/YYYY-MM-DD-<说明>.md`, **preserve the full original text** (no trimming), and extract the still-valid information into the new task.md:

| Extract into the new task.md | Fine to leave in the archive file |
|---|---|
| Items still unfinished that must be carried forward | Details of completed steps |
| Still-valid risks / items pending confirmation | Process-level records |

Directly overwriting or deleting the old task.md is **forbidden** (see the no-overwrite rule in specs-lifecycle.md).

**Single archive form (frozen — no domain has a choice here)**: the archive destination of `task.md` is the archive-root **directory** declared by this skill's `metadata.role` (`specs/task/` for a coding-skill, `orchestration/task/` for an orchestration-skill), **one file per archived task/iteration**, named `YYYY-MM-DD-<说明>.md`. There is **no single-file form**. Specifically:

- ❌ A rolling file (`task-archive.md`, `archive.md`, `history.md`, …) that successive iterations **append** into MUST NOT be used as the archive destination, MUST NOT be created by any scaffold script, and MUST NOT appear in any gate checklist item.
- ❌ "Append a summary of this iteration to the archive file" contradicts **preserve the full original text** above — appending forces trimming, and trimmed history is lost history.
- ✅ A file named `task-archive.md` may exist **only as a convention note** — a short document explaining *how* archiving works and pointing at the archive root. It is never a destination. When in doubt, do not ship the file at all.
- ✅ Orchestration-class skills relocate the directory with their layout (`orchestration/task/`), but the form is unchanged: **a directory, one file per archive**.

Gate checklist items MUST read 「task.md 已归档到 `specs/task/YYYY-MM-DD-<说明>.md`」 (or the domain's relocated directory) — never 「归档到 <某单个文件>」.

### Archive directory stratification (F36 · applied to `specs/task/`)

`specs/task/` only ever grows — the no-overwrite rule guarantees it, and every task turnover adds one more file. The mechanism, the thresholds, the `INDEX.md` contract, the grandfathering clause and the execution rule are frozen in specs-lifecycle.md §10 (R1–R5); **that is the single source of truth**, and this section states only how they land on the kanban archive root.

- **Declared rule (R1)**: `specs/task/` is this skill's kanban archive root and carries the stratification rule — **≤ 30** archive files stay flat directly under `specs/task/`; **> 30** split into one subdirectory per year, `specs/task/YYYY/`; **any single year > 60** splits that year into one subdirectory per month, `specs/task/YYYY/MM/`. Counted over archive `.md` files only; `INDEX.md` is never counted.
- **Year and month only (R3)** — never per-week, never per-day, and no other granularity (per-quarter, per-iteration, per-author). `YYYY` / `MM` come from the archive filename's own date prefix, never from the filesystem mtime.
- **Every level carries an `INDEX.md` (R4)**: `specs/task/INDEX.md`, plus `specs/task/YYYY/INDEX.md` and `specs/task/YYYY/MM/INDEX.md` once stratified. The field set is fixed in specs-lifecycle.md §10 and its header stays Chinese verbatim. Writing the row is **part of the archive action** described above — a kanban archive with no index row is an incomplete archive.
- **Grandfathering**: kanban archives written **before** this rule landed are legacy and are never retroactively judged incomplete. Their missing index rows are back-filled only inside a `/sdd-tidy` plan gate, row by row, on the user's approval — never silently, never reported as a defect.
- **Migration is move-only (R5)**: restratification runs as a `/sdd-tidy` plan; every `current path → target path` row waits for approval, and files are **moved, never deleted, never renamed** (the `YYYY-MM-DD-<说明>.md` filename is preserved verbatim — only its directory changes). The §3 trigger points always write into the currently deepest applicable level and never create a level on their own.
- Collisions are unaffected by stratification: a composed name that already exists **at any level** of `specs/task/` takes the smallest unused two-digit ordinal from `-02` (specs-lifecycle.md §11).

### The kanban archive root is a reserved name (F37)

A directory name is a contract — one semantic, one lifetime, one naming rule. Within a repository governed by this skill, two directories MUST NOT share a name while carrying different meanings, and a destructive verb defined on a name is scoped to that name's one meaning. The repo-wide reserved-name list lives in structure.md; the kanban's four neighbours are:

| Name | The one thing it means | Shape and lifetime |
|---|---|---|
| `specs/task/` | archive root of the global kanban `task.md` (an orchestration-skill relocates it to `orchestration/task/`; the form is unchanged) | a **directory** of `YYYY-MM-DD-<说明>.md`, one file per archived task/iteration, append-only, stratified per F36 |
| `<stage>/history/` | date-indexed archive of **one stage's** `current.md` | same filename pattern, scoped to that stage — never a home for kanban archives |
| `context/iteration-log.md` | append-only running record, one line per delivered iteration | a **FILE, not an archive directory** — never split into per-iteration files, never renamed to `context/history/` |
| `docs/requirements/` | the F33 requirement inbox, **emptied on claim** | transient queue; long-lived requirement specifications live in `docs/product-specs/` and are never parked here |

- ❌ Never invent a second name for the kanban archive (`specs/history/`, `specs/task-history/`, `specs/task/history/`, `specs/archive/`). One document class has exactly one archive root; a second name splits the history and makes both `INDEX.md` tables lie.
- ❌ Never cross-file the two archive kinds: a kanban archive does not go into a `<stage>/history/`, and a stage workbench does not go into `specs/task/`. Detection, indexing and `/sdd-tidy` all read the semantic off the directory name.
- ❌ Never treat `context/iteration-log.md` as an archive destination — appending the one-line iteration record there does **not** replace archiving `task.md` in full (see **preserve the full original text** above). Both records are mandatory; they are not substitutes.
- ✅ "Clear the inbox" clears claimed packets under `docs/requirements/` and touches nothing under `specs/task/`, any `history/`, or `docs/product-specs/` (requirement-inbox-protocol.md).
- ✅ Existing violations are migrated only through a `/sdd-tidy` plan the user approves row by row — **move only, never delete** (tidy-protocol.md).

Rule of thumb: **date-indexed archive → `specs/task/` (kanban) or `<stage>/history/` (stage); version-indexed snapshot → `versions/`; append-only running record → `*-log.md`.**

---

## 5. Hard constraints

- On every skill trigger, the reading order is: `README.md → task.md → docs/ → mode/stage detection`.
- Every task must maintain task.md; update it promptly during execution — it must never drift from real progress.
- task.md holds coarse granularity only; no detailed requirements/design/test cases.
- Archive before switching tasks; direct overwrite is forbidden.
