#!/usr/bin/env python3
"""
Test-gate true-status derivation (optional read-only tool).

Positioning (P0-02):
- Derive the **true status** of each test gate from engineering facts (package.json
  scripts, test frameworks in dependencies, and optional real run results), to avoid
  "build succeeded" being written down as "tests done", or "unit tests passed" when there
  are actually zero test cases.
- Read-only; runs no scripts and changes no files. It is the deterministic fallback /
  corroboration for the AI when filling in the test gate.

Usage (run at the project root):
  python derive_gate_status.py --root .
  python derive_gate_status.py --root . --ran run-result.json

--ran points at a JSON, of the form:
  {"build":{"exit":0},"lint":{"exit":1},"unit":{"exit":0,"tests":42},"e2e":"N/A"}
  Merge rules: exit==0 -> passed; exit!=0 -> failed; unit with tests==0 ->
  ran-but-zero-tests (never recorded as passed); a string value "N/A" -> that item is not
  applicable.

Status vocabulary:
  missing               no script, and (unit/e2e) no test-framework dependency
  configured-not-run    a script/framework exists, but no run result was provided
  passed / failed       only given when --ran provides a run result
  ran-but-zero-tests    unit ran but had zero cases (must never be recorded as passed)
  N/A                   only when explicitly marked "N/A" in --ran

Exit code: always 0 (this tool is advisory); but if any item is failed or
ran-but-zero-tests, it prints a prominent warning line.
"""
from __future__ import annotations

import argparse
import datetime
import json
from pathlib import Path

CAPS = ["build", "lint", "typecheck", "unit", "e2e"]
CAP_CN = {
    "build": "Build (build)",
    "lint": "Lint (lint)",
    "typecheck": "Type check (typecheck)",
    "unit": "Unit test (unit)",
    "e2e": "End-to-end (e2e)",
}
STATUS_CN = {
    "missing": "missing (no script/framework configured)",
    "configured-not-run": "configured, not run",
    "passed": "passed",
    "failed": "failed",
    "ran-but-zero-tests": "ran but zero cases (must not be recorded as passed)",
    "N/A": "not applicable",
}


def read(p: Path) -> str:
    for enc in ("utf-8-sig", "utf-8", "gbk", "cp936", "latin-1"):
        try:
            return p.read_text(encoding=enc)
        except (UnicodeDecodeError, FileNotFoundError):
            if not p.exists():
                return ""
            continue
    return ""


def load_json(p: Path):
    txt = read(p)
    if not txt.strip():
        return {}
    try:
        return json.loads(txt)
    except (ValueError, json.JSONDecodeError):
        return {}


def detect_pm(root: Path, pkg: dict) -> str:
    if (root / "pnpm-lock.yaml").exists():
        return "pnpm"
    if (root / "yarn.lock").exists():
        return "yarn"
    if (root / "package-lock.json").exists():
        return "npm"
    if (root / "bun.lockb").exists():
        return "bun"
    pm = pkg.get("packageManager")
    if isinstance(pm, str) and pm:
        return pm.split("@")[0]
    return "unknown"


def apply_ran(cap: str, base: str, r) -> str:
    """Merge the --ran run result onto the base status."""
    if isinstance(r, str) and r.strip().upper() == "N/A":
        return "N/A"
    if isinstance(r, dict):
        exit_code = r.get("exit")
        if exit_code is not None and exit_code != 0:
            return "failed"
        # exit_code == 0 or missing
        if cap == "unit" and r.get("tests") == 0:
            return "ran-but-zero-tests"
        if exit_code == 0:
            return "passed"
    return base


def main() -> int:
    ap = argparse.ArgumentParser(description="Derive true test-gate status from engineering facts (read-only).")
    ap.add_argument("--root", default=".")
    ap.add_argument("--ran", default=None, help="optional: path to run-result JSON")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    pkg = load_json(root / "package.json")

    scripts = pkg.get("scripts") or {}
    deps = {**(pkg.get("dependencies") or {}), **(pkg.get("devDependencies") or {})}

    build_script = scripts.get("build", "") or ""
    has_build = "build" in scripts
    has_lint = "lint" in scripts
    has_typecheck = ("typecheck" in scripts) or ("tsc" in build_script) or ("vue-tsc" in build_script)
    has_unit_script = ("test" in scripts) or ("test:unit" in scripts)
    has_e2e_script = "test:e2e" in scripts

    frameworks = {
        "vitest": "vitest" in deps,
        "jest": "jest" in deps,
        "@playwright/test": "@playwright/test" in deps,
        "cypress": "cypress" in deps,
    }
    unit_fw = frameworks["vitest"] or frameworks["jest"]
    e2e_fw = frameworks["@playwright/test"] or frameworks["cypress"]

    def base_status(cap: str) -> str:
        if cap == "build":
            return "configured-not-run" if has_build else "missing"
        if cap == "lint":
            return "configured-not-run" if has_lint else "missing"
        if cap == "typecheck":
            return "configured-not-run" if has_typecheck else "missing"
        if cap == "unit":
            return "configured-not-run" if (has_unit_script or unit_fw) else "missing"
        if cap == "e2e":
            return "configured-not-run" if (has_e2e_script or e2e_fw) else "missing"
        return "missing"

    ran = {}
    if args.ran:
        ran = load_json(Path(args.ran).resolve())
        if not isinstance(ran, dict):
            ran = {}

    gate = {}
    for cap in CAPS:
        status = base_status(cap)
        if cap in ran:
            status = apply_ran(cap, status, ran[cap])
        gate[cap] = status

    pm = detect_pm(root, pkg)

    # ---- Status table ----
    print("# Test-gate true-status derivation\n")
    print(f"Root directory: {root}")
    print(f"Package manager: {pm}")
    fw_on = [k for k, v in frameworks.items() if v]
    print(f"Test frameworks: {', '.join(fw_on) if fw_on else 'none detected'}\n")
    print("| Capability | Status | Description |")
    print("| --- | --- | --- |")
    for cap in CAPS:
        st = gate[cap]
        print(f"| {CAP_CN[cap]} | {st} | {STATUS_CN.get(st, st)} |")
    print()

    bad = [cap for cap in CAPS if gate[cap] in ("failed", "ran-but-zero-tests")]
    if bad:
        names = ", ".join(CAP_CN[c] for c in bad)
        print(f"\033[1m⚠ The following capabilities are failed/zero-cases and must never be recorded as passed in the test gate: {names}\033[0m")
        print()

    print(json.dumps({
        "root": str(root),
        "package_manager": pm,
        "frameworks": frameworks,
        "gate": gate,
        "checked_at": datetime.date.today().isoformat(),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
