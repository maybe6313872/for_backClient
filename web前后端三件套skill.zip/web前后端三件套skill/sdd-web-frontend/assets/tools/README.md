# Optional tools: source-coverage index

> **Optional.** The core of Mode B is the `specs/context/` cognition layer, **not** this index. If there is no Python or you don't want to use scripts, simply skip this and have the AI build the source inventory and coverage table by hand — equivalent effect (see `references/mode-b-twin.md` §7, §8).

## build_source_index.py
Zero dependencies (standard library only); no SQLite, no HTML generation, no network dependency. It answers only three questions:
1. Which source files / entry points / symbols / dependencies exist in the project;
2. Which of them are already covered by `context/` and which may have been missed;
3. Which source-code evidence to revisit when back-deriving a module/scenario.

### Usage
Copy this script into the project's `specs/_tools/` and run:
```bash
python build_source_index.py --root <project-root> --out specs/_generated/source-index
```
Artifacts (JSON + summary.md) land in `specs/_generated/source-index/`; **do not mix them into the `specs/context/` body** — this is a rebuildable, disposable machine-aid index, not a source of factual adjudication.

### Boundaries
No pursuit of interactive graphs, graph databases, or visualization pages. When finer in-domain symbol parsing is needed, prefer the domain ecosystem's tools (tsc/AST, javap, roslyn, pydeps, etc.), or add another zero-dependency mini-script in the child skill.

## check_iteration_docs.py
An **optional deterministic fallback** for the iteration-boundary document gate (read-only; changes no files). Checks that `specs/task.md` exists and carries the current-iteration date header, that `specs/task/` has archives (archive first · no overwrite), and that `context/iteration-log.md`/`open-issues.md`/`retro/README.md` are in place. It also grades the three-field date header (迭代标识/迭代日期/状态) on `task.md` and every stage's `current.md`: an out-of-set 状态 value is critical, a header that doesn't split into exactly 3 fields is a warning, and a legacy four-field header (pre-freeze inline status enumeration) is read under legacy tolerance rather than repaired or guessed.

### Usage
```bash
python check_iteration_docs.py --root .
```
The exit code is 1 when a critical item fails (task.md missing, no date header, or an out-of-set 状态 value). **Without Python, the AI cross-checks manually against the entry/exit gates in gate-and-stages — equivalent effect.**

## check_i18n.py
A **zero-dependency, read-only** Web front-end i18n consistency checker, library-agnostic. Only runs when the project has an i18n resource directory (auto-discovered under `src/i18n`, `src/locales`, `src/lang`, `locales`, `i18n`; otherwise judged N/A and exits 0). Reports four invariants: cross-language key parity (critical), interpolation parameter-set parity (critical), orphan/unreferenced keys (warn), and a hardcoded-Chinese-visible-text heuristic (warn).

### Usage
```bash
python check_i18n.py --root . [--locales-dir <path>] [--src-dir src]
```
The exit code is 1 when a critical item fails (a missing key or an interpolation parameter-set mismatch across languages). **Without Python, the AI cross-checks the same invariants by hand — equivalent effect.**

## derive_gate_status.py
A **read-only, advisory** tool that derives the true status of each test-gate capability (build/lint/typecheck/unit/e2e) from engineering facts in `package.json` — scripts present, test frameworks in dependencies — and an optional real run-result JSON. Exists to stop "build succeeded" from being recorded as "tests done", and to stop a unit run with zero cases from ever being recorded as passed.

### Usage
```bash
python derive_gate_status.py --root .
python derive_gate_status.py --root . --ran run-result.json
```
Exit code is always 0 (advisory only); when any capability is `failed` or `ran-but-zero-tests` it prints a highlighted warning line instead of failing the process.
