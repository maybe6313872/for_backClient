#!/usr/bin/env python3
"""
i18n consistency check (optional tool, P1-07).

Positioning:
- Zero-dependency, read-only, library-agnostic Web front-end i18n consistency checker.
  Uses only the standard library (argparse / pathlib / re / json / sys / datetime);
  pulls in no third-party packages.
- Used in the test gate to define and validate a set of i18n invariants when the project
  has i18n enabled.
- Read-only scan; does not modify any file. When Python is unavailable, an AI can verify
  the same invariants by hand for an equivalent result.

Usage (run at the project root):
  python check_i18n.py --root . [--locales-dir <path>] [--src-dir src]

Auto-discovery:
- When --locales-dir is not given explicitly, search under root for the common locale
  resource directories in order: src/i18n, src/locales, src/lang, locales, i18n.
- If none exist, treat as N/A (single language or i18n not enabled), print a notice, and
  exit with 0.

Invariants (each is reported, split into critical / warn):
  1) Cross-language key parity (critical): using the union of all languages' keys as the
     baseline, list per-language missing keys / extra keys; any language with a missing
     key -> critical.
  2) Interpolation parameter-set parity (critical): for keys present in >=2 languages,
     extract the placeholder parameter names from each template, supporting both
     double-brace (mustache) and single-brace interpolation styles; if the parameter-name
     set differs across languages for the same key -> critical.
  3) Orphan / unreferenced keys (warn): grep each key as a "string literal" under
     --src-dir; a key that never appears as a literal -> warn (may be a dynamically
     concatenated key, needs human review, must not be blindly deleted).
  4) Hardcoded visible-text heuristic (warn): scan .tsx/.vue/.jsx under --src-dir; a
     Chinese run (>=2 consecutive Han characters) that sits between > and <, or appears in
     a placeholder=/title=/aria-label= etc. attribute, and is not wrapped by a t(...) call
     on the same line -> warn (heuristic, may have false positives).

Exit codes:
- No locale resource directory -> N/A -> exit 0.
- critical_pass is false (a missing key or a parameter-set mismatch exists) -> exit 1;
  otherwise exit 0.

Parsing limits (best-effort, see the parse_ts_like note below):
- TS/JS locale files are parsed with regex approximation, not a full AST; deeply nested
  objects are only best-effort reconstructed into dotted key paths; complex dynamic
  concatenation / spread operators / computed property names cannot be covered, so a few
  keys may be missed or captured incorrectly.
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Candidate locale resource directories (relative to root, by priority)
CANDIDATE_LOCALE_DIRS = ["src/i18n", "src/locales", "src/lang", "locales", "i18n"]

# Locale identifiers: zh-CN / en-US / en / fr, etc.
LOCALE_RE = re.compile(r"^[a-z]{2}(-[A-Za-z]{2,4})?$")

# Locale resource file extensions
LOCALE_FILE_EXTS = {".json", ".ts", ".js", ".mjs", ".cjs"}

# Source scan extensions (orphan-key check)
SRC_LITERAL_EXTS = {".ts", ".tsx", ".js", ".jsx", ".vue"}

# Hardcoded-text scan extensions
SRC_HARDCODE_EXTS = {".tsx", ".vue", ".jsx"}

# Directory names to skip
SKIP_DIRS = {"node_modules", ".git", "dist", "build", "coverage", ".output", ".next", ".nuxt"}

# A run of >=2 consecutive CJK Han characters
CJK_RUN_RE = re.compile(r"[一-鿿]{2,}")

# Interpolation placeholders: double-brace (mustache) and single-brace
DOUBLE_BRACE_RE = re.compile(r"\{\{\s*([#/^]?\s*[\w.$]+)\s*\}\}")
SINGLE_BRACE_RE = re.compile(r"(?<!\{)\{\s*([\w.$]+)\s*\}(?!\})")

# t(...) call (whether a translation-function call exists on the same line)
T_CALL_RE = re.compile(r"\b(?:i18n\.)?(?:t|\$t|tc|\$tc)\s*\(")

# JSX/template text node: > ... <
TEXT_NODE_RE = re.compile(r">([^<>]*?)<")

# Visible-text attributes: placeholder / title / aria-label / alt / label
ATTR_TEXT_RE = re.compile(
    r'\b(?:placeholder|title|aria-label|alt|label)\s*=\s*(?:"([^"]*)"|\'([^\']*)\')'
)


# ---------------------------------------------------------------------------
# Generic reading
# ---------------------------------------------------------------------------

def read_text(p: Path) -> str:
    """Fault-tolerant text read (multi-encoding fallback). Returns empty string on failure."""
    for enc in ("utf-8-sig", "utf-8", "gbk", "cp936", "latin-1"):
        try:
            return p.read_text(encoding=enc)
        except (UnicodeDecodeError, FileNotFoundError):
            if not p.exists():
                return ""
            continue
    return ""


# ---------------------------------------------------------------------------
# Locale resource parsing
# ---------------------------------------------------------------------------

def flatten_json(obj, prefix: str = "") -> dict:
    """Flatten nested JSON/dict into dotted keys: {"a":{"b":"x"}} -> {"a.b":"x"}."""
    out: dict = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, (dict, list)):
                out.update(flatten_json(v, key))
            else:
                out[key] = "" if v is None else str(v)
    elif isinstance(obj, list):
        # Array: expand by index, values are mostly strings
        for i, v in enumerate(obj):
            key = f"{prefix}.{i}" if prefix else str(i)
            if isinstance(v, (dict, list)):
                out.update(flatten_json(v, key))
            else:
                out[key] = "" if v is None else str(v)
    return out


def parse_json_file(p: Path) -> dict:
    """Parse a JSON locale file into flat key -> string. Returns empty dict on failure."""
    txt = read_text(p)
    if not txt.strip():
        return {}
    try:
        data = json.loads(txt)
    except (json.JSONDecodeError, ValueError):
        return {}
    return flatten_json(data)


# TS/JS key-value pairs: supports
#   "key.path": "value"
#   key: "value"
#   'key': 'value'
#   key: `value`
# Values may be single-quoted / double-quoted / backtick-quoted.
_KV_RE = re.compile(
    r"""
    (?P<key>
        "(?P<dq>[^"\\]*(?:\\.[^"\\]*)*)"     # double-quoted key
      | '(?P<sq>[^'\\]*(?:\\.[^'\\]*)*)'     # single-quoted key
      | (?P<id>[A-Za-z_$][\w$]*)             # bare identifier key
    )
    \s*:\s*
    (?P<val>
        "(?P<vdq>[^"\\]*(?:\\.[^"\\]*)*)"    # double-quoted value
      | '(?P<vsq>[^'\\]*(?:\\.[^'\\]*)*)'    # single-quoted value
      | `(?P<vbt>[^`\\]*(?:\\.[^`\\]*)*)`    # backtick-quoted value
    )
    """,
    re.VERBOSE,
)


def parse_ts_like(p: Path) -> dict:
    """
    Approximately parse a TS/JS locale file into key -> template string (best-effort).

    Implementation limits (intentional; zero-dependency, no full AST):
    - Only regex-extracts "leaf-level" key: "value" pairs (keys may be dotted string keys
      or bare identifier keys).
    - Cannot reliably reconstruct the full dotted path of deeply nested objects: for
      something like
        { home: { title: "Home" } }
      it only extracts the leaf key; when the parent identifier cannot be chained level by
      level, it degrades to extracting the nearest identifier key "title".
      Therefore, for "multi-level nesting without dotted flat keys" styles, key names may
      lack the full prefix.
    - Spread operators (...), computed property names ([expr]), function return values, and
      conditional-expression values cannot be covered.
    The limits above are "isomorphic" across languages in cross-language comparison (the
    same set of files is parsed by the same rules), so the relative comparison for
    "parameter-set parity" and "key parity" remains valid; only cross-referencing against
    source grep may introduce orphan false positives, which is why the orphan check is
    graded warn rather than critical.
    """
    txt = read_text(p)
    if not txt.strip():
        return {}
    out: dict = {}
    for m in _KV_RE.finditer(txt):
        key = m.group("dq")
        if key is None:
            key = m.group("sq")
        if key is None:
            key = m.group("id")
        if key is None:
            continue
        val = m.group("vdq")
        if val is None:
            val = m.group("vsq")
        if val is None:
            val = m.group("vbt")
        if val is None:
            val = ""
        out[key] = val
    return out


def parse_locale_source(p: Path) -> dict:
    """Dispatch parsing of a single locale file by extension."""
    if p.suffix == ".json":
        return parse_json_file(p)
    return parse_ts_like(p)


def is_locale_name(name: str) -> bool:
    """Decide whether a file stem or subdirectory name looks like a locale identifier."""
    return bool(LOCALE_RE.match(name))


def discover_locales_dir(root: Path, explicit: str | None) -> Path | None:
    """Locate the locale resource directory; return None when not found."""
    if explicit:
        p = Path(explicit)
        if not p.is_absolute():
            p = root / p
        return p if p.exists() else None
    for cand in CANDIDATE_LOCALE_DIRS:
        p = root / cand
        if p.is_dir():
            return p
    return None


def load_locales(locales_dir: Path) -> dict:
    """
    Load all languages from the locale resource directory: locale -> {flat_key: template}.

    Two layouts are supported:
      (a) Single-file language: zh-CN.ts / en-US.json etc., where the stem looks like a
          locale identifier.
      (b) Subdirectory language: several namespace files under zh-CN/, where the directory
          name looks like a locale identifier; each file's keys inside the subdirectory are
          merged with the "file stem" as namespace prefix (unless the stem is index).
    """
    locales: dict = {}

    # (a) Top-level file form
    for child in sorted(locales_dir.iterdir()):
        if child.is_file() and child.suffix in LOCALE_FILE_EXTS and is_locale_name(child.stem):
            data = parse_locale_source(child)
            if data:
                locales.setdefault(child.stem, {}).update(data)

    # (b) Subdirectory form
    for child in sorted(locales_dir.iterdir()):
        if child.is_dir() and is_locale_name(child.name):
            merged: dict = {}
            for f in sorted(child.rglob("*")):
                if f.is_file() and f.suffix in LOCALE_FILE_EXTS:
                    ns = "" if f.stem.lower() == "index" else f.stem
                    data = parse_locale_source(f)
                    for k, v in data.items():
                        merged[f"{ns}.{k}" if ns else k] = v
            if merged:
                locales.setdefault(child.name, {}).update(merged)

    return locales


# ---------------------------------------------------------------------------
# Invariant checks
# ---------------------------------------------------------------------------

def extract_params(template: str) -> set:
    """Extract interpolation parameter names from a template, supporting both double-brace (mustache) and single-brace styles."""
    params = set()
    for m in DOUBLE_BRACE_RE.finditer(template):
        name = m.group(1).lstrip("#/^").strip()
        if name:
            params.add(name)
    for m in SINGLE_BRACE_RE.finditer(template):
        name = m.group(1).strip()
        if name:
            params.add(name)
    return params


def iter_src_files(src_dir: Path, exts: set, exclude_dir: Path | None = None):
    """Walk source files, skipping dependency / build directories; optionally exclude a subdirectory (such as the locale resource directory)."""
    if not src_dir.exists():
        return
    exclude_resolved = exclude_dir.resolve() if exclude_dir else None
    for p in src_dir.rglob("*"):
        if p.is_dir():
            continue
        if any(part in SKIP_DIRS for part in p.parts):
            continue
        if exclude_resolved is not None:
            try:
                p.resolve().relative_to(exclude_resolved)
                continue  # inside the excluded directory, skip
            except ValueError:
                pass
        if p.suffix in exts:
            yield p


def check_orphans(all_keys: set, src_dir: Path, locales_dir: Path | None = None) -> list:
    """
    Orphan-key check: a key that never appears in source as a string literal -> suspected
    unreferenced (warn).
    Naive implementation: concatenate all sources and, for each key, test whether "key" or
    'key' or `key` appears.
    Note: exclude the locale resource directory itself, otherwise a key would count as
    "referenced" in its own definition file and orphans could never be detected.
    """
    blob_parts = []
    for p in iter_src_files(src_dir, SRC_LITERAL_EXTS, exclude_dir=locales_dir):
        blob_parts.append(read_text(p))
    blob = "\n".join(blob_parts)
    suspects = []
    for key in sorted(all_keys):
        if not key:
            continue
        if (f'"{key}"' in blob) or (f"'{key}'" in blob) or (f"`{key}`" in blob):
            continue
        suspects.append(key)
    return suspects


def check_hardcoded(src_dir: Path) -> list:
    """
    Hardcoded visible-text heuristic: find Chinese visible text not wrapped by t(...) in
    .tsx/.vue/.jsx.
    Returns [(rel_path, lineno, snippet), ...].
    """
    hits = []
    for p in iter_src_files(src_dir, SRC_HARDCODE_EXTS):
        txt = read_text(p)
        for i, line in enumerate(txt.splitlines(), start=1):
            if not CJK_RUN_RE.search(line):
                continue
            has_t = bool(T_CALL_RE.search(line))
            flagged = False
            # Text node > Chinese <
            for m in TEXT_NODE_RE.finditer(line):
                seg = m.group(1)
                if CJK_RUN_RE.search(seg) and not has_t:
                    flagged = True
                    break
            # Chinese in visible attributes
            if not flagged:
                for m in ATTR_TEXT_RE.finditer(line):
                    seg = m.group(1) if m.group(1) is not None else m.group(2)
                    if seg and CJK_RUN_RE.search(seg) and not has_t:
                        flagged = True
                        break
            if flagged:
                snippet = line.strip()
                if len(snippet) > 120:
                    snippet = snippet[:117] + "..."
                hits.append((str(p), i, snippet))
    return hits


# ---------------------------------------------------------------------------
# Main flow
# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(
        description="Web front-end i18n consistency check (read-only, zero-dependency)."
    )
    ap.add_argument("--root", default=".", help="project root directory")
    ap.add_argument("--locales-dir", default=None, help="locale resource directory (auto-discovered if omitted)")
    ap.add_argument("--src-dir", default="src", help="source directory (relative to root), default src")
    args = ap.parse_args()

    root = Path(args.root).resolve()
    locales_dir = discover_locales_dir(root, args.locales_dir)

    # N/A path: no locale resource directory
    if locales_dir is None:
        print("No locale resource directory found; i18n check judged N/A (single language or i18n not enabled)")
        return 0

    src_dir = Path(args.src_dir)
    if not src_dir.is_absolute():
        src_dir = root / src_dir

    locales = load_locales(locales_dir)

    print("# i18n consistency check\n")
    print(f"Root directory: {root}")
    print(f"Locale resource directory: {locales_dir}")

    if not locales:
        print("\nLocale resource directory found, but no locale file could be parsed (names do not look like locale identifiers, or files are empty).")
        print("Judged N/A (cross-language comparison not possible).")
        result = {
            "root": str(root),
            "locales_dir": str(locales_dir),
            "locales": [],
            "total_keys": 0,
            "missing": {},
            "extra": {},
            "param_mismatch": [],
            "orphan_suspects": [],
            "hardcoded_suspects_count": 0,
            "critical_pass": True,
            "checked_at": datetime.date.today().isoformat(),
        }
        print("\n```json")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print("```")
        return 0

    locale_names = sorted(locales.keys())
    print(f"Detected languages: {', '.join(locale_names)}\n")

    # Key union
    union_keys: set = set()
    for keys in locales.values():
        union_keys.update(keys.keys())
    total_keys = len(union_keys)

    # --- 1) Cross-language key parity ---
    missing: dict = {}
    extra: dict = {}
    for loc in locale_names:
        keys = set(locales[loc].keys())
        miss = sorted(union_keys - keys)
        # "extra": meaningless relative to the union (the union contains everything); here
        # defined as "keys unique to this language only"
        ext = sorted(k for k in keys if sum(1 for L in locale_names if k in locales[L]) == 1)
        missing[loc] = miss
        extra[loc] = ext

    any_missing = any(missing[loc] for loc in locale_names)

    print("## 1. Cross-language key parity (critical)")
    print(f"Total keys in union: {total_keys}")
    for loc in locale_names:
        miss = missing[loc]
        ext = extra[loc]
        mark = "✗" if miss else "✓"
        print(f"{mark} [{loc}] missing {len(miss)}, unique {len(ext)}")
        if miss:
            show = miss[:20]
            print(f"    missing keys: {show}{' ...' if len(miss) > 20 else ''}")
        if ext:
            show = ext[:20]
            print(f"    unique keys: {show}{' ...' if len(ext) > 20 else ''}")
    print()

    # --- 2) Interpolation parameter-set parity ---
    param_mismatch: list = []
    mismatch_detail: list = []
    for key in sorted(union_keys):
        present = [loc for loc in locale_names if key in locales[loc]]
        if len(present) < 2:
            continue
        param_sets = {loc: extract_params(locales[loc][key]) for loc in present}
        distinct = {frozenset(s) for s in param_sets.values()}
        if len(distinct) > 1:
            param_mismatch.append(key)
            mismatch_detail.append((key, {loc: sorted(s) for loc, s in param_sets.items()}))

    print("## 2. Interpolation parameter-set parity (critical)")
    if not param_mismatch:
        print("✓ No interpolation parameter-set mismatch found")
    else:
        print(f"✗ Interpolation parameter-set mismatch: {len(param_mismatch)} keys")
        for key, detail in mismatch_detail[:20]:
            print(f"    [{key}] {detail}")
        if len(mismatch_detail) > 20:
            print(f"    ... {len(mismatch_detail) - 20} more omitted")
    print()

    # --- 3) Orphan / unreferenced keys ---
    orphan_suspects = check_orphans(union_keys, src_dir, locales_dir=locales_dir)
    print("## 3. Orphan / unreferenced keys (warn)")
    if not src_dir.exists():
        print(f"• Source directory does not exist ({src_dir}); skipping orphan-key check")
        orphan_suspects = []
    elif not orphan_suspects:
        print("✓ All keys appear as literals in source")
    else:
        print(f"• Suspected unreferenced keys (may be dynamically concatenated, need human review): {len(orphan_suspects)}")
        for k in orphan_suspects[:50]:
            print(f"    {k}")
        if len(orphan_suspects) > 50:
            print(f"    ... {len(orphan_suspects) - 50} more omitted")
        print("  Note: dynamically concatenated keys cause false positives; for keys that are"
              " genuinely used dynamically, register a \"documented exception\" rather than deleting them.")
    print()

    # --- 4) Hardcoded visible text ---
    hardcoded = check_hardcoded(src_dir)
    print("## 4. Hardcoded visible-text heuristic (warn)")
    if not src_dir.exists():
        print(f"• Source directory does not exist ({src_dir}); skipping hardcoded scan")
    elif not hardcoded:
        print("✓ No suspected non-internationalized Chinese visible text found")
    else:
        print(f"• Suspected hardcoded Chinese visible text: {len(hardcoded)} occurrences (heuristic, may have false positives)")
        for path, lineno, snip in hardcoded[:20]:
            print(f"    {path}:{lineno}: {snip}")
        if len(hardcoded) > 20:
            print(f"    ... {len(hardcoded) - 20} more omitted")
    print()

    critical_pass = (not any_missing) and (not param_mismatch)

    print("## Conclusion")
    print(f"{'✓ Critical items passed' if critical_pass else '✗ Critical items not passed'}"
          f" (a missing key or interpolation parameter-set mismatch causes failure)\n")

    result = {
        "root": str(root),
        "locales_dir": str(locales_dir),
        "locales": locale_names,
        "total_keys": total_keys,
        "missing": {loc: missing[loc] for loc in locale_names},
        "extra": {loc: extra[loc] for loc in locale_names},
        "param_mismatch": param_mismatch,
        "orphan_suspects": orphan_suspects[:50],
        "hardcoded_suspects_count": len(hardcoded),
        "critical_pass": critical_pass,
        "checked_at": datetime.date.today().isoformat(),
    }
    print("```json")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print("```")

    return 0 if critical_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
