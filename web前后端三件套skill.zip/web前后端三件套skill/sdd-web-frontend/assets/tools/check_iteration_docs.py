#!/usr/bin/env python3
"""
Iteration-boundary document gate check (optional tool).

Positioning:
- Optional deterministic fallback, not a hard dependency. Without Python, the AI
  cross-checks manually against the entry/exit gates in gate-and-stages — equivalent effect.
- Read-only check of specs/ document discipline; changes no files.

Usage (run at the project root):
  python check_iteration_docs.py --root .
Exit codes: 0 = critical items pass; 1 = critical items fail (task.md missing or no date header).
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
from pathlib import Path

DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


def read(p: Path) -> str:
    for enc in ("utf-8-sig", "utf-8", "gbk", "cp936", "latin-1"):
        try:
            return p.read_text(encoding=enc)
        except (UnicodeDecodeError, FileNotFoundError):
            if not p.exists():
                return ""
            continue
    return ""


STATUS_SET = ("就绪", "进行中", "已交付待归档")
FIELD_NAMES = ("迭代标识", "迭代日期", "状态")
HEADER_RE = re.compile(r"^\s*<!--(?P<body>.+?)-->\s*$")


def check_date_header(p: Path) -> tuple[str, str]:
    """Grade the three-field date header (specs-lifecycle.md §3).

    Returns (level, detail) with level in "ok" / "warn" / "critical".

    Only an **out-of-set 状态 value** is critical. A legacy header written before
    the field set was frozen may still split into four fields (an inline status
    enumeration); such files are read under legacy tolerance — take field 3 and
    warn. Rationale: archived files are protected by F3 (no overwrite / delete),
    so a hard red light on a file the framework forbids editing could never be
    cleared. Never repairs, never guesses a value.
    """
    txt = read(p)
    if not txt.strip():
        return "warn", f"{p}: file is empty, no date header"

    m = HEADER_RE.match(txt.splitlines()[0])
    if not m:
        return "warn", f"{p}: first line is not a date-header comment"

    parts = [seg.strip() for seg in m.group("body").split("|")]
    if len(parts) < 3:
        return "warn", f"{p}: date header splits into {len(parts)} fields, expected exactly 3"

    legacy = ""
    if len(parts) > 3:
        legacy = (
            f"{p}: date header splits into {len(parts)} fields — legacy inline status "
            f"enumeration ('|' is the field separator); reading field 3 only"
        )
        parts = parts[:3]

    for got, want in zip(parts, FIELD_NAMES):
        if not got.startswith(f"{want}: "):
            return "warn", f"{p}: field '{got}' does not start with '{want}: '"

    status = parts[2].split(":", 1)[1].strip()
    if status not in STATUS_SET:
        return "critical", f"{p}: 状态 value '{status}' is outside the frozen set {'/'.join(STATUS_SET)}"

    return ("warn", legacy) if legacy else ("ok", "")


def main() -> int:
    ap = argparse.ArgumentParser(description="SDD iteration-boundary doc gate check (read-only).")
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    specs = root / "specs"

    checks = []  # (name, ok, level, detail)  level: critical|warn|info

    task = specs / "task.md"
    task_txt = read(task)
    has_task = task.exists() and task_txt.strip() != ""
    head = "\n".join(task_txt.splitlines()[:12])
    has_date = bool(DATE_RE.search(head))
    checks.append(("task.md exists and is non-empty", has_task, "critical", str(task)))
    checks.append(("task.md header carries a date (current iteration header)", has_date, "critical", "no YYYY-MM-DD found in first 12 lines" if not has_date else ""))

    task_dir = specs / "task"
    archives = sorted(task_dir.glob("*.md")) if task_dir.exists() else []
    big_task = len(task_txt) > 4000
    checks.append(("task/ has archives (archive first · no overwrite)", bool(archives), "warn" if big_task else "info",
                   f"{len(archives)} archive(s)" if archives else "no archives; a large task.md should be archived first" if big_task else "no archives (possibly no history yet)"))

    iteration_log = specs / "context" / "iteration-log.md"
    checks.append(("context/iteration-log.md exists", iteration_log.exists(), "warn", str(iteration_log)))

    stage_dirs = ("1-constitution", "2-spec", "3-design", "4-tasks", "5-test", "6-deliver")
    header_targets = [specs / "task.md"] + [specs / s / "current.md" for s in stage_dirs]
    # A stage that has not been entered legitimately has no current.md; presence itself is
    # governed by the §4 presence rule, not by this check. Only existing files are asserted.
    present = [t for t in header_targets if t.exists()]
    graded = [check_date_header(t) for t in present]
    fatal = [d for lvl, d in graded if lvl == "critical"]
    shaky = [d for lvl, d in graded if lvl == "warn"]
    checks.append((
        "date header: 状态 within the frozen set 就绪/进行中/已交付待归档",
        not fatal,
        "critical",
        "; ".join(fatal) if fatal else f"{len(present)} document(s) checked",
    ))
    checks.append((
        "date header shape: exactly 3 fields 迭代标识/迭代日期/状态",
        not shaky,
        "warn",
        "; ".join(shaky) if shaky else f"{len(present)} document(s) checked",
    ))

    open_issues = specs / "open-issues.md"
    checks.append(("open-issues.md exists (governance entry)", open_issues.exists(), "info", str(open_issues)))

    retro_readme = specs / "retro" / "README.md"
    checks.append(("retro/README.md exists (retro ledger available)", retro_readme.exists(), "info", str(retro_readme)))

    critical_fail = [c for c in checks if c[2] == "critical" and not c[1]]
    print("# Iteration-boundary document gate check\n")
    for name, ok, level, detail in checks:
        mark = "✓" if ok else ("✗" if level == "critical" else "•")
        tag = {"critical": "[critical]", "warn": "[advice]", "info": "[info]"}[level]
        line = f"{mark} {tag} {name}"
        if detail:
            line += f" — {detail}"
        print(line)
    print()
    print(json.dumps({
        "root": str(root),
        "critical_pass": not critical_fail,
        "critical_failed": [c[0] for c in critical_fail],
        "checked_at": datetime.date.today().isoformat(),
    }, ensure_ascii=False, indent=2))
    return 1 if critical_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
