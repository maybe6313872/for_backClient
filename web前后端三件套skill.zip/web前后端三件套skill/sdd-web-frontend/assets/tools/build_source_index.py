#!/usr/bin/env python3
"""
Lightweight source coverage index (optional tool).

Positioning:
- Optional tool, not a prerequisite for mode B. When no Python/tooling environment is
  available, just skip it; an AI-built source inventory achieves an equivalent result.
- Only helps the AI take stock of sources, entrypoints, dependencies, and context
  coverage clues.
- Outputs JSON/Markdown; does not use SQLite, does not generate HTML, and has no
  network dependency.

Usage (copy into the project's specs/_tools/ and run):
  python build_source_index.py --root <project root> --out specs/_generated/source-index
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


DEFAULT_EXTENSIONS = {
    ".ts", ".tsx", ".js", ".jsx", ".vue", ".scss",
}

SKIP_DIRS = {
    ".git", ".svn", ".hg", ".idea", ".vscode",
    "node_modules", "dist", "build", "out", "target",
    ".venv", "venv", "__pycache__", ".pytest_cache",
    "_generated",
}


@dataclass
class Symbol:
    name: str
    kind: str
    line: int


@dataclass
class SourceFile:
    path: str
    extension: str
    size: int
    lines: int
    symbols: list[Symbol]
    dependencies: list[str]


def read_text(path: Path) -> str:
    for encoding in ("utf-8-sig", "utf-8", "gbk", "cp936", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return path.read_text(errors="ignore")


def iter_source_files(root: Path, extensions: set[str]) -> Iterable[Path]:
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        parts = set(path.relative_to(root).parts)
        if parts & SKIP_DIRS:
            continue
        if path.suffix.lower() in extensions:
            yield path


def line_no(text: str, pos: int) -> int:
    return text.count("\n", 0, pos) + 1


def extract_symbols(path: Path, text: str) -> list[Symbol]:
    ext = path.suffix.lower()
    patterns: list[tuple[str, str]] = []

    if ext == ".py":
        patterns = [
            ("class", r"(?m)^\s*class\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("function", r"(?m)^\s*def\s+([A-Za-z_][A-Za-z0-9_]*)\s*\("),
        ]
    elif ext in {".ts", ".tsx", ".js", ".jsx"}:
        patterns = [
            ("class", r"(?m)^\s*export\s+class\s+([A-Za-z_$][A-Za-z0-9_$]*)\b|^\s*class\s+([A-Za-z_$][A-Za-z0-9_$]*)\b"),
            ("function", r"(?m)^\s*export\s+function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\(|^\s*function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\("),
            ("interface", r"(?m)^\s*export\s+interface\s+([A-Za-z_$][A-Za-z0-9_$]*)\b|^\s*interface\s+([A-Za-z_$][A-Za-z0-9_$]*)\b"),
            ("type", r"(?m)^\s*export\s+type\s+([A-Za-z_$][A-Za-z0-9_$]*)\b|^\s*type\s+([A-Za-z_$][A-Za-z0-9_$]*)\b"),
        ]
    elif ext in {".java", ".cs"}:
        patterns = [
            ("class", r"(?m)^\s*(?:public|private|protected|internal|final|abstract|static|\s)*\s*class\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("interface", r"(?m)^\s*(?:public|private|protected|internal|\s)*\s*interface\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("enum", r"(?m)^\s*(?:public|private|protected|internal|\s)*\s*enum\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("method", r"(?m)^\s*(?:public|private|protected|internal|static|final|async|virtual|override|\s)+[\w<>\[\],\s]+\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;]*\)\s*\{"),
        ]
    elif ext in {".c", ".h", ".cpp", ".hpp", ".cc", ".hh"}:
        patterns = [
            ("macro", r"(?m)^\s*#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("type", r"(?m)^\s*(?:typedef\s+)?(?:struct|enum)\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
            ("function", r"(?m)^\s*(?:static\s+)?(?:inline\s+)?[A-Za-z_][\w\s\*\(\)]*?\s+([A-Za-z_][A-Za-z0-9_]*)\s*\([^;{}]*\)\s*\{"),
        ]
    elif ext == ".go":
        patterns = [
            ("function", r"(?m)^\s*func\s+(?:\([^)]+\)\s*)?([A-Za-z_][A-Za-z0-9_]*)\s*\("),
            ("type", r"(?m)^\s*type\s+([A-Za-z_][A-Za-z0-9_]*)\b"),
        ]

    symbols: list[Symbol] = []
    for kind, pattern in patterns:
        for match in re.finditer(pattern, text):
            name = next((group for group in match.groups() if group), None)
            if not name:
                continue
            symbols.append(Symbol(name=name, kind=kind, line=line_no(text, match.start())))
    return sorted(symbols, key=lambda item: (item.line, item.kind, item.name))


def extract_dependencies(path: Path, text: str) -> list[str]:
    ext = path.suffix.lower()
    patterns: list[str] = []

    if ext in {".c", ".h", ".cpp", ".hpp", ".cc", ".hh"}:
        patterns = [r'(?m)^\s*#\s*include\s+[<"]([^>"]+)[>"]']
    elif ext == ".py":
        patterns = [r"(?m)^\s*import\s+([A-Za-z0-9_\.]+)", r"(?m)^\s*from\s+([A-Za-z0-9_\.]+)\s+import\s+"]
    elif ext in {".ts", ".tsx", ".js", ".jsx"}:
        patterns = [r'(?m)^\s*import\b.*?\bfrom\s+[\'"]([^\'"]+)[\'"]', r'(?m)^\s*import\s+[\'"]([^\'"]+)[\'"]']
    elif ext in {".java", ".cs"}:
        patterns = [r"(?m)^\s*import\s+([A-Za-z0-9_\.]+)\s*;", r"(?m)^\s*using\s+([A-Za-z0-9_\.]+)\s*;"]
    elif ext == ".go":
        patterns = [r'(?m)^\s*import\s+"([^"]+)"']

    deps: set[str] = set()
    for pattern in patterns:
        deps.update(match.group(1) for match in re.finditer(pattern, text))
    return sorted(deps)


def find_entrypoints(source: SourceFile) -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []
    for symbol in source.symbols:
        lowered = symbol.name.lower()
        if symbol.name == "main":
            reason = "main"
        elif lowered.endswith("handler") or "handler" in lowered:
            reason = "handler"
        elif lowered.startswith("task") or lowered.endswith("task"):
            reason = "task"
        elif "controller" in lowered or "route" in lowered:
            reason = "web-entry"
        elif symbol.kind in {"class", "interface"} and ("service" in lowered or "controller" in lowered):
            reason = "service-entry"
        else:
            continue
        entries.append({"path": source.path, "name": symbol.name, "kind": symbol.kind, "line": symbol.line, "reason": reason})
    return entries


def collect_context_text(root: Path) -> str:
    context_dir = root / "specs" / "context"
    if not context_dir.exists():
        return ""
    chunks: list[str] = []
    for path in context_dir.rglob("*.md"):
        chunks.append(read_text(path))
    return "\n".join(chunks)


def build_coverage(files: list[SourceFile], context_text: str) -> list[dict[str, object]]:
    coverage: list[dict[str, object]] = []
    for source in files:
        mentioned_symbols = [
            symbol.name for symbol in source.symbols
            if symbol.name and re.search(rf"\b{re.escape(symbol.name)}\b", context_text)
        ]
        file_mentioned = source.path.replace("\\", "/") in context_text.replace("\\", "/")
        coverage.append({
            "path": source.path,
            "file_mentioned": file_mentioned,
            "symbol_count": len(source.symbols),
            "mentioned_symbol_count": len(mentioned_symbols),
            "mentioned_symbols": mentioned_symbols[:50],
        })
    return coverage


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def write_summary(out_dir: Path, files: list[SourceFile], entrypoints: list[dict[str, object]], coverage: list[dict[str, object]]) -> None:
    total_symbols = sum(len(item.symbols) for item in files)
    uncovered = [item for item in coverage if not item["file_mentioned"] and item["mentioned_symbol_count"] == 0]
    lines = [
        "# Source Coverage Index Summary",
        "",
        f"- Source files: {len(files)}",
        f"- Symbols: {total_symbols}",
        f"- Entrypoint clues: {len(entrypoints)}",
        f"- File clues not present in context: {len(uncovered)}",
        "",
        "## Entrypoint clues",
    ]
    for item in entrypoints[:80]:
        lines.append(f"- `{item['name']}` ({item['reason']}) -> `{item['path']}:{item['line']}`")
    lines.extend(["", "## Possibly uncovered files"])
    for item in uncovered[:120]:
        lines.append(f"- `{item['path']}`")
    (out_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a lightweight source index for SDD mode B.")
    parser.add_argument("--root", default=".", help="project root")
    parser.add_argument("--out", default="specs/_generated/source-index", help="output directory")
    parser.add_argument("--ext", nargs="*", default=sorted(DEFAULT_EXTENSIONS), help="source extensions")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    out_dir = (root / args.out).resolve()
    extensions = {ext if ext.startswith(".") else f".{ext}" for ext in args.ext}

    files: list[SourceFile] = []
    for path in sorted(iter_source_files(root, extensions)):
        text = read_text(path)
        rel = path.relative_to(root).as_posix()
        files.append(SourceFile(
            path=rel,
            extension=path.suffix.lower(),
            size=path.stat().st_size,
            lines=text.count("\n") + 1,
            symbols=extract_symbols(path, text),
            dependencies=extract_dependencies(path, text),
        ))

    entrypoints = [entry for source in files for entry in find_entrypoints(source)]
    context_text = collect_context_text(root)
    coverage = build_coverage(files, context_text)
    dependencies = [{"path": item.path, "dependencies": item.dependencies} for item in files if item.dependencies]
    unresolved = [item for item in coverage if not item["file_mentioned"] and item["mentioned_symbol_count"] == 0]

    write_json(out_dir / "inventory.json", [asdict(item) for item in files])
    write_json(out_dir / "entrypoints.json", entrypoints)
    write_json(out_dir / "dependencies.json", dependencies)
    write_json(out_dir / "coverage.json", coverage)
    write_json(out_dir / "unresolved.json", unresolved)
    write_summary(out_dir, files, entrypoints, coverage)

    print(json.dumps({
        "files": len(files),
        "symbols": sum(len(item.symbols) for item in files),
        "entrypoints": len(entrypoints),
        "unresolved": len(unresolved),
        "out": str(out_dir),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
