# 总体设计 — {项目名称}

> 版本：1.0 | 日期：{YYYY-MM-DD}

## 架构概览

```mermaid
graph TD
    Browser --> CDN
    CDN --> App
    App --> Router
    Router --> Pages
    Pages --> Components
    Components --> Store
    Store --> APILayer
    APILayer --> Backend
```

## 组件架构

### 组件层级

```mermaid
graph TD
    App --> Layout
    Layout --> Header
    Layout --> Sidebar
    Layout --> MainContent
    MainContent --> RouterView
```

### 组件分类

| 类别 | 目录 | 说明 |
|------|------|------|
| 页面组件 | `src/pages/` | 路由级组件 |
| 布局组件 | `src/layouts/` | 页面布局骨架 |
| 业务组件 | `src/components/` | 业务逻辑组件 |
| 基础组件 | `src/components/ui/` | 通用 UI 组件 |

## 状态管理

### Store 结构

```
stores/
├── useAuthStore     ← 认证状态
├── useUserStore     ← 用户信息
├── useAppStore      ← 应用全局状态
└── use{Feature}Store ← 功能模块状态
```

### 数据流向

```mermaid
flowchart LR
    Component -->|action| Store
    Store -->|state| Component
    Store -->|request| API
    API -->|response| Store
```

## 路由设计

| 路径 | 页面 | 守卫 | 懒加载 |
|------|------|------|--------|
| `/` | Home | - | 是 |
| `/login` | Login | guest | 是 |
| `/dashboard` | Dashboard | auth | 是 |

## API 层设计

### 请求封装

- 基础封装：{axios/fetch}
- 拦截器：请求添加 token、响应统一错误处理
- 缓存策略：{TanStack Query / 自定义}

### 错误处理

| HTTP 状态 | 处理方式 |
|-----------|---------|
| 401 | 跳转登录页 |
| 403 | 显示无权限提示 |
| 500 | 显示服务器错误提示 |
| 网络错误 | 显示网络异常提示 |

## 响应式策略

| 断点 | 宽度 | 布局 |
|------|------|------|
| sm | >= 640px | 单列 |
| md | >= 768px | 侧边栏收起 |
| lg | >= 1024px | 侧边栏展开 |
| xl | >= 1280px | 宽屏优化 |
