<!-- 迭代标识: 交付归档 | 迭代日期: YYYY-MM-DD | 状态: 就绪 -->
# 交付文档 — {项目名称}

> 版本：1.0 | 日期：{YYYY-MM-DD} | 迭代：{迭代名称}

## Changelog

### {版本号}（{YYYY-MM-DD}）

#### 新增
- {新增功能描述}

#### 修复
- {修复描述}

#### 变更
- {变更描述}

## 构建产物

| 项目 | 值 |
|------|---|
| 构建命令 | `pnpm build` |
| 产物目录 | `dist/` |
| 产物大小 | {KB/MB} |
| 构建时间 | {时间} |

## 部署策略

| 项目 | 值 |
|------|---|
| 部署方式 | {Vercel/Nginx/Docker/CDN} |
| 部署环境 | {staging/production} |
| 回滚方案 | {回滚步骤} |

## 交付证据

- [ ] 构建成功截图
- [ ] 测试通过报告
- [ ] 部署成功截图
- [ ] 关键功能验证截图

## 文档同步

- [ ] README.md 架构鹰眼图已更新
- [ ] context/modules.md 已更新
- [ ] context/features.md 已更新
- [ ] context/environment.md 已更新
- [ ] context/architecture.md 已更新
- [ ] context/iteration-log.md 已追加本次迭代记录
- [ ] task.md 已归档到 specs/task/

## Gate checklist

- [ ] changelog 已更新
- [ ] 构建产物路径已记录
- [ ] 部署策略明确且可执行
- [ ] 交付证据齐全
- [ ] 文档同步完成
- [ ] task.md 已归档到 specs/task/
