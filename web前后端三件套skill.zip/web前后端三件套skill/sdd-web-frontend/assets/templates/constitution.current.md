<!-- 迭代标识: 宪章基线 | 迭代日期: YYYY-MM-DD | 状态: 就绪 -->
# 宪章 — {项目名称}

> 版本：1.0 | 日期：{YYYY-MM-DD}

## 通用协议

1. **决策优先级**：用户明确指令 > 宪章约束 > AI 最佳实践
2. **编码风格**：跟随项目已有风格，不引入新风格
3. **最小改动**：每次修改只改必要的部分，不做额外重构
4. **类型安全**：TypeScript strict 模式，禁止 `any` 逃逸
5. **测试覆盖**：新功能必须有对应测试

## 项目专属协议

### 技术栈固化

| 项目 | 约束 |
|------|------|
| 框架 | {React/Vue} {版本} |
| 语言 | TypeScript {版本} |
| 构建工具 | Vite {版本；默认 8.x，见版本基线表} |
| CSS 方案 | {SCSS/CSS Modules/Tailwind} |
| 包管理器 | {从锁文件/packageManager **识别**：pnpm-lock→pnpm / yarn.lock→yarn / package-lock→npm / bun.lockb→bun；全新项目默认 pnpm；**存量项目跟随既有唯一锁文件，勿硬套**} |
| 包管理器迁移 | {如需迁移：作为显式 constitution 决策 + 独立任务；否则填"不迁移，跟随既有"} |
| Node.js | {版本；Vite 8/7 需 20.19+ 或 22.12+} |
| 目标浏览器 | {默认 Chrome 最近 2 稳定版；多浏览器/更低版本/移动端此处显式声明} |
| 条件化能力 | 路由={需要/N-A} 响应式={需要/N-A} 可观测性={需要/N-A} i18n={多语言/单语言 N-A}（N/A 记理由+剩余风险） |
| 部署方式 | {Vercel/Nginx/Docker/CDN} |

### 禁区

- 禁止引入 jQuery 或其他 DOM 操作库
- 禁止使用 `var`，统一使用 `const`/`let`
- 禁止在组件中直接调用 fetch/axios，必须通过 service 层
- 禁止提交 `.env` 文件到版本控制
- {其他项目特定禁区}

## Gate checklist

- [ ] 包含通用协议条目
- [ ] 包含项目专属协议条目（技术栈、禁区）
- [ ] 宪章条目已与用户逐条确认
- [ ] task.md 已更新为 constitution 阶段完成
