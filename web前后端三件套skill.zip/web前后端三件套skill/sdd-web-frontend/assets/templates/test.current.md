<!-- 迭代标识: 测试验证 | 迭代日期: YYYY-MM-DD | 状态: 就绪 -->
# 测试文档 — {项目名称}

> 版本：1.0 | 日期：{YYYY-MM-DD} | 迭代：{迭代名称}

## 测试覆盖矩阵

| 需求编号 | 测试类型 | 测试文件 | 状态 |
|---------|---------|---------|------|
| REQ-001 | 单元测试 | `__tests__/{file}.test.ts` | 待执行 |
| REQ-001 | E2E 测试 | `e2e/{file}.spec.ts` | 待执行 |

## 单元测试

### {Component} 测试

```typescript
describe('{Component}', () => {
  it('should {测试描述}', () => {
    // 测试代码
  });
});
```

## E2E 测试

### {用户流程} 测试

```typescript
test('{流程描述}', async ({ page }) => {
  // E2E 测试代码
});
```

## Gate 状态派生（P0-02 · 每项状态来自工程事实，禁止把"构建成功"写成"测试完成"）

> 状态取值：`passed` / `failed` / `ran-but-zero-tests` / `configured-not-run` / `missing` / `N/A`。可用 `python specs/_tools/derive_gate_status.py --root . [--ran run.json]` 自动派生。`ran-but-zero-tests` 与 `failed` **不得**记为 passed。`N/A`/`missing` 须写理由+剩余风险。

| 能力 | 脚本/框架是否配置 | 命令退出码 | 测试发现数 | **派生状态** | 证据文件 |
|---|---|---|---|---|---|
| build | {是/否} | {0/n/未跑} | — | {状态} | {路径} |
| lint | {是/否} | {…} | — | {状态} | {…} |
| typecheck | {是/否} | {…} | — | {状态} | {…} |
| 单元测试 | {vitest/jest/无} | {…} | {n} | {状态} | {…} |
| E2E | {playwright/cypress/无} | {…} | {n} | {状态/N-A} | {…} |

## 逐请求异步链路验证（RULE-ASYNC-04 · 逐行对 design 状态矩阵）

| 链路 | idle | loading | 成功非空 | 成功为空 | error | 旧数据刷新失败 | 取消/过期 | 命令类:防重 | L 级证据 |
|---|---|---|---|---|---|---|---|---|---|
| {查询X} | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | — | L? + 证据 |

## i18n 检查（如启用；单语言整节 N/A）

- [ ] `python specs/_tools/check_i18n.py --root .` 通过（缺键/多余键/插值参数/孤儿/硬编码）
- [ ] 语言切换回归：state/日志/通知/错误/日期数字格式不残留旧语言

## API 契约异常用例（RULE-TYPE-04）

- [ ] 字段缺失 / 类型变化 / 错误响应 / 非 JSON 响应已覆盖

## 执行记录

| 测试类型 | 执行时间 | 通过/总数 | 覆盖率 |
|---------|---------|----------|--------|
| 单元测试 | {时间} | {x/y} | {%} |
| E2E 测试 | {时间} | {x/y} | - |

## Gate checklist

- [ ] build/lint/typecheck 各自派生状态（非笼统"通过"）
- [ ] 单元测试状态派生正确（zero-tests/failed 未升格 passed）
- [ ] E2E 命中触发条件则执行，否则 N/A（记理由）
- [ ] 逐请求异步链路矩阵逐行验证并标 L 级
- [ ] （如启用）i18n 不变量检查通过 + 切换回归
- [ ] API 契约异常用例已覆盖
- [ ] 关键页 Lighthouse/axe（如适用）；性能 LCP<2.5s/INP<200ms/CLS<0.1
- [ ] 测试用例覆盖 spec 验收点；每条结论标 L1–L5
- [ ] 执行记录与证据已归档；task.md 已更新
