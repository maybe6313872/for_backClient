<!-- 模板：放到每个外部资料副本目录（如 specs/2-spec/inputs/sources.md 或 docs/requirements/<迭代>/inputs/sources.md）。机制见 references/specs-lifecycle.md「外部资料副本」节 -->
# 副本来源登记（sources.md）

| 副本文件 | 源头路径/URL | 抓取时间 | 抓取时源版本/mtime/内容哈希 | 备注 |
|---|---|---|---|---|
| <需求规格书-V1.6.md> | <\\server\...\需求规格书.docx 或 URL> | <YYYY-MM-DD HH:MM> | <V1.6 / mtime / sha256 前8位> | <> |

> 规则：① 任何副本入本目录必须同步登记本表；② 开迭代前巡检与任何阶段消费副本前，逐行比对源头当前 mtime/版本/哈希，不一致即上报用户、经确认后重新复制并更新本表；③ 源头不可达标 ⚠️ 待确认 入 open-issues。
