# 性能预算

> 最后更新：{YYYY-MM-DD}

## Core Web Vitals 目标

> 阈值唯一值见 environment-and-tools.md §版本化基线表；**INP 已于 2024-03 取代 FID**。

| 指标 | 目标值 | 当前值 |
|------|--------|--------|
| LCP | < 2.5s | - |
| INP | < 200ms | - |
| CLS | < 0.1 | - |
| TTFB | < 800ms | - |
| FCP | < 1.8s | - |

## 包体积预算

| 资源 | 预算 | 当前 |
|------|------|------|
| JS (gzip) | < 200KB | - |
| CSS (gzip) | < 50KB | - |
| 首屏图片 | < 100KB | - |
| 总计 | < 500KB | - |

## 性能规则

- 路由级代码分割
- 图片懒加载
- 字体 preload + font-display: swap
- 第三方脚本 async/defer
