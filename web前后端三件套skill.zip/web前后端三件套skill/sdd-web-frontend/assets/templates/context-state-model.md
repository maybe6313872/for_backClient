<!-- 全局状态模型 | 更新日期: YYYY-MM-DD -->
# 全局状态模型（state-model.md）

> 本域跨组件共享的状态切片、状态流与持久化。选型由状态分类驱动（见 §0），不预设"必用某库"或"全用原生"。模式 B 必填，模式 A 改到共享状态时同步。DTO/实体类型见同目录 `data-model.md`。

## 0. 状态分类与选型（RULE-STATE-04）
| 类别 | 本项目具体状态 | 选型（原生 / Query / store / 表单库 / 表格库） | 理由 / 触发信号 | 原生时已覆盖的边界 |
|---|---|---|---|---|
| 服务端状态 | <列表/详情/状态轮询> | <TanStack Query / 自研缓存> | <需缓存+失效+轮询> | <四态/竞态/失效映射…> |
| UI 状态 | <弹窗/选中/tab> | <局部 useState> | <仅本组件> | — |
| 表单状态 | <字段/校验/提交> | <原生 / React Hook Form…> | <是否字段联动+异步校验> | <脏检查/防重/聚焦> |
| 流程/机器状态 | <长流程/步骤/进度> | <原生 / 状态机> | <多步+重置分支> | <非法迁移防护> |
| 持久化状态 | <sessionStorage/URL> | <—> | <恢复来源> | <读不到的兜底> |
| 跨组件共享 | <会话/连接> | <store> | <多处读写> | — |

## 1. Store 切片清单
| 切片/Store | 关键字段 | 含义 | 持久化 | 主要读写方 |
|---|---|---|---|---|
| <userStore> | <token, profile, isAuth> | <用户会话状态> | <localStorage / 无> | <AuthGuard, Header, LoginPage> |

## 2. 状态流（action/mutation → store → view）
| 动作 | 触发处 | 改变的切片字段 | 影响的视图 | 证据强度 |
|---|---|---|---|---|
| <login()> | <LoginPage 提交> | <userStore.token/profile> | <Header, 受保护路由> | 静态可见 |

## 3. 外部触点（EXTERNAL_TOUCHPOINTS）
| 触点 | 类型 | 协议/契约出处 | 失败/超时行为 |
|---|---|---|---|
| <后端 /api/login> | REST | <Swagger / src/api/auth.ts> | <401→清 token 重定向登录> |
| <localStorage 'token'> | 浏览器 API | <src/stores/user.ts> | <读不到→未登录态> |

## 4. 状态机/生命周期（如有）
- <会话状态：匿名 → 登录中 → 已登录 → 过期；非法迁移防护>

## 5. 缓存模型（RULE-ASYNC-05 · 有共享服务端数据/轮询/离线/写后刷新时必填，否则写"无共享缓存"）
| 缓存数据 | 所有者（组件/service/store/queryClient） | key（参数身份） | 新鲜度（TTL/stale） | 恢复/刷新时机（聚焦/轮询/重连/手动） |
|---|---|---|---|---|
| <状态探测> | <queryClient> | <['status', id]> | <staleTime 5s> | <refetchOnWindowFocus + 15s 轮询> |

**写路径 → 失效 key 映射（必列，禁"靠开发者记得清缓存"）**：
| 写操作(mutation) | 失效/更新的 key | 同步方式（invalidate/setQueryData/乐观更新+回滚） |
|---|---|---|
| <updateConfig()> | <['config'], ['status']> | <invalidateQueries> |

**并发写语义**：<同飞去重 / 写-写冲突处理 / 乐观更新回滚>。
