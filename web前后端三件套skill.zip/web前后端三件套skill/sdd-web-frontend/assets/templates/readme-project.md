# {项目名称}

> 项目认知文档（代码地图）— 供 AI 助手快速理解项目全貌

## 架构鹰眼图

```mermaid
graph TD
    App --> Layout
    Layout --> RouterView
    RouterView --> Pages
    Pages --> Components
    Components --> Store
    Store --> API
```

> 请根据实际项目结构更新此图

## 技术栈

| 类别 | 技术 | 版本 |
|------|------|------|
| 框架 | {React/Vue/Svelte} | {版本} |
| 语言 | TypeScript | {版本} |
| 构建 | {Vite/Webpack} | {版本} |
| CSS | {Tailwind/SCSS/CSS Modules} | {版本} |
| 状态管理 | {Zustand/Pinia/Redux} | {版本} |
| 路由 | {React Router/Vue Router} | {版本} |
| 包管理 | pnpm | {版本} |
| Node.js | - | {版本} |

## 目录结构

```
src/
├── components/     ← 公共组件
├── pages/          ← 页面组件
├── layouts/        ← 布局组件
├── stores/         ← 状态管理
├── services/       ← API 服务层
├── hooks/          ← 自定义 Hooks
├── utils/          ← 工具函数
├── types/          ← TypeScript 类型
├── styles/         ← 全局样式
└── assets/         ← 静态资源
```

## 核心模块索引

> 详见 `context/modules.md`

## 已实现功能

> 详见 `context/features.md`

## 快速启动

```bash
pnpm install
pnpm dev
```

## 构建部署

```bash
pnpm build
pnpm preview
```
