# 设计 Token

> 最后更新：{YYYY-MM-DD}

## 颜色

| Token | 值 | 用途 |
|-------|---|------|
| --color-primary | {#hex} | 主色 |
| --color-secondary | {#hex} | 辅色 |
| --color-success | {#hex} | 成功 |
| --color-warning | {#hex} | 警告 |
| --color-error | {#hex} | 错误 |

## 字体

| Token | 值 | 用途 |
|-------|---|------|
| --font-family-base | {字体栈} | 正文 |
| --font-family-mono | {字体栈} | 代码 |

## 间距

| Token | 值 |
|-------|---|
| --spacing-xs | 4px |
| --spacing-sm | 8px |
| --spacing-md | 16px |
| --spacing-lg | 24px |
| --spacing-xl | 32px |

## 断点

| Token | 值 |
|-------|---|
| --breakpoint-sm | 640px |
| --breakpoint-md | 768px |
| --breakpoint-lg | 1024px |
| --breakpoint-xl | 1280px |

## 圆角

| Token | 值 |
|-------|---|
| --radius-sm | 4px |
| --radius-md | 8px |
| --radius-lg | 12px |
| --radius-full | 9999px |

## 阴影

| Token | 值 |
|-------|---|
| --shadow-sm | 0 1px 2px rgba(0,0,0,0.05) |
| --shadow-md | 0 4px 6px rgba(0,0,0,0.1) |
| --shadow-lg | 0 10px 15px rgba(0,0,0,0.1) |
