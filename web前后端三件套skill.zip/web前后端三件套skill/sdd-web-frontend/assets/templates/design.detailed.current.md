# 详细设计 — {项目名称}

> 版本：1.0 | 日期：{YYYY-MM-DD} | 迭代：{迭代名称}

## 组件详细设计

### {ComponentName}

**职责**：{组件职责描述}

**Props**：
```typescript
interface {ComponentName}Props {
  // {属性描述}
}
```

**Events**：
```typescript
// {事件描述}
```

**状态**：
```typescript
// 组件内部状态
```

**生命周期**：
- 挂载时：{行为}
- 更新时：{行为}
- 卸载时：{清理逻辑}

## API 接口详细设计

### {接口名称}

| 项目 | 值 |
|------|---|
| 方法 | GET/POST/PUT/DELETE |
| 路径 | `/api/v1/{resource}` |
| 认证 | Bearer Token |

**请求参数**：
```typescript
interface RequestParams {
  // ...
}
```

**响应格式**：
```typescript
interface ResponseData {
  code: number;
  message: string;
  data: {
    // ...
  };
}
```

**错误码**：
| 错误码 | 说明 | 前端处理 |
|--------|------|---------|
| 401 | 未认证 | 跳转登录 |
| 403 | 无权限 | 提示无权限 |
