# 数据模型与状态 Schema

> 最后更新：{YYYY-MM-DD}

## 全局状态结构

```typescript
interface RootState {
  auth: AuthState;
  user: UserState;
  app: AppState;
}
```

## 状态定义

### AuthState

```typescript
interface AuthState {
  token: string | null;
  isAuthenticated: boolean;
}
```

## 数据实体

### {EntityName}

```typescript
interface {EntityName} {
  id: string;
  // ...
}
```
