# 知识地图 — {项目名称}
> 更新日期：YYYY-MM-DD
> 导航总台：要了解某件事，去看哪个文件的哪一节。轻量索引，只放入口级指引。

## 项目认知
| 想了解什么 | 去哪看 | 最后更新 |
|---|---|---|
| 项目概览/技术栈/已实现功能 | `specs/README.md` | YYYY-MM-DD |
| 系统分层与数据流（SPA 渲染） | `context/architecture.md` | YYYY-MM-DD |
| 各组件/模块职责与公共接口（Props/Events） | `context/modules.md` | YYYY-MM-DD |
| 全局状态/数据模型（store 结构、DTO） | `context/data-model.md` | YYYY-MM-DD |
| 路由表/守卫/懒加载策略 | `context/architecture.md`（路由节） | YYYY-MM-DD |
| 后端 API 契约 | `context/api-contracts.md` | YYYY-MM-DD |
| 运行环境（Node/pnpm/Vite/部署） | `context/environment.md` | YYYY-MM-DD |
| 性能预算（Core Web Vitals/Bundle） | `context/performance-budget.md` | 按需 |
| 设计 Token（颜色/字体/间距/断点） | `context/design-tokens.md` | 按需 |
| 代码符号/组件引用关系 | `context/code-map.md` | 🔜 S2 |

## 当前迭代
| 想了解什么 | 去哪看 | 最后更新 |
|---|---|---|
| 当前在做什么/进度 | `specs/task.md` | YYYY-MM-DD |
| 本迭代需求/设计/任务 | `specs/2-spec|3-design|4-tasks/current.md` | YYYY-MM-DD |

## 历史与归档
| 想了解什么 | 去哪看 |
|---|---|
| 历次迭代记录 | `context/iteration-log.md` |
| 历史阶段版本 | 各阶段 `history/` 子目录 |
| 历史任务看板 | `specs/task/` |
| 输入文档与文本化映射 | `docs/converted/README.md` |
