#!/usr/bin/env node
// ──────────────────────────────────────────────────────────────
// SDD Web front-end project specs/ directory-structure initializer (Node.js ESM version)
// Cross-platform, compatible with non-ASCII paths
// Usage:
//   node init-spec.mjs
//   node init-spec.mjs --root /path/to/project --with-templates --with-optional
// ──────────────────────────────────────────────────────────────

import { existsSync, mkdirSync, writeFileSync } from "fs";
import { join, resolve } from "path";

// ── Argument parsing ──

const args = process.argv.slice(2);
let root = process.cwd();
let withTemplates = false;
let withOptional = false;

for (let i = 0; i < args.length; i++) {
  switch (args[i]) {
    case "--root":
      root = resolve(args[++i]);
      break;
    case "--with-templates":
      withTemplates = true;
      break;
    case "--with-optional":
      withOptional = true;
      break;
    case "-h":
    case "--help":
      console.log("Usage: node init-spec.mjs [--root <dir>] [--with-templates] [--with-optional]");
      process.exit(0);
    default:
      console.error(`Unknown argument: ${args[i]}`);
      process.exit(1);
  }
}

// ── Counters ──
let createdDirs = 0;
let createdFiles = 0;
let skipped = 0;

// ── Utility functions ──

function ensureDir(dirPath) {
  if (!existsSync(dirPath)) {
    mkdirSync(dirPath, { recursive: true });
    console.log(`  \x1b[32m[Created dir]\x1b[0m ${dirPath}`);
    createdDirs++;
  } else {
    console.log(`  \x1b[90m[Exists]     \x1b[0m ${dirPath}`);
    skipped++;
  }
}

function ensureFile(filePath, content = "") {
  if (!existsSync(filePath)) {
    // Make sure the parent directory exists
    const dir = filePath.substring(0, filePath.lastIndexOf("/") >= 0 ? filePath.lastIndexOf("/") : filePath.lastIndexOf("\\"));
    if (dir && !existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    writeFileSync(filePath, content, "utf-8");
    console.log(`  \x1b[36m[Created file]\x1b[0m ${filePath}`);
    createdFiles++;
  } else {
    console.log(`  \x1b[90m[Exists]     \x1b[0m ${filePath}`);
    skipped++;
  }
}

// ── Template definitions ──

// Local calendar date, not UTC: toISOString() shifts the date by one day in
// UTC+8, which would stamp date headers with yesterday before 08:00 local time
// and diverge from init-spec.sh / init-spec.ps1.
const now = new Date();
const today = [
  now.getFullYear(),
  String(now.getMonth() + 1).padStart(2, "0"),
  String(now.getDate()).padStart(2, "0"),
].join("-");

const templates = {
  "README.md": `# 项目规格文档（SDD）

本目录包含项目的规格驱动开发文档，按阶段组织。

## 目录结构

- \`context/\` - 项目上下文信息
- \`1-constitution/\` - 阶段1：宪章（工程约束）
- \`2-spec/\` - 阶段2：需求规格（做什么·可验收）
- \`3-design/\` - 阶段3：设计（技术方案）
- \`4-tasks/\` - 阶段4：任务（拆解并写代码·两段式）
- \`5-test/\` - 阶段5：测试（可复现测试与证据）
- \`6-deliver/\` - 阶段6：交付（变更/发布/回滚）

## 使用方式

每个阶段目录下的 \`current.md\` 为当前工作文档。
`,

  "task.md": `<!-- 迭代标识: 进度看板 | 迭代日期: ${today} | 状态: 就绪 -->
# 当前迭代任务

## 迭代信息

- 迭代编号：v0.1.0
- 开始日期：${today}
- 当前阶段：1-constitution
- 状态：进行中

## 任务列表

- [ ] 完成宪章（工程约束）
- [ ] 确定技术栈
- [ ] 定义项目范围
`,

};

const contextTemplates = {
  "context/project.md": `# 项目上下文

## 项目名称

（待填写）

## 项目简介

（待填写）

## 技术栈

（待填写）

## 团队信息

（待填写）
`,

  "context/glossary.md": `# 术语表

| 术语 | 定义 | 备注 |
|------|------|------|
| SDD  | 规格驱动开发（Spec-Driven Development） | 本项目采用的开发方法论 |
`,

  "context/constraints.md": `# 约束条件

## 技术约束

（待填写）

## 业务约束

（待填写）

## 时间约束

（待填写）
`,
};

// Date-header 迭代标识 per stage (specs-lifecycle.md §3, frozen three-field header)
const dateHeader = (id) => `<!-- 迭代标识: ${id} | 迭代日期: ${today} | 状态: 就绪 -->\n`;

const phaseTemplates = {
  "1-constitution": dateHeader("宪章基线") + `# 阶段1：宪章（工程约束）\n\n## 通用协议\n\n（待填写）\n\n## 项目专属协议\n\n（待填写）\n\n## 禁区\n\n（待填写）\n`,
  "2-spec": dateHeader("需求规格") + `# 阶段2：需求规格（做什么·可验收）\n\n## 需求\n\n（待填写）\n\n## 验收标准\n\n（待填写）\n\n## 边界与异常\n\n（待填写）\n`,
  "3-design": dateHeader("设计概要") + `# 阶段3：设计（技术方案）\n\n## 技术方案\n\n（待填写）\n\n## 组件架构\n\n（待填写）\n\n## 状态与API\n\n（待填写）\n`,
  "4-tasks": dateHeader("任务拆解") + `# 阶段4：任务（拆解并写代码·两段式）\n\n## 任务清单\n\n（待填写）\n\n## 修改文件\n\n（待填写）\n\n## 验证与证据\n\n（待填写）\n`,
  "5-test": dateHeader("测试验证") + `# 阶段5：测试（可复现测试与证据）\n\n## 测试用例\n\n（待填写）\n\n## 执行记录\n\n（待填写）\n\n## 证据\n\n（待填写）\n`,
  "6-deliver": dateHeader("交付归档") + `# 阶段6：交付（变更/发布/回滚）\n\n## changelog\n\n（待填写）\n\n## 发布\n\n（待填写）\n\n## 回滚\n\n（待填写）\n`,
};

const optionalTemplates = {
  "context/performance-budget.md": `# 性能预算

| 指标 | 目标值 | 备注 |
|------|--------|------|
| FCP  | < 1.5s |      |
| LCP  | < 2.5s |      |
| CLS  | < 0.1  |      |
| TTI  | < 3.5s |      |
`,

  "context/browser-compat.md": `# 浏览器兼容性

## 支持范围

- Chrome >= 90
- Firefox >= 88
- Safari >= 14
- Edge >= 90

## 特殊处理

（待填写）
`,

  "context/design-tokens.md": `# 设计令牌（Design Tokens）

## 颜色

（待填写）

## 字体

（待填写）

## 间距

（待填写）
`,
};

// ── Main logic ──

const specsRoot = join(root, "specs");

console.log("");
console.log("\x1b[33m[SDD] Initializing specs/ directory structure\x1b[0m");
console.log(`  Root: ${root}`);
console.log("");

// Validate the root directory
if (!existsSync(root)) {
  console.error(`Error: root directory not found: ${root}`);
  process.exit(1);
}

// Create the directory structure
const dirs = [
  specsRoot,
  join(specsRoot, "context"),
  join(specsRoot, "1-constitution"),
  join(specsRoot, "2-spec"),
  join(specsRoot, "3-design"),
  join(specsRoot, "4-tasks"),
  join(specsRoot, "5-test"),
  join(specsRoot, "6-deliver"),
];

for (const dir of dirs) {
  ensureDir(dir);
}

// Create the archive destination (specs/task/, one file per iteration; task-archive.md is NOT it)
mkdirSync(join(specsRoot, "task"), { recursive: true });

// Create the top-level files
for (const [key, tpl] of Object.entries(templates)) {
  const filePath = join(specsRoot, key);
  ensureFile(filePath, withTemplates ? tpl : "");
}

// Create the files under context/
for (const [key, tpl] of Object.entries(contextTemplates)) {
  const filePath = join(specsRoot, key);
  ensureFile(filePath, withTemplates ? tpl : "");
}

// Create each phase's current.md
for (const [phase, tpl] of Object.entries(phaseTemplates)) {
  const filePath = join(specsRoot, phase, "current.md");
  ensureFile(filePath, withTemplates ? tpl : "");
}

// Optional files
if (withOptional) {
  for (const [key, tpl] of Object.entries(optionalTemplates)) {
    const filePath = join(specsRoot, key);
    ensureFile(filePath, withTemplates ? tpl : "");
  }
}

// Print the summary
console.log("");
console.log("\x1b[32m[SDD] Initialization complete\x1b[0m");
console.log(`  Created dirs: ${createdDirs}`);
console.log(`  Created files: ${createdFiles}`);
console.log(`  \x1b[90mAlready exists (skipped): ${skipped}\x1b[0m`);
if (withTemplates) {
  console.log("  \x1b[36mTemplate content: filled\x1b[0m");
}
if (withOptional) {
  console.log("  \x1b[36mOptional files: created\x1b[0m");
}
