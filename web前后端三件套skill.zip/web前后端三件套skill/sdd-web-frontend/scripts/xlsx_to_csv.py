#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Zero-dependency Excel (.xlsx) to CSV converter.

This script uses only the Python standard library (zipfile / xml.etree.ElementTree / csv /
argparse / pathlib / re) and does **not** depend on third-party libraries such as pandas or
openpyxl. An .xlsx is essentially a ZIP archive containing OpenXML (SpreadsheetML) files; this
script unpacks it and parses the XML directly, exporting every worksheet in the workbook into a
separate CSV file.

Usage:
    python xlsx_to_csv.py "<path/to/file.xlsx>" [--output-dir <dir>]

- When --output-dir is omitted, output defaults to (relative to the current working directory):
      docs/converted/<workbook-filename-without-extension>/
- Each worksheet produces one CSV, named `<worksheet-name>.csv` (the name is sanitized).
- CSV is written as UTF-8 with BOM (utf-8-sig) so Excel opens it directly without mojibake.

Exit codes:
    0  success
    1  parse failure (corrupted file / invalid OpenXML, etc.)
    2  argument error (e.g. the input is not an .xlsx file)
"""

import argparse
import csv
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

# SpreadsheetML primary namespace (informational only; parsing strips namespaces uniformly and does not hard-depend on prefixes).
SPREADSHEETML_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
# Relationships namespace.
RELS_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
# Namespace that r:id belongs to.
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"


def _local(tag: str) -> str:
    """Return the local name of an XML tag (dropping the `{namespace}` prefix), making parsing namespace-prefix-agnostic."""
    if tag is None:
        return ""
    # ElementTree writes namespaced tags as "{uri}local"; take the last segment.
    return tag.rsplit("}", 1)[-1]


def _find_attr_by_local(elem, local_name: str):
    """Find an attribute value by its local name (ignoring the namespace prefix). Returns None if not found."""
    for key, value in elem.attrib.items():
        if _local(key) == local_name:
            return value
    return None


def _col_ref_to_index(cell_ref: str) -> int:
    """Convert the column letters in a cell reference (e.g. "B3" / "AA10") into a 0-based column index.

    Examples: "A" -> 0, "B" -> 1, "Z" -> 25, "AA" -> 26. Returns -1 when it cannot be parsed.
    """
    if not cell_ref:
        return -1
    letters = re.match(r"[A-Za-z]+", cell_ref)
    if not letters:
        return -1
    col = 0
    for ch in letters.group(0).upper():
        col = col * 26 + (ord(ch) - ord("A") + 1)
    return col - 1


def _sanitize_filename(name: str) -> str:
    """Sanitize a worksheet name so it is safe to use as a filename.

    Rule: replace the illegal characters / \\ : * ? " < > | and runs of whitespace with a single underscore `_`.
    """
    # First collapse illegal characters and whitespace (including runs) into a single underscore.
    cleaned = re.sub(r'[/\\:*?"<>|\s]+', "_", name)
    # Strip leading/trailing underscores to avoid results like "_name_".
    cleaned = cleaned.strip("_")
    return cleaned or "sheet"


def _read_shared_strings(zf: zipfile.ZipFile):
    """Read the shared-strings table `xl/sharedStrings.xml` and return a list mapping index -> string.

    A shared-string item (<si>) may be plain text <t>, or composed of several rich-text runs (<r><t>...);
    here all <t> text within one <si> is concatenated in order into the final string.
    """
    shared = []
    if "xl/sharedStrings.xml" not in zf.namelist():
        return shared
    root = ET.fromstring(zf.read("xl/sharedStrings.xml"))
    for si in root:
        if _local(si.tag) != "si":
            continue
        # Collect all <t> text under this shared-string item (including <t> inside rich-text runs).
        parts = []
        for t in si.iter():
            if _local(t.tag) == "t":
                parts.append(t.text or "")
        shared.append("".join(parts))
    return shared


def _read_sheet_map(zf: zipfile.ZipFile):
    """Parse the workbook and its relationships file, returning [(display name, worksheet internal path)] in workbook order.

    - `xl/workbook.xml`: gives each worksheet's display name and r:id (relationship id), preserving declaration order.
    - `xl/_rels/workbook.xml.rels`: maps r:id to the concrete `worksheets/sheetN.xml` target.
    """
    # 1) Read the relationships table: rId -> target path (relative to the xl/ directory).
    rels = {}
    rels_path = "xl/_rels/workbook.xml.rels"
    if rels_path in zf.namelist():
        rels_root = ET.fromstring(zf.read(rels_path))
        for rel in rels_root:
            if _local(rel.tag) != "Relationship":
                continue
            rid = rel.attrib.get("Id")
            target = rel.attrib.get("Target", "")
            if rid and target:
                rels[rid] = target

    # 2) Read workbook.xml: take <sheet name=... r:id=.../> in order.
    result = []
    wb_root = ET.fromstring(zf.read("xl/workbook.xml"))
    for sheets in wb_root:
        if _local(sheets.tag) != "sheets":
            continue
        for sheet in sheets:
            if _local(sheet.tag) != "sheet":
                continue
            name = sheet.attrib.get("name", "sheet")
            rid = _find_attr_by_local(sheet, "id")  # the local name of r:id is "id"
            target = rels.get(rid, "")
            if not target:
                continue
            # The relationship target may look like "worksheets/sheet1.xml" or "/xl/worksheets/sheet1.xml".
            target = target.lstrip("/")
            if target.startswith("xl/"):
                sheet_path = target
            else:
                sheet_path = "xl/" + target
            result.append((name, sheet_path))
    return result


def _cell_value(cell, shared_strings):
    """Resolve a cell's text value according to its type.

    Supports:
    - t="s"         shared string, <v> is an index into the shared-strings table;
    - t="inlineStr" inline string, concatenate all <t> under <is>;
    - t="b"         boolean, <v> is 0/1 -> FALSE/TRUE;
    - t="str"       string returned by a formula, take <v> directly;
    - otherwise (numbers/date serials/formula numerics, etc.) take the raw <v> text.
    """
    cell_type = cell.attrib.get("t")

    if cell_type == "inlineStr":
        # Inline string: the text is in <t> inside <is> (may include rich-text runs).
        parts = []
        for t in cell.iter():
            if _local(t.tag) == "t":
                parts.append(t.text or "")
        return "".join(parts)

    # Take the <v> child element (numeric values / shared-string indices / booleans all live in <v>).
    v_text = None
    for child in cell:
        if _local(child.tag) == "v":
            v_text = child.text
            break

    if v_text is None:
        return ""

    if cell_type == "s":
        # Shared string: v_text is the index.
        try:
            idx = int(v_text)
        except ValueError:
            return ""
        if 0 <= idx < len(shared_strings):
            return shared_strings[idx]
        return ""

    if cell_type == "b":
        # Boolean: 1 -> TRUE, 0 -> FALSE.
        return "TRUE" if v_text.strip() == "1" else "FALSE"

    # Other cases (numbers, formula numerics, t="str", etc.) return the raw text directly.
    return v_text


def _parse_sheet_rows(zf: zipfile.ZipFile, sheet_path: str, shared_strings):
    """Parse a single worksheet and return a 2D list (each row is a list of strings, aligned by column reference)."""
    root = ET.fromstring(zf.read(sheet_path))

    rows_out = []
    max_cols = 0

    # Locate <sheetData>; each <row> beneath it is one row.
    for sheet_data in root:
        if _local(sheet_data.tag) != "sheetData":
            continue
        for row in sheet_data:
            if _local(row.tag) != "row":
                continue
            # Collect cell values by column index in a dict, then pad missing columns for alignment.
            cells_by_col = {}
            next_col = 0  # fallback column index when a cell has no r reference
            for cell in row:
                if _local(cell.tag) != "c":
                    continue
                ref = cell.attrib.get("r")
                col_idx = _col_ref_to_index(ref) if ref else -1
                if col_idx < 0:
                    col_idx = next_col
                value = _cell_value(cell, shared_strings)
                cells_by_col[col_idx] = value
                next_col = col_idx + 1

            if cells_by_col:
                row_width = max(cells_by_col) + 1
            else:
                row_width = 0
            # Fill by column index, padding gaps with empty strings so rows stay column-aligned.
            row_list = [cells_by_col.get(i, "") for i in range(row_width)]
            rows_out.append(row_list)
            if row_width > max_cols:
                max_cols = row_width

    # Normalize every row to the same number of columns (pad with empty strings) so the whole sheet is aligned.
    for r in rows_out:
        if len(r) < max_cols:
            r.extend([""] * (max_cols - len(r)))

    return rows_out


def convert(xlsx_path: Path, output_dir: Path):
    """Perform the conversion: write each worksheet of the xlsx into a CSV.

    Returns a list of [(worksheet name, csv path, row count)] for printing the summary.
    """
    written = []
    with zipfile.ZipFile(xlsx_path) as zf:
        shared_strings = _read_shared_strings(zf)
        sheet_map = _read_sheet_map(zf)

        output_dir.mkdir(parents=True, exist_ok=True)

        # Track used filenames so different worksheets do not overwrite each other after sanitizing to the same name.
        used_names = {}
        for display_name, sheet_path in sheet_map:
            rows = _parse_sheet_rows(zf, sheet_path, shared_strings)

            base = _sanitize_filename(display_name)
            filename = base
            # Handle name collisions: append _2, _3 ...
            if filename in used_names:
                used_names[filename] += 1
                filename = f"{base}_{used_names[base]}"
            else:
                used_names[filename] = 1
            csv_path = output_dir / f"{filename}.csv"

            # utf-8-sig writes a BOM so Excel opens it without mojibake; lineterminator is fixed to \n.
            with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
                writer = csv.writer(f, lineterminator="\n")
                for row in rows:
                    writer.writerow(row)

            written.append((display_name, csv_path, len(rows)))

    return written


def main() -> int:
    """Command-line entry point: parse arguments, run the conversion, print a summary, and return an exit code."""
    parser = argparse.ArgumentParser(
        description="Zero-dependency xlsx->CSV converter (one CSV per worksheet)."
    )
    parser.add_argument("xlsx", help="Path to the .xlsx file to convert")
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory (defaults to docs/converted/<workbook-name>/ when omitted)",
    )
    args = parser.parse_args()

    xlsx_path = Path(args.xlsx)

    # Only handle .xlsx; any other extension errors out (exit code 2).
    if xlsx_path.suffix.lower() != ".xlsx":
        print(f"Error: only .xlsx files are supported; received '{xlsx_path.suffix or 'no extension'}': {xlsx_path}")
        return 2

    if not xlsx_path.is_file():
        print(f"Error: file does not exist or is not a regular file: {xlsx_path}")
        return 2

    # Determine the output directory: when unspecified, use docs/converted/<workbook-without-extension>/ (relative to the current working directory).
    if args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        output_dir = Path("docs") / "converted" / xlsx_path.stem

    try:
        written = convert(xlsx_path, output_dir)
    except zipfile.BadZipFile:
        print(f"Error: cannot parse; the file is not a valid .xlsx (ZIP) archive: {xlsx_path}")
        return 1
    except ET.ParseError as exc:
        print(f"Error: XML parsing failed inside the workbook (file may be corrupted): {exc}")
        return 1
    except KeyError as exc:
        print(f"Error: a required workbook part is missing; the file structure is incomplete: {exc}")
        return 1
    except Exception as exc:  # fallback: give a readable message for any other exception
        print(f"Error: an exception occurred during conversion: {exc}")
        return 1

    # Print the summary.
    if not written:
        print(f"No worksheets found in the workbook: {xlsx_path}")
        print(f"Output directory: {output_dir}")
        return 0

    print(f"Conversion complete: {xlsx_path}")
    print(f"Output directory: {output_dir}")
    print(f"Exported {len(written)} worksheet(s):")
    for display_name, csv_path, row_count in written:
        print(f"  - {display_name} -> {csv_path.name} ({row_count} rows)")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
