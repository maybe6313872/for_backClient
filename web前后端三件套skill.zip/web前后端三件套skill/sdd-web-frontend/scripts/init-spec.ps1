﻿<#
.SYNOPSIS
    SDD Web front-end project specs/ directory-structure initializer
.DESCRIPTION
    Creates the full specs/ directory structure under the project root, including each phase's
    subdirectory and template files. Supports optional template-content filling and optional files.
.PARAMETER Root
    Project root directory path, defaults to the current directory
.PARAMETER WithTemplates
    Whether to fill in template content (by default only empty files are created)
.PARAMETER WithOptional
    Whether to create optional files (performance-budget.md, etc.)
.EXAMPLE
    .\init-spec.ps1
    .\init-spec.ps1 -Root "C:\myproject" -WithTemplates -WithOptional
#>

[CmdletBinding()]
param(
    [string]$Root = (Get-Location).Path,
    [switch]$WithTemplates,
    [switch]$WithOptional
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ── Utility functions ──

function Ensure-Dir {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
        Write-Host "  [Created dir] $Path" -ForegroundColor Green
    } else {
        Write-Host "  [Exists]      $Path" -ForegroundColor DarkGray
    }
}

function Ensure-File {
    param([string]$Path, [string]$Content = "")
    if (-not (Test-Path $Path)) {
        New-Item -ItemType File -Path $Path -Force | Out-Null
        if ($Content) {
            Set-Content -Path $Path -Value $Content -Encoding UTF8
        }
        Write-Host "  [Created file] $Path" -ForegroundColor Cyan
    } else {
        Write-Host "  [Exists]      $Path" -ForegroundColor DarkGray
    }
}

# ── Template content definitions ──

$templates = @{
    "README.md" = @"
# 项目规格文档（SDD）

本目录包含项目的规格驱动开发文档，按阶段组织。

## 目录结构

- ``context/`` - 项目上下文信息
- ``1-constitution/`` - 阶段1：宪章（工程约束）
- ``2-spec/`` - 阶段2：需求规格（做什么·可验收）
- ``3-design/`` - 阶段3：设计（技术方案）
- ``4-tasks/`` - 阶段4：任务（拆解并写代码·两段式）
- ``5-test/`` - 阶段5：测试（可复现测试与证据）
- ``6-deliver/`` - 阶段6：交付（变更/发布/回滚）

## 使用方式

每个阶段目录下的 ``current.md`` 为当前工作文档。
"@

    "task.md" = @"
<!-- 迭代标识: 进度看板 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 当前迭代任务

## 迭代信息

- 迭代编号：v0.1.0
- 开始日期：$(Get-Date -Format "yyyy-MM-dd")
- 当前阶段：1-constitution
- 状态：进行中

## 任务列表

- [ ] 完成宪章（工程约束）
- [ ] 确定技术栈
- [ ] 定义项目范围
"@

    "context/project.md" = @"
# 项目上下文

## 项目名称

（待填写）

## 项目简介

（待填写）

## 技术栈

（待填写）

## 团队信息

（待填写）
"@

    "context/glossary.md" = @"
# 术语表

| 术语 | 定义 | 备注 |
|------|------|------|
| SDD  | 规格驱动开发（Spec-Driven Development） | 本项目采用的开发方法论 |
"@

    "context/constraints.md" = @"
# 约束条件

## 技术约束

（待填写）

## 业务约束

（待填写）

## 时间约束

（待填写）
"@
}

# current.md template for each phase
# Date-header 迭代标识 per stage (specs-lifecycle.md §3, frozen three-field header)
$phaseTemplates = @{
    "1-constitution" = @"
<!-- 迭代标识: 宪章基线 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 阶段1：宪章（工程约束）

## 通用协议

（待填写）

## 项目专属协议

（待填写）

## 禁区

（待填写）
"@
    "2-spec" = @"
<!-- 迭代标识: 需求规格 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 阶段2：需求规格（做什么·可验收）

## 需求

（待填写）

## 验收标准

（待填写）

## 边界与异常

（待填写）
"@
    "3-design" = @"
<!-- 迭代标识: 设计概要 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 阶段3：设计（技术方案）

## 技术方案

（待填写）

## 组件架构

（待填写）

## 状态与API

（待填写）
"@
    "4-tasks" = @"
<!-- 迭代标识: 任务拆解 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 阶段4：任务（拆解并写代码·两段式）

## 任务清单

（待填写）

## 修改文件

（待填写）

## 验证与证据

（待填写）
"@
    "5-test" = @"
<!-- 迭代标识: 测试验证 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 阶段5：测试（可复现测试与证据）

## 测试用例

（待填写）

## 执行记录

（待填写）

## 证据

（待填写）
"@
    "6-deliver" = @"
<!-- 迭代标识: 交付归档 | 迭代日期: $(Get-Date -Format "yyyy-MM-dd") | 状态: 就绪 -->
# 阶段6：交付（变更/发布/回滚）

## changelog

（待填写）

## 发布

（待填写）

## 回滚

（待填写）
"@
}

# Optional-file templates
$optionalTemplates = @{
    "context/performance-budget.md" = @"
# 性能预算

| 指标 | 目标值 | 备注 |
|------|--------|------|
| FCP  | < 1.5s |      |
| LCP  | < 2.5s |      |
| CLS  | < 0.1  |      |
| TTI  | < 3.5s |      |
"@
    "context/browser-compat.md" = @"
# 浏览器兼容性

## 支持范围

- Chrome >= 90
- Firefox >= 88
- Safari >= 14
- Edge >= 90

## 特殊处理

（待填写）
"@
    "context/design-tokens.md" = @"
# 设计令牌（Design Tokens）

## 颜色

（待填写）

## 字体

（待填写）

## 间距

（待填写）
"@
}

# ── Main logic ──

$specsRoot = Join-Path $Root "specs"
$createdDirs = 0
$createdFiles = 0
$skippedItems = 0

Write-Host "`n[SDD] Initializing specs/ directory structure" -ForegroundColor Yellow
Write-Host "  Root: $Root" -ForegroundColor Yellow
Write-Host ""

# Validate the root directory
if (-not (Test-Path $Root)) {
    Write-Error "root directory not found: $Root"
    exit 1
}

# Create the directory structure
$dirs = @(
    $specsRoot
    (Join-Path $specsRoot "context")
    (Join-Path $specsRoot "1-constitution")
    (Join-Path $specsRoot "2-spec")
    (Join-Path $specsRoot "3-design")
    (Join-Path $specsRoot "4-tasks")
    (Join-Path $specsRoot "5-test")
    (Join-Path $specsRoot "6-deliver")
)

foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) { $createdDirs++ } else { $skippedItems++ }
    Ensure-Dir $dir
}

# Create the archive destination (specs/task/, one file per iteration; task-archive.md is NOT it)
New-Item -ItemType Directory -Force -Path (Join-Path $specsRoot "task") | Out-Null

# Create the top-level files
foreach ($key in @("README.md", "task.md")) {
    $filePath = Join-Path $specsRoot $key
    $content = if ($WithTemplates) { $templates[$key] } else { "" }
    if (-not (Test-Path $filePath)) { $createdFiles++ } else { $skippedItems++ }
    Ensure-File $filePath $content
}

# Create the files under context/
foreach ($key in @("context/project.md", "context/glossary.md", "context/constraints.md")) {
    $filePath = Join-Path $specsRoot $key
    $content = if ($WithTemplates) { $templates[$key] } else { "" }
    if (-not (Test-Path $filePath)) { $createdFiles++ } else { $skippedItems++ }
    Ensure-File $filePath $content
}

# Create each phase's current.md
foreach ($phase in $phaseTemplates.Keys) {
    $filePath = Join-Path $specsRoot "$phase/current.md"
    $content = if ($WithTemplates) { $phaseTemplates[$phase] } else { "" }
    if (-not (Test-Path $filePath)) { $createdFiles++ } else { $skippedItems++ }
    Ensure-File $filePath $content
}

# Optional files
if ($WithOptional) {
    foreach ($key in $optionalTemplates.Keys) {
        $filePath = Join-Path $specsRoot $key
        $content = if ($WithTemplates) { $optionalTemplates[$key] } else { "" }
        if (-not (Test-Path $filePath)) { $createdFiles++ } else { $skippedItems++ }
        Ensure-File $filePath $content
    }
}

# Print the summary
Write-Host ""
Write-Host "[SDD] Initialization complete" -ForegroundColor Green
Write-Host "  Created dirs: $createdDirs" -ForegroundColor Green
Write-Host "  Created files: $createdFiles" -ForegroundColor Green
Write-Host "  Already exists (skipped): $skippedItems" -ForegroundColor DarkGray
if ($WithTemplates) {
    Write-Host "  Template content: filled" -ForegroundColor Cyan
}
if ($WithOptional) {
    Write-Host "  Optional files: created" -ForegroundColor Cyan
}
