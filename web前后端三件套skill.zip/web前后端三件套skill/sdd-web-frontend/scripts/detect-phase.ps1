﻿<#
.SYNOPSIS
    SDD phase detection script - detects which SDD development phase the current project is in
.DESCRIPTION
    Scans the specs/ directory structure, determines the current phase from which files exist,
    reads task.md for iteration information, and prints diagnostics and a suggestion.
.PARAMETER Root
    Project root directory path, defaults to the current directory
.PARAMETER Json
    Output the result in JSON format
.EXAMPLE
    .\detect-phase.ps1
    .\detect-phase.ps1 -Root "C:\myproject" -Json
#>

[CmdletBinding()]
param(
    [string]$Root = (Get-Location).Path,
    [switch]$Json
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Entry point (pick one, by environment):
#   Windows PowerShell 5.1 : powershell.exe -ExecutionPolicy Bypass -File .\detect-phase.ps1
#   PowerShell 7+          : pwsh -File ./detect-phase.ps1
#   Linux/macOS            : bash detect-phase.sh

# ── Force UTF-8 output to avoid garbled Chinese under Windows PowerShell 5.1 ──
$OutputEncoding = [System.Text.Encoding]::UTF8
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

# ── Phase definitions ──

$phases = @(
    @{ Id = "1-constitution"; Name = "宪章";     Desc = "项目级工程约束固化" }
    @{ Id = "2-spec";         Name = "需求规格"; Desc = "定义做什么·可验收需求" }
    @{ Id = "3-design";       Name = "设计";     Desc = "技术方案·组件架构·状态·API·路由" }
    @{ Id = "4-tasks";        Name = "任务";     Desc = "任务拆解并写出代码（两段式）" }
    @{ Id = "5-test";         Name = "测试";     Desc = "可复现测试与证据" }
    @{ Id = "6-deliver";      Name = "交付";     Desc = "变更记录·发布·回滚" }
)

# ── Detection logic ──

$specsRoot = Join-Path $Root "specs"
$result = @{
    specsExists   = $false
    currentPhase  = $null
    phaseName     = $null
    phaseDesc     = $null
    taskMd        = @{ exists = $false; content = $null }
    phaseStatus   = @()
    suggestion    = ""
}

# Check whether specs/ exists
if (-not (Test-Path $specsRoot)) {
    $result.suggestion = "specs/ directory not found; run init-spec first to initialize the project structure"
    if ($Json) {
        $result | ConvertTo-Json -Depth 5
    } else {
        Write-Host "`n[SDD] Phase detection" -ForegroundColor Yellow
        Write-Host "  Status: specs/ directory not found" -ForegroundColor Red
        Write-Host "  Suggestion: $($result.suggestion)" -ForegroundColor Cyan
    }
    exit 0
}

$result.specsExists = $true

# Read task.md
$taskMdPath = Join-Path $specsRoot "task.md"
if (Test-Path $taskMdPath) {
    $result.taskMd.exists = $true
    $taskContent = Get-Content $taskMdPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
    $result.taskMd.content = $taskContent

    # Try to extract the current phase info from task.md
    if ($taskContent -match "当前阶段[：:]\s*(\S+)") {
        $taskPhase = $Matches[1]
    }
    # Extract the iteration number
    if ($taskContent -match "迭代编号[：:]\s*(\S+)") {
        $result.taskMd | Add-Member -NotePropertyName "iteration" -NotePropertyValue $Matches[1] -Force
    }
    # Extract the status
    if ($taskContent -match "状态[：:]\s*(\S+)") {
        $result.taskMd | Add-Member -NotePropertyName "status" -NotePropertyValue $Matches[1] -Force
    }
}

# Scan each phase directory and determine which files exist
$detectedPhase = $null
$lastNonEmptyPhase = $null

foreach ($phase in $phases) {
    $phaseDir = Join-Path $specsRoot $phase.Id
    $currentMd = Join-Path $phaseDir "current.md"
    $dirExists = Test-Path $phaseDir
    $hasCurrentMd = Test-Path $currentMd
    $fileCount = 0
    $hasContent = $false

    if ($dirExists) {
        $files = Get-ChildItem -Path $phaseDir -File -ErrorAction SilentlyContinue
        $fileCount = ($files | Measure-Object).Count

        # Check whether current.md has substantive content (non-empty, not just a template)
        if ($hasCurrentMd) {
            $content = Get-Content $currentMd -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
            if ($content -and $content.Trim().Length -gt 50) {
                # Exclude pure template placeholders
                $stripped = $content -replace "（待填写）", "" -replace "#.*", "" -replace "\s+", ""
                if ($stripped.Length -gt 10) {
                    $hasContent = $true
                }
            }
        }
    }

    $status = @{
        id         = $phase.Id
        name       = $phase.Name
        dirExists  = $dirExists
        hasCurrent = $hasCurrentMd
        hasContent = $hasContent
        fileCount  = $fileCount
    }
    $result.phaseStatus += $status

    if ($hasContent) {
        $lastNonEmptyPhase = $phase
    }
}

# Determine the current phase
# Prefer the phase declared in task.md
if ($taskPhase) {
    foreach ($phase in $phases) {
        if ($phase.Id -eq $taskPhase -or $phase.Name -eq $taskPhase) {
            $detectedPhase = $phase
            break
        }
    }
}

# If task.md does not declare it, infer from file content
if (-not $detectedPhase) {
    if ($lastNonEmptyPhase) {
        $detectedPhase = $lastNonEmptyPhase
    } else {
        # No phase has content; default to the first phase
        $detectedPhase = $phases[0]
    }
}

$result.currentPhase = $detectedPhase.Id
$result.phaseName = $detectedPhase.Name
$result.phaseDesc = $detectedPhase.Desc

# Generate a suggestion
$currentIdx = [Array]::IndexOf(($phases | ForEach-Object { $_.Id }), $detectedPhase.Id)
$currentStatus = $result.phaseStatus[$currentIdx]

if (-not $currentStatus.hasContent) {
    $result.suggestion = "Currently in the [$($detectedPhase.Name)] phase; current.md has no substantive content yet, please start writing"
} elseif ($currentIdx -lt ($phases.Count - 1)) {
    $nextPhase = $phases[$currentIdx + 1]
    $result.suggestion = "The [$($detectedPhase.Name)] phase already has content; consider advancing to the [$($nextPhase.Name)] phase"
} else {
    $result.suggestion = "Reached the final delivery phase; please confirm all deliverables are complete"
}

# ── Output results ──

if ($Json) {
    $result | ConvertTo-Json -Depth 5
} else {
    Write-Host "`n[SDD] Phase detection result" -ForegroundColor Yellow
    Write-Host "  Root: $Root" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  Current phase: $($result.currentPhase) ($($result.phaseName))" -ForegroundColor Green
    Write-Host "  Phase description: $($result.phaseDesc)" -ForegroundColor White
    Write-Host ""

    # task.md status
    if ($result.taskMd.exists) {
        Write-Host "  task.md: exists" -ForegroundColor Green
        if ($result.taskMd.iteration) {
            Write-Host "    Iteration: $($result.taskMd.iteration)" -ForegroundColor White
        }
        if ($result.taskMd.status) {
            Write-Host "    Status: $($result.taskMd.status)" -ForegroundColor White
        }
    } else {
        Write-Host "  task.md: not found" -ForegroundColor Red
    }

    Write-Host ""
    Write-Host "  Phase status:" -ForegroundColor Yellow
    foreach ($ps in $result.phaseStatus) {
        $icon = if ($ps.hasContent) { "[*]" } elseif ($ps.hasCurrent) { "[ ]" } else { "[-]" }
        $color = if ($ps.hasContent) { "Green" } elseif ($ps.hasCurrent) { "White" } else { "DarkGray" }
        Write-Host "    $icon $($ps.id) ($($ps.name)) - Files: $($ps.fileCount)" -ForegroundColor $color
    }

    Write-Host ""
    Write-Host "  Suggestion: $($result.suggestion)" -ForegroundColor Cyan
}
