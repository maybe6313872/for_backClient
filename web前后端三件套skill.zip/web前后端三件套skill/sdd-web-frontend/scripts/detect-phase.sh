#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# SDD phase detection script (Bash version)
# Detects which SDD development phase the current project is in
# Usage:
#   ./detect-phase.sh
#   ./detect-phase.sh --root /path/to/project --json
# ──────────────────────────────────────────────────────────────

set -euo pipefail

# ── Default parameters ──
ROOT="$(pwd)"
JSON_OUTPUT=false

# ── Argument parsing ──
while [[ $# -gt 0 ]]; do
    case "$1" in
        --root)
            ROOT="$2"
            shift 2
            ;;
        --json)
            JSON_OUTPUT=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--root <dir>] [--json]"
            echo "  --root  Project root directory (default: current directory)"
            echo "  --json  Output in JSON format"
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

SPECS_ROOT="$ROOT/specs"

# ── Phase definitions ──
PHASE_IDS=("1-constitution" "2-spec" "3-design" "4-tasks" "5-test" "6-deliver")
PHASE_NAMES=("宪章" "需求规格" "设计" "任务" "测试" "交付")
PHASE_DESCS=(
    "项目级工程约束固化"
    "定义做什么·可验收需求"
    "技术方案·组件架构·状态·API·路由"
    "任务拆解并写出代码（两段式）"
    "可复现测试与证据"
    "变更记录·发布·回滚"
)

# ── Detection logic ──

# Check whether specs/ exists
if [[ ! -d "$SPECS_ROOT" ]]; then
    if $JSON_OUTPUT; then
        echo '{"specsExists":false,"currentPhase":null,"suggestion":"specs/ directory not found; run init-spec first to initialize the project structure"}'
    else
        echo ""
        echo -e "\033[33m[SDD] Phase detection\033[0m"
        echo -e "  \033[31mStatus: specs/ directory not found\033[0m"
        echo -e "  \033[36mSuggestion: run init-spec first to initialize the project structure\033[0m"
    fi
    exit 0
fi

# Read task.md
TASK_MD="$SPECS_ROOT/task.md"
TASK_EXISTS=false
TASK_PHASE=""
TASK_ITERATION=""
TASK_STATUS=""

if [[ -f "$TASK_MD" ]]; then
    TASK_EXISTS=true
    TASK_CONTENT=$(cat "$TASK_MD" 2>/dev/null || true)

    # Extract the current phase
    TASK_PHASE=$(echo "$TASK_CONTENT" | grep -oP '当前阶段[：:]\s*\K\S+' 2>/dev/null || true)
    # Extract the iteration number
    TASK_ITERATION=$(echo "$TASK_CONTENT" | grep -oP '迭代编号[：:]\s*\K\S+' 2>/dev/null || true)
    # Extract the status
    TASK_STATUS=$(echo "$TASK_CONTENT" | grep -oP '状态[：:]\s*\K\S+' 2>/dev/null || true)
fi

# Scan each phase directory
DETECTED_PHASE=""
DETECTED_IDX=-1
LAST_CONTENT_IDX=-1

# Store per-phase status (simulated with arrays)
declare -a PHASE_DIR_EXISTS
declare -a PHASE_HAS_CURRENT
declare -a PHASE_HAS_CONTENT
declare -a PHASE_FILE_COUNT

for i in "${!PHASE_IDS[@]}"; do
    phase_dir="$SPECS_ROOT/${PHASE_IDS[$i]}"
    current_md="$phase_dir/current.md"

    if [[ -d "$phase_dir" ]]; then
        PHASE_DIR_EXISTS[$i]=true
    else
        PHASE_DIR_EXISTS[$i]=false
    fi

    if [[ -f "$current_md" ]]; then
        PHASE_HAS_CURRENT[$i]=true
    else
        PHASE_HAS_CURRENT[$i]=false
    fi

    # Count files
    if [[ -d "$phase_dir" ]]; then
        PHASE_FILE_COUNT[$i]=$(find "$phase_dir" -maxdepth 1 -type f 2>/dev/null | wc -l | tr -d ' ')
    else
        PHASE_FILE_COUNT[$i]=0
    fi

    # Check whether there is substantive content
    PHASE_HAS_CONTENT[$i]=false
    if [[ -f "$current_md" ]]; then
        content=$(cat "$current_md" 2>/dev/null || true)
        # Strip template placeholders and headings before checking length
        stripped=$(echo "$content" | sed 's/（待填写）//g' | sed 's/#.*//g' | tr -d '[:space:]')
        if [[ ${#stripped} -gt 10 ]]; then
            PHASE_HAS_CONTENT[$i]=true
            LAST_CONTENT_IDX=$i
        fi
    fi
done

# ── Determine the current phase ──

DETECTED_IDX=0

# Prefer the phase declared in task.md
if [[ -n "$TASK_PHASE" ]]; then
    for i in "${!PHASE_IDS[@]}"; do
        if [[ "${PHASE_IDS[$i]}" == "$TASK_PHASE" || "${PHASE_NAMES[$i]}" == "$TASK_PHASE" ]]; then
            DETECTED_IDX=$i
            break
        fi
    done
elif [[ $LAST_CONTENT_IDX -ge 0 ]]; then
    DETECTED_IDX=$LAST_CONTENT_IDX
fi

CURRENT_PHASE="${PHASE_IDS[$DETECTED_IDX]}"
CURRENT_NAME="${PHASE_NAMES[$DETECTED_IDX]}"
CURRENT_DESC="${PHASE_DESCS[$DETECTED_IDX]}"

# Generate a suggestion
SUGGESTION=""
if [[ "${PHASE_HAS_CONTENT[$DETECTED_IDX]}" != "true" ]]; then
    SUGGESTION="Currently in the [$CURRENT_NAME] phase; current.md has no substantive content yet, please start writing"
elif [[ $DETECTED_IDX -lt 5 ]]; then
    NEXT_IDX=$((DETECTED_IDX + 1))
    SUGGESTION="The [$CURRENT_NAME] phase already has content; consider advancing to the [${PHASE_NAMES[$NEXT_IDX]}] phase"
else
    SUGGESTION="Reached the final delivery phase; please confirm all deliverables are complete"
fi

# ── Output results ──

if $JSON_OUTPUT; then
    # Build the JSON output
    PHASE_STATUS_JSON="["
    for i in "${!PHASE_IDS[@]}"; do
        [[ $i -gt 0 ]] && PHASE_STATUS_JSON+=","
        PHASE_STATUS_JSON+="{\"id\":\"${PHASE_IDS[$i]}\",\"name\":\"${PHASE_NAMES[$i]}\","
        PHASE_STATUS_JSON+="\"dirExists\":${PHASE_DIR_EXISTS[$i]},\"hasCurrent\":${PHASE_HAS_CURRENT[$i]},"
        PHASE_STATUS_JSON+="\"hasContent\":${PHASE_HAS_CONTENT[$i]},\"fileCount\":${PHASE_FILE_COUNT[$i]}}"
    done
    PHASE_STATUS_JSON+="]"

    cat <<ENDJSON
{
  "specsExists": true,
  "currentPhase": "$CURRENT_PHASE",
  "phaseName": "$CURRENT_NAME",
  "phaseDesc": "$CURRENT_DESC",
  "taskMd": {
    "exists": $TASK_EXISTS,
    "iteration": "$TASK_ITERATION",
    "status": "$TASK_STATUS"
  },
  "phaseStatus": $PHASE_STATUS_JSON,
  "suggestion": "$SUGGESTION"
}
ENDJSON
else
    echo ""
    echo -e "\033[33m[SDD] Phase detection result\033[0m"
    echo -e "  Root: $ROOT"
    echo ""
    echo -e "  \033[32mCurrent phase: $CURRENT_PHASE ($CURRENT_NAME)\033[0m"
    echo -e "  Phase description: $CURRENT_DESC"
    echo ""

    # task.md status
    if $TASK_EXISTS; then
        echo -e "  \033[32mtask.md: exists\033[0m"
        [[ -n "$TASK_ITERATION" ]] && echo "    Iteration: $TASK_ITERATION"
        [[ -n "$TASK_STATUS" ]] && echo "    Status: $TASK_STATUS"
    else
        echo -e "  \033[31mtask.md: not found\033[0m"
    fi

    echo ""
    echo -e "  \033[33mPhase status:\033[0m"
    for i in "${!PHASE_IDS[@]}"; do
        if [[ "${PHASE_HAS_CONTENT[$i]}" == "true" ]]; then
            icon="[*]"
            color="\033[32m"
        elif [[ "${PHASE_HAS_CURRENT[$i]}" == "true" ]]; then
            icon="[ ]"
            color="\033[0m"
        else
            icon="[-]"
            color="\033[90m"
        fi
        echo -e "    ${color}${icon} ${PHASE_IDS[$i]} (${PHASE_NAMES[$i]}) - Files: ${PHASE_FILE_COUNT[$i]}\033[0m"
    done

    echo ""
    echo -e "  \033[36mSuggestion: $SUGGESTION\033[0m"
fi
