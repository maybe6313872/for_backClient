#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────
# SDD Web front-end project specs/ directory-structure initializer (Bash version)
# Usage:
#   ./init-spec.sh
#   ./init-spec.sh --root /path/to/project --with-templates --with-optional
# ──────────────────────────────────────────────────────────────

set -euo pipefail

# ── Default parameters ──
ROOT="$(pwd)"
WITH_TEMPLATES=false
WITH_OPTIONAL=false

# ── Argument parsing ──
while [[ $# -gt 0 ]]; do
    case "$1" in
        --root)
            ROOT="$2"
            shift 2
            ;;
        --with-templates)
            WITH_TEMPLATES=true
            shift
            ;;
        --with-optional)
            WITH_OPTIONAL=true
            shift
            ;;
        -h|--help)
            echo "Usage: $0 [--root <dir>] [--with-templates] [--with-optional]"
            echo "  --root           Project root directory (default: current directory)"
            echo "  --with-templates Fill in template content"
            echo "  --with-optional  Create optional files"
            exit 0
            ;;
        *)
            echo "Unknown argument: $1" >&2
            exit 1
            ;;
    esac
done

# ── Counters ──
CREATED_DIRS=0
CREATED_FILES=0
SKIPPED=0

# ── Utility functions ──

ensure_dir() {
    local dir="$1"
    if [[ ! -d "$dir" ]]; then
        mkdir -p "$dir"
        echo -e "  \033[32m[Created dir]\033[0m $dir"
        CREATED_DIRS=$((CREATED_DIRS + 1))
    else
        echo -e "  \033[90m[Exists]     \033[0m $dir"
        SKIPPED=$((SKIPPED + 1))
    fi
}

ensure_file() {
    local file="$1"
    local content="${2:-}"
    if [[ ! -f "$file" ]]; then
        # Make sure the parent directory exists
        mkdir -p "$(dirname "$file")"
        if [[ -n "$content" ]]; then
            echo "$content" > "$file"
        else
            touch "$file"
        fi
        echo -e "  \033[36m[Created file]\033[0m $file"
        CREATED_FILES=$((CREATED_FILES + 1))
    else
        echo -e "  \033[90m[Exists]     \033[0m $file"
        SKIPPED=$((SKIPPED + 1))
    fi
}

SPECS_ROOT="$ROOT/specs"

echo ""
echo -e "\033[33m[SDD] Initializing specs/ directory structure\033[0m"
echo -e "  Root: $ROOT"
echo ""

# Validate the root directory
if [[ ! -d "$ROOT" ]]; then
    echo "Error: root directory not found: $ROOT" >&2
    exit 1
fi

# ── Create the directory structure ──

DIRS=(
    "$SPECS_ROOT"
    "$SPECS_ROOT/context"
    "$SPECS_ROOT/1-constitution"
    "$SPECS_ROOT/2-spec"
    "$SPECS_ROOT/3-design"
    "$SPECS_ROOT/4-tasks"
    "$SPECS_ROOT/5-test"
    "$SPECS_ROOT/6-deliver"
)

for dir in "${DIRS[@]}"; do
    ensure_dir "$dir"
done

# ── Create the archive destination (specs/task/, one file per iteration; task-archive.md is NOT it) ──
mkdir -p "$SPECS_ROOT/task"

# ── Create the top-level files ──

TODAY=$(date +%Y-%m-%d)

if $WITH_TEMPLATES; then
    ensure_file "$SPECS_ROOT/README.md" "# 项目规格文档（SDD）

本目录包含项目的规格驱动开发文档，按阶段组织。

## 目录结构

- \`context/\` - 项目上下文信息
- \`1-constitution/\` - 阶段1：宪章（工程约束）
- \`2-spec/\` - 阶段2：需求规格（做什么·可验收）
- \`3-design/\` - 阶段3：设计（技术方案）
- \`4-tasks/\` - 阶段4：任务（拆解并写代码·两段式）
- \`5-test/\` - 阶段5：测试（可复现测试与证据）
- \`6-deliver/\` - 阶段6：交付（变更/发布/回滚）

## 使用方式

每个阶段目录下的 \`current.md\` 为当前工作文档。"

    ensure_file "$SPECS_ROOT/task.md" "<!-- 迭代标识: 进度看板 | 迭代日期: $TODAY | 状态: 就绪 -->
# 当前迭代任务

## 迭代信息

- 迭代编号：v0.1.0
- 开始日期：$TODAY
- 当前阶段：1-constitution
- 状态：进行中

## 任务列表

- [ ] 完成宪章（工程约束）
- [ ] 确定技术栈
- [ ] 定义项目范围"
else
    ensure_file "$SPECS_ROOT/README.md"
    ensure_file "$SPECS_ROOT/task.md"
fi

# ── Create the files under context/ ──

if $WITH_TEMPLATES; then
    ensure_file "$SPECS_ROOT/context/project.md" "# 项目上下文

## 项目名称

（待填写）

## 项目简介

（待填写）

## 技术栈

（待填写）

## 团队信息

（待填写）"

    ensure_file "$SPECS_ROOT/context/glossary.md" "# 术语表

| 术语 | 定义 | 备注 |
|------|------|------|
| SDD  | 规格驱动开发（Spec-Driven Development） | 本项目采用的开发方法论 |"

    ensure_file "$SPECS_ROOT/context/constraints.md" "# 约束条件

## 技术约束

（待填写）

## 业务约束

（待填写）

## 时间约束

（待填写）"
else
    ensure_file "$SPECS_ROOT/context/project.md"
    ensure_file "$SPECS_ROOT/context/glossary.md"
    ensure_file "$SPECS_ROOT/context/constraints.md"
fi

# ── Create each phase's current.md ──

PHASE_DIRS=("1-constitution" "2-spec" "3-design" "4-tasks" "5-test" "6-deliver")
PHASE_TITLES=("宪章（工程约束）" "需求规格（做什么·可验收）" "设计（技术方案）" "任务（拆解并写代码·两段式）" "测试（可复现测试与证据）" "交付（变更/发布/回滚）")
PHASE_SEC1=("通用协议" "需求" "技术方案" "任务清单" "测试用例" "changelog")
PHASE_SEC2=("项目专属协议" "验收标准" "组件架构" "修改文件" "执行记录" "发布")
PHASE_SEC3=("禁区" "边界与异常" "状态与API" "验证与证据" "证据" "回滚")
# Date-header 迭代标识 per stage (specs-lifecycle.md §3, frozen three-field header)
PHASE_IDS=("宪章基线" "需求规格" "设计概要" "任务拆解" "测试验证" "交付归档")

for i in "${!PHASE_DIRS[@]}"; do
    phase="${PHASE_DIRS[$i]}"
    title="${PHASE_TITLES[$i]}"
    sec1="${PHASE_SEC1[$i]}"
    sec2="${PHASE_SEC2[$i]}"
    sec3="${PHASE_SEC3[$i]}"
    pid="${PHASE_IDS[$i]}"
    idx=$((i + 1))

    if $WITH_TEMPLATES; then
        ensure_file "$SPECS_ROOT/$phase/current.md" "<!-- 迭代标识: ${pid} | 迭代日期: $TODAY | 状态: 就绪 -->
# 阶段${idx}：${title}

## ${sec1}

（待填写）

## ${sec2}

（待填写）

## ${sec3}

（待填写）"
    else
        ensure_file "$SPECS_ROOT/$phase/current.md"
    fi
done

# ── Optional files ──

if $WITH_OPTIONAL; then
    if $WITH_TEMPLATES; then
        ensure_file "$SPECS_ROOT/context/performance-budget.md" "# 性能预算

| 指标 | 目标值 | 备注 |
|------|--------|------|
| FCP  | < 1.5s |      |
| LCP  | < 2.5s |      |
| CLS  | < 0.1  |      |
| TTI  | < 3.5s |      |"

        ensure_file "$SPECS_ROOT/context/browser-compat.md" "# 浏览器兼容性

## 支持范围

- Chrome >= 90
- Firefox >= 88
- Safari >= 14
- Edge >= 90

## 特殊处理

（待填写）"

        ensure_file "$SPECS_ROOT/context/design-tokens.md" "# 设计令牌（Design Tokens）

## 颜色

（待填写）

## 字体

（待填写）

## 间距

（待填写）"
    else
        ensure_file "$SPECS_ROOT/context/performance-budget.md"
        ensure_file "$SPECS_ROOT/context/browser-compat.md"
        ensure_file "$SPECS_ROOT/context/design-tokens.md"
    fi
fi

# ── Print the summary ──

echo ""
echo -e "\033[32m[SDD] Initialization complete\033[0m"
echo "  Created dirs: $CREATED_DIRS"
echo "  Created files: $CREATED_FILES"
echo -e "  \033[90mAlready exists (skipped): $SKIPPED\033[0m"
if $WITH_TEMPLATES; then
    echo -e "  \033[36mTemplate content: filled\033[0m"
fi
if $WITH_OPTIONAL; then
    echo -e "  \033[36mOptional files: created\033[0m"
fi
