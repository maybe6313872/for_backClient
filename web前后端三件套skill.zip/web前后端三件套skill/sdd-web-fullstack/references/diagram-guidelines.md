# Mermaid Diagram Usage Guidelines

> This file defines the usage rules for mermaid diagrams in the orchestration workflow, the recommended diagram types per stage, and anti-example notes. Diagram labels in generated project documents are written in Simplified Chinese for the user (as the examples below illustrate).

---

## Core principles

1. **Focused**: each diagram shows exactly one topic; you MUST NOT draw a "big and complete" whole-monorepo diagram
2. **Lean**: a single diagram SHOULD NOT exceed 15 nodes; when it does, split it into multiple diagrams
3. **Consistent**: a diagram MUST match the body text exactly, with no extra or missing nodes; any diagram touching interfaces MUST also match `contracts/openapi/` at the stated version
4. **Titled**: every diagram MUST have a title (a markdown heading or a diagram caption) stating the scope of what it shows
5. **Auxiliary**: diagrams assist the textual description; they cannot replace it

**Orchestration-specific depth rule (red line 2)**: a root diagram resolves **down to the sub-project boundary and no further**. Drawing a sub-project's internal classes, tables, or control states at the root is overreach even when it is "just a diagram" — that content belongs to the sub-project's own single-stack sdd skill.

---

## Recommended diagrams per stage

### constitution stage

**Recommended**: a sub-project registry diagram (business vs supporting) or a repo-shape diagram (aggregate root + gitlink pins)
**Purpose**: freeze "who exists and who is in scope"
**Forbidden**: any interface-level or implementation-level detail

### requirements stage

**Recommended**: use-case diagrams, scenario flowcharts
**Purpose**: show "what to do" — actor-to-feature relationships, business scenario flows
**Forbidden**: showing "how to do it" — contract shapes, module partitioning inside a sub-project, dispatch splitting

Example (use-case diagram):
```mermaid
flowchart LR
    User([终端用户/浏览器]) --> F1[功能A 数据看板]
    User --> F2[功能B 告警订阅]
    Admin([管理员/运维]) --> F3[配置管理]
    Admin --> F4[审计日志/导出]
```

Example (scenario flowchart):
```mermaid
flowchart TD
    A[用户提交筛选条件] --> B{已登录且有权限?}
    B -->|是| C[返回分页结果]
    B -->|否| D[提示无权限/跳转登录]
    C --> E[前端渲染并记录埋点]
```

### contract-design stage

**Recommended**: sequence diagrams, contract-module dependency diagrams, cross-stack data flow diagrams, architecture diagrams down to the sub-project boundary
**Purpose**: show "what the interface looks like" — call order across the stack, contract module splitting and `$ref` dependencies, data handoff chains
**Forbidden**: a sub-project's internal implementation structure (its class model, its persistence schema, its component tree); those belong to that sub-project's own design stage

Example (sequence diagram):
```mermaid
sequenceDiagram
    participant FE as 前端 frontend
    participant GW as 网关/反向代理
    participant BE as 后端 backend

    FE->>GW: GET /alarms (契约 v1.2.0)
    GW->>BE: 转发请求
    BE-->>GW: 返回 AlarmPage 结构
    GW-->>FE: 透传响应
    FE->>FE: 按契约 schema 渲染
```

Example (contract-module dependency diagram):
```mermaid
flowchart LR
    R[openapi.yaml 根] --> P1[paths/alarm.yaml]
    R --> P2[paths/auth.yaml]
    P1 --> S1[schemas/alarm.yaml]
    P2 --> S2[schemas/user.yaml]
    S1 --> S3[schemas/common.yaml]
    S2 --> S3
```

Example (cross-stack data flow diagram):
```mermaid
flowchart LR
    A[上游数据源] --> B[后端服务层]
    B --> C[契约响应模型]
    C --> D[前端数据层]
    D --> E[视图渲染]
    E --> F[异常与降级提示]
```

### dispatch stage

**Recommended**: dependency graphs
**Purpose**: show the execution order and blocking relationships between dispatch packets, plus the joint-debugging convergence point

Example:
```mermaid
flowchart TD
    D0[契约 v1.2.0 冻结] --> D1[DISP-1 后端 告警接口]
    D0 --> D2[DISP-2 前端 告警看板]
    D1 --> D3[联调点 接口可用]
    D2 --> D3
    D3 --> D4[集成点检]
```

### integration-checkpoint stage

**Recommended**: coverage matrix (a table works better than mermaid)
**Purpose**: show the mapping between requirement items, contract operations, the sub-project that implements each side, and the evidence level of the conclusion

Example (table form):

| Requirement | Contract operation | frontend | backend | Evidence |
|------|------|-----|-----|-----|
| R1/AC1 | `GET /alarms` | ✓ | ✓ | L3 |
| R1/AC2 | `GET /alarms/{id}` | ✓ | ✓ | L2 |
| R2/AC1 | `POST /alarms/ack` | | ✓ | L2 |

A blank cell means "not covered on that side" and MUST have a matching line in the checkpoint table's blocker or gap column — never leave it silently blank.

### deliver stage

Usually no diagrams are needed. A complex release process — or the submodule-aggregate pointer-reclaim flow — may be shown with a `flowchart` (nodes ≤8).

Example:
```mermaid
flowchart LR
    A[子仓提交并推送] --> B[根仓更新指针]
    B --> C[契约版本归档]
    C --> D[迭代记录入库]
    D --> E[交付语义标注证据等级]
```

---

## Anti-examples and corrections

### Anti-example 1: the whole-monorepo mega-diagram

❌ Drew a whole-system architecture diagram with 30+ nodes in the requirements stage, covering every sub-project, every module and every interface

✅ Correction: split into multiple focused diagrams — one use-case diagram for the actor-to-feature relationships, one flowchart for the key business scenario, and leave the architecture map to `context/architecture.md`

### Anti-example 2: a sub-project's internals drawn at the root

❌ Drew the backend's internal service/entity structure (or the frontend's component tree) in the contract-design stage, at the root

✅ Correction: this is overreach across the sub-project boundary (red line 2). The root diagram stops at "frontend / backend / contract module"; internal structure is drawn by that sub-project's own sdd skill in its own design stage. The root only states which contract operations each side owns.

### Anti-example 3: text-diagram inconsistency

❌ The body text describes 5 handoff steps, but the mermaid diagram only draws 3, omitting 「网关转发」 and 「异常降级」

✅ Correction: the diagram must correspond to the body text exactly — check item by item and fill in the gaps. When the diagram involves interfaces, also diff it against `contracts/openapi/` at the stated version; a diagram that disagrees with the contract is a contract-consistency failure, not a drawing nit.

### Anti-example 4: the diagram replaces the text

❌ Only a mermaid diagram was drawn, with no accompanying textual explanation

✅ Correction: every diagram must have an accompanying text paragraph explaining its meaning and key details

---

## Self-check list (diagram-specific)

After each use of a mermaid diagram, confirm item by item:

- [ ] Does this diagram focus on a single topic?
- [ ] Is the node count ≤15?
- [ ] Does every node in the diagram have a corresponding description in the body text?
- [ ] Is every key point in the body text shown in the diagram?
- [ ] Is this diagram a type allowed in the current stage?
- [ ] Does it stop at the sub-project boundary, with no sub-project internals drawn?
- [ ] If it touches interfaces, does it match `contracts/openapi/` at the stated version?
- [ ] Is there a title stating the scope the diagram shows?
