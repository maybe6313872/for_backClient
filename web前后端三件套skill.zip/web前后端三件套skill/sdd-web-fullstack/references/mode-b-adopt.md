# Mode B: adopt the existing state (existing monorepo → root-level orchestration cognition)

> Reverse an existing, non-standard monorepo into `orchestration/context/` root-level orchestration cognition + a reversed modular contract, as the memory base for Mode A orchestration. `/sdd-init` is the explicit entry. **Boundary restraint: only to the sub-project boundary, never down into a sub-project's function-level twin (that is each single-stack sdd skill's Mode B job).**

---

## 1. When to use

Taking over a full-stack repository with "scattered docs, a monolithic or missing contract, no `orchestration/`" (this repository's current state is a typical case). Adopt it into a disciplined root structure first, then keep orchestrating iterations with Mode A.

---

## 2. Adoption artifacts (into `orchestration/context/`)

| Artifact | Content | Boundary |
|---|---|---|
| Repo mode + registry `repo-mode.md` | detected repo mode (mono-repo / submodule-aggregate per `.gitmodules`); sub-project registry classed business vs supporting; submodule-aggregate: pin inventory (path / remote / pinned commit) parsed from `.gitmodules` + `git submodule status` — never treat submodule dirs as plain folders | read-only detection; drift (local ≠ pin) goes to open-issues |
| Full-stack architecture map `architecture.md` | eagle-eye diagram + code map of root → each sub-project → tech stack → deployment form | only to the sub-project boundary, not into a sub-project's functions |
| Module↔sub-project↔contract mapping `module-map.md` | which sub-project implements each business module, and its corresponding contract module | business-module granularity |
| Contract state inventory → `contracts/openapi/*` | reverse a modular contract draft from the existing monolithic/scattered yaml (split paths/ and components/schemas/) | reverse; divergences go to open-issues |
| Sub-project state snapshot `subprojects.md` | each sub-project's current iteration/stage, whether the corresponding single-stack sdd skill is installed, existing deliverables | snapshot; do not judge internal implementation |

---

## 3. Workflow

1. **Scan the root structure**: detect the repo mode first (`.gitmodules` → submodule-aggregate, parse the pin inventory; else mono-repo); identify sub-projects (frontend/backend/…), class them business vs supporting (see [repo-management-protocol.md](repo-management-protocol.md) §2), tech stacks, build/deployment forms, existing docs and yaml.
2. **Handle docs**: if the root `docs/` has binary input documents, textualize them first (see collaboration-protocol.md).
3. **Draw the full-stack architecture map**: eagle-eye diagram (≤10 nodes) + sub-project code map (directory → responsibility, to the sub-project boundary).
4. **Build the module↔sub-project↔contract mapping**: list business modules, mark the owning sub-project and corresponding contract module.
5. **Reverse the modular contract**: split existing monolithic/scattered interface definitions into `contracts/openapi/paths/*` and `components/schemas/*`; mark unclear points `[待澄清]` into open-issues, **no guessing to fill gaps**.
6. **Sub-project state snapshot**: each sub-project's current state, whether the single-stack sdd skill is installed (not installed → suggest installing/building it later).
7. **Coverage self-check + confirm with the user**: does the architecture map and mapping cover all sub-projects and the main modules.
8. **Write `orchestration/README.md`**: as the entry cognition for every later session.

---

## 4. Three iron rules (inlined)

1. **Purity**: `context/` records only closed facts; doubts/conflicts go to `orchestration/open-issues.md`, in-flight tasks go to `task.md`, and the three are not mixed.
2. **No guessing**: when reversing the contract, on a state/material conflict write per the actual state and log divergences to open-issues; never fill gaps with 「通常/应该/按经验」; evidence provenance may be recorded in `context/evidence-trace.md`.
3. **Boundary restraint**: the main agent's adoption reaches only the sub-project boundary; a sub-project's internal function-level twin is left to that sub-project's single-stack sdd skill Mode B, not rebuilt at the root.

---

## 5. Handoff to Mode A

After adoption, `orchestration/README.md` + `context/` + the reversed `contracts/openapi/` become the memory base for every Mode A `/sdd-iterate`. Each Mode A delivery writes back and updates this cognition to keep the orchestration map from rotting.
