# Checkpoint protocol (checkpoint)

> **Positioning**: after dispatch the main agent does not "dispatch and forget"; it periodically checkpoints each sub-project's progress and deliverables, surfacing the global picture with a **checkpoint table**. This file defines the checkpoint-table schema, checkpoint cadence, deliverable verification, and blocker surfacing. `/sdd-checkpoint` is the explicit entry.

---

## 1. Why checkpoint

After dispatch to sub-agents, each sub-project progresses independently inside its own working root. The main agent needs a **unified view** to answer: how far has each sub-project gotten? Are deliverables verified? Is the contract aligned? Who blocks whom? Without a checkpoint mechanism, full-stack orchestration degrades into "issued a pile of work orders, no idea of overall progress."

**Checkpoint ≠ doing the sub-agent's work**: checkpointing is **read-only verification + recording + coordination**; the main agent does not enter a sub-project to change code (red line 2).

---

## 2. Checkpoint-table schema (into `orchestration/checkpoints/`)

The checkpoint table is the main agent's global sub-project status board. Template in `assets/templates/checkpoint-table.md`.

**Main table (one row per sub-project)**:

| Field | Description |
|---|---|
| Sub-project | `frontend` / `backend` / … |
| Sub-skill used | the corresponding `sdd-web-*` (verification is mode-aware, see dispatch-protocol §4) |
| Linked dispatch | the `DISP-*` dispatch id + its execution mode (`handoff` / `agent-drive`) |
| Current iteration/stage | the executor's SDD stage read from its own artifacts per §3b (`specs/task.md` first); handoff states: 「已派单待外部开发」(inbox still holds the packet) → 「已接单开发中」(inbox cleared, §5d) → per its specs/task.md |
| Contract alignment | the dependent contract version + whether consistent with the latest contract (aligned / pending-sync / breaking-change-pending-adaptation) |
| Deliverable list | the key deliverables from the sub-agent (pages/interfaces/test reports, etc.) + whether verified |
| Evidence level | this sub-project's current highest evidence L1–L5 (see evidence-gate-protocol) |
| Pointer alignment (submodule-aggregate mode only) | the root-pinned gitlink commit vs the sub-repo's latest reported commit (aligned / sub-repo ahead pending pointer reclaim / drifted-needs-investigation); reclaim happens at deliver per repo-management-protocol §4 |
| Blocker | the current blocker + its source (missing sub-skill / prerequisite dependency / contract conflict / unpushed sub-repo commit…) + the clearing condition |
| Last checkpoint | date |
| Next checkpoint action | what to verify next |

**Checkpoint record (one appended per checkpoint)**: `orchestration/checkpoints/checkpoint-YYYY-MM-DD.md`, recording this checkpoint's conclusions, blockers added/cleared, and contract-sync actions.

---

## 3. Checkpoint cadence (when to checkpoint)

| Timing | Action |
|---|---|
| First time after dispatch lands | Establish the checkpoint-table baseline; each sub-project's initial state entered (**handoff mode: state = 「已派单待外部开发」, then the iteration suspends**) |
| **Handoff mode: the user reports back** ("frontend/backend is done / has progress"), **a later root session finds suspended dispatches in task.md, or the inbox is observed cleared (pickup acknowledgment, dispatch-protocol §5d)** | Inbox cleared → state 「已接单开发中」; then track progress via the sub-project's SDD artifacts (§3b, `specs/task.md` first); on completion signals verify deliverables against the packet's acceptance points (root copy) and continue integration-checkpoint |
| Agent-drive mode: when a sub-agent reports progress | Update that row's stage/deliverables/evidence/blocker |
| After a contract change | Verify each sub-project's contract-alignment column; trigger two-way notification (see contract-first-protocol §4) |
| At the integration-checkpoint stage | Full checkpoint: contract consistency + joint debugging + end-to-end; verify each sub-project's deliverables and label the evidence level |
| When the user asks about progress | Read the checkpoint table + task.md directly and give a global-status summary |

---

## 3a. Post-delivery verification: overreach (ORCH-G3), specs↔code pairing (G5), claim↔git pairing (G6)

> Gate IDs used here are resolved in [gate-and-stages.md](gate-and-stages.md): `ORCH-*` are this skill's own orchestration-class gates; bare `G5`/`G6` are the frozen universal gates shared byte for byte with every sdd-xx. **G5 and G6 are different checks and both run** — G5 asks "did specs get written for this code?", G6 asks "does the working tree actually contain what was claimed?".

All three checks run **after an executor delivers and before any integration-checkpoint conclusion is drawn** (mandatory in agent-drive mode; in handoff mode run them when the user's report-back resumes checkpointing). All are **read-only**.

**ORCH-G3 — overreach check**: run `git status` (and `git diff --stat` as needed) in the sub-project's working root:
- Uncommitted changes to **business code files** (`src/`, `services/`, `models.py`, `api.py`, i18n dictionaries, page/module files…) that fall **outside the dispatch packet's scope** = overreach.
- On overreach: **mark the sub-project 越界待处置, block it from passing checkpoint, report to the user, and ask for the disposition** (revert / backfill specs and keep / keep as-is with justification). The main agent **never auto-reverts** (`git checkout`) on its own judgment — a misjudged auto-revert destroys legitimate work.

**G5 — specs↔code pairing check**: business-code changes and `specs/` changes must **appear in pairs** in the sub-project:
- Code changes present but no corresponding specs change (no task.md row, no spec entry, no context mapping update) = **incomplete delivery**: block checkpoint/delivery for that item, report, and require the specs backfill (or the user's explicit waiver) before it may pass.
- G5 is **grain-independent**: fixes and small increments are covered too — "the fix was tiny" is not a waiver.

**G6 — claim↔git pairing check**: what the executor (or this orchestration's own report) **claims** to have landed must match the actual working tree, verified against the same read-only `git status` / `git diff --stat` output:
- **Claimed but absent**: a deliverable, file or test asset named in the report with no corresponding change in the working tree = the claim is unsupported. Do not grade it, do not carry it into the checkpoint table's deliverable column; report it and ask whether the work is unpushed, in another branch, or was never done.
- **Present but unregistered**: changes in the tree that no claim, packet scope or specs entry accounts for = incidental changes. Surface them (they are also the input to the ORCH-G3 overreach judgment) rather than absorbing them silently into "done".
- **Inbox reconciliation**: the sub-project's `docs/requirements/` inbox being cleared is an **acknowledgment** signal, never a completion signal (dispatch-protocol §5d); a report claiming completion on the strength of a cleared inbox alone fails G6.
- G6 is the **deliver-gate** counterpart of G5 and is re-run at deliver against the orchestration's own claims before delivery semantics are written (orchestration-stages.md §6).

❌ Running G5 alone and calling the pair "checked" is an error: G5 passes happily on a sub-project that wrote beautiful specs for code that does not exist in the tree.

Record all three checks' outcomes in the checkpoint record and, when blocking, in `open-issues.md` and `task.md`.

## 3b. Progress observation sources (the sub-project speaks SDD — read its artifacts)

Business sub-projects follow their own sdd skill, so the main agent's **default, read-only** way to learn progress is the sub-project's own SDD artifacts, in this priority order:

| Priority | Source | What it tells you |
|---|---|---|
| 1 | `<sub>/specs/task.md` | **the primary signal**: the sub-project's cross-iteration board — current task, stage progress, blockers |
| 2 | `<sub>/specs/README.md` + the stage `current.md` files (esp. `6-deliver`) | which SDD stage it is in, gate states, delivery status |
| 3 | `<sub>/specs/context/` + `open-issues.md` | module/feature mapping updates, open doubts that may block integration |
| 4 | `<sub>/docs/requirements/` inbox state | packet still present = not picked up; cleared = acknowledged (dispatch-protocol §5d) |
| 5 | `<sub>/docs/` deliverable docs, build/test reports | evidence for the checkpoint's L1–L5 grading |

Map the sub-project's reported SDD stage into the checkpoint table's 「当前迭代/阶段」 column. Asking the user is the fallback when artifacts are missing/stale — but read the artifacts first; a sub-project that keeps its specs current should never need to be asked. All observation is **read-only** (red line 2); never "fix up" a sub-project's task.md from the root.

## 4. Deliverable verification (no exaggeration, no substitution)

When checkpointing a sub-project's deliverables:
- **Verification basis**: the "acceptance points" in the dispatch packet + contract compliance.
- **Verification method**: read the sub-project's deliverables (page screenshots / interface responses / test reports / build logs) read-only and compare against the contract; **do not enter the sub-project to change the implementation**.
- **Label the evidence level honestly**: build passed ≠ feature done. When a sub-project says "done," check which L the evidence lands at, resolving the level **against the single source of truth** — the frozen ladder in [evidence-gate-protocol.md](evidence-gate-protocol.md) §1. Do not restate the ladder here or anywhere else, not even as a parenthetical shorthand: a shorthand that drifts is indistinguishable from a redefinition. Sub-project L values are **aggregated literally, with no conversion layer**; a report that looks self-inconsistent is raised as a blocker, never silently re-graded.
- **Unverified may not be marked done**: if the "whether verified" column of a deliverable does not pass, that sub-project cannot be marked done in task.md.

---

## 5. Blocker surfacing

One of the most important outputs of checkpointing is putting blockers on the table:
- Each blocker records: whom it blocks, its source, the clearing condition, the owner.
- Frequent blocker sources: a missing corresponding sub-skill (red line 3 block), an unready prerequisite (e.g. frontend waiting on a backend interface), an unadapted breaking contract change, an internally-stuck sub-project.
- Sync blockers into `orchestration/open-issues.md` and `task.md`, and track them to clearance in the checkpoint record.

---

## 6. Global-status summary (for the user)

After each checkpoint, give the user a **global-status summary** in 5–8 lines (rather than piling up detail):
- each sub-project's current stage + evidence level;
- the contract version and alignment;
- the current blocker list + clearing progress;
- the next global action (continue dispatch / wait for sub-agents / do integration).

> The summary serves "let the user see full-stack progress at a glance"; the detail stays traceable in the checkpoint table and records.
