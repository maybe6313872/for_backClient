# task.md protocol: the main agent's global board, and the difference from 4-dispatch

> `orchestration/task.md` is the **main agent's command deck**: maintained for any orchestration task — orchestration iterations, adoption, contract revision, checkpointing — cross-session, user-visible. It answers "what is being done now, how is each sub-project progressing, what is next," **always with a coarse-grained checklist**.

## 1. What task.md looks like
| Section | Content |
|---|---|
| Date header | the frozen three-field contract `<!-- 迭代标识: <简短说明> \| 迭代日期: YYYY-MM-DD \| 状态: 进行中 -->`; `状态` holds **exactly one** of `就绪` / `进行中` / `已交付待归档` — never an inline enumeration (specs-lifecycle.md §3) |
| Current task | coarse-grained description (e.g. "orchestrate: some full-stack requirement" / "adopt: the existing monorepo"), type, one-line goal, start date |
| Progress (coarse checklist) | a few big steps (the six stages as big steps + each sub-project's dispatch/checkpoint status) |
| Sub-project status | each sub-project's current stage / contract alignment / blocker (coarse; detail in the checkpoint table). Handoff-mode dispatched-not-yet-picked-up state: 「已派单待外部开发」 |
| Current status / next | what is being done now, next, blockers |
| Notes | risks, external dependencies, pending user confirmation |

Do not pile fine-grained dispatch details or detailed requirements/contracts into task.md — that is the job of other documents / the checkpoint table.

## 2. task.md vs `orchestration/4-dispatch/` (do not conflate, red line 6)
| | `orchestration/task.md` | `orchestration/4-dispatch/current.md` |
|---|---|---|
| Positioning | command deck: overall orchestration + progress, user-visible | dispatch blueprint: fine-grained dispatch breakdown within a single iteration |
| Scope | maintained for any orchestration task | exists/used only when orchestrating an iteration via the six stages |
| Granularity | coarse (iteration name, a few big steps, sub-project status) | fine (what each sub-project is dispatched, acceptance points, contract version) |
| Lifecycle | long-lived, archived to `orchestration/task/` as tasks turn over | produced per single iteration, archived into `4-dispatch/history/` |

**Decision rule**: any orchestration task updates task.md; only when "orchestrating an iteration via the six stages" do you additionally do the fine-grained dispatch breakdown in `4-dispatch/current.md`.

### Pro examples
- ✅「收编现状 monorepo」→ not six-stage → update task.md only, do not build 4-dispatch.
- ✅ Handoff-mode dispatch landed → task.md marks each sub-project 「已派单待外部开发」 and the iteration suspends; a later session reads task.md, sees the suspended dispatches, and resumes integration-checkpoint.
- ✅「修订某契约模块」→ usually not a full six stages → update task.md, take a slim flow as needed.
- ✅「按六阶段做某全栈需求」→ task.md records coarse progress **and** `4-dispatch/current.md` does the fine dispatch.

### Anti examples
- ❌ Stuffing a single sub-project's dispatch details into task.md (should go to 4-dispatch).
- ❌ Building 4-dispatch for a non-six-stage task like "adopt the existing state."
- ❌ task.md drifting more than one stage away from real progress.

## 3. Hard constraints
- The read order on each skill trigger: `orchestration/README.md → task.md → docs/ → mode/stage detection`.
- Maintain task.md for any orchestration task; update it promptly during execution.
- task.md holds only coarse granularity; archive before switching tasks, never overwrite in place.
