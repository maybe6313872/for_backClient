# docs Textualization Adapter (standalone · swappable)

> **This module is deliberately standalone**: it isolates the capability of turning "binary input documents (requirement-spec xlsx, protocol pdf, mind-map emmx…) → text" — a capability that is **tightly coupled to company infrastructure and subject to change** — from the rest of the framework. Every sdd-xx **references only the contract defined in this file** and never hard-codes converter details into its own body. **When infrastructure changes (service address / tool replacement), change only this one place and every sdd-xx follows automatically.**
>
> Business slot S8's `binary-doc-converter` (the company binary-document textualization capability) is what this file points at; this file is where it lands.

---

## 1. Adapter contract (framework-level, stable)

Every textualization implementation must satisfy this contract; this skill's docs flow depends only on the contract, never on a concrete implementation:

| Contract item | Requirement |
|---|---|
| Input | Any binary/text input document under the root `docs/` |
| Detection | Can determine which documents need conversion and which are already text and directly readable |
| Conversion | Binary → text (xlsx→CSV/MD, one file per workbook; pdf/docx→MD/text; mind map→hierarchical CSV) |
| Artifact destination | Everything goes into `docs/converted/`: files needing conversion go into `<same-name folder>/`; files needing none become a same-name file |
| Index | Maintain `docs/converted/README.md` (source↔artifact mapping + per-file SHA-256/date + aggregate hash) + `manifest.json` |
| Quick check | Supports a check pass that reports "which source documents changed and need reconversion" and a write pass that books the change and refreshes the index |
| Idempotence | Skip when a source document's hash is unchanged, guaranteeing artifacts map one-to-one to sources |

> `orchestration/README.md` and the knowledge map's "reference document index" should both point at `docs/converted/README.md`.

**Orchestration-tier scope (red line 2)**: this adapter governs the **root** `docs/` only. Binary documents living inside a sub-project (`frontend/docs/`, `backend/docs/`, …) are that sub-project's own business, textualized by its own single-stack sdd skill; the main agent never converts, rewrites, or indexes them. If a sub-project's binary document is needed as orchestration input, it is referenced through the dispatch packet's downlink list by absolute path — not copied up and converted at the root.

---

## 2. Current company implementation (⚠️ infrastructure-bound, will change — edits touch this section only)

> Below is the **current** implementation. When company infrastructure changes (e.g. converter service migration, tool replacement), **modify only this section**; the contract (§1) and every reference to it remain untouched.

**Capability priority (detection + degradation)**:
1. **First choice: the company `binary-doc-converter`** — the internal capability dedicated to textualizing binary documents.
   - Currently hosted at: internal service **`192.168.1.39`** (⚠️ placeholder pending confirmation — verify against reality whether it is an HTTP service / shared script / standalone skill).
   - Invocation: ⚠️ pending confirmation, to be filled per the actual infrastructure (skill invocation / HTTP API / command line). Until confirmed, do not fabricate a call — degrade to step 2 and say so in the report.
2. **Second choice: the built-in document skills of the current environment** — for pdf call the built-in pdf/pdf-reading skill; for docx call the docx skill; for xlsx call the spreadsheet skill.
3. **Fallback: the AI textualizes on demand by itself** — not forbidden, but prefer reusing the capabilities above to avoid reinventing wheels and creating inconsistency.

**Index & quick-check tool (current)**: this skill **ships no converter or index script** (it has no `scripts/` directory — the main agent orchestrates, it does not build tooling). `docs/converted/README.md` and `docs/converted/manifest.json` are maintained by the `/sdd-docs` flow below: the check pass compares each source document's SHA-256 against the manifest entry, the write pass books the new hash and date. If a project supplies its own index script, register it in `orchestration/context/` and call it here instead — the contract in §1 is unchanged either way.

---

## 3. `/sdd-docs` standard flow (contract-driven, implementation-agnostic)

```
Inspect the root docs/ → check pass (hash vs manifest.json) to find what needs conversion
→ call the current converter (§2 priority order) to textualize
→ artifacts go into docs/converted/<same-name folder>/ (one file per workbook)
→ write pass books the new hash/date into README.md + manifest.json
→ report: added / changed / needs-reconversion list, plus which capability tier of §2 was actually used
```

**Freshness coupling (specs-lifecycle §8)**: a textualized artifact that an orchestration document already quotes counts as an `inputs/` copy — when the source document changes, the input-copy freshness check fires and the quote must be refreshed before the stage proceeds. Never keep orchestrating on a stale conversion silently.

---

## 4. How this is wired into this skill (S8)

- The SKILL.md entry behavior says only one sentence: docs textualization follows the contract in this file, currently hosted by the company `binary-doc-converter`. Concrete addresses and invocation details live **here and nowhere else**.
- Do **not** scatter `192.168.1.39` or concrete invocation details into SKILL.md or other protocol files — that would force N places to be edited whenever the infrastructure changes (the leave-blank risk of business-slots S8).

---

## 5. Maintenance notes

- Changes to §2 are recorded in this skill's README iteration log (noting "S8 adapter: old → new").
- If the company standardizes the conversion capability into a stable interface, §2 can be collapsed into a one-line interface note, further reducing coupling.
- `192.168.1.39` and the invocation form are currently **placeholders pending confirmation** — verify the real address/form on first use of this skill and update them here.
