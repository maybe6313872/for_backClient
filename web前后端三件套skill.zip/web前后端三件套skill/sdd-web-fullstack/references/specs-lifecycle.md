# orchestration / contracts lifecycle & archiving mechanism (must read)

> Core iron rule: **no document under `orchestration/`, `contracts/`, or `docs/` may be overwritten or deleted in place — to update, archive the old version first, then write the new workbench version (red line 5).** Violating it loses the orchestration evolution history and is a serious error. This skill ports the single-stack skill's specs lifecycle to the orchestration layer, with directory names adjusted for the orchestration layout.

## 1. Why this mechanism
`orchestration/` and `contracts/` are the full-stack project's long-term memory. If you overwrite `2-requirements/current.md` directly, edit a contract in place without leaving a version, or clear `task.md` on switching iterations, the orchestration history is gone — no one can trace "what the previous requirement/contract was and why it changed." So they are modeled as stateful workspaces with archiving discipline.

## 2. Domain model: workbench vs history
Each document class has one workbench version (active, read-write) and a set of history versions (read-only, archived by date).

| Workbench (active document) | History archive location |
|---|---|
| `orchestration/task.md` | `orchestration/task/YYYY-MM-DD-<说明>.md` |
| `orchestration/1-constitution/current.md` | `orchestration/1-constitution/history/YYYY-MM-DD-<说明>.md` |
| `orchestration/2-requirements/current.md` | `orchestration/2-requirements/history/...` |
| `orchestration/3-contract-design/current.md` | `orchestration/3-contract-design/history/...` |
| `orchestration/4-dispatch/current.md` | `orchestration/4-dispatch/history/...` |
| `orchestration/5-integration-checkpoint/current.md` | `orchestration/5-integration-checkpoint/history/...` |
| `orchestration/6-deliver/current.md` | `orchestration/6-deliver/history/...` |
| `contracts/openapi/` (whole dir or module) | `contracts/openapi/history/v<oldVersion>/` or a module `history/` |

> `task.md` archives to `orchestration/task/`; the six-stage `current.md` files archive to their own `history/`; contracts archive by version (see contract-first-protocol §4).

## 3. current.md date header
Each `current.md` — and `orchestration/task.md` — carries a one-line date-header comment at the top, used for archive naming and the "is it ready" judgment. The contract is **frozen**; the six Chinese literals below are language-bound (F32) and are reproduced byte for byte, never translated:
```
<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
```
**Exactly three ` | `-separated fields.** Inside the header `|` is the field separator and nothing else, so the third field holds **exactly one** value drawn from the frozen closed set of §4 — `就绪` / `进行中` / `已交付待归档` — chosen at write time.

❌ **Never write the enumeration inline**: `状态: 进行中 | 已交付待归档` makes a three-field header parse as four and silently breaks every parser and every archive-naming step that greps these literals. The enumeration belongs in §4 (the lifecycle-state definition), never in the header itself.

## 4. Document lifecycle states
```
就绪 → 进行中 → 已交付待归档 → (archive to history/, extract the necessary info back into a clean current.md)
```
"就绪" judgment: current.md is empty, or holds only template placeholders, or its date-header status is "就绪". Non-ready and wanting to open a new iteration → must archive first.

## 5. Archiving operation (the standard action, never overwrite in place)
1. Read the date header, compose the archive filename `YYYY-MM-DD-<说明>.md`.
2. Move the current content to the corresponding history location (preserve the full original).
3. Extract the still-valid conclusions the next iteration must carry into a new current.md, write a new date header.
4. The new current.md holds only content relevant to the current iteration, not piled history.

## 6. Hooks: trigger → action
| Hook | Trigger | Action |
|---|---|---|
| Pre-iteration inspection | a new iteration / `/sdd-update` / `/sdd-iterate` starts | inspect task.md, each current.md, contract versions: archive whatever belongs to the previous iteration; confirm the workbench is ready before starting; **run the input-copy freshness check (§8)** |
| Input-copy freshness | pre-iteration inspection, or before any stage consumes an `inputs/` copy | compare each copy against its registered source per §8; stale → report to the user and re-copy on approval, never proceed silently with a stale copy |
| Stage gate passed | the user explicitly says "pass / next stage" | finalize that stage's current.md (update the date header); update task.md coarse progress; give a progress-clarification note |
| Iteration delivery done | the deliver Gate passes | archive task.md to task/; archive the contract version; iteration record into docs/iterations/; refresh the orchestration cognition; suggest /sdd-retro |
| No-overwrite rule | any action that would overwrite/delete an existing document | intercept → reroute through §5 archive-first-then-write |
| Contract change | any contract modification | archive the old version first; version by the semantic change; two-way notify front/back (contract-first §4) |
| docs change | root docs/ added or updated / `/sdd-docs` | textualize as needed and update the index |

## 7. Anti-examples and corrections
- ❌ A new iteration overwrites `2-requirements/current.md` directly → ✅ archive to history/ first, extract valid constraints into a new current.md.
- ❌ Clearing task.md on a task switch → ✅ archive to `orchestration/task/`, then build a new board.
- ❌ Editing the contract in place without leaving a version → ✅ archive the old version to `contracts/openapi/history/`, then change and bump the version.
- ❌ Copying whole history into the new current.md at archive time → ✅ extract only the conclusions the next iteration must carry.

## 8. External input copies: `sources.md` registry + freshness check

Directories holding **copies of external materials** (typically `docs/requirements/<迭代>/inputs/` — requirement spec snapshots, migration-script copies, protocol excerpts) are outside the archive discipline above but have their own staleness failure: the source updates and the copy silently rots, then a stage consumes the stale copy.

**Registry**: each such directory keeps a `sources.md` (template in `assets/templates/sources.md`) with one row per copy: copy filename · source path/URL · capture time · source version/mtime/content-hash at capture · notes.

**Freshness check (hard action at pre-iteration inspection, and before any stage consumes a copy)**:
1. For every row in `sources.md`, compare the source's current mtime / version / content hash against the recorded capture values (read-only).
2. Mismatch → **report the stale copies to the user and re-copy on approval** (then update the registry row); a source that is unreachable → mark `⚠️ 待确认` in open-issues.
3. ❌ Never carry a known-stale copy into requirements/contract-design silently; ❌ never add a copy to `inputs/` without registering it in `sources.md`.
