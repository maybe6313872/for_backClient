# Usage Guidance Protocol (/sdd-help · F29)

> **Positioning**: `/sdd-help` is this skill's **skill meta-command** — it targets no particular project; it addresses **the user themselves**, interactively explaining "how to use this orchestration skill" and answering, step by step, any question that comes up during use. It lets newcomers / occasional users get started without reading through SKILL.md and the references.
>
> **Zero side effects**: `/sdd-help` is **read-only, never writes** — it changes no project file, changes no skill file, never launches the six orchestration stages / the Mode B adoption flow, and never emits or lands a dispatch packet; it only converses.

## 1. Core principles (frozen) — interactive, no info-dumping

- **Ask before explaining**: on entering `/sdd-help`, first use **a one-sentence welcome + one multiple-choice question** to locate what the user wants to learn; you must **not** open with a wall of explanation or a recitation of SKILL.md.
- **One question at a time, one answer at a time**: each round focuses on a single topic; explain it clearly, then ask "what else would you like to know", handing the pace to the user. Follow the framework interview priority (F6): **multiple-choice > fill-in with suggested value > confirmation > open-ended**.
- **Go deep on demand**: answer exactly what the user asks; name the corresponding reference only when it is needed, avoiding information overload.
- **Use in-domain examples**: prefer **in-domain** scenarios for examples (see §4 in-domain guidance seeds) — a front-end/back-end split, a contract change, a dispatch packet — so explanations feel tangible.
- **Acknowledge boundaries**: for questions beyond this skill's scope, say so honestly and route to the correct entry point. This skill orchestrates; it never writes front-end or back-end business code. Questions about implementing a screen or an endpoint belong to the sub-project skill (`sdd-web-frontend`, `sdd-web-backend-java`, `sdd-web-backend-python`), not here.

❌ Anti-example: the user types `/sdd-help` and the AI immediately outputs a long article covering the six stages + Mode B + all nine commands + both dispatch execution modes.
✅ Good example: the AI asks one multiple-choice question — "Which part first? ① orchestrate a new requirement from scratch ② adopt an existing monorepo ③ command quick reference ④ how dispatch to front-end/back-end works ⑤ why gates/archiving are so strict ⑥ set my usage preferences ⑦ other" — and expands a topic only after the user has chosen it.

## 2. Guidance flow

```
/sdd-help
  → ① One-sentence welcome + multiple-choice to locate the topic (offer 4–6 common topic options + "other")
  → ② User picks / asks → explain that topic concisely (add 1 in-domain example when useful)
  → ③ Closing question: is this clear? want more on [adjacent topic options], or all done?
  → ④ Loop ②③ until the user ends; on ending, close by inviting the user back to /sdd-help anytime
```

## 3. Guidable topic list (expand per the user's choice; never dump all at once)

| Topic | One-sentence key points | Deep-dive pointer |
|---|---|---|
| The two working modes | Mode A forward orchestration (`/sdd-iterate`) / Mode B adopting an existing monorepo (`/sdd-init`); for a repo that already has code, do B first, then A | SKILL.md §Two working modes |
| Orchestrating a requirement from scratch | Six stages: constitution→requirements→contract-design→dispatch→integration-checkpoint→deliver; stop after each stage and wait for clearance | references/orchestration-stages.md |
| Adopting an existing monorepo | `/sdd-init` surveys the repo, builds the `orchestration/context/` cognition layer, registers each sub-project and its skill, and can back-derive upstream document drafts | references/mode-b-adopt.md |
| Command quick reference | `/sdd-init` `/sdd-iterate` `/sdd-contract` `/sdd-dispatch` `/sdd-checkpoint` `/sdd-update` `/sdd-retro`, plus the skill meta-commands `/sdd-help` `/sdd-custom` | references/commands.md |
| Contract first | `contracts/openapi/openapi.yaml` is the single source of truth; interface changes are made in the contract before any dispatch, and `/sdd-contract` maintains the modular split under `paths/` and `components/schemas/` | references/contract-first-protocol.md |
| How dispatch works | `/sdd-dispatch` produces a packet per sub-project; **handoff** (packet hand-over, default) vs **agent-drive** (a sub-agent drives the sub-project skill, only when the user explicitly asks) | references/dispatch-protocol.md |
| Where dispatch packets land | Authoritative copy stays at `orchestration/4-dispatch/`; the delivered copy goes into `<sub-project>/docs/requirements/`; an emptied inbox means the requirement was picked up | references/requirement-inbox-protocol.md |
| Checking sub-project progress | `/sdd-checkpoint` reads each sub-project's own `specs/task.md` and evidence, then records the result under `orchestration/checkpoints/` | references/checkpoint-protocol.md |
| Repository modes | mono-repo (one repo, plain sub-directories) vs submodule-aggregate (each sub-project is a git submodule); commit/pin order differs | references/repo-management-protocol.md |
| Why the gates are strict | Prevent the AI from running stages back-to-back / skipping stages / dispatching before the contract is settled / accepting bare PASS from a sub-project / overwriting history / speculating | SKILL.md §Gate system |
| Archiving discipline | Under `orchestration/` nothing is overwritten — archive first; `current.md` + `history/`; date headers | references/specs-lifecycle.md |
| Retro distillation | `/sdd-retro` writes lessons/highlights into `orchestration/retro/`, which can be aggregated and fed back into the framework | references/reflow-evolution.md |
| Set personal preferences | `/sdd-custom` sets style, tone and habits (default 「专业可靠」) | references/custom-protocol.md |
| What to do when something goes wrong | Run the self-check list first (missing workbench file, contract/dispatch out of sync, unclear sub-project state); anything involving a sub-project or a person is escalated through the collaboration protocol. **A missing or unavailable sub-project skill is a blocking condition: report it and stop — never degrade into writing the sub-project's code yourself** | references/self-check.md · references/collaboration-protocol.md |

## 4. In-domain guidance seeds (orchestration layer)

> The in-domain getting-started essentials and high-frequency questions most worth covering first, so `/sdd-help`'s examples and answers fit this layer closely.

- **"Where does my requirement enter?"** — a top-level full-stack requirement dropped by a human lands in the root `docs/requirements/`; the orchestrator claims it, registers it, and runs the six stages. Long-lived specifications belong in `docs/product-specs/`, never in the inbox.
- **"Who writes the code?"** — nobody at this layer. The requirements stage splits the requirement, the contract-design stage settles the interface, the dispatch stage hands each slice to `frontend/` or `backend/` with its own sdd skill, and the integration-checkpoint stage verifies what came back.
- **"Front-end and back-end disagree about a field"** — that is a contract question, not a code question: reopen the contract-design stage, change `contracts/openapi/openapi.yaml`, then re-dispatch. Never let the two sides settle it privately in code.
- **"The sub-project says it is done"** — a bare claim is not evidence. `/sdd-checkpoint` reads the sub-project's own `specs/task.md` and its graded evidence; ungraded or missing evidence keeps the checkpoint open.
- **"What is the difference between handoff and agent-drive?"** — handoff is the default: you receive a packet and hand it to whoever (or whichever session) owns that sub-project. agent-drive is only used when the user explicitly asks for it, and even then the sub-project skill still governs the sub-project.
- **"The repo uses git submodules"** — say so early; it changes the commit and pin order at the deliver stage (see repo-management-protocol.md).

## 5. Relationship with /sdd-custom
`/sdd-help` explains "how to use it"; `/sdd-custom` sets "use it my way". When the "set personal preferences" topic comes up inside `/sdd-help`, you may route the user to `/sdd-custom`, but both are bound by the same gate red lines and read-only guard (see custom-protocol.md).
