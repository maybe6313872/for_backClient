# Contract-first protocol (contract-first / OpenAPI modularization)

> **Positioning**: `contracts/openapi/` is the **single interface source of truth** for front/back collaboration (red line 4). Every interface is finalized in the contract first, and both sub-agents consume the same contract. This file defines: the modular-split spec, `$ref` organization, versioning, two-way notification, bundle/lint validation, and per-project extension.

---

## 1. Why contract-first

The biggest collaboration risk in front/back separation is "both sides inventing interfaces behind the contract's back": the frontend writes requests by guesswork, the backend returns structures by guesswork, and the mismatch only surfaces at integration. Contract-first pulls the interface agreement **forward, before dispatch**, so what is dispatched to front and back is the **same** source of truth — eliminating interface drift at the root.

**Hard constraints**:
- Before an interface is finalized in the contract, **do not dispatch** the front/back coding tasks related to that interface.
- When a frontend/backend sub-agent implements an interface, **do not** deviate from the contract to add fields / change structure on its own; a genuine change goes through the §4 change flow.

---

## 2. Modular-split spec (no single-file bloat)

**Red line**: do not use a single `openapi.yaml` to carry all paths and schemas. It must be split by business module, organized with `$ref`.

```
contracts/openapi/
├── openapi.yaml                 # root: openapi version, info, servers, security, tags, $ref into paths
├── paths/                       # path split by module (one module one file)
│   ├── auth.yaml
│   ├── usage.yaml
│   ├── trace.yaml
│   ├── keys.yaml
│   ├── models.yaml
│   └── cost.yaml
├── components/
│   ├── schemas/                 # schema split by module (no single-file bloat)
│   │   ├── common.yaml          #   pagination, error, common enums
│   │   ├── usage.yaml
│   │   ├── trace.yaml
│   │   └── keys.yaml
│   ├── parameters/              # reusable parameters (as needed)
│   ├── responses/               # reusable responses (as needed, e.g. 401/400/404)
│   └── securitySchemes.yaml     # auth schemes (e.g. cookieAuth)
└── README.md                    # contract module index + bundle/lint/diff commands
```

**Split criteria**:
- Keep a single `paths/*.yaml` within one business module's endpoint set; when line count clearly bloats (rule-of-thumb ~300 lines), split into sub-modules.
- Cross-module reusable schemas go to `components/schemas/common.yaml`; module-private ones go to each module's own schema file.
- The root `openapi.yaml` keeps only `info/servers/security/tags` and `$ref` assembly; it **does not inline** concrete path/schema bodies.

**Per-project extension**: contracts support adding/removing modules as the project actually needs — a new module adds `paths/<module>.yaml` and `components/schemas/<module>.yaml`, registered in the root file and the README index. Do not be bound by the ai-cms sample modules the skeleton provides.

---

## 3. `$ref` organization and bundle validation

- Use relative-path `$ref` uniformly for cross-file references, e.g. in the root file `paths: { /usage/daily: { $ref: './paths/usage.yaml#/UsageDaily' } }`, and a schema reference `$ref: '../components/schemas/usage.yaml#/UsageRow'`.
- Before delivery/dispatch it must **bundle successfully** (resolve the scattered files into one complete contract with no dangling `$ref`) and **pass lint**.
- Tools follow capability detection + degradation:
  - Preferred: `redocly bundle`/`redocly lint`, `swagger-cli bundle`/`validate`, `openapi-generator validate`, etc. (use whichever is installed in the project).
  - Fallback: the AI manually resolves all `$ref`, confirming one by one that each target file/anchor exists, with no circular reference, and that the root file's tags and paths are consistent.
- Record the bundle command and the tool used in `contracts/openapi/README.md`, for sub-agents and CI to reuse.

---

## 4. Versioning and two-way notification (contract change flow)

Contracts are versioned. A change must leave a version, be traceable, and notify both front and back at once.

**Version convention**:
- Mark a semantic version in `info.version` (or a module-level `x-module-version`).
- **Non-breaking change** (adding an optional field / adding an endpoint): minor +1.
- **Breaking change** (removing a field / changing a type / changing required / changing a path): major +1, and **must be reviewed by the user** (red-line level, equivalent to a reflow).

**Archiving** (with specs-lifecycle red line 5):
- Before a change, archive the old contract version first (snapshot the whole directory to `contracts/openapi/history/v<oldVersion>/`, or keep it in a version directory); **do not overwrite in place without leaving a version**.

**Two-way notification (core)**: once a contract changes, you must, **within the same action**, update the "dependent contract version" of both sides' dispatch packets and annotate the change points:
1. Update the contract version number and change summary in the dispatch packets under `frontend/docs/` and `backend/docs/`.
2. In `orchestration/task.md` and the checkpoint table, mark "contract vX→vY, front/back pending sync".
3. A breaking change additionally opens an entry in `orchestration/open-issues.md`, closed only after both front and back confirm adaptation is done.

❌ Changing the contract without notifying front/back, ❌ one side quietly following the contract while the other side is unaware — both are errors.

---

## 5. Integration points and error conventions (the contract must cover them)

The contract defines not only success responses but also the integration points, otherwise the checkpoint stage will inevitably devolve into finger-pointing:
- **Auth**: securitySchemes + which endpoints require auth + the unauthenticated response (e.g. 401).
- **Error model**: a unified error schema (code/message/detail), referenced by every endpoint.
- **Pagination/filtering**: unified pagination parameters and a response-wrapping structure.
- **Time/unit conventions**: time zone and format, numeric units, and other cross-stack conventions noted in the contract description or a common schema.

---

## 6. Relationship to the stages

- **contract-design stage**: produces/updates this contract; only enters dispatch after passing the bundle+lint gate.
- **dispatch stage**: dispatch packets reference a concrete contract version; front and back each implement that version.
- **integration-checkpoint stage**: verify that front/back implementations are consistent with the contract (contract consistency is a mandatory checkpoint-table item).
- **deliver stage**: the contract version is archived with the iteration.

`/sdd-contract` is this protocol's explicit entry and can be called independently for contract maintenance.
