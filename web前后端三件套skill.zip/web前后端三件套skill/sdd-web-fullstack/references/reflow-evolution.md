# Retro reflow loop (reflow / evolution)

> **Positioning**: a **first-class mechanism** of this skill. Capture each orchestration's lessons/highlights locally in the project retro, sediment the candidates that could rise to a framework hard standard into this skill's standalone `evolution/` folder, and — after user feedback — extract them into the **hard standards** of SKILL.md/references. `/sdd-retro` is the explicit entry.
>
> **Zero blast radius**: `/sdd-retro` reads orchestration output only and writes only `orchestration/retro/`; sedimentation writes only this skill's `evolution/`. It never changes sub-project code or other specs artifacts.

---

## 1. The three-stage loop

```
① project-local retro (frequent · cheap)          ② framework-candidate sediment (rare · framework-level)      ③ reflow into hard standards (after user feedback)
orchestration/retro/  ──filter [框架候选]──▶  evolution/experience-packages/  ──you feed back to me──▶  iterated into SKILL.md/references
(done after each orchestration iteration/integration)  (self-contained experience-package.md)              (becomes this skill's hard standard + one README row)
```

- **①** In the project: `/sdd-retro` runs the retro schema, producing `orchestration/retro/retro-YYYY-MM-DD-<topic>.md` and updating the `orchestration/retro/README.md` ledger.
- **②** In this skill: distill a retro that is tagged `[框架候选]` and whose generalizability is domain-general/cross-domain-general into a **self-contained experience package** in `evolution/experience-packages/`.
- **③** The user feeds `evolution/` back to the maintainer (me) → extract the necessary content → iterate it into the hard standards of `references/*` and SKILL.md → append one row to the README iteration log.

---

## 2. Project-local retro (`orchestration/retro/`)

**Triggers**: ① the user explicitly orders it on "this orchestration was wrong / done well"; ② the deliver exit gate auto-suggests it; ③ a periodic retro.

**Folder**:
```
orchestration/retro/
  README.md                       ← ledger / index
  retro-YYYY-MM-DD-<topic>.md      ← one file per topic
```
Ledger fields: `| id | date | topic | type (教训/亮点) | severity | tags | generalizability | status | linked task |`.

**Retro schema (frozen · facts first · no guessing on root cause · record highlights too)**:

| Section | Requirement |
|---|---|
| Meta | date / trigger / type (教训\|亮点) / severity CRITICAL·HIGH·MEDIUM·LOW / tags / generalizability / linked task / linked iteration |
| 1 What happened | facts + evidence strength. If an error, record the wording verbatim at the time |
| 2 What was expected | the correct/expected outcome |
| 3 Root-cause analysis | 5 whys or a single-hypothesis test; without evidence mark `[待确认]`; never guess the root cause |
| 4 Which rule/gate should have caught it | map to a red line / ORCH-# / Gate; no matching framework constraint = a gap |
| 5 Improvement actions | in this project: …; `[框架候选]`: … (an explicit tag for what could rise to the framework) |
| 6 Generalizability call | 项目专属 \| 本域通用 \| 跨域通用 |
| 7 Status | 待沉淀 \| 已沉淀 |

**Severity call**: violating a red line / an ORCH-* MUST or breaking orchestration = CRITICAL; contract conflict / uncheckpointable / front-back drift = HIGH; term drift / under-specified boundary = MEDIUM; format/naming = LOW.

**Discipline (frozen)**: purity (an uninvestigated doubt goes to open-issues, not mixed into the retro body); no guessing on root cause; record both wins and losses; focus on the issue, not the person (target the rule/gate gap, do not assign blame).

---

## 3. Framework-candidate sediment (`evolution/experience-packages/`)

Distill a retro tagged `[框架候选]` into a **self-contained experience package** — a reader/AI **not relying on this conversation's context** can still see "what to change, why, in which file, and how to verify."

An experience package must contain (schema in `evolution/README.md`):
- **Background**: which project, which orchestration, what problem it exposed / what better practice it found;
- **Current framework gap**: which line in the current SKILL.md/references is uncovered or under-covered;
- **Proposed change**: exactly which file to change, which rule to add/change (with draft wording);
- **Why it's better**: the advantage over the current practice, the generalizability call;
- **How to verify**: how to confirm the change works (e.g. some class of orchestration no longer fails);
- **Source retro**: traced to the specific entry in `orchestration/retro/`.

❌ Sedimenting a context-dependent package like "change it the way we just discussed" is an error.

---

## 4. Reflow into hard standards (done by the maintainer after user feedback)

When the user feeds this skill's `evolution/` back:
1. Evaluate each package: is the generalizability sound, does it conflict with the current framework, is the wording directly landable.
2. Extract the necessary content → iterate it into the **hard standards** of `references/*` and SKILL.md (change the SKILL.md inline summary first, then make the corresponding reference consistent — three-way alignment).
3. Bump the SKILL.md frontmatter version +1; append one row to the README iteration log (version/date/framework baseline/main content/impact).
4. Mark the reflowed package `已沉淀` in `evolution/` and keep its provenance; do not delete it.

> Boundary: only what is **generally better for this domain (full-stack orchestration)** lands as this skill's hard standard; if it turns out to be a paradigm **better for all SDD domains**, take it further through the mother skill `sdd-skill-creator`'s `/sdd-distill` + `/sdd-absorb` to upgrade the framework core.

---

## 5. Domain retro seeds (help the AI not miss this domain's typical pitfalls)

| Typical domain pitfall / good practice | Type | Typical severity |
|---|---|---|
| Main agent overreaches, writes sub-project code directly (violates the isolation red line) | 教训 | CRITICAL |
| A missing sub-skill was not blocked; the main agent stood in and roughed out a version | 教训 | CRITICAL |
| Front and back invent interfaces behind the contract; the mismatch blows up only at integration | 教训 | HIGH |
| A contract change was notified to only one side; the other is unaware | 教训 | HIGH |
| A monolithic yaml is not split and bloats to unmaintainable | 教训 | HIGH |
| A dispatch packet lacks acceptance points / contract version, leaving checkpointing with no basis | 教训 | MEDIUM |
| Contract finalized before dispatch; front and back align on the first try | 亮点 | — |
| The checkpoint table surfaces blockers; global progress is clear at a glance | 亮点 | — |

> These are initial seeds; keep adding to them as project retros accumulate.
