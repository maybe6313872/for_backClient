# Mode A orchestration — the six stages in detail

> Mode A runs a full-stack requirement from grooming to delivery in a disciplined way. Each stage produces only its own content, and after each stage a gate stops and awaits approval (red line 1). This file gives each stage's duty, interview questions, Gate, recommended diagrams, and self-check points.

---

## Stage overview

```
constitution → requirements → contract-design → dispatch → integration-checkpoint → deliver
```
The default order is as above; on discovering a risk/inconsistency at any stage you may reflow back to requirements/contract-design to fix it (tell the user why and sync task.md).

---

## 1. constitution (full-stack charter)

**Duty**: define project-level engineering constraints, itemized, few and sharp.
**Minimal artifact**: `orchestration/1-constitution/current.md`
**Interview questions (3–5)**:
- Repo management mode: mono-repo or submodule-aggregate? (detect `.gitmodules` first, confirm the detection in one line; see [repo-management-protocol.md](repo-management-protocol.md))
- What is each sub-project's tech stack? (frontend framework/build; backend language/framework) → freeze it
- Sub-project split and directory layout? Which entries are **business sub-projects** vs **supporting sub-repos** (tool/script — registered only, not orchestrated by default)?
- Contract directory convention? (default `contracts/openapi/`, can change)
- Sub-skill mapping? (which `sdd-web-*` each business sub-project uses)
- Full-stack no-go zones? (e.g. the main agent writes no sub-project business code, does not edit LiteLLM config directly, and other project-specific red lines)

**Gate**:
- [ ] Common protocols (decision priority, minimal change, documents first)
- [ ] **Repo mode detected/declared** (submodule-aggregate: `.gitmodules` parsed into the pin inventory — path/remote/pinned commit)
- [ ] **Sub-project registry built and classed** (business: dispatched/checkpointed/sub-skill-mapped; supporting: registered only, frozen default)
- [ ] Front/back tech stack and versions frozen
- [ ] Contract directory convention clear
- [ ] Sub-skill mapping table listed (with the "missing = block" statement)
- [ ] The main agent's "orchestrate, don't code" red line written in (submodule-aggregate: plus "never runs git inside a sub-repo; one-way pointer flow")

---

## 2. requirements (full-stack grooming)

**Duty**: define "what" — acceptable requirements, split by module, with an initial front/back responsibility call.
**Minimal artifact**: `orchestration/2-requirements/current.md`
**Interview questions**:
- The goal and scope of this full-stack requirement?
- Which business modules are involved? Does each roughly belong to frontend/backend/shared?
- Acceptance criteria and boundary exceptions (auth failure / empty data / large volume / concurrency / timeout)?
- Evidence conventions (screenshots / interface responses / test reports)?

**Clarify loop**: at most 5 clarification points per round; key ambiguities not closed → do not enter contract-design.
**Layered requirement sediment (ORCH-G4, stage-end hard action)**: besides the overall requirement in `current.md`, land **per-sub-project layered requirement files** in the root repo: `docs/requirements/<迭代>/frontend-requirements.md` / `backend-requirements.md` (one per business sub-project in scope), each extracting that dimension's ownership from the overall requirement. This forms the three-level chain **overall requirement → layered requirements → dispatch slices**, so integration-checkpoint can verify per layer and traceability never jumps between the packet and the root requirement.
**Gate**:
- [ ] Each requirement has acceptance criteria (testable / observable / evidenced)
- [ ] Already split by module
- [ ] Each module has an initial frontend/backend/shared call
- [ ] **Layered requirement files landed in `docs/requirements/<迭代>/` (one per in-scope business sub-project), consistent with the overall requirement (ORCH-G4)**
- [ ] Boundaries and exceptions covered
- [ ] Key Clarify closed

**Recommended diagrams**: module-split diagram (`flowchart`, ≤15 nodes), requirement↔sub-project ownership table.

---

## 3. contract-design (contract design)

**Duty**: define "what the interface looks like" — OpenAPI modular finalization (single source of truth) + integration points + cross-stack data models.
**Mandatory pre-step — sub-project capability probe**: before drafting any contract, probe each involved sub-project's **existing interfaces and capabilities** (read-only; docs/specs layer first, targeted source reads only where docs are silent): existing endpoint inventory · reusable or not · owning service/module. Write the findings as a **capability probe report** into `orchestration/context/` (e.g. `capability-probe-<迭代>.md`); unresolved doubts go to `open-issues.md`. The probe is design *input*, not an improvised action — a contract drafted without it is guessing (red line 6).
**Minimal artifact**: `orchestration/3-contract-design/current.md` + `contracts/openapi/*` + the capability probe report in `context/`
**Interview questions**:
- Endpoint list per module (method/path/purpose)?
- Auth scheme and unauthenticated response?
- Unified error model, pagination, time/unit conventions?
- Any breaking changes (affecting existing front/back)?

**Gate** (details in [contract-first-protocol.md](contract-first-protocol.md)):
- [ ] **Capability probe report attached (existing interface inventory + reusability + owning service); without it the gate does not pass**
- [ ] Contract split by module (no single-file bloat)
- [ ] `$ref` resolvable, bundle validation passes, lint passes
- [ ] Version fixed (breaking changes reviewed)
- [ ] Integration points (auth/error/pagination/conventions) clear
- [ ] Old contract version archived (if changed)

**Recommended diagrams**: contract-module diagram, key sequence diagram (`sequenceDiagram`, frontend→backend→upstream).

---

## 4. dispatch (split & dispatch)

**Duty**: cut requirement + contract into frontend/backend dispatch packets, assigning sub-skill + working root + acceptance points, **in the declared execution mode (handoff default / agent-drive on explicit request, red line 8)**. Two-phase (see [dispatch-protocol.md](dispatch-protocol.md)).
**Minimal artifact**: `orchestration/4-dispatch/current.md` + dispatch packets in each sub-project's `docs/requirements/`
**Interview questions (3–5)**:
- Execution mode: handoff (default — only land packets, development happens in external sessions) or agent-drive (the user explicitly wants sub-agents to execute now)?
- Dispatch slice boundaries per sub-project? Front/back prerequisite ordering?
- Acceptance points and evidence requirements per packet?
- Anything the packet must carry so an external session can execute it stand-alone (env, scripts, data)?

**Gate**:
- [ ] **Execution mode declared (handoff default; agent-drive only on the user's explicit request)** and recorded in current.md / packets / task.md / checkpoint table
- [ ] **Boundary intake done (dispatch-protocol §5a)**: each target sub-project's `specs/context/modules.md` (or equivalent) read; extracted constraints written into each packet's 「建议实现边界」
- [ ] Each packet has execution mode / working root / sub-skill / contract version / requirement slice / acceptance points / integration conventions / suggested implementation boundary / **parent-file downlink list (restrained absolute paths; contract modules mandatory — dispatch-protocol §5c)** / specs-first requirements (ORCH-G1/ORCH-G2/G5) / pickup instructions incl. clear-to-acknowledge (§5d), and is **self-contained against the executor's parent-folder blindness**
- [ ] **agent-drive mode: specs dispatch and code dispatch are two separate calls; the code dispatch waits for the user's specs confirmation (ORCH-G1/ORCH-G2, dispatch-protocol §5b)**
- [ ] **Sub-skill verified per mode** (agent-drive: triggerable here, missing = block; handoff: mapping declared, no mapped skill at all = block); a blocker reported and stopped on
- [ ] Packets written into each sub-project's `docs/requirements/` (legacy `docs/`-root packets recognized, not migrated)
- [ ] The main agent has not overreached into writing any sub-project business code
- [ ] task.md and the checkpoint table record each sub-project's dispatch status (**handoff: 「已派单待外部开发」 and the iteration suspended after gate ②**)

**Recommended diagram**: dispatch-flow diagram (root → each sub-project, ≤10 nodes).

---

## 5. integration-checkpoint (integration checkpoint)

**Duty**: checkpoint sub-project output, contract consistency, joint debugging, end-to-end.
**Handoff-mode entry**: in handoff mode this stage does **not** start right after dispatch — the iteration sits suspended as 「已派单待外部开发」 and resumes here when the user reports a sub-project's progress/completion, or when a later root session finds suspended dispatches in `task.md`. In agent-drive mode it follows dispatch in-session as usual.
**Minimal artifact**: `orchestration/5-integration-checkpoint/current.md` + checkpoint table (see [checkpoint-protocol.md](checkpoint-protocol.md))
**Gate**:
- [ ] Checkpoint table covers all sub-projects; deliverables verified item by item
- [ ] **ORCH-G3 overreach check run per sub-project (`git status`, read-only): out-of-scope uncommitted business-code changes → marked 越界待处置, blocked, user asked for disposition (never auto-reverted)**
- [ ] **G5 specs↔code pairing check run: business-code changes pair with specs changes; code-without-specs = incomplete, blocked until specs backfilled or explicitly waived (G5 is grain-independent — fixes included)**
- [ ] **G6 claim↔git pairing check run: every deliverable and test asset claimed by an executor is present in that sub-project's working tree; claimed-but-absent items are not graded and are reported; a cleared inbox alone is acknowledgment, never completion (checkpoint-protocol §3a)**
- [ ] **Layered-requirement verification: each sub-project's deliverables checked against its `docs/requirements/<迭代>/<sub>-requirements.md` (ORCH-G4 chain)**
- [ ] Contract consistency verified (front/back implementations aligned with the contract)
- [ ] Joint/end-to-end debugging executed and evidenced
- [ ] Each conclusion labeled with an L1–L5 evidence level
- [ ] Blockers made explicit and synced to open-issues/task.md

**Recommended diagrams**: contract-consistency matrix (table), end-to-end path diagram.

---

## 6. deliver (delivery)

**Duty**: version archiving, iteration record, ADR, trigger the retro reflow.
**Minimal artifact**: `orchestration/6-deliver/current.md`
**Gate (including a doc-sync section)**:
- [ ] Iteration record written into `docs/iterations/` (template in assets)
- [ ] **Submodule-aggregate mode: each touched business sub-repo's target commit verified pushed (read-only) + the pointer-reclaim command checklist written into current.md (user executes by default; the main agent runs root-repo git only on explicit authorization); delivery semantics state whether the pins are already reclaimed** (see [repo-management-protocol.md](repo-management-protocol.md) §4)
- [ ] Contract version archived
- [ ] Major decisions written into `docs/decisions/` (ADR)
- [ ] `orchestration/README.md` orchestration cognition reflects the current state
- [ ] `orchestration/context/*` module↔sub-project↔contract mapping updated
- [ ] `task.md` archived to `task/` and cleared for the next iteration
- [ ] **G6 claim↔git pairing re-run against this orchestration's own claims**: every artifact this delivery claims to have landed is verified present in the actual working tree (`git status`, read-only, per sub-project and at the root); no "claimed changed but no change present", no unregistered incidental changes; the root `docs/requirements/` inbox is cleared per claim (acknowledgment, not completion) — see [checkpoint-protocol.md](checkpoint-protocol.md) §3a and [gate-and-stages.md](gate-and-stages.md)
- [ ] Delivery semantics do not exceed the highest evidence level from integration-checkpoint
- [ ] Suggest `/sdd-retro` for this orchestration's retrospective (see [reflow-evolution.md](reflow-evolution.md))

If any of these doc-sync items fails, the deliver Gate is not released.

---

## Common to every stage: pre-output chain-of-thought + post-output self-check
See [self-check.md](self-check.md). On entering a stage, interview first ([collaboration-protocol.md](collaboration-protocol.md)); run the chain-of-thought before output; run the checklist after output; then show the Gate.
