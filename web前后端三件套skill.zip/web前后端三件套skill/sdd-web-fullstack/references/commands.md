# `/sdd-*` command-set definition + routing

> Command naming may be reasonably self-chosen per the actual project (not over-designed for conflicts); the table below is the recommended set. Two command classes: project commands (handled by this skill only when the root orchestration signature is matched) + skill meta-commands (always available). **Every command also responds to its Chinese natural-language equivalents (F9)** — slash commands are hard to memorize, so the phrases are the usability contract; they are language-bound content and stay Chinese.

## Project commands
| Command | Chinese equivalents (also trigger it) | Duty | Lands in |
|---|---|---|---|
| `/sdd-init` | 「收编这套monorepo」「接手这个全栈项目」「梳理现有全栈工程」 | Adopt an existing monorepo's current state (Mode B) | mode-b-adopt.md |
| `/sdd-iterate` | 「做个全栈需求」「按六阶段编排」「加个前后端功能」 | Forward orchestration, the six stages (Mode A) | orchestration-stages.md |
| `/sdd-contract` | 「维护契约」「拆分OpenAPI契约」「给契约升版本」 | Modular contract upkeep (split/version/bundle/two-way notify) | contract-first-protocol.md |
| `/sdd-dispatch` | 「生成派发包」「只派单不开发」「派发给子代理」 | Generate/land dispatch packets in the declared execution mode (handoff default / agent-drive on explicit request); mode-aware sub-skill verification (no mapped skill = block) | dispatch-protocol.md |
| `/sdd-checkpoint` | 「点检子项目进度」「各子项目做到哪了」「核验产出物」 | Checkpoint sub-project progress and deliverables | checkpoint-protocol.md |
| `/sdd-update` | 「归档工作台」「巡检并归档」「维护编排台账」 | Workbench upkeep: inspect and archive task.md / each current.md / contract versions | specs-lifecycle.md |
| `/sdd-docs` | 「整理文档」「把 docs 文本化」 | Docs governance: inspect the orchestration root's `docs/`, textualize binary docs as needed, maintain `docs/converted/README.md` | docs-binarification-adapter.md |
| `/sdd-tidy` | 「规整项目目录」「收拾项目结构」「整理目录结构」 | Structure tidy-up (F35): gated scan→plan→execute against this skill's `structure.md` (the orchestration-root layout); moves/archives only, never deletes; **sub-project interiors are out of scope** | tidy-protocol.md |
| `/sdd-retro` | 「复盘这次编排」「沉淀本次教训」「做个编排复盘」 | Retro sedimentation (writes orchestration/retro/, candidates to evolution/) | reflow-evolution.md |

## Skill meta-commands (not restricted by project signature)
| Command | Chinese equivalents (also trigger it) | Duty |
|---|---|---|
| `/sdd-help` | 「这个skill怎么用」「讲讲用法」「介绍下这个技能」 | Interactively explain this skill's usage and answer questions (read-only, never starts a workflow, ask-before-explaining, one question at a time, no info-dumping) |
| `/sdd-custom` | 「设定我的偏好」「自定义风格语调」「调整表达习惯」 | Set style/tone and usage habits into the only writable preference file `preferences/user-preferences.md`; refuse to write preferences that violate the gates (e.g. "skip gates / main agent writes sub-project code / no archiving"); hold principle when the user is wrong, no sycophancy |

> Style-tone tiers (frozen 5-tier enum, set via `/sdd-custom`; default when unset): 专业可靠 (default) / 亲和友善 / 直言不讳 / 高效务实 / 吐槽达人.

## Routing
1. First judge "currently at the project root (matching the orchestration signature) or inside a subfolder." Inside a subfolder → hand off to the corresponding single-stack sub-skill.
2. Root orchestration signature matched + a project command → go straight per the table above.
3. A skill meta-command → always available.
4. Ownership unclear → ask the user in one line.

> **Design assumptions (frozen)**: one role installs exactly one concrete `sdd-*` skill, so identical project-command names across `sdd-*` skills are not a conflict; a command is never used before this skill is in context (so the description does not enumerate commands); routing is a wrong-domain guard, not a per-turn arbiter. Do not re-litigate these with the user.
