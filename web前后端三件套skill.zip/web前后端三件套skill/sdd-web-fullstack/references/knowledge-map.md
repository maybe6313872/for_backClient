# Knowledge Map

> The knowledge map is the "navigation desk" of `orchestration/`: one lightweight index that answers "**to learn about X, which file and which section do I look at**". It lets both the user and the main agent locate knowledge in seconds without reading every document. It complements the **orchestration cognition maps** (`context/architecture.md` + `context/module-map.md`) — those maps index "which sub-project implements a capability, and under which contract module"; the knowledge map indexes "where knowledge/documents are".

---

## 1. Knowledge map vs orchestration cognition maps

| | Knowledge map | Orchestration cognition maps |
|---|---|---|
| Indexed objects | Documents/knowledge topics (requirements, architecture, contract discipline, dispatch state, checkpoint conclusions, constraints, ...) | Engineering entities (root → sub-project boundaries, business modules, contract modules, repo mode and gitlink pins) |
| Question it answers | "To learn X, which document do I read?" | "Which sub-project implements module Y, and which contract module governs it?" |
| Location | `orchestration/context/knowledge-map.md` | `orchestration/context/architecture.md`, `orchestration/context/module-map.md` |
| Generation | Maintained by the main agent (lightweight manual fill/update) | Produced by the Mode B adopt workflow, refreshed on delivery |
| Depth limit | Points at documents only; never copies their content | Stops at the sub-project boundary; never dives into a sub-project's internals (red line 2) |

Both hang on the specs lifecycle hooks and refresh as the project evolves.

---

## 2. Format (keep it lightweight)

One main table is enough: `topic/question → location (file + anchor) → last updated`. It may be grouped by area. Example (per the language protocol, the generated knowledge map itself is a project deliverable and is written in Simplified Chinese, as shown):

```markdown
# 知识地图 — <项目名称>
> 更新日期：YYYY-MM-DD

## 根编排认知
| 想了解什么 | 去哪看 | 最后更新 |
|---|---|---|
| 项目概览/子项目清单/技术栈 | `orchestration/README.md` | 2026-06-02 |
| 仓库形态与子项目登记 | `context/repo-mode.md` | 2026-06-02 |
| 全栈架构地图与部署形态 | `context/architecture.md` | 2026-06-02 |
| 模块↔子项目↔契约映射 | `context/module-map.md` | 2026-06-02 |
| 各子项目状态快照与子技能映射 | `context/subprojects.md` | 2026-05-20 |
| 契约模块索引与打包校验命令 | `contracts/openapi/README.md` | 2026-06-02 |
| 结论证据溯源 | `context/evidence-trace.md` | 2026-05-20 |

## 当前迭代
| 想了解什么 | 去哪看 | 最后更新 |
|---|---|---|
| 当前在做什么/各子项目派单状态 | `orchestration/task.md` | 2026-06-02 |
| 本迭代需求与分层需求文件 | `orchestration/2-requirements/current.md` | 2026-06-02 |
| 本迭代契约设计与能力摸底 | `orchestration/3-contract-design/current.md` | 2026-06-02 |
| 本迭代派发包与执行模式 | `orchestration/4-dispatch/current.md` | 2026-06-02 |
| 集成点检结论与证据等级 | `orchestration/5-integration-checkpoint/current.md` | 2026-06-02 |
| 未决疑点/冲突 | `orchestration/open-issues.md` | 2026-06-02 |

## 历史与归档
| 想了解什么 | 去哪看 |
|---|---|
| 历次迭代记录 | `docs/iterations/` |
| 历次点检记录 | `orchestration/checkpoints/checkpoint-YYYY-MM-DD.md` |
| 历史需求/契约设计/派发版本 | 各阶段 `history/` 子目录 |
| 历史任务看板 | `orchestration/task/` |
| 复盘台账 | `orchestration/retro/` |
| 输入文档与文本化映射 | 根 `docs/` 下的文本化产物索引 |
```

Put only "entry-level" pointers in it — never copy the content itself; the content lives in the files being pointed to. Keep the entries to roughly one screen; going too fine-grained defeats the very value of a "map".

A row MUST NOT point inside a sub-project's implementation. A sub-project's own knowledge is indexed by that sub-project's own single-stack sdd skill; at the root, one row per sub-project pointing at its own `<sub-project>/specs/task.md` (read-only progress source) is the deepest allowed granularity.

---

## 3. Maintenance mechanism (hung on hooks)

The knowledge map is derived navigation and refreshes as the project evolves (see the hook table in [specs-lifecycle.md](specs-lifecycle.md) §6):

- When `/sdd-init` (Mode B adopt, root cognition building) completes, **generate/rebuild** the knowledge map.
- When the `Iteration delivery done` hook fires, **update** the affected entries' locations and "last updated" dates.
- When the `Contract change` hook fires, **update** the contract-related rows so every reader lands on the current contract version, not a superseded one.
- When a context document is added/split, a new stage history appears, or a new sub-project is registered, **add one row** pointing to it.
- When the `docs change` hook fires (a binary input document was textualized), **add or refresh** the row pointing at the textualized index.

When the knowledge map is found inconsistent with the actual files (it points to a nonexistent file, or misses an important document), align the knowledge map first, following the "documents first" principle.

---

## 4. Why it is worth maintaining

A front/back-separated monorepo accumulates root docs + modular contracts + six orchestration stages + N sub-projects that each keep their own specs. Without one navigation desk, every session has to re-discover "which one should I read", and the main agent burns its context on exploration that belongs to nobody's remit.

It pays off twice over in this skill's own mechanisms:

- **Dispatch (handoff mode)**: the packet is written against the blindness premise — the executor opens a window at the sub-project root and cannot see the parent folder. The **restrained absolute-path downlink list** is assembled straight from the knowledge map, so a maintained map is the difference between a self-contained packet and a packet that strands its executor (see [dispatch-protocol.md](dispatch-protocol.md)).
- **Integration checkpoint**: locating "which document backs this conclusion" is a prerequisite for labeling it L1–L5 rather than emitting a bare PASS (see [evidence-gate-protocol.md](evidence-gate-protocol.md)).

At a tiny maintenance cost, the knowledge map buys the navigation ability of "anyone / any session walks in, reads one table, and knows where to look" — which is exactly what makes `orchestration/` quickly usable.
