# Development Progress Clarification Protocol

> Goal: after every completed stage, let the user clearly see what has been developed, what has not, what is blocked, and the next step — avoiding "lots of documents but unclear status". At the orchestration layer the unit of progress is the **sub-project**, not the function: the main agent reports what each sub-project has and has not delivered, never what it has written itself (red line 2).

## 1. Trigger points

| When | Action |
|---|---|
| Before a stage gate | draft the development progress table |
| After a stage gate passes | write into `orchestration/task.md` and show a summary in the reply |
| After dispatch packets land (handoff mode) | mark each sub-project 「已派单待外部开发」, suspend the iteration, and state explicitly that nothing is developed yet in this session |
| At every checkpoint | refresh each sub-project's row from its own SDD artifacts (read-only: its own `<sub-project>/specs/task.md` first, then its stage files and inbox state) |
| When a blocker is found | immediately update Blockers and the not-yet-developed content |
| When a reflow happens | mark the reflow reason and the affected sub-projects / contract modules |
| Before deliver | verify that all developed/not-developed content is consistent with the checkpoint evidence and its L1–L5 labels |

## 2. Standard table

(This table is written verbatim into the Chinese-language `orchestration/task.md`, so its content stays in Chinese.)

| 子项目/模块 | 状态 | 已开发内容 | 未开发内容 | 阻塞 | 下一步 |
|---|---|---|---|---|---|
| 子项目名/模块名 | 已完成/进行中/未开始/已派单待外部开发/已接单开发中/阻塞/回流中 | 产出物、契约操作、文档、点检证据 | 具体缺口 | 责任方与原因 | 下一步动作 |

Each row's 「已开发内容」 MUST cite a verifiable source (a sub-project deliverable, a contract operation at a stated version, or a checkpoint record). A row whose source is only "the user said so" is L1 and must be labeled as such.

## 3. Reply summary

When replying to the user, show at most 5 lines (verbatim, in Chinese):

```text
编排进度：
- 已完成：...
- 未完成：...
- 阻塞：...
- 下一步：...
- 已同步：orchestration/task.md
```

## 4. Chart suggestion

(Node labels stay in Chinese — the chart appears in Chinese-language documents.)

```mermaid
flowchart LR
    A[已开发] --> B[子项目产出物/契约操作/点检证据]
    C[未开发] --> D[缺口与原因]
    E[阻塞] --> F[待澄清/待外部开发/待联调]
    F --> G[下一步动作]
```

## 5. Prohibitions

- Do not write only 「已完成」 without listing the not-yet-developed content.
- Do not write a sub-project's 「编译通过」 as 「功能完成」; a build result is not a requirement result.
- Do not write 「已派单」 as 「已开发」 — in handoff mode, landing the packets means development has not started.
- Do not fill a sub-project's progress by guessing. Read its own SDD artifacts read-only; when they are missing or stale, mark 「⚠️ 待确认」 and ask the user.
- Do not state a progress conclusion whose semantics exceed its L1–L5 evidence level, and do not emit a bare PASS.
- Do not show lengthy details in the reply; the details belong in the stage files and the checkpoint record.
- Do not omit the `orchestration/task.md` sync status.
