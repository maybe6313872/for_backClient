# Collaboration protocol (interview + gating + docs handling + self-check entry)

> The orchestration-domain interview structure, gating ritual, and docs handling. The interview's structure/priority/skip conditions are frozen (inherited from framework F6); the questions are filled for the orchestration domain.

## 1. Interview first
- On entering each stage, gather the information that stage needs with 3–5 structured questions first.
- Before a reply is received, MUST NOT write the stage output.
- Keep questions focused on the current stage; MUST NOT ask ahead about the next stage.
- The user already gave documents (requirements/contract) → extract and turn them into confirmation questions first, and ask only about what is not covered.

**Priority**: multiple-choice > fill-in-the-blank-with-a-suggested-value > confirmation > open-ended. Compose each round into one questionnaire (3–5 questions), ordered "confirmation → multiple-choice → fill-in-the-blank → open-ended."

## 2. Orchestration-domain interview bank per stage (examples, adjust per project)
- **constitution**: repo mode — mono-repo or submodule-aggregate (confirm the `.gitmodules` detection)? each sub-project's tech stack/version? sub-project split — which are business sub-projects vs supporting sub-repos (registered only)? contract directory convention? sub-skill mapping? full-stack no-go zones?
- **requirements**: requirement goal and scope? which modules, each owned by frontend/backend/shared? acceptance criteria and boundary exceptions? evidence conventions?
- **contract-design**: endpoint list per module? auth and unauthenticated response? unified error/pagination/time-unit conventions? any breaking changes?
- **dispatch**: execution mode — handoff (default, only land packets) or agent-drive (the user explicitly wants sub-agents to execute now)? is each sub-project's sub-skill mapped (and, for agent-drive, triggerable)? dispatch slice boundaries? acceptance points? front/back prerequisite ordering? which parent files must be downlinked (absolute paths, restrained; contract modules mandatory)?
- **integration-checkpoint**: is the joint-debugging environment ready? key end-to-end paths? deliverable-verification conventions per sub-project?
- **deliver**: this iteration's deliverable scope? which ADRs to record? rollback/risk? do a retro?

## 3. Stage gating
- After a stage's output, show the Gate checklist with each item's status.
- Before the user explicitly says "pass/OK/confirm/next stage," MUST NOT enter the next stage.
- The user points out a problem → fix within the current stage and re-show the Gate.
- Announce stage switches explicitly: "the current stage X is complete, about to enter Y, please confirm."
- On each Gate pass, sync-update `orchestration/task.md`.

## 4. Docs handling (root docs/)
The root `docs/` holds the user's raw input documents (requirement specs, protocols, etc.). On finding a binary document:
| Raw format | Handling |
|---|---|
| `.xlsx`/`.xls` | convert to CSV under `docs/converted/<original-filename>/<sheet>.csv` |
| `.pdf` | call a pdf-reading skill or ask the user for a text version |
| `.docx` | call a docx skill or ask the user to save as md/txt |
| `.md`/`.txt`/`.csv`/`.json`/`.yaml` | read as-is |
| image | view directly |
Conversion artifacts go to `docs/converted/`, indexed into the `orchestration/README.md` reference-document index. Textualization capability follows capability detection + degradation.

**External input copies**: any `inputs/`-style copy directory follows the `sources.md` registry + freshness check in [specs-lifecycle.md](specs-lifecycle.md) §8 — check freshness before consuming a copy; stale → report and re-copy on approval.

## 5. Self-check entry
The pre-output chain-of-thought + post-output checklist are in [self-check.md](self-check.md).
