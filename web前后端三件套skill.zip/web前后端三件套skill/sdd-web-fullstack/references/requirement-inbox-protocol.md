# Requirement inbox protocol (`docs/requirements/`) — F33

> Every sdd-xx project keeps a **requirement inbox** at `docs/requirements/`. This skill sits at the orchestration layer, so it uses the mechanism **in both directions**: it is the **upstream dispatcher** that lands packets in each sub-project's inbox (`frontend/docs/requirements/`, `backend/docs/requirements/`), and it is itself a **recipient** — the repository root's own `docs/requirements/` takes top-level full-stack requirements dropped by a human. This file defines the inbox convention, the claim protocol, the acknowledgment signal, and the two-direction discipline. The inbox is a **frozen framework mechanism (F33)** — every sdd-xx inherits it.

---

## 1. Why an inbox

Requirements arrive from two directions: an upper layer that splits a bigger requirement and hands a project its slice, or a human dropping a requirement spec. Both need ① one standard, predictable landing place, and ② one unambiguous signal that the requirement was picked up. Without the convention, packets scatter across `docs/` and nobody can tell "received" from "ignored".

At this layer the same need appears twice over. Downward, the orchestrator must be able to tell whether the front-end and back-end sides have actually picked up their slices — in handoff mode nobody reports back in real time, and an emptied inbox is the only machine-readable acknowledgment available. Upward, the root inbox is where a full-stack requirement enters the repository before any splitting has happened.

## 2. The convention

- **Two locations, one convention**:
  - **Root inbox** — `docs/requirements/` at the repository root. Takes top-level full-stack requirements dropped by a human (and, in a larger hierarchy, packets from a still-higher orchestrator). Claimed by this skill.
  - **Sub-project inboxes** — `<sub-project>/docs/requirements/` (`frontend/docs/requirements/`, `backend/docs/requirements/`). **Written by this skill, claimed by the sub-project's own sdd skill.**
- **Naming**: dispatched packets are named `dispatch-YYYYMMDD-<slug>.md`; a human drop-in may be any requirement spec. Legacy requirement files directly under `docs/` stay readable; do not force-migrate.
- **The authoritative copy of a dispatch packet stays at the root**: `orchestration/4-dispatch/` holds the authoritative version (`current.md` plus `history/` per the lifecycle); what lands in `<sub-project>/docs/requirements/` is a **delivered copy**. When the sub-project clears its inbox, nothing is lost — the root still owns the record.
- **`docs/requirements/` is a RESERVED directory name (F37)**: within any repository governed by an sdd-xx skill, this exact path may carry **inbox semantics only** — a short-lived queue that gets cleared on claim. **Never** use it to store long-lived requirement specifications, product baselines, or anything else that must survive a claim. Long-lived requirement artifacts belong in `docs/product-specs/` (see structure.md). Rationale: the claim protocol below **clears** whatever sits in the inbox; a directory that means two things means the AI cannot tell which files are safe to clear. This holds for the root inbox and for every sub-project inbox alike.
- **Claim boundary**: "clear the inbox" removes **only** the claimed packet files inside that `docs/requirements/`. It never touches `docs/product-specs/`, `docs/iterations/`, `docs/decisions/`, or any other `docs/` subtree.
- **Created at init**: `/sdd-init` creates the root `docs/` tree (including `docs/requirements/`) alongside the `orchestration/` structure, and verifies that every registered sub-project has its own inbox directory, so both ends exist before anyone needs them.
- **One-way**: an inbox is an intake, never a status board. This skill never writes progress into the root inbox, and — the point that matters most here — **never writes progress into a sub-project's inbox either**. Progress on a dispatched slice is read from that sub-project's own `specs/task.md` (see checkpoint-protocol.md and task-kanban-protocol.md).

## 3. Entry-behavior hook

On every trigger, after loading preferences and reading `orchestration/README.md` + `orchestration/task.md`, **check both ends**:

1. **Root inbox** — non-empty means there is a pending top-level requirement: summarize it to the user in one line and confirm claiming it (a packet that names this repository is normally claimed directly; an ambiguous drop-in gets one clarifying question).
2. **Sub-project inboxes** — for every slice currently in flight, check whether the delivered packet is still sitting in `<sub-project>/docs/requirements/`. Still there → not yet picked up; emptied → picked up. Fold the result into the kanban state update described in §5. This is a read, not a write: never re-deliver, re-order or clean up a sub-project inbox on the way past.

## 4. Claim protocol for the root inbox (register → archive a copy → clear)

Claiming a requirement that arrived at the repository root is a three-step hard action:

1. **Register into the workbench**: append an `orchestration/task.md` row and create/extend the `orchestration/2-requirements/current.md` entry from the requirement content (then run the normal six-stage orchestration from the appropriate stage: constitution → requirements → contract-design → dispatch → integration-checkpoint → deliver).
2. **Archive a copy inside this repository**: preserve the requirement content under `orchestration/2-requirements/inputs/`, so clearing the inbox loses nothing even when no upper-layer authoritative copy exists.
3. **Clear the claimed item from the root inbox.** An emptied inbox is the **acknowledgment signal** to whoever dropped it: "requirement received, orchestration started." It is a **pickup signal, NOT a completion signal** — completion is still judged by gates and evidence.

❌ Anti-patterns: starting to split or dispatch from an inbox file without registering it into the workbench; clearing the inbox without archiving a local copy under `orchestration/2-requirements/inputs/`; leaving the claimed packet in the inbox "for reference" (whoever dropped it will read that as not-yet-received); writing status notes into the inbox.

## 5. Outbound direction — delivering packets and reading the acknowledgment

This is the part specific to an orchestration skill.

- **Delivery**: at the dispatch stage, `/sdd-dispatch` writes the authoritative packet to `orchestration/4-dispatch/`, then lands a copy in each target `<sub-project>/docs/requirements/`. Delivery happens **after** the dispatch gate clears, never during planning.
- **Acknowledgment**: the sub-project's own sdd skill runs its claim protocol (register → archive locally → clear). In **handoff** mode the clearing is done by the sub-project side, in its own session, and the orchestrator learns about it only by looking. In **agent-drive** mode the driven sub-agent runs the same protocol through the sub-project's skill — the orchestrator still does not clear another project's inbox by hand.
- **State transition**: an emptied sub-project inbox moves that slice's `orchestration/task.md` state from 「已派单待外部开发」 to 「已接单开发中」. Nothing more may be inferred: pickup is not progress, and progress is not completion.
- **Never write progress back**: the orchestrator does not annotate the delivered packet, does not add a status line to the sub-project inbox, and does not "helpfully" tidy it. Progress comes from the sub-project's own `specs/task.md` and its graded evidence, read at `/sdd-checkpoint` time (checkpoint-protocol.md).
- **Re-dispatch**: when a slice changes, do not edit the delivered copy in place. Archive the authoritative packet under `orchestration/4-dispatch/history/`, write the new authoritative version, and deliver a new packet file. If the previous packet is still unclaimed in the sub-project inbox, say so explicitly in the report so the receiving side knows which one supersedes which.

## 6. Working with dispatch packets (as the author)

A dispatch packet is written against the assumption that the receiving session **cannot see the orchestration root's working state**. It carries the requirement slice, acceptance points, integration conventions, and a restrained list of **absolute paths** to root files that project should read or co-maintain — the contract above all (`contracts/openapi/openapi.yaml` and the relevant fragments under `paths/` and `components/schemas/`). Mark each downlinked path as read-only reference or co-maintained. On the receiving side those paths are treated the same way: a broken/unreachable path is marked `⚠️ 待确认` into `open-issues.md` and asked about — never guessed.

Symmetrically, when *this* repository receives a packet at its root inbox from a higher layer, apply the same reading: downlinked paths are references, an unreachable one goes to `orchestration/open-issues.md` as `⚠️ 待确认`, and the missing content is never invented.
