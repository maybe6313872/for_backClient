# Sub-agent dispatch protocol (dispatch)

> **Positioning**: the main agent cuts the full-stack requirement + contract into frontend/backend **dispatch packets**, assigning sub-skill + working root + acceptance points. This file defines the **two execution modes (handoff default / agent-drive)**, the packet format and landing path, working-root isolation, the sub-skill mapping, and mode-aware sub-skill verification. Core red lines: **the main agent only orchestrates, never codes (red line 2); a missing sub-skill blocks per the mode-aware rules (red line 3); honor the declared execution mode — handoff is the default (red line 8).**

---

## 1. What dispatch is

The main agent is the "project conductor," not a "full-stack programmer." It cuts a full-stack requirement into work units (dispatch packets) that each sub-project can take on independently. The one that actually writes the frontend/backend code is always a sub-project session driven by that sub-project's own single-stack sdd skill — never the main agent.

```
main agent (root)
  ├─ finalize the contract (contracts/openapi)
  ├─ generate the frontend packet → land into frontend/docs/requirements/
  └─ generate the backend packet  → land into backend/docs/requirements/
        ↓ then, by declared execution mode:
  handoff (DEFAULT): STOP here — the iteration suspends; development happens
                     later, in external sessions opened inside each sub-project,
                     driven by that sub-project's own sdd skill
  agent-drive:       spawn sub-agents now, one per sub-project, each locked to
                     its own working root, driven by its own sdd skill
```

---

## 2. Execution modes: handoff (default) vs agent-drive

| | **handoff（派单交接）— DEFAULT** | **agent-drive（子代理直驱）** |
|---|---|---|
| After packets land | Nothing more. The iteration **suspends** as 「已派单待外部开发」 | The main agent spawns sub-agents immediately; each executes inside its own working root |
| Who develops | A later session opened at the sub-project root (a human-driven session or a fresh agent) picks the packet up from `docs/requirements/` and runs that sub-project's sdd skill (`/sdd-iterate`) on it | Sub-agents spawned by the main agent in this session |
| Sub-skill verification | **Declaration check** (see §4): mapping table names it + packet carries it; triggerability in the current environment NOT required | **Strict check** (see §4): must be triggerable in the current environment; missing = block |
| integration-checkpoint | Deferred: resumes when the user reports back ("backend is done") or when a later root session finds suspended dispatches | Continues in-session after sub-agents deliver |
| When to use | Always, unless the user explicitly asks for agent-drive. Mandatory fit: weaker / locally-deployed models that cannot reliably control sub-agents or hold long multi-project context | Only on the user's **explicit request** (e.g. 「让子代理当场做」「直驱」「派子代理现在就执行」), typically with a strong model |

**Mode selection rules (frozen)**:
1. **Default is handoff.** No explicit signal from the user → handoff. Never silently choose agent-drive.
2. The user explicitly asks for immediate sub-agent execution → agent-drive; record the declared mode in `4-dispatch/current.md`, every packet, `task.md`, and the checkpoint table.
3. The declared mode binds the whole dispatch round; switching modes mid-round requires the user's explicit approval and a note in `task.md`.

**Why handoff is the default**: after landing packets, a main agent that "just continues" into a sub-project floods its own context with single-stack implementation detail — capability degrades, the goal drifts, and the orchestration view is lost. Handoff hard-stops that failure: the main agent's job ends at "packets landed + board updated." This keeps the skill usable by weaker / locally-deployed models, and costs nothing with strong ones.

**Anti-patterns in handoff mode (each one is an error)**:
- ❌ Spawning sub-agents anyway "since we're already here."
- ❌ Entering `frontend/`/`backend/` to develop, scaffold, or "pre-fix" anything after the packets land.
- ❌ Bulk-reading a sub-project's **source code** (`src/`, `services/`, `models.py`…) "to enrich the packet" — the packet is built from the requirement + contract + constitution mapping + the sub-project's **docs-layer conventions**. **Carve-out (required, not forbidden)**: reading a sub-project's `specs/context/modules.md` and equivalent module-map/constraint documents is the mandatory §5a boundary intake — docs-layer reading is bounded and cheap; source dives are the context-blowing failure this mode prevents.
- ❌ Treating "packets landed" as "requirement done" — landing a packet is orchestration progress, not delivery; semantics stay bounded by evidence levels.

**Scope guard (both modes)**: dispatch covers **business sub-projects** from the constitution registry only; supporting sub-repos (toolchain/script/agent repos) are never dispatched unless the user explicitly names one into this iteration's scope (see [repo-management-protocol.md](repo-management-protocol.md) §2). In submodule-aggregate mode the main agent additionally never runs git inside a sub-repo (§3 there).

---

## 3. Sub-skill mapping (chosen by sub-project tech stack)

| Sub-project / tech stack | Corresponding sub-skill |
|---|---|
| Browser-side Web frontend (React/Vue/Svelte/Next/Nuxt…) | `sdd-web-frontend` |
| Java backend (Spring, etc.) | `sdd-web-backend-java` |
| Python backend (FastAPI/Django/Flask, etc.) | `sdd-web-backend-python` |
| Other backend/service (as actual) | the corresponding `sdd-web-backend-<stack>` |

> The mapping table is frozen into `orchestration/1-constitution/current.md` at the constitution stage and maintained as the project actually evolves.

---

## 4. Sub-skill verification (mode-aware; red line 3)

**Before** dispatching a sub-project, verify its corresponding sub-skill **per the declared execution mode**:

**handoff (default) — declaration check**:
1. The constitution mapping table must name a concrete sub-skill for the target sub-project, and the packet's 「使用子 skill」 field must carry it.
2. Whether that sub-skill is triggerable in the *current* environment is irrelevant (execution happens elsewhere); do **not** block on it — just note the observed availability in the packet and the checkpoint table.
3. **No mapped sub-skill exists at all** (nobody could ever pick the packet up) → still a blocker: report to the user, suggest building it with the mother skill's `/sdd-new`, register it in `orchestration/open-issues.md`, and stop.

**agent-drive — strict check**:
1. Verify the sub-skill exists and is triggerable in the current environment.
2. Missing → **stop at the dispatch stage immediately** and report the blocker to the user: which sub-skill is missing, which sub-project's dispatches it blocks, and the suggestion to build it first with the mother skill `sdd-skill-creator`'s `/sdd-new`. Register the blocker in `orchestration/open-issues.md` and the checkpoint table, keeping the status blocked until the sub-skill is ready.

❌ **Never allowed in either mode**: because a sub-skill is missing, having the main agent personally enter `frontend/`/`backend/` to write that sub-project's code (violating red line 2), or "degrading" the dispatch into a rough version by the main agent. Missing means blocked; report it to the user honestly.

---

## 5a. Pre-dispatch boundary intake (mandatory hard action)

Before cutting packets, for **each target business sub-project** the main agent must read, **read-only and docs-layer only**:
1. The sub-project's `specs/context/modules.md` (or its equivalent module map / architecture-constraint document).
2. Any boundary conventions found there — e.g. "a new workstation gets its own route prefix," "do not hardcode per-station logic into existing flows," "reuse existing service X" — are **explicitly copied into the packet's 「建议实现边界」(suggested implementation boundary) section**, so the executor sees them without re-discovering.
3. The constitution maintains a **sub-project convention index** (per business sub-project: the path of its module-map/constraint files), so intake is a lookup, not an exploratory dive. Missing/unreadable convention file → note it in the packet and `open-issues.md`, do not guess.

Scope guard: intake reads `specs/`-layer documents only — it never extends into `src/` source dives (see the handoff anti-patterns in §2).

## 5b. Specs-first split (ORCH-G1/ORCH-G2/G5)

> `ORCH-G1` (specs-before-code dispatch ordering) and `ORCH-G2` (specs-phase business-code freeze) are this skill's own orchestration-class gates; `G5` (specs-first at every grain) is the frozen universal gate. All three are defined in [gate-and-stages.md](gate-and-stages.md). A packet quoting them must use these exact IDs — a bare `G1`/`G2` in a packet means the universal stage-boundary and archiving gates and will be resolved that way by the executor's own skill.

**agent-drive mode (ORCH-G1+ORCH-G2, hard gate)**: a sub-project's work is dispatched as **two separate sub-agent calls**, never one:
1. **Specs dispatch** — instruction must contain the hard constraint: *"this step writes only `<sub-project>/specs/` (and its docs); touching any business code file is forbidden."* (ORCH-G2)
2. **Code dispatch** — may only be issued **after the user has confirmed the specs output**. The dispatch instruction states "the user has confirmed the specs" explicitly. (ORCH-G1)
❌ One combined "implement + code + sync specs" call — including on retries after a failed call — is an error.

**handoff mode (written into the packet)**: the packet's pickup instructions must require the executor to follow its own sdd skill's six stages — specs first, code only after gates — and state G5: **any fix or small increment, no matter how small, first registers in the sub-project's `specs/` (task.md row, spec entry, context module/feature mapping updates), then touches business code.** Fix-scale work is not exempt from specs-first.

## 5c. Cross-boundary visibility: self-containment + restrained parent-file downlink

**The blindness premise (write every packet against it)**: in handoff mode the developer typically opens an **independent AI-coding-tool window at the sub-project root**; that tool's working root is the sub-project — it **cannot see the parent full-stack folder or its documents at all**. Anything the executor must know either lives inside the packet text, or is handed down as an explicit path.

**Downlink list (「上级文件下放清单」, a required packet section)**: a **restrained allowlist** of parent files the executor should read or co-maintain, each entry carrying:
- the **absolute path** (relative paths pointing above the sub-project root are useless in the executor's window);
- the purpose (why the executor needs it);
- the access mode: `read-only`（只读参考）or `co-maintain`（应参与维护）.

**Mandatory entries**: the depended contract module files under `contracts/openapi/` @ the pinned version (interface docs MUST be downlinked with an explanation of what to consume); the sub-project's layered requirement file `docs/requirements/<迭代>/<sub>-requirements.md` when it exists. **Restraint rules**: only files the executor genuinely needs; ❌ downlinking whole parent directories or "the root docs for context"; ❌ paths whose content is already fully quoted in the packet (quote small things instead of linking them); keep the list to a handful of entries.

## 5d. Pickup acknowledgment (inbox-clear protocol)

The sub-project's `docs/requirements/` is a **one-way inbox** with a clear-to-acknowledge convention:
1. The root keeps the **authoritative packet copy** in `orchestration/4-dispatch/` (current.md registration + the packet content archived per specs-lifecycle) — the inbox copy is expendable.
2. When the sub-project's AI tool (per its own sdd skill) **accepts** the requirement, it clears the packet from the inbox and proceeds through its specs workflow.
3. The main agent **observes the inbox** (read-only) to learn acceptance: packet still present → not yet picked up, state stays 「已派单待外部开发」; packet gone (and/or the sub-project's `specs/task.md` shows the new task) → transition the state to 「已接单开发中」 in `task.md` and the checkpoint table.
4. An emptied inbox is an acknowledgment signal, **not** a completion signal — completion is judged at checkpoint against the packet's acceptance points (root copy).

## 5. Dispatch packet format and landing path

Each dispatch packet is a "work order" issued to a sub-project; template in `assets/templates/dispatch-packet.md`.

**Landing path (semantic convention)**: `<sub-project>/docs/requirements/dispatch-YYYYMMDD-<slug>.md` — the sub-project's **requirement inbox**, where a later session (or a spawned sub-agent) picks the work up. Legacy packets sitting directly under `<sub-project>/docs/` remain recognized read-only; do not force-migrate them.

Required fields:

| Field | Description |
|---|---|
| Dispatch id | `DISP-<iteration>-<sub-project>-<seq>` |
| **Execution mode** | `handoff`（派单交接）or `agent-drive`（子代理直驱） |
| Target sub-project | `frontend` / `backend` / … |
| Working root | the **absolute/relative path of the sub-project directory** (isolation-critical, see §6) |
| Sub-skill used | the corresponding `sdd-web-*` (from the constitution mapping table) |
| Requirement slice | the requirement this sub-project does this time (a subset cut from the full-stack requirement) |
| Dependent contract | the version number in `contracts/openapi/` + the involved contract module files |
| Acceptance points | acceptance criteria (mapped to the full-stack requirement's acceptance points), with evidence requirements |
| Integration conventions | the integration points with the other side (endpoints, errors, auth, time conventions) |
| Suggested implementation boundary | boundary constraints extracted from the sub-project's `specs/context/modules.md` per §5a (route-prefix rules, no-hardcoding rules, services to reuse…) |
| Parent-file downlink list | restrained allowlist of parent files per §5c: absolute path + purpose + read-only/co-maintain; contract modules @ version are mandatory entries |
| Specs-first requirements | ORCH-G1/ORCH-G2/G5 statements per §5b (two-phase specs→code; specs step forbids business-code edits; fixes also specs-first) |
| Blocking/prerequisite | which prerequisites it depends on (e.g. "needs the backend to implement /auth/login first") |
| Repo context (submodule-aggregate mode only) | the sub-repo's remote URL + working branch; reminders: `git submodule update` leaves detached HEAD — check out / create a branch before developing; commit & push **in the sub-repo**; the root gitlink pointer is reclaimed at deliver (see [repo-management-protocol.md](repo-management-protocol.md)) |
| Pickup instructions | how the executing side proceeds: open a session at the sub-project root, let that sub-project's own sdd skill take over with this packet as the requirement input (`/sdd-iterate`), report back for checkpointing |

**The packet must be self-contained**: the executing session has none of this conversation's context **and cannot see the parent folder at all** (§5c blindness premise). The requirement slice, contract version, acceptance points, and integration conventions must be fully readable stand-alone; everything else the executor needs goes through the §5c downlink list as absolute paths.

---

## 6. Working-root isolation (keep the executor's focus narrow)

**Core**: whoever executes a packet — a later external session (handoff) or a spawned sub-agent (agent-drive) — its **working root is locked to its own subfolder** (`frontend/` or `backend/`), not the project root.

- Inside its working root, the executor — via the corresponding single-stack sdd skill — maintains that sub-project's `specs/`, `docs/`, `task.md`. That is the sub-skill's job; the main agent does not touch its interior.
- The main agent reads a sub-project's deliverables, contract compliance, and progress **read-only** for checkpointing; it **does not edit its source implementation** (red line 2).
- A dispatch packet is a **one-way work order** from main agent → executor, landed into the sub-project's `docs/requirements/`; the executor's output and reports are aggregated back to the main agent through the checkpoint stage.

**Why isolate**: so the frontend executor focuses only on the frontend and the backend executor only on the backend, each with focused context and no cross-contamination; and so the main agent keeps a global view without sinking into one stack's implementation details.

---

## 7. Two-phase dispatch (matching the single-stack skill's two-phase tasks)

- **Phase ① plan the dispatch**: based on contract-design + requirements, cut a draft dispatch packet for each sub-project (requirement slice, contract dependency, acceptance points). **🚦Gate ①**: show the dispatch list + **the declared execution mode (handoff by default; agent-drive only if the user explicitly asked)** + the mode-aware sub-skill verification result, and await user approval; resolve any blocker first.
- **Phase ② land the dispatch**: after approval, write the packets into each sub-project's `docs/requirements/`, register them in `task.md` and the checkpoint table. **🚦Gate ②, by mode**:
  - **handoff**: mark each sub-project 「已派单待外部开发」, show the landing result, and **suspend the iteration** — do not enter integration-checkpoint until the user reports back or a later root session resumes it.
  - **agent-drive**: mark each sub-project "dispatched, awaiting sub-agent execution," show the landing result, and await user confirmation before entering integration-checkpoint.

> Note: in this skill "landing the dispatch" means **putting the work order in place**, not writing code. The coding happens inside each sub-project's working root, driven by its own sdd skill — later in external sessions (handoff) or now by spawned sub-agents (agent-drive).

---

## 8. Handoff to checkpointing

- **agent-drive**: after dispatch, sub-agents progress inside their own working roots; the main agent periodically checkpoints each sub-project's progress and deliverables via `/sdd-checkpoint` (see [checkpoint-protocol.md](checkpoint-protocol.md)).
- **handoff**: the iteration sits suspended as 「已派单待外部开发」. Checkpointing resumes when (a) the user reports a sub-project's progress or completion, (b) a later session at the root reads `task.md` and finds suspended dispatches, or (c) the inbox is observed cleared (§5d acknowledgment → 「已接单开发中」) — then track progress via the sub-project's own SDD artifacts (checkpoint-protocol §3b) and verify deliverables against the packet's acceptance points (root copy).

The "acceptance points" in the dispatch packet are the verification basis at checkpoint time in both modes.
