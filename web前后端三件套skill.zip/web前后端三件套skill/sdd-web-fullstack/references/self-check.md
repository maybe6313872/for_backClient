# Unified self-check protocol (pre-output chain-of-thought + post-output checklist)

> Shared by both modes. Run the "chain-of-thought" before writing a stage output, and the "checklist" item by item before handing to the user.

## Pre-output chain-of-thought
```
## 🧠 Pre-start framing
- Current stage/mode: {stage name, or which step of Mode B}
- Input basis: user interview points / orchestration README / task.md / contract state / sub-project checkpoint table / previous stage output
- This output's goal: {one line}
- Content boundary: this stage allows {…}; this stage forbids {…}
- Risks/uncertainties: {list, mark 待确认; if none, "none"}
```

## Post-output checklist
1. **Overreach check**: compare each paragraph against the current stage's content boundary. requirements wrote contract details → move to contract-design; contract-design wrote dispatch → move to dispatch.
2. **Isolation red-line check**: does this output contain "the main agent writing sub-project business code directly"? If so → stop and delete immediately, switch to dispatch (red line 2).
3. **Missing-sub-skill block check**: has dispatch-related output verified sub-skills **per the declared execution mode** (agent-drive: triggerable here; handoff: mapping declared)? Was a blocker reported rather than done in its place (red line 3)?
3a. **Repo-mode & scope check**: does the output respect the declared repo mode (mono-repo / submodule-aggregate)? Were only **business sub-projects** from the constitution registry dispatched/checkpointed (supporting sub-repos untouched unless explicitly promoted)? In submodule-aggregate mode: no git run inside a sub-repo, one-way pointer flow respected, pointer reclaim left as a checklist for the user unless explicitly authorized?
3b. **Execution-mode check (red line 8)**: was the mode explicitly declared, defaulting to handoff? In handoff mode: no sub-agents spawned, no sub-project entered, no sub-project source bulk-read, and the iteration suspended as 「已派单待外部开发」 after the packets landed? Agent-drive chosen only on the user's explicit request?
3c. **Specs-first & pairing check (ORCH-G1 · ORCH-G2 · ORCH-G3 · ORCH-G4 · G5 · G6 — enumerated, never written as a range)**: specs and code dispatched as two calls in agent-drive, code only after user-confirmed specs (**ORCH-G1**), with the specs call carrying the business-code freeze wording (**ORCH-G2**)? packets carry 「建议实现边界」 from the sub-project module map and the specs-first requirements? at checkpoint: the `git status` overreach check (**ORCH-G3**) run, blockers reported and dispositions asked (no auto-revert)? the specs↔code pairing check (**G5**, grain-independent — fixes included) run? the claim↔git pairing check (**G6**) run, so nothing claimed-but-absent is graded and a cleared inbox is read as acknowledgment rather than completion? layered requirement files (**ORCH-G4**) landed at requirements end and verified per layer at integration-checkpoint?

> **Why enumerated**: `ORCH-*` and bare `G*` are two different namespaces ([gate-and-stages.md](gate-and-stages.md)). A range like "G1–G6" spans both and silently re-reads this skill's domain gates as universal ones; it also hides that **G5 and G6 are separate checks that must both run**. List the IDs.
3d. **Input-freshness check**: before consuming any `inputs/` copy, was it verified against its `sources.md` registration (stale → reported, re-copied on approval)?
3e. **Cross-boundary packet check**: is each packet readable by an executor that **cannot see the parent folder** (self-contained; downlink list uses absolute paths, restrained, contract modules included)? Does the pickup section state the clear-to-acknowledge convention? Is progress being read from the sub-project's own SDD artifacts (`specs/task.md` first) rather than guessed or over-asked?
4. **Contract-consistency check**: does interface-related output treat `contracts/openapi/` as the single source of truth, with no invention on either side (red line 4)? Was a contract change two-way notified?
5. **Diagram-text consistency**: diagram node names/arrows match the prose; ≤15 nodes.
6. **Hallucination check**: do technical details (endpoints, contract fields, sub-project internal behavior) have a clear source (contract / sub-agent deliverable / user confirmation)? Without a source, mark 待确认.
7. **Reference check**: any contradiction with known info in `orchestration/README.md` or the checkpoint table?
8. **Alignment check**: did it answer each of the user's interview replies? Did anything the user said "don't do" slip in?
9. **Progress check**: did it list each sub-project's done/in-progress/blocked/next and sync task.md and the checkpoint table? No exaggeration (build passed ≠ requirement done).
10. **Retro self-check**: before opening a new iteration, did it pass the entry gate (read task.md / archive first / write the new iteration header / check the retro ledger)? Before delivery, did it pass the exit gate (task.md archived / iteration record / open-issues closed out / retro judgment)?
11. **Preference-guard self-check**: is expression tuned per preferences (default 「专业可靠」if empty)? Was no gate/evidence/interview/archiving/isolation discipline weakened to please a preference? Were no skill files changed other than preferences/, orchestration/retro/, and this skill's evolution/?

## Reflow protocol
On finding a needed reflow (fix requirements/contract-design): stop the current output → state the reason → await confirmation → reflow and fix → re-run the target stage's Gate → continue at the original stage after it passes.
