# Gate vocabulary and stage gates (orchestration class)

> **What this file is**: the gate **vocabulary** of this skill — the frozen universal gate segment that every sdd-xx shares byte for byte, the numbering namespace that keeps it shareable across skills, and this skill's own `ORCH-` domain gates. **What it is not**: the stage definitions. This skill is an orchestration-class skill (F34); its six stages — `constitution → requirements → contract-design → dispatch → integration-checkpoint → deliver` — with their duties, interview questions, per-stage Gate checklists and recommended diagrams live in [orchestration-stages.md](orchestration-stages.md). Read this file to resolve a gate **ID**; read that one to run a **stage**.

---

## Gate execution flow (common to every stage)

Every stage ends the same way: run the post-output checklist ([self-check.md](self-check.md)) → show the stage's Gate checklist → **stop and wait for the user's explicit approval** (red line 1) → only then enter the next stage. A gate is never self-released, never batched with the next stage's output, and never marked passed on the strength of "it looks fine".

---

## Gate numbering namespace (frozen)

Gate IDs are a **shared vocabulary across every sdd-xx**: an orchestrator writes a gate ID into a dispatch packet and the executor — running a different skill, in a different window, with no shared context — must resolve it to the same obligation. That only works if the numbering is governed. Two frozen rules:

1. **The bare `G1`–`Gn` segment is reserved for cross-skill universal gates.** Every sdd-xx, whatever its domain or class, defines these identically, byte for byte. A skill may not add to, remove from, renumber, or locally reinterpret this segment. Changing it is a mother-skill action (`/sdd-distill` → `/sdd-absorb` → `/sdd-evolve`), never a local edit.
2. **A domain-specific or class-specific gate MUST take its own prefix and MUST NOT consume a `G` number.** A new domain registers its prefix in the table below when its skill is created. ❌ Writing a domain gate as `G7` is an error. ❌ Reusing a `G` number with a different local meaning is an error.

> **Why**: `G6` once meant "code↔specs pairing" in the orchestrator and "claim↔git pairing" in the executor. A packet saying "comply with G6" made the two sides verify different things, and the union of what neither checked shipped.

> **Scope of this namespace**: it governs **gate IDs only**. Question numbers in an interview/profile question bank (`G1 Which converter? …`) are ordinals of a questionnaire, not gates; they live outside this namespace and are neither renumbered nor prefixed by this rule.

### The universal segment (frozen — identical in every sdd-xx)

| ID | Gate | Obligation | Where it is enforced |
|---|---|---|---|
| G1 | Stage responsibility boundary | Content belongs to exactly one stage; the allowed/forbidden table of the current stage governs. Out-of-stage content flows back (spec/design) instead of being written here. | Every stage gate (F19) |
| G2 | Archiving discipline | Nothing under `specs/` is overwritten or deleted; the previous iteration is archived first (`task.md` → `specs/task/YYYY-MM-DD-说明.md`; stage → `<stage>/history/YYYY-MM-DD-说明.md`), then written. | Iteration entry gate + every write (F4, red line 3) |
| G3 | Evidence grading | Every test/run conclusion carries an L1–L5 level bound to a reproducible asset; delivery semantics never exceed the highest level reached in test. | test gate + deliver gate (F7) |
| G4 | Progress transparency | Before each gate, output the developed / not-developed / blocked / next-step clarification table and sync `task.md`; "it builds" is never reported as "it works". | Every stage gate (F16) |
| G5 | specs-first at every grain | Any code fix or small increment, however small, registers in `specs/` (task.md row + spec entry + context mapping) **before** business code is touched, and every business-code change of this iteration has a paired specs change. Fix-scale work is not exempt. | tasks + deliver gate (F2/F5) |
| G6 | Claim↔git pairing | Before delivery, verify against `git status` that the claimed artifacts and test evidence match the actual working tree — no "claimed changed but no change present", no unregistered incidental changes; the `docs/requirements/` inbox is cleared per claim (acknowledgment, not completion). | deliver gate (F5/F33) |

> G1–G4 give IDs to mechanisms that were already frozen (F19 / F4 / F7 / F16); they introduce **no new obligation**. G5 and G6 keep their existing meanings and are here separated for the first time: G5 is "specs paired with code", G6 is "claims paired with the working tree" — two different checks that must both run.

**Class binding of the universal segment (this skill only — the table above is never edited)**: the table is written in the vocabulary of a single-stack skill, whose workbench root is `specs/`. This skill is orchestration-class (F34), so the **same obligations** resolve against the orchestration workbench:

| Universal gate | How it resolves at the orchestration root | How it resolves inside a sub-project |
|---|---|---|
| G1 | the six stages of [orchestration-stages.md](orchestration-stages.md); out-of-stage content reflows to requirements / contract-design | the executor's own sdd skill enforces it inside its own stages |
| G2 | archive root is **`orchestration/task/`**, not `specs/task/`; stage workbenches archive to `orchestration/<stage>/history/`; contracts archive by version ([specs-lifecycle.md](specs-lifecycle.md), [contract-first-protocol.md](contract-first-protocol.md) §4) | the sub-project archives under its own `specs/` |
| G3 | every integration-checkpoint conclusion carries an L1–L5 label; the orchestrator **aggregates** each sub-project's reported L with **no conversion layer** ([evidence-gate-protocol.md](evidence-gate-protocol.md) §1) | the sub-project grades its own evidence on the same frozen ladder |
| G4 | the developed / not-developed / blocked / next table before every gate, synced to `orchestration/task.md` and the checkpoint table ([development-progress-protocol.md](development-progress-protocol.md)) | the sub-project's own `specs/task.md` is the primary progress signal |
| G5 | verified **at integration-checkpoint, read-only**: each sub-project's business-code changes must pair with `specs/` changes ([checkpoint-protocol.md](checkpoint-protocol.md) §3a) | the executor does specs before code, fixes included |
| G6 | verified **at deliver**: what this orchestration claims to have landed matches the actual working tree; the root `docs/requirements/` inbox is cleared per claim ([checkpoint-protocol.md](checkpoint-protocol.md) §3a, [requirement-inbox-protocol.md](requirement-inbox-protocol.md)) | the executor runs its own G6 before reporting back |

> **G5 vs G6 must not be collapsed.** They fail in different ways: G5 catches "code landed, specs never written"; G6 catches "the report says it landed, `git status` says nothing changed". Running only one leaves the other class of defect unshipped-but-unseen. Both run — G5 at integration-checkpoint, G6 at deliver.

### Registered domain/class prefixes

| Prefix | Owner | Scope |
|---|---|---|
| `ORCH-*` | orchestration-class skills (F34) | root-side dispatch/checkpoint gates; never appear in a single-stack skill |
| `FE-*` | `sdd-web-frontend` | web front-end domain gates |
| `BE-*` | `sdd-web-backend-python` | web back-end domain gates |

This skill's own domain gates are defined in this file under its registered prefix and never consume a `G` number.

---

## This skill's domain gates (`ORCH-` prefix)

These are **orchestration-class obligations**: they exist because a root agent dispatches work it must not perform itself. A single-stack skill has no equivalent, which is exactly why they may not consume a `G` number — an executor receiving `ORCH-G2` in a packet must be able to tell "this is the orchestrator's gate, not one of mine".

| ID | Gate | Obligation | Where it is enforced |
|---|---|---|---|
| `ORCH-G1` | Specs-before-code dispatch ordering | A sub-project's work is dispatched **specs first, code second**. In agent-drive mode the code dispatch may only be issued **after the user has confirmed the specs output**, and the dispatch instruction says so explicitly. ❌ One combined "implement + code + sync specs" call — including on retries — is an error. | dispatch gate ([dispatch-protocol.md](dispatch-protocol.md) §5b) |
| `ORCH-G2` | Specs-phase business-code freeze | The specs dispatch instruction must carry the hard constraint *"this step writes only `<sub-project>/specs/` (and its docs); touching any business code file is forbidden."* The freeze is a property of the **instruction text**, not a hope about the executor's behaviour. | dispatch gate ([dispatch-protocol.md](dispatch-protocol.md) §5b) |
| `ORCH-G3` | Overreach verification | After an executor delivers, run `git status` (read-only) in the sub-project's working root. Uncommitted **business-code** changes outside the packet's scope = overreach → mark 越界待处置, block the checkpoint, report, and **ask the user for the disposition**. The main agent **never auto-reverts** on its own judgment. | integration-checkpoint gate ([checkpoint-protocol.md](checkpoint-protocol.md) §3a) |
| `ORCH-G4` | Layered requirement sediment | Besides the overall requirement, land **per-sub-project layered requirement files** under `docs/requirements/<迭代>/`, forming the chain **overall requirement → layered requirements → dispatch slices**, and verify each sub-project's deliverables against its own layer at integration-checkpoint. Traceability never jumps from the packet straight to the root requirement. | requirements gate + integration-checkpoint gate ([orchestration-stages.md](orchestration-stages.md) §2, §5) |

> **Renumbering note (F-06)**: `ORCH-G1`–`ORCH-G4` previously occupied the bare numbers `G1`–`G4` in this skill with these same meanings. Only the IDs changed; **no obligation was added, removed or weakened**. The old bare-number readings are superseded — a `G1` written after this change means the universal "stage responsibility boundary", never "specs first".

---

## Stage gates

Per-stage Gate checklists (constitution / requirements / contract-design / dispatch / integration-checkpoint / deliver), together with each stage's duty, minimal artifact, interview questions and recommended diagrams, are defined in **[orchestration-stages.md](orchestration-stages.md)**. The iteration entry gate and exit gate, and the archive-first discipline they enforce, are in **[specs-lifecycle.md](specs-lifecycle.md)**.

## Flow-back

On finding at any stage that an earlier stage was wrong (requirements missed a case, the contract cannot express something, a dispatch slice is uncuttable): **stop the current output → state the reason → await the user's confirmation → reflow and fix the earlier stage → re-run that stage's Gate → resume at the original stage.** Never patch an upstream defect downstream and never reflow silently. Full protocol: [self-check.md](self-check.md) and [reflow-evolution.md](reflow-evolution.md).
