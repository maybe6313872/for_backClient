# Standard Directory Structure

> The standard structure and naming conventions for `orchestration/`, `contracts/` and `docs/` at the **monorepo root**. Core: each stage has `current.md` + a `history/` archive; `task.md` archives into `orchestration/task/`; textualized `docs/` artifacts go into `docs/converted/`. Archiving discipline is in specs-lifecycle.md — **direct overwriting/deletion is forbidden**.
>
> **Tier scope (red line 2)**: everything described here is the **root orchestration workbench**. A sub-project's own `specs/` layout is governed by that sub-project's single-stack sdd skill (`sdd-web-frontend` / `sdd-web-backend-java` / `sdd-web-backend-python`); the main agent reads it read-only and never restructures it.

## orchestration/ standard structure
```
orchestration/
  README.md                    ← root orchestration cognition document (shared by both modes; the information base for all stages)
  task.md                      ← global task command deck (must-read as step 1 of every session; carries a date header)
  task/                        ← archive directory for task.md history
    YYYY-MM-DD-<说明>.md
  open-issues.md               ← global governance inbox: doubts/conflicts/pending verification (purity rules; template: assets/templates/open-issues.md)
  retro/                       ← retrospectives and experience distillation (written by /sdd-retro; ledger + per-topic files)
    README.md                  ←   retro ledger/index
    retro-YYYY-MM-DD-<主题>.md ←   one entry per topic
  checkpoints/                 ← checkpoint tables and past checkpoint records (one file per round)
    checkpoint-YYYY-MM-DD.md
  context/                     ← root orchestration cognition layer (organized by "root cognition/architecture/sub-projects/contract mapping/evidence", never by sub-project source tree)
    architecture.md            ← architecture level: root → sub-project → tech stack → deployment form; only down to the sub-project boundary
    subprojects.md             ← sub-project registry: business vs supporting, working root, mapped sub-skill, repo mode, gitlink pin inventory
    module-map.md              ← domain global state model: module ↔ sub-project ↔ contract-module mapping (the orchestration equivalent of a global data model)
    modules.md                 ← module level: cross-stack module index and their boundaries (create as needed)
    capability-probe-<迭代>.md ← contract-design pre-step: existing-interface capability probe report (mandatory input of stage 3)
    evidence-trace.md          ← evidence level: source/material/checkpoint provenance and evidence strength for key conclusions
    knowledge-map.md           ← knowledge map (navigation desk: topic → where to look)
    iteration-log.md           ← append-only iteration log: one line per delivered iteration (a FILE, not an archive directory — see F37)
    <domain additions as needed> ← e.g. deployment topology, cross-stack error-code conventions, environment matrix
  _tools/                      ← root-level scripts (optional, e.g. a contract bundle wrapper); allowed to exist but not mandatory
  _generated/                  ← machine artifacts (rebuildable/cleanable/optionally uncommitted), e.g. bundled contract output; never mix into context/
  1-constitution/current.md + history/ + <increment container>
  2-requirements/current.md + history/ + inputs/ + <子需求>/ + clarify-log.md(optional) + <increment container>
  3-contract-design/current.md + history/ + <increment container>
  4-dispatch/current.md + history/        ← two-phase: plan packets → gate ① → land packets → gate ②; + <increment container>
  5-integration-checkpoint/current.md + history/ + evidence/ + <increment container>
  6-deliver/current.md + history/ + <increment container>
```

> `orchestration/4-dispatch/` keeps the **authoritative copy** of every dispatch packet. The copy landed in `<sub-project>/docs/requirements/` is the executor's inbox copy and is cleared by the executor to acknowledge pickup (requirement-inbox-protocol.md) — clearing the inbox never loses the packet.

## contracts/ structure (the single source of truth for front/back)
```
contracts/openapi/
  openapi.yaml                 ← root: info/servers/security/tags + $ref (no single-file bloat)
  paths/                       ← path split by module
  components/schemas/          ← schema split by module
  components/securitySchemes.yaml
  README.md                    ← contract module index + bundle/lint commands
  history/v<oldVersion>/       ← version-indexed contract snapshots (whole-directory snapshot per superseded version)
```

## docs/ structure (root input documents and textualized artifacts)
```
docs/
  <original input documents: full-stack SRS/protocols/standards, possibly binary>
  requirements/                ← root requirement inbox (F33) — RESERVED NAME, inbox semantics ONLY: human-dropped full-stack requirement specs; claim = register into orchestration → archive a copy (orchestration/2-requirements/inputs/ or docs/product-specs/) → clear the inbox (see requirement-inbox-protocol.md)
  product-specs/               ← long-lived requirement specifications / product baselines (survive claims, never cleared). NEVER store these in requirements/ — that directory is emptied on claim (F37)
  iterations/                  ← iteration records, archived by date/version (written at deliver)
  decisions/                   ← architecture decision records (ADR)
  converted/                   ← all textualized artifacts go here (see docs-binarification-adapter.md)
    README.md                  ←   index and mapping + hash/date
    manifest.json              ←   machine-readable verification ledger
    <same-name folder>/        ←   binary → a folder of the same name, one file per workbook/section
    <same-name text file>      ←   text needing no conversion → a file of the same name
```

> **Sub-project inboxes are not part of the root tree**: each business sub-project carries its own `<sub-project>/docs/requirements/` as the dispatch-packet inbox (`dispatch-YYYYMMDD-<slug>.md`). The root creates nothing else inside a sub-project.

## Mode B adoption drafts
Mode B (adopt) reverses an existing monorepo into root cognition. Its reverse-derived artifacts are **the modular contract draft** under `contracts/openapi/` plus the `orchestration/context/` documents above — there is no separate upstream-design draft tree at the orchestration tier (back-deriving a sub-project's SRS/design is that sub-project's single-stack skill's job, boundary restraint). Every reversed contract module carries a reverse-derivation completeness declaration in `contracts/openapi/README.md`, and **before user confirmation it is a draft and must not be treated as the source of truth**; divergences and gaps go to `orchestration/open-issues.md`. Protocol: mode-b-adopt.md.

## Naming conventions
- **Workbench vs history**: each stage's workbench is `current.md` (with a date header); history goes into that stage's `history/YYYY-MM-DD-<说明>.md` (`<说明>` = a short Chinese description); `task.md` history goes into `orchestration/task/`. **Overwriting/deleting is forbidden — archive first, then write.** Archive directories are themselves stratified once they grow (≤30 flat / >30 by year / a year >60 by month, each level carrying an `INDEX.md`) — see specs-lifecycle.md §10; `/sdd-tidy` executes the moves under a plan gate. Same-day, same-description collisions are disambiguated by a two-digit ordinal from `-02` (`YYYY-MM-DD-<说明>-02.md`; the first file stays unsuffixed) — see specs-lifecycle.md §11.
- **The name `history` is reserved for stage date-archives only (F37)**: `<stage>/history/` holds `YYYY-MM-DD-<说明>.md` snapshots of a workbench document, and nothing else in the repository may share that name with a different meaning. One neighbour that is deliberately NOT called `history`: the append-only iteration log is `orchestration/context/iteration-log.md` (a file, not an archive). Rule of thumb: **date-indexed archive → `history/YYYY-MM-DD-<说明>.md`; append-only running record → `*-log.md`.**
  **Registered divergence (contract archive)**: the contract archive is version-indexed, not date-indexed, yet this skill parks it at `contracts/openapi/history/v<oldVersion>/` — the convention already fixed by contract-first-protocol.md §4 and specs-lifecycle.md. Because a version directory sits one level *below* `history/` and never mixes with date snapshots, the F37 same-name hazard does not arise; do not "fix" this path, and do not create a parallel `versions/` tree.
- **Stage workbench presence**: every stage the current iteration has entered has its `current.md`; stages not yet reached have none (absence is the honest "not entered" signal — never pre-create empty stage files). In handoff mode an empty `5-integration-checkpoint/` alongside a landed `4-dispatch/current.md` is the designed suspended state, not a defect (detection.md §1). A stage holding a `history/` but no `current.md` is a hollow state and must be repaired per specs-lifecycle.md §4.
- **Date header**: the top of every current.md and task.md carries `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->` (iteration id | iteration date | status) — **exactly three ` | `-separated fields**, the third holding **exactly one** value of the frozen closed set (`就绪` / `进行中` / `已交付待归档`) defined in specs-lifecycle.md §3. **Never write the enumeration inline**: inside the header `|` is the field separator and nothing else, so an inline enum makes a three-field header parse as four and silently breaks every parser. The three field names are frozen; scripts must grep these literals.
- **README/context**: read `orchestration/README.md` before entering any stage; `context/` splits out overlong content and contains the navigation desk — the **knowledge map** — plus the **module ↔ sub-project ↔ contract map** that replaces a single-stack code map at this tier.
- **Document purity (Mode B)**: the `context/` body contains only closed facts; doubts/conflicts go into `orchestration/open-issues.md`; in-flight tasks go into `orchestration/task.md`. The three must never be mixed (see mode-b-adopt.md).
- **Machine-artifact separation**: auto-generated artifacts go into `_generated/` (rebuildable/discardable), root scripts go into `_tools/`, and they are **never mixed into the `context/` body**; `context/` may reference `_generated/` as an auxiliary index entry point, but the sources of fact remain the contract, the sub-projects' own deliverables, and checkpoint records.
- **Increment container (F4/F19 meta-rule)**: each stage lands its **in-stage small increments** in a fixed 「本迭代增量」 section at the tail of that stage's `current.md` (no per-stage `increments/` subdirectory at this tier — an orchestration increment is a paragraph-sized note such as "contract module X bumped", "sub-project Y re-dispatched", not a file-sized artifact). Every increment is registered **both** in that section and as a coarse row in `orchestration/task.md`; increments never carry content belonging to another stage (that flows back); the section archives together with its stage. Full protocol: specs-lifecycle.md §12.

## Evidence landing points (F7 meta-rule — this table is REQUIRED)

Each evidence class has **exactly one** authoritative location. Conclusions reference these paths — evidence files are never duplicated across locations. At this tier the governing rule is: **the root stores orchestration-level evidence and references to sub-project evidence; it never copies a sub-project's evidence up** (that would duplicate the fact and rot).

| Evidence class | Authoritative path | Written by | Archive / retention |
|---|---|---|---|
| Integration / joint-debugging execution records | `orchestration/5-integration-checkpoint/evidence/` | integration-checkpoint stage | archives with 5-integration-checkpoint |
| Checkpoint tables (per-sub-project state & deliverable verification) | `orchestration/checkpoints/checkpoint-YYYY-MM-DD.md` | `/sdd-checkpoint` | one file per round, retained; stratified per specs-lifecycle.md §10 |
| Sub-project build / unit-test evidence | owned by the sub-project (its own SDD evidence location); the root records only a **read-only reference path** in the checkpoint table | sub-project executor | retained by the sub-project; never copied to the root |
| Contract bundle / lint validation reports | `orchestration/3-contract-design/evidence/` | contract-design stage | archives with 3-contract-design |
| Screenshots and captures (end-to-end, near-production) | `orchestration/5-integration-checkpoint/evidence/captures/` | integration-checkpoint / deliver stage | archives with 5-integration-checkpoint |
| Submodule pin inventory / pointer-reclaim verification | `orchestration/6-deliver/current.md` + `orchestration/context/subprojects.md` | deliver stage | pin inventory is refreshed in place in context/; the per-iteration snapshot archives with 6-deliver |
| Machine-generated indexes (bundled contract output, etc.) | `orchestration/_generated/` | tools (`orchestration/_tools/`) | rebuildable, never archived |

Rules: ① a class absent from this table MUST NOT be written anywhere — declare it here first; ② the same evidence file MUST NOT be stored twice (reference the path instead); ③ every `5-integration-checkpoint/current.md` conclusion carries a project-relative path into one of these locations **and** an L1–L5 label. Full protocol: evidence-gate-protocol.md §7.

## Archive description vocabulary (`<说明>` controlled list — REQUIRED)

Archive filenames are `YYYY-MM-DD-<说明>.md`. `<说明>` MUST start with one entry from the table below, optionally followed by `-<自由补充>` for specificity. This makes `orchestration/task/` and every `history/` directory searchable by semantics instead of by opening each file. The entries are **language-bound content and stay Chinese verbatim** (F32) — never translate them.

**Common entries (frozen — every sdd-xx inherits all of them; a domain MAY append rows, MUST NOT delete any):**

| 词条 | 适用场景 |
|---|---|
| `需求澄清` | 需求访谈、澄清轮次、验收点确认的归档 |
| `设计定稿` | 概要/详细设计定稿、架构决策的归档 |
| `任务执行` | 任务拆解与编码执行过程的归档 |
| `测试验收` | 测试用例、执行记录、证据与验收结论的归档 |
| `交付发布` | changelog/release-note/回滚方案、发布记录的归档 |
| `复盘` | 复盘结论、经验沉淀的归档 |
| `契约变更` | 接口/协议/契约版本变更的归档 |
| `派单` | 需求投放、任务派发、跨项目交接的归档 |
| `缺陷修复` | bug 修复迭代的归档 |
| `结构规整` | `/sdd-tidy` 整理动作产生的归档 |

**Domain entries (this skill's additions):**

| 词条 | 适用场景 |
|---|---|
| `点检` | `/sdd-checkpoint` 点检表、子项目产出物核验结论的归档 |
| `收编` | Mode B 收编现有 monorepo、根编排认知重建的归档 |
| `指针回收` | submodule-aggregate 模式下 gitlink 指针回收清单与核验的归档 |

Rules: ① the prefix before the first hyphen after the date MUST match one entry exactly; ② `-<自由补充>` is optional and free (iteration name, sub-project, defect id); ③ `/sdd-tidy` reports filenames that miss the vocabulary but **never renames them** — renaming an archived file is the user's call (tidy-protocol.md §3).
