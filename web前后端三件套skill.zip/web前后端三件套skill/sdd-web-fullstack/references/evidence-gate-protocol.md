# Evidence grading & deliver gate protocol (orchestration wording)

> Solves the problem of build-pass / joint-debug-pass / checkpoint-pass being written as a blanket `PASS`. **The ladder — its five level names AND their order — is frozen by the framework and is identical in every sdd-xx. Exactly one column is tuned per domain: "Domain evidence".**

## 1. L1–L5 evidence levels (frozen ladder · the domain-evidence column is the only slot)

| Level | Name (frozen, language-bound) | Domain evidence (orchestration class) | May claim (frozen) |
|---|---|---|---|
| L1 | 构建通过/静态可见 | every sub-project's build/type-check log received from its executor; the contract-consistency review and the deliverable diff review completed (**review/lint is L1's precondition, not a rung of its own**) | it builds; the artifact/structure exists and is type-self-consistent |
| L2 | 单元测试通过 | each sub-project's unit-test report received and read against its dispatch packet's acceptance points (discovered count > 0) | the unit-level logic is verified by executable tests |
| L3 | 受控集成通过 | front/back joint debugging in a controlled environment, contract cases pass, mock joint debugging, integration tests, script validation | the components integrate and behave correctly in a controlled environment |
| L4 | 预生产环境验证 | real front/back joint debugging, pre-prod/staging end-to-end, canary small traffic | it passes in a near-real environment |
| L5 | 生产环境验证 | full/soak/online canary ramp-up running records | it passes in the real production environment |

> **Single source of truth (frozen)**: this table is the **only** definition of the L1–L5 ladder. No other file — in this skill or in any skill that consumes its reports — may restate the ladder as an inline shorthand, an abbreviated list, or a parenthetical gloss (e.g. "L1 build / L2 review / L4 joint debugging"). A shorthand that drifts is indistinguishable from a redefinition, and readers obey whichever copy they hit first. Where another document must mention the ladder, it **links here** and names levels by ID only.
>
> **Frozen items (never changed by a child skill)**: the five level **names**, their **order**, and the "May claim" column. The five names are Chinese language-bound literals (F32) and are reproduced byte for byte; translating them is a violation, not a localisation. A child skill that wants different wording has misread the slot — the slot is the **Domain evidence** column, nothing else.
>
> **Review/lint is not a level.** Static review, lint and diff review are a **mandatory precondition of L1**, not a rung: a reviewed-but-unbuilt change claims nothing. Do not re-introduce a "review passed" level under any number. This skill previously carried "contract/output review passed" as its L2; that evidence now sits in **L1's** domain-evidence cell, where it belongs — it was not deleted, and it is not a level.
>
> **Domain evidence may not weaken a level.** Each cell above lists what *this domain* accepts as proof **of that level's frozen meaning**; it may not redefine the meaning. Filling L3 with "the build passes" is a violation — that is L1 evidence.
>
> **Why the orchestration class in particular must not drift**: an orchestration-class skill (F34) **aggregates** the L values reported by every sub-project into one checkpoint table **with no conversion layer** — a sub-project's reported `L3` is written into the checkpoint table as `L3`, unchanged. A per-domain ladder would make `L3` mean "it builds" in one sub-project and "front and back are integrated" in another, systematically overstating readiness and breaking the deliver exit gate. This skill therefore reads sub-project L values **literally**; if a sub-project's report looks self-inconsistent, raise it as a blocker — never silently re-grade it.

## 2. Deliver semantics constraint (frozen)
| Highest evidence | Allowed delivery semantics | Forbidden semantics |
|---|---|---|
| L1/L2 | orchestration draft, joint-debug candidate | formal delivery, releasable |
| L3 | staged integration package | field-stable, batch release |
| L4 | joint-debug-passed candidate package | no monitoring needed, final done |
| L5 | releasable delivery package | — |

## 3. Gate requirements (frozen)
- integration-checkpoint must label an evidence level on every checkpoint conclusion.
- deliver references integration-checkpoint's highest evidence level; **deliver must not exceed the checkpoint's highest evidence**.
- Un-jointly-debugged / untested boundaries must be written into the deliver risks, not hidden.

## 4. Traceability matrix
| REQ | Contract module | Dispatch (sub-project) | Checkpoint | Evidence level | Status |
|---|---|---|---|---|---|
| REQ-001 | usage.yaml | DISP-...-backend | CP-... | L1/L2/L3/L4/L5 | 未开始/进行中/通过/阻塞 |

## 5. Mode B evidence-strength annotations (separate from L1–L5)
When Mode B adopts/reverses a contract, conclusions carry textual annotations, **not the L1–L5 numbers**:

| Annotation | Meaning |
|---|---|
| 静态可见 | statically visible in the current state/source (directories, existing yaml, config) |
| 资料互证 | statically visible + corroborated by project materials (requirement docs, interface notes) |
| 运行佐证 | statically visible + materials + runtime/test evidence (build logs, joint-debug records) |

Conflict and no-guessing rule: when the state and the materials conflict, write per the state and log the divergence to `orchestration/open-issues.md`; never fill gaps with 「通常/应该/按经验」.
