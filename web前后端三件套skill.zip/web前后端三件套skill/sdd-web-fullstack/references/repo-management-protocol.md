# Repository management protocol (repo modes)

> **Positioning**: a front/back-separated full-stack project comes in two repository shapes. This file defines the **two repo management modes (mono-repo / submodule-aggregate)**, their detection, the hard discipline each imposes on orchestration (dispatch, checkpoint, deliver), the **sub-project registry with orchestration-scope classification**, and the gitlink pointer-reclaim flow. The repo mode is detected/declared once at the constitution stage (or during Mode B adoption) and recorded in `orchestration/1-constitution/current.md` and `orchestration/README.md`.

---

## 1. The two repo management modes

| | **mono-repo（单仓统管）** | **submodule-aggregate（聚合主仓+子模块）** |
|---|---|---|
| Shape | One Git repository directly contains the root **and** all sub-project sources; one shared history | The root is an **aggregate repo** keeping only cross-repo assets (README, `contracts/`, `orchestration/`, `docs/`, start/build/deploy scripts); each sub-project is an **independent remote repository** mounted via `.gitmodules` and pinned to an exact commit by a **gitlink** |
| Detection | No `.gitmodules` at the root; sub-project sources tracked by the root repo | `.gitmodules` exists at the root; `git submodule status` lists the pinned sub-repos |
| Sub-project history | Shared with the root | Each sub-repo owns its independent history and remote |
| Version reproducibility | Root commit = whole-set version | Root commit + gitlink pins = a **fixed, reproducible combination** of front/back/toolchain versions |
| Change flow for sub-project code | Commit in the root repo as usual | **Commit & push in the sub-repo first, then return to the root and update + commit the submodule pointer** — never the other way around |

**Detection rule**: at the constitution stage (Mode A) or step 1 of Mode B adoption, check for `.gitmodules` at the root → declare the mode, record it (with the pin inventory in submodule-aggregate mode), and confirm with the user in one line. When the actual layout contradicts the declaration → surface to `orchestration/open-issues.md`, do not guess.

---

## 2. Sub-project registry and orchestration scope (frozen default)

The constitution stage builds a **sub-project registry** covering every sub-directory/sub-repo, classified as:

| Class | Examples | Orchestration treatment |
|---|---|---|
| **Business sub-project（业务子项目）** | `frontend/`, `backend/`, `cms-frontend/` | In scope: dispatched, checkpointed, mapped to a sub-skill, contract-bound |
| **Supporting sub-repo（配套子仓）** | `toolchain-packaging/`, `local-agent/`, `docker-scripts/`, script/tooling repos | **Registered only** — NOT dispatched, NOT checkpointed, no sub-skill mapping required. Its gitlink pin is still inventoried in submodule-aggregate mode |

**Frozen default**: unless the user explicitly names a supporting sub-repo into a specific iteration's scope, orchestration (requirements split / dispatch / checkpoint) covers **business sub-projects only**. When a requirement genuinely touches a supporting sub-repo (e.g. `local-agent`), the user's explicit call promotes it into that iteration's scope — record the promotion in `task.md` and the dispatch blueprint.

Registry fields (per entry): path · class (business/supporting) · tech stack · sub-skill mapping (business only) · repo form (in-tree / submodule + remote URL) · current gitlink pin (submodule-aggregate only).

---

## 3. Hard discipline in submodule-aggregate mode

1. **Pointer flow is one-way**: sub-repo commit & push **first**, root pointer update **after**. ❌ Committing sub-project source "into the root repo" (it cannot hold it — only the gitlink moves); ❌ updating the root pointer to a commit that is not pushed to the sub-repo remote (breaks reproducibility for everyone else).
2. **The main agent never runs git inside a sub-repo.** Sub-repo commits/pushes belong to the executor (external session in handoff, sub-agent in agent-drive) — this is the git-dimension extension of red line 2. The main agent reads sub-repo state (`git submodule status`, log of the pinned commit) **read-only** for checkpointing.
3. **Pointer reclaim is checklist-first**: after integration-checkpoint passes, the main agent ① verifies read-only that each business sub-repo's target commit is pushed to its remote, ② writes a **pointer-update command checklist** (see §4) into the deliver document; **the user executes it by default**. Only when the user explicitly authorizes at the deliver gate may the main agent run the root-repo git operations itself — and even then it still never touches a sub-repo's interior.
4. **Detached-HEAD awareness**: `git submodule update` leaves sub-repos on detached HEAD — the executor must check out / create a branch in the sub-repo before developing; put this reminder into the dispatch packet's pickup instructions in this mode.
5. **Root-side sync before orchestrating**: on entering an iteration in this mode, the recommended sync is
   ```bash
   git pull --ff-only
   git submodule sync --recursive
   git submodule update --init --recursive
   ```
   Run/request it before trusting the on-disk sub-project state; a dirty or drifted submodule (local state ≠ pinned commit) is surfaced to open-issues, not silently reconciled.
6. **Contract stays at the root**: `contracts/openapi/` lives in the aggregate root in both modes — sub-repos consume it via the dispatch packet's contract version; they do not fork their own contract truth.

**Anti-patterns (each one is an error)**:
- ❌ Dispatching or checkpointing a supporting sub-repo nobody asked about.
- ❌ The main agent committing/pushing inside `frontend/`/`backend/` sub-repos.
- ❌ Updating the root gitlink to an unpushed sub-repo commit.
- ❌ Marking a delivery "done" while the root still pins the old sub-repo commits and no pointer-reclaim checklist exists.
- ❌ Treating submodule directories as plain folders in Mode B adoption (losing the pin inventory).

---

## 4. Pointer-reclaim command checklist (deliver-stage artifact, submodule-aggregate mode)

Written into `orchestration/6-deliver/current.md` (seed in `assets/templates/stage-6-deliver.md`), one block per business sub-project touched this iteration:

- Pre-check (read-only, done by the main agent): sub-repo target commit hash · pushed to remote? · CI/evidence level.
- Commands (executed by the user by default):
  ```bash
  cd <sub-project> && git fetch && git checkout <target-commit-or-branch>
  cd .. && git add <sub-project>
  git commit -m "chore: bump <sub-project> to <short-hash> (<iteration>)"
  git push
  ```
- Post-check: `git submodule status` shows the new pins; record the new pin set into the iteration record and the sub-project registry.

In **mono-repo mode** this section degenerates to the normal "root commit contains the iteration's changes" check; no pointer flow exists.

---

## 5. Interaction with the other mechanisms

| Mechanism | mono-repo | submodule-aggregate |
|---|---|---|
| constitution | declare mode; registry (class + stack + sub-skill) | same + remote URL & pin per entry |
| dispatch packet | unchanged | add repo context: sub-repo remote/branch, detached-HEAD reminder, "commit & push in the sub-repo, pointer reclaimed at deliver" |
| checkpoint table | unchanged | plus a pointer-alignment observation per business sub-project (pinned commit vs sub-repo latest reported commit) |
| deliver gate | root commit check | plus §4 pointer-reclaim checklist; delivery semantics must state whether pins are already reclaimed |
| Mode B adoption | registry from directory scan | plus parse `.gitmodules` + `git submodule status` into the pin inventory |
