# Mode & Stage Detection Logic

> Two detection layers: first **which mode** (forward orchestration / adopt the existing monorepo), then within Mode A **which stage**. Do the **routing decision** first (does this project belong to this domain — see the SKILL.md routing section).

## 0. Routing + mode detection (do first)

**Routing**: scan the project root for the fingerprint **`frontend/` and `backend/` (or equivalent multiple sub-projects) existing as sibling directories at the root — in-tree folders (mono-repo) or `.gitmodules`-mounted submodules (submodule-aggregate) both count — plus `contracts/openapi/` (modular contract directory) or `orchestration/` (the orchestration workbench); a root `.gitmodules` mounting the sub-projects is a supporting signal**. Match ⇒ this skill takes over (orchestration). Working root already inside a sub-project (`frontend/`, `backend/`, …) ⇒ hand over to that sub-project's single-stack sdd skill and stay out. No/multiple matches ⇒ ask the user in one line.

**Mode** (after the domain matches). Chinese natural-language equivalents count exactly like their commands (F9):

| Signal | Decision |
|---|---|
| `/sdd-iterate`, or 「做个全栈需求」「按六阶段编排」「加个前后端功能」 | **Mode A** (six orchestration stages) |
| `/sdd-init`, or 「收编这套monorepo」「接手这个全栈项目」「梳理现有全栈工程」 | **Mode B** (adopt the existing monorepo) |
| `/sdd-contract`, or 「维护契约」「拆分OpenAPI契约」「给契约升版本」 | contract maintenance (callable independently — contract-first-protocol.md) |
| `/sdd-dispatch`, or 「生成派发包」「只派单不开发」「派发给子代理」 | dispatch action (callable independently — dispatch-protocol.md) |
| `/sdd-checkpoint`, or 「点检子项目进度」「各子项目做到哪了」「核验产出物」 | checkpoint action (callable independently — checkpoint-protocol.md) |
| `/sdd-update`, or 「归档工作台」「巡检并归档」「维护编排台账」 | workbench maintenance (pre-iteration inspection hook) |
| `/sdd-docs`, or 「整理文档」「把 docs 文本化」 | docs governance & textualization (docs-binarification-adapter.md) |
| `/sdd-tidy`, or 「规整项目目录」「收拾项目结构」「整理目录结构」 | structure tidy-up (gated plan; moves/archives only, never deletes — tidy-protocol.md) |
| `/sdd-retro`, or 「复盘这次编排」「沉淀本次教训」「做个编排复盘」 | retro reflow loop (write `orchestration/retro/` only) |
| `/sdd-help`, `/sdd-custom`, or 「这个skill怎么用」「设定我的偏好」 | **skill meta-commands**: no fingerprint scan, work without a project (help = interactive usage; custom = personal preferences). Multiple sdd-xx installed & ownership unclear → ask in one line |
| Pure tool request | use the tool directly, no full workflow |
| Mode A but `orchestration/README.md` missing, an existing monorepo present | run Mode B first (`/sdd-init`), then back to Mode A |
| Mode A but README missing, brand-new 0→1 monorepo | enter Mode A directly from constitution |
| Undecidable | ask in one line: 新的全栈需求（A），还是先把现有 monorepo 收编成编排认知（B）？ |

`orchestration/README.md` and `orchestration/task.md` are the shared memory base of both modes — read them at every session start.

**Execution-mode detection (red line 8, dispatch only)**: the dispatch execution mode is detected separately from the working mode. Default is **handoff（派单交接）** — no signal from the user means handoff. Only an explicit request such as 「让子代理当场做」「直驱」「派子代理现在就执行」 selects **agent-drive（子代理直驱）**. Never infer agent-drive from urgency, from the size of the requirement, or from the sub-skills happening to be installed.

**Repo-mode detection (orthogonal)**: `.gitmodules` absent at the root ⇒ **mono-repo**; `.gitmodules` present ⇒ **submodule-aggregate**, and `git submodule status` is read (read-only) into the pin inventory. Detected once at constitution or Mode B adoption and recorded — see repo-management-protocol.md.

## 1. Stage detection (inside Mode A)

Fixed-order detection, README first:
1. `orchestration/README.md` missing → prompt "root orchestration cognition must be built first" (Mode B)
2. constitution → enter if not ready
3. requirements → 4. contract-design → 5. dispatch → 6. integration-checkpoint → 7. deliver (in order; enter the first not-ready stage)
8. All ready → complete

**Readiness**: the stage directory contains `current.md` or any substantive `.md`. contract-design counts as ready only when the capability-probe report exists alongside it (a `current.md` without the probe report is an unfinished stage, not a ready one).

**Suspended state (handoff, not "stage not entered")**: in handoff mode the iteration **suspends** after the packets land — `4-dispatch/current.md` exists and every business sub-project is marked 「已派单待外部开发」, while `5-integration-checkpoint/` is still empty. This is **not** evidence that dispatch failed or that checkpoint must be forced open; it is the designed pause. Resume at integration-checkpoint on the user's report-back, or on observed progress in the sub-project's own SDD artifacts (`<sub>/specs/task.md` first, then a cleared `<sub>/docs/requirements/` inbox meaning the packet was picked up) — see checkpoint-protocol.md.

**Hollow state (not "stage not entered")**: a stage directory holding a `history/` but no `current.md` is **not** evidence that the stage was never entered — it is a hollow state left by an incomplete archive. Report and repair it per specs-lifecycle.md §4 **before** inferring the current stage, and never conclude from it that the stage's work must be redone.

**Fallback**: AI lists `orchestration/` directly and matches the table above on each stage's `current.md` existence and substance to conclude the current stage.
