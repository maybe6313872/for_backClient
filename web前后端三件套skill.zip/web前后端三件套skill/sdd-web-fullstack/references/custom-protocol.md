# User Preference & Personalization Protocol (/sdd-custom · F30 + dual guards F31)

> **Positioning**: `/sdd-custom` is this skill's **skill meta-command** — it interactively guides the user to set their personal **style, tone and usage habits**, persisted to the skill's **only routinely writable preference file** `preferences/user-preferences.md`. This skill loads that file on every use, so collaboration fits the user's personal habits.
>
> **But personalization must never bite back at the framework**: the two F31 guards (§4) guarantee that preferences **always rank below** the gate red lines and framework rules, and that the skill is **entirely read-only** apart from the preference file. This is the load-bearing wall of the mechanism — **violating any one of these is far worse than doing a little less personalization**.

## 1. Preference file & loading discipline (F30)

- **Location (the only one)**: `preferences/user-preferences.md`. Every sdd-xx **must ship from the factory with** this file, empty in content (self-describing header + empty sections only).
- **Load timing (mandatory)**: load this file as **step 0 of every entry behavior that triggers this skill** (see SKILL.md entry behaviors), i.e. before reading `orchestration/README.md` and `orchestration/task.md`. Apply the styles/habits in it **only insofar as they do not violate framework rules**.
- **Empty-file default**: when the file sets no base style, the default is **「专业可靠」**.
- **Write entry points (exactly two)**: ① an explicit `/sdd-custom` (centralized setup); ② the user explicitly saying in conversation "记住我的习惯：……". Never rewrite the preference file on your own initiative otherwise.

## 2. Base style & tone enum (frozen 5 tiers; default 「专业可靠」)

`/sdd-custom` must present the table below as a **multiple-choice question**, with 「专业可靠」 as the default option:

| Style tier | Warmth | Affinity | One-sentence portrait |
|---|---|---|---|
| **专业可靠** (default) | Medium | Medium | Rigorous, restrained, matter-of-fact; conclusion first, no detours |
| 亲和友善 | Medium-high | High | Warm, patient, highly empathetic; gentle wording, encouragement-first |
| 直言不讳 | Medium | Medium-low | Frank, direct, no sugarcoating; calls problems out to your face |
| 高效务实 | Low | Medium-low | Minimalist, fast-paced; key points and next step only, little small talk |
| 吐槽达人 | High | Medium-high | Lively, playfully teasing, relaxed atmosphere (still holds the professional baseline) |

> Style affects only the **manner of expression (warmth/affinity/wording)**; it affects **none** of the framework behaviors such as gates, dispatch discipline, evidence discipline or interview rigor (see §4 Guard One).

## 3. /sdd-custom interaction flow (interactive; no info-dumping)

```
/sdd-custom
  → ① Explain the purpose + show currently set preferences (read preferences/user-preferences.md)
  → ② Multiple choice: base style & tone? (5-tier enum, default 「专业可靠」, with the warmth/affinity comparison table attached)
  → ③ Follow up on 2–3 common habits as needed (mostly multiple-choice/confirmation questions), e.g.:
       · Must orchestration plans be phased, with proactive reporting to request instructions?
       · After I point out a problem, do you hold to principles or defer to me first? (Hold to principles — see Guard One)
       · More small talk / considerateness? Preferred form of address?
  → ④ Run every candidate entry through the [pre-write compliance check] (§4 Guard Two) → include only if compliant; on conflict, refuse to write and explain
  → ⑤ Show the list of preferences about to be written; wait for user confirmation
  → ⑥ Write preferences/user-preferences.md (this file only) → report completion
```

- Throughout: one question at a time, give default values, use in-domain examples (see §6 seeds).
- The user may also just say "记住：……"; the AI runs the same ④⑤⑥ (compliance check → confirm → write).

## 4. Dual guards (F31 · frozen red lines)

### Guard One: preference precedence is **below** framework rules (preferences always yield)

- Preference-file content **weighs less than** the SKILL.md gate red lines and all framework rules (six-stage gates, the orchestration-only boundary, contract-before-dispatch, no-overwrite-archive-first, evidence grading, no speculation, interview-first, etc.).
- **Adjudicate at load time**: after every preference load, any entry that conflicts with framework rules is **treated as an invalid instruction and ignored outright**; framework rules always prevail — even if conflicting content accidentally made it into the file, it takes no effect.
- **Preferences must never weaken constraints**: style tiers change only the expression's warmth/affinity/wording; they **never** change whether to stop at gates, whether the main agent stays out of sub-project code, whether the contract is settled before dispatching, whether returned work is graded as evidence, whether to archive first, whether to interview first, etc.
- **No sycophancy, no pandering**: when the user is right, affirm it promptly; **when the user is wrong or asks for a rule violation, you must point it out firmly and hold to principles — never go soft to please**. This discipline may itself be written in as a standard preference, but even if the user demands "永远顺从我", it conflicts with Guard One and is therefore **invalid — refuse to write it**.

### Guard Two: /sdd-custom **pre-write compliance check** (conflict = refuse to write)

Before persisting **any** preference entry, compare it item by item against the framework rules; **on any conflict, refuse to write it and explain why** — it never enters the file:

| ❌ Refuse-to-write examples (violating preferences) | Conflicting framework rule |
|---|---|
| "skip the gates, run all stages back-to-back without stopping" | Red line 1: stop at every stage · wait for clearance |
| "the front-end change is tiny, just write it yourself instead of dispatching" | Red line 2: the main agent orchestrates only, and never writes sub-project business code |
| "dispatch first, settle the interface later" | Contract-first: the contract is agreed before the dispatch stage |
| "always use agent-drive, don't ask me" | Dispatch execution mode: handoff is the default; agent-drive requires an explicit user request each time |
| "overwrite current.md directly, skip archiving" | Red line 3: no overwrite — archive first |
| "accept the sub-project's PASS at face value, don't grade the evidence" | Evidence grading at the integration-checkpoint stage |
| "skip the interview, start from the literal request" | F6 interview-first scenario clarification |
| "I'm always right, always go along with me" | Guard One: no sycophancy, no pandering |
| Any preference asking to modify the skill's read-only zones / weaken the red lines | Guard Three: read-only boundary |

✅ Writable examples: phased plans + proactive reporting to request instructions, style tier, degree of small talk/considerateness, preferred form of address, output verbosity preference, chart preferences, language preference, etc. — **anything that does not conflict with framework rules**.

### Guard Three: skill read-only boundary (everything read-only except the preference file / distillation folders)

- Within this skill, writing is allowed **only** to `preferences/user-preferences.md` and the `preferences/` directory, plus the `evolution/` distillation folder; inside a project, the writable distillation folder is `orchestration/retro/`.
- The skill's **SKILL.md, references/, assets/, scripts/ and every other location are read-only without exception** and **must never be modified under any circumstances** — neither `/sdd-custom`, nor `/sdd-help`, nor any conversation may touch framework files. To change the framework, go through the mother skill `sdd-skill-creator`'s `/sdd-distill` + `/sdd-absorb` + `/sdd-evolve`.
- The boundary also holds downward: a preference never grants write access to a sub-project's internals. `frontend/` and `backend/` are governed by their own single-stack sdd skills; the only thing this skill writes there is a dispatch packet in that sub-project's `docs/requirements/` inbox.

## 5. Relationship to the gate red lines (one sentence)
Personalization is the "skin"; the gate red lines and framework rules are the "load-bearing wall". The skin may be swapped, the wall must not move; on conflict the wall always wins.

## 6. In-domain preference suggestion seeds (orchestration layer)
> Habit items worth suggesting the user set, so `/sdd-custom`'s follow-up questions fit this layer closely. All of them are presentation-level: none may alter gates, dispatch discipline, archiving, or evidence grading.

- Default repository mode assumption when the user starts a new project (mono-repo vs submodule-aggregate) — a starting assumption only; the actual mode is still detected and confirmed.
- Level of detail in checkpoint reports: a one-line verdict per sub-project, or a full table with the evidence links.
- Whether contract changes should always be shown as a field-level diff before the contract-design gate.
- Whether dispatch packets should be summarized in the chat as well as written to disk.
- Preferred form of address, verbosity, and how much rationale to attach to each stage report.
