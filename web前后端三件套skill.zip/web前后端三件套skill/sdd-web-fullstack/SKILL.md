---
name: sdd-web-fullstack
description: 'Spec-driven orchestration for a front/back-separated Web full-stack monorepo. The main agent stays at the root and never writes frontend/backend code — it grooms requirements, splits by module, dispatches with the OpenAPI contract as single source of truth, and checkpoints sub-projects. Modes: A forward orchestration (six gated stages); B adopts an existing monorepo into root cognition. Dispatch execution modes: handoff (DEFAULT — only land requirement packets into each sub-project docs/requirements/; external sessions pick them up via sdd-web-frontend / sdd-web-backend-java / -python) and agent-drive (spawn sub-agents now, on explicit request). Repo modes: mono-repo or submodule-aggregate (.gitmodules gitlink-pinned sub-repos); tool/script sub-repos registered, not orchestrated by default. Built-in contract-first / isolation / checkpoint rules, L1–L5 evidence, specs archiving, retro reflow. 触发词：全栈编排、前后端分离、monorepo、子模块、聚合主仓、submodule、契约优先、OpenAPI、派单、需求包、交接派发、子代理派发、点检、web-fullstack、sdd-web-fullstack。'
metadata:
  owner: envicool
  version: 2.5.0
  domain: web-fullstack
  role: orchestration-skill
  framework: SDD
  framework_baseline: sdd-skill-creator v2.3.0
---

# SDD-Web-Fullstack — Orchestration workflow for front-end/back-end-separated Web full-stack projects

An **orchestration / assembly-layer** workflow for a **front-end/back-end-separated Web full-stack monorepo**.

> **One-line positioning**: this skill makes the main agent the *project conductor* at the monorepo root. It **never writes frontend/backend business code itself**; it only *grooms full-stack requirements → splits them by module → dispatches with the contract as the single source of truth → checkpoints each sub-project's progress and deliverables*. Dispatch runs in two execution modes (red line 8): **handoff（派单交接, default）** — only land requirement packets into each sub-project's `docs/requirements/` and stop; **agent-drive（子代理直驱, on explicit request）** — spawn sub-agents to execute now. Either way the code is actually written inside each subfolder, driven by `sdd-web-frontend` / `sdd-web-backend-java` / `sdd-web-backend-python` and similar sub-skills.
>
> This skill is **deliberately different in both role and structure** from single-stack development skills (like `sdd-web-frontend`): it inherits SDD's *load-bearing-wall discipline* (gates, archiving, kanban, evidence grading, retrospectives), but the six stages are remapped to an orchestration viewpoint, and it adds five domain-specific mechanisms — *contract-first / sub-agent dispatch / isolation / checkpoint / retro reflow*.

## Domain routing signature (auto-routing when multiple skills coexist)

This skill owns the **full-stack orchestration of the monorepo root**; it **never takes over the coding inside any single sub-project**.

**Root fingerprint (all must hold to be an orchestration-domain hit)**:
- `frontend/` and `backend/` (or equivalent multiple sub-projects) both exist at the root as sibling directories — in-tree folders (mono-repo) or `.gitmodules`-mounted submodules (submodule-aggregate) both count;
- the root has `contracts/openapi/` (modular contract directory) or `orchestration/` (the orchestration workbench). A root `.gitmodules` mounting the sub-projects is a supporting signal.

**Routing rules**:
- Receiving a `/sdd-*` project command **at the project root** and matching the root fingerprint above → this skill takes over (orchestration).
- **Inside a subfolder** (working root already `frontend/` or `backend/`) → hand off to the corresponding single-stack sub-skill; this skill stays out.
- The exact naming of `/sdd-*` may be reasonably self-chosen per the actual project (see [commands.md](references/commands.md)); when ownership is unclear, ask the user in one line.

**Design assumptions (frozen · do not re-litigate with the user)**:
1. **One role, one skill** — each engineer installs exactly one concrete `sdd-*` skill, so identical project-command names across `sdd-*` skills are *not* a conflict. Never re-ask the user about command-name collisions.
2. **Commands are never used standalone** — a `/sdd-*` command always fires after this skill is already in context, so the description need not enumerate commands (they live in the command table below instead).
3. **Domain routing is a wrong-domain guard**, not a multi-skill arbiter — its job is to keep this skill from acting inside a single sub-project's working root, not to negotiate ownership on every turn.

## Two working modes

| | **Mode A — forward orchestration** | **Mode B — adopt the existing state** |
|---|---|---|
| Solves what | Runs a full-stack requirement through groom→split→dispatch→integration-checkpoint→deliver in a disciplined way | Reverses an existing, non-standard monorepo into root-level orchestration cognition |
| Entry command | `/sdd-iterate` (or "do some full-stack requirement") | `/sdd-init` (or "take over / tidy up this full-stack project") |
| Main artifacts | Root six-stage specs + modular contracts + dispatch packets + checkpoint tables + iteration records | `orchestration/README.md` + `context/` (full-stack architecture map, module↔sub-project↔contract mapping, modular contracts reversed from a monolithic yaml, sub-project state snapshots) |

**Dependency between them**: Mode B's artifacts are the "memory base" for every Mode A orchestration; each Mode A delivery writes back into the Mode B cognition to keep the orchestration map from rotting. **Taking over a monorepo without `orchestration/` (like this repository's current state): run `/sdd-init` (Mode B adopt) first, then `/sdd-iterate` (Mode A orchestration).**

## Two repository management modes (orthogonal to the working modes)

The project's Git shape is detected/declared once at constitution (or Mode B adoption) and recorded; full discipline in [repo-management-protocol.md](references/repo-management-protocol.md).

| | **mono-repo（单仓统管）** | **submodule-aggregate（聚合主仓+子模块）** |
|---|---|---|
| Shape | One Git repo directly contains root + all sub-project sources | Root is an aggregate repo (cross-repo docs/contracts/orchestration/scripts only); each sub-project is an independent remote repo mounted via `.gitmodules`, pinned to an exact commit by a gitlink |
| Detection | No `.gitmodules` at the root | `.gitmodules` at the root; `git submodule status` lists the pins |
| Key discipline | normal root commits | **one-way pointer flow**: commit & push in the sub-repo first, then update + commit the root pointer; the main agent never runs git inside a sub-repo; pointer reclaim at deliver is **checklist-first — the user executes by default** (the main agent may run root-repo git only on explicit gate authorization) |

**Sub-project registry & scope (frozen default)**: constitution builds a registry of every sub-directory/sub-repo, classed as **business sub-project** (frontend/backend/cms-frontend… — dispatched, checkpointed, sub-skill-mapped) or **supporting sub-repo** (toolchain-packaging/local-agent/docker-scripts and other tool/script repos — **registered only, never dispatched or checkpointed unless the user explicitly names one into an iteration's scope**; its gitlink pin is still inventoried).

---

## 🚦 Gate system (hard rules · red lines · must obey)

> The "ugly words" come first. **Violating any one is an error**, far worse than doing fewer features. These are this skill's load-bearing walls.

**1. After every stage: stop, report, and await the user's approval.**
Mode A has six stages; on finishing each one you **must stop**: show that stage's Gate checklist item by item → "this stage is complete, please review" → **continue only after the user explicitly says "pass / go to the next stage."**
❌ Do not chain-run from constitution straight through to deliver; ❌ do not push several stages forward on your own; ❌ do not skip any stage. Even when what follows seems "obvious," advance exactly one stage at a time.

**2. The main agent never writes frontend/backend business code — it only orchestrates, dispatches, and checkpoints.**
The main agent's only outputs are: root-level specs docs, modular contracts, dispatch packets, checkpoint tables, iteration records, ADRs.
❌ The main agent editing business source under `frontend/` or `backend/`, ❌ "just implementing it" on a sub-agent's behalf, ❌ pulling a sub-project's coding task up to the root — all are overreach and are errors. A sub-project's code may only be produced by the corresponding sub-agent inside its working root. The main agent reads a sub-project's deliverables/contract/progress **read-only** for checkpointing; it never edits the implementation.

> **tasks and test do not overlap and neither replaces the other**: **tasks guarantees "it is testable as it is written"; test guarantees "it holds up before delivery."** Tests written during tasks are *not* a reason to shorten or skip the test stage, and the test stage is *not* the place to retrofit the unit tests tasks owed. See [gate-and-stages.md](references/gate-and-stages.md).

**This-skill note (orchestration class, F34)**: the frozen block above is quoted **verbatim** and is a **downlink obligation**, not a stage of this skill. This skill's own six stages are requirements → design → contract → dispatch → checkpoint → deliver — it has **no `tasks` or `test` stage**, so the block never binds the main agent directly. It binds the **executing side**: every dispatch packet must carry it through to the sub-skill, and the checkpoint stage verifies it there (a sub-project that hands back a task list with no runnable code and no tests **fails the checkpoint**). ❌ Deleting the block because "this skill has no tasks stage" is an error — that is exactly how the obligation gets lost between the two sides.

**3. A missing sub-skill = a blocker (verified per the declared execution mode): report to the user immediately, never do it yourself, never degrade.**
Before dispatching a sub-project you must verify its corresponding sub-skill (`sdd-web-frontend` / `sdd-web-backend-java` / `sdd-web-backend-python` / …) **per the declared execution mode** (red line 8):
- **agent-drive** → strict check: the sub-skill must be available/triggerable in the current environment; missing → **immediately list it as a blocker and report to the user** (which one is missing, which dispatch it blocks, and the suggestion to build it first with the mother skill's `/sdd-new`), and **stop at the dispatch stage awaiting the user.**
- **handoff (default)** → declaration check: the constitution mapping table must name a concrete sub-skill and the packet must carry it; triggerability in the current environment is NOT required (execution happens in external sessions). **No mapped sub-skill exists at all** (nobody could pick the packet up) → still a blocker, same reporting.
❌ Having the main agent personally write that sub-project's code because the sub-skill is missing, ❌ "degrading" the dispatch into a rough version by the main agent — both are errors (they directly violate red line 2). Details in [dispatch-protocol.md](references/dispatch-protocol.md) §4.

**4. The contract is the single source of truth for front and back ends — no inventing interfaces on either side; contract changes must be versioned + two-way notified.**
`contracts/openapi/` is the single interface truth for front/back collaboration. Every interface is finalized in the contract first, and both sub-agents consume the same contract.
❌ The frontend writing requests by guesswork, the backend returning structures by guesswork, the two sides integrating behind the contract's back — that is an error. Contracts must be split modularly (no single-yaml bloat, see red line 5); changes must be versioned and simultaneously notified to both sides' dispatch packets. See [contract-first-protocol.md](references/contract-first-protocol.md).

**5. Documents under `contracts/`, `orchestration/specs`, and `docs/` must not be overwritten or deleted in place — archive first, then write.**
Before updating `task.md`, each stage `current.md`, or a contract module, if the old content belongs to a previous iteration / contract version → archive first (`task.md`→`orchestration/task/`; stage→`<stage>/history/`; contract→a version directory or `history/`), extract the necessary information into the new workbench, then write the new content.
❌ Overwriting current.md directly, ❌ editing a contract in place without leaving a version — both lose the evolution history and are errors. See [specs-lifecycle.md](references/specs-lifecycle.md).

**6. `task.md` (command deck) ≠ `4-dispatch/` (dispatch blueprint) — do not conflate them; no guessing; preferences rank below the framework; the skill is read-only except preferences/evolution.**
`task.md` = the main agent's global command deck (coarse-grained, cross-iteration, user-visible); a stage `current.md` is a single-iteration blueprint (see [task-kanban-protocol.md](references/task-kanban-protocol.md)).
Never guess third-party / sub-project internal behavior; label integration/checkpoint conclusions with L1–L5 evidence levels, and delivery semantics must never exceed the highest evidence.
Personalization (`preferences/user-preferences.md` and `/sdd-custom`) only tunes expression style; it **never** changes gates, dispatch discipline, archiving, or evidence grading. **Two frozen guards**: ① **precedence guard** — preferences rank below these red lines and all framework rules; any conflicting entry is void/ignored at load; `/sdd-custom` refuses to write violating preferences (skip gates / main agent writing sub-project code / not blocking on a missing sub-skill / no archiving / bare PASS / always comply), and holds principle when the user is wrong (no sycophancy); ② **read-only guard** — only `preferences/` (and the project's `orchestration/retro/`, and this skill's `evolution/`) are writable; everything else (SKILL.md/references/assets) is read-only and never modified under any circumstances; framework changes go through the mother skill's `/sdd-distill` + `/sdd-absorb` + `/sdd-evolve`.

**7. Language protocol (F32, frozen) — implementation in English, interaction & deliverables in Simplified Chinese.**
This skill's **implementation content** (this SKILL.md body, every `references/` protocol) is written in **English**, because English-implemented skills are the most reliable for AI execution. In contrast, **user interaction, the orchestration/contract/docs deliverables generated for the project, and project code comments default to Simplified Chinese**; human-facing docs (README, changelog, `evolution/` notes) also stay Chinese. **Language-bound content is exempt and stays Chinese**: the Chinese trigger keywords in the description, the Chinese natural-language equivalents column of the command table, the five style-enum names (专业可靠/亲和友善/直言不讳/高效务实/吐槽达人), everything under `assets/templates/` (seeds of Chinese deliverables), `preferences/user-preferences.md`, quoted user utterances, and literal strings that must byte-match the Chinese templates (date headers, whose `状态` field carries exactly one frozen value — `就绪` / `进行中` / `已交付待归档` — never an inline enumeration, since `|` is the field separator; archive names like `YYYY-MM-DD-说明.md`, gap markers `[待澄清]/[草稿]/[假设]/[缺口]`). ❌ Writing these protocol files in Chinese, or translating the Chinese deliverable templates into English — both violate this red line.

**8. Honor the declared dispatch execution mode; `handoff` is the default — land the packets, then stop.**
Dispatch runs in one of two execution modes (full definition in [dispatch-protocol.md](references/dispatch-protocol.md) §2):
- **handoff（派单交接, DEFAULT）**: the main agent only splits the requirement and lands self-contained dispatch packets into each sub-project's `docs/requirements/`; **no development happens in this session**. Write every packet against the **blindness premise**: the executor opens an independent AI-tool window at the sub-project root and **cannot see the parent folder** — so the packet is stand-alone, and anything else it needs is handed down via a **restrained absolute-path downlink list** (contract modules @ version are mandatory entries; see dispatch-protocol §5c). After the packets land, the iteration **suspends** as 「已派单待外部开发」; the executor **clears the inbox to acknowledge pickup** (root keeps the authoritative copy in `orchestration/4-dispatch/`) → state becomes 「已接单开发中」; development happens in external sessions driven by each sub-project's own sdd skill, and integration-checkpoint resumes on the user's report-back or on observed progress in the sub-project's own SDD artifacts (`specs/task.md` first).
- **agent-drive（子代理直驱）**: used **only when the user explicitly asks** for immediate sub-agent execution — the main agent spawns sub-agents that execute inside their own working roots now.
❌ In handoff mode: spawning sub-agents anyway, entering `frontend/`/`backend/` to "just continue" into development, or bulk-reading a sub-project's implementation "to prepare" — all are errors that flood the main agent's context and drift the goal (the exact failure this mode exists to prevent). ❌ Silently choosing agent-drive without the user's explicit request. ❌ Switching modes mid-round without the user's approval.

---

## Entry behavior (every time this skill triggers, in order)

0. **Load user preferences**: read `preferences/user-preferences.md` and apply its style/habits, provided they never violate the gate red lines or framework rules; if empty, default to **「专业可靠」**. Any entry that conflicts with the framework is void and ignored. If `/sdd-help` or `/sdd-custom` was invoked → go to the matching skill meta-command.
1. **Read the current state**: first read `orchestration/README.md` and `orchestration/task.md` (the cross-session memory base). Neither exists → not yet adopted: **with an existing monorepo** → run `/sdd-init` (Mode B) first; **a fresh 0→1** → enter Mode A directly from constitution.
1b. **Check the requirement inbox — this skill is a claiming side, not only a dispatching side** (F33): look at the **root** `docs/requirements/` ([requirement-inbox-protocol.md](references/requirement-inbox-protocol.md)). This skill sits on **both sides** of the inbox mechanism: as the **dispatching side** it lands packets into each sub-project's `docs/requirements/` and later reads their emptied inbox as the pickup acknowledgment (red line 8); as the **claiming side** the orchestration root is itself an SDD project whose own inbox receives human-dropped requirement specs and upper-layer packets — and that side has an owner: **this skill**. Root inbox non-empty → a pending requirement: confirm with the user, then **claim it** in three hard steps —
   ① **register into specs**: append an `orchestration/task.md` row and create/extend the matching `orchestration/2-requirements/` entry, then run the six stages from the appropriate stage;
   ② **archive a copy inside this project**: preserve the requirement content under this project's own workbench (e.g. `orchestration/2-requirements/inputs/`, registered in `sources.md`), so clearing the inbox loses nothing even when no upper-layer authoritative copy exists;
   ③ **clear the claimed item from the inbox** — an emptied inbox is the **acknowledgment signal** to the upper layer ("requirement received, iteration started"). It is a **pickup signal, NOT a completion signal**; completion is still judged by gates and evidence.
   **Claim boundary**: clearing removes **only** the claimed packet files inside `docs/requirements/` — never `docs/iterations/`, `docs/decisions/`, or any long-lived requirement specification. ⚠️ At a root whose `docs/requirements/` still doubles as the store for full-stack top-level / layered requirement specs (the structure tree below, and the requirements-stage output), that directory carries **two meanings at once** — a collision with the F33 reserved inbox semantics (F37). Until those long-lived artifacts are migrated to `docs/product-specs/`, **never bulk-clear the root inbox**: claim and clear one packet file at a time, and when a file's nature is not certain, **stop and ask the user** — never guess which files are safe to remove.
   ❌ Dispatching or drafting straight from an inbox file without registering it into specs; ❌ clearing without archiving a local copy first; ❌ leaving a claimed packet in the inbox "for reference" (the upper layer reads that as not-yet-received); ❌ writing progress notes back into the inbox — it is one-way intake, and upper layers read progress from `orchestration/task.md` instead.
   *(Do not confuse this entry-behavior `1b` with the dispatch stage's own `1b` boundary intake further below — same label, different mechanism; neither is a renumbering of the other.)*
2. **Routing + commands**: first confirm via the [domain routing signature](#domain-routing-signature-auto-routing-when-multiple-skills-coexist) that "this is root orchestration, not a sub-project's interior"; a `/sdd-*` hit → go straight per [commands.md](references/commands.md); otherwise decide by mode.
3. **Pre-iteration inspection (archive hook + input freshness)**: before opening a new iteration / new dispatch, inspect `task.md`, each `current.md`, and contract versions; whatever belongs to a previous iteration is archived first (red line 5 and specs-lifecycle.md). Also run the **input-copy freshness check** (specs-lifecycle §8): compare every `inputs/` copy against its `sources.md`-registered source (mtime/version/hash); stale → report and re-copy on approval, never proceed silently with a stale copy.
4. **Handle docs/**: if the root `docs/` has binary input documents, textualize them before referencing (see the docs handling in collaboration-protocol.md).
5. **Enter the matching mode**: Mode A runs the six stages and does scenario-clarification interviews first; Mode B runs the adopt workflow.

---

## Command set `/sdd-*` (naming may be reasonably self-chosen per project)

> Every command also responds to its **Chinese natural-language equivalents** (F9): slash commands are hard to memorize, so the semantic phrases are the usability contract. The phrases are language-bound content and stay Chinese.

| Command | Chinese equivalents (also trigger it) | Duty | Lands in |
|---|---|---|---|
| `/sdd-init` | 「收编这套monorepo」「接手这个全栈项目」「梳理现有全栈工程」 | **Build/rebuild root-level orchestration cognition** for an existing monorepo (Mode B adopt) | [mode-b-adopt.md](references/mode-b-adopt.md) |
| `/sdd-iterate` | 「做个全栈需求」「按六阶段编排」「加个前后端功能」 | **Forward orchestration**: run a full-stack requirement through the six gated stages (Mode A) | [orchestration-stages.md](references/orchestration-stages.md) |
| `/sdd-contract` | 「维护契约」「拆分OpenAPI契约」「给契约升版本」 | Maintain modular contracts: split / version / bundle-validate / two-way notify | [contract-first-protocol.md](references/contract-first-protocol.md) |
| `/sdd-dispatch` | 「生成派发包」「只派单不开发」「派发给子代理」 | Generate/land sub-project dispatch packets in the declared execution mode (**handoff default** / agent-drive on explicit request); mode-aware sub-skill verification (no mapped skill = block) | [dispatch-protocol.md](references/dispatch-protocol.md) |
| `/sdd-checkpoint` | 「点检子项目进度」「各子项目做到哪了」「核验产出物」 | Checkpoint sub-project progress & deliverables, update the checkpoint table | [checkpoint-protocol.md](references/checkpoint-protocol.md) |
| `/sdd-update` | 「归档工作台」「巡检并归档」「维护编排台账」 | Workbench upkeep: inspect & archive `task.md`, each `current.md`, contract versions | [specs-lifecycle.md](references/specs-lifecycle.md) |
| `/sdd-docs` | 「整理文档」「把 docs 文本化」 | Docs governance: inspect the orchestration root's `docs/`, textualize binary input documents, maintain `docs/converted/README.md` | [docs-binarification-adapter.md](references/docs-binarification-adapter.md) |
| `/sdd-tidy` | 「规整项目目录」「收拾项目结构」「整理目录结构」 | **Structure tidy-up (F35)**: gated scan → plan → execute against this skill's orchestration-root layout; **moves/archives only, never deletes**; sub-project interiors are out of scope (entering them violates red line 2) | [tidy-protocol.md](references/tidy-protocol.md) |
| `/sdd-retro` | 「复盘这次编排」「沉淀本次教训」「做个编排复盘」 | **Retrospective**: structure lessons/wins into `orchestration/retro/`, candidates to `evolution/` | [reflow-evolution.md](references/reflow-evolution.md) |
| `/sdd-help` | 「这个skill怎么用」「讲讲用法」「介绍下这个技能」 | Usage onboarding (skill meta-command): interactive, read-only, never starts a workflow | [commands.md](references/commands.md) |
| `/sdd-custom` | 「设定我的偏好」「自定义风格语调」「调整表达习惯」 | Personalization (skill meta-command): set style/habits into the only writable preference file | [commands.md](references/commands.md) |

> **Two command classes**: **project commands** `/sdd-init|iterate|contract|dispatch|checkpoint|update|docs|tidy|retro` are handled by this skill only when "currently at the root and matching the orchestration signature" (see routing); **skill meta-commands** `/sdd-help`, `/sdd-custom` are about "how to use this skill / use it my way" — **no project needed, not signature-restricted**, always available. Full definitions: [commands.md](references/commands.md).

### Mode-detection rules
- `/sdd-iterate` or "do some full-stack requirement / add a feature (spanning front and back)" → **Mode A**. If `orchestration/README.md` is absent and code already exists → suggest `/sdd-init` first.
- `/sdd-init` or "take over / tidy up this full-stack project / map out the monorepo" → **Mode B adopt**.
- `/sdd-contract`, `/sdd-dispatch`, `/sdd-checkpoint` → orchestration-domain focused actions (callable independently).
- **Execution-mode detection (red line 8)**: default **handoff** — no signal from the user means handoff. Only an explicit request like 「让子代理当场做」「直驱」「派子代理现在就执行」 selects **agent-drive**. The user reports 「某子项目做完了」 or a suspended dispatch is found in `task.md` → resume integration-checkpoint (`/sdd-checkpoint`).
- `/sdd-update` → workbench upkeep; `/sdd-docs` or 「整理文档」「把 docs 文本化」 → **docs governance & textualization** (see [docs-binarification-adapter.md](references/docs-binarification-adapter.md)).
- `/sdd-tidy` or 「规整项目目录」「收拾项目结构」「整理目录结构」 → **structure tidy-up** (gated plan; moves/archives only, never deletes; sub-project interiors out of scope — see [tidy-protocol.md](references/tidy-protocol.md)). Not the same as `/sdd-update`: update maintains workbench *content*, tidy moves *files*.
- `/sdd-retro` or "do a retro on this orchestration" → the retro reflow loop.
- Unclear → ask in one line: "a new full-stack requirement (A), or first adopt the existing monorepo into orchestration cognition (B)?"

---

## Core collaboration principles

> These run through both modes. Understand the *why* and you'll do the right thing even where the letter of the rule doesn't reach. Details in [collaboration-protocol.md](references/collaboration-protocol.md).

- **Interview first, clarify scenarios before acting**. A full-stack requirement hides plenty of implicit context — which part belongs to the frontend, which to the backend, where the contract boundary is, who moves first. On entering a stage, ask 3–5 structured questions first; before the scenario closes, only emit clarifying questions or drafts. Priority: multiple-choice > fill-in-the-blank-with-a-suggested-value > confirmation > open-ended.
- **Probe before contracting**. Contract design starts from a capability probe report of the involved sub-projects' existing interfaces (never improvised, never guessed); dispatch starts from a boundary intake of each sub-project's module-map constraints.
- **Contract first**. Interfaces are finalized in the contract, then dispatched; both sides consume the same contract (red line 4).
- **Gate ID vocabulary (universal G1–G6, frozen and identical across every sdd-xx)**: G1 stage responsibility boundary · G2 archiving discipline · G3 evidence grading · G4 progress transparency · G5 specs-first at every grain · G6 claim↔git pairing. In daily terms: any code fix or small increment, no matter how small, first registers in `specs/` (task.md row + spec entry + context mapping) and only then touches business code, and every business-code change pairs with a specs change (G5); before delivery `git status` must also match what the delivery claims (G6) — code-without-specs or claim-without-change = incomplete: block, report, backfill (or obtain the user's explicit waiver); never auto-revert — ask the user for disposition. Definitions and enforcement points: [gate-and-stages.md](references/gate-and-stages.md) §Gate numbering namespace. **This skill's own domain gates take the `ORCH` prefix and never consume a `G` number.**
- **Specs first at every grain**. Executors do specs before code (`ORCH-G1`/`ORCH-G2`, two separate dispatches in agent-drive); fixes and small increments also register in the sub-project's specs before code (G5); at checkpoint, code changes must pair with specs changes (G5) and out-of-scope code changes block as overreach (`ORCH-G3` — report and ask, never auto-revert); at deliver, what this orchestration claims must match the actual working tree per `git status` (G6).
- **Isolated dispatch**. The main agent only orchestrates, never codes (red line 2); each executor's working root is locked to its own subfolder, keeping its focus narrow (see dispatch-protocol.md).
- **Handoff by default, agent-drive on request**. Unless the user explicitly asks for immediate sub-agent execution, dispatch means landing packets and stopping — the iteration suspends as 「已派单待外部开发」 (red line 8).
- **A missing sub-skill blocks (mode-aware)**. Verify sub-skills before dispatch per the declared mode; on a blocker, report immediately and stop at the dispatch stage (red line 3).
- **Documents first**. Code rots; the only durable memory for cross-session collaboration is the root-level specs/contracts/docs — have (or update) the document first, then dispatch.
- **Transparent checkpointing, no exaggeration**. Each checkpoint faithfully records each sub-project's "done / in-progress / blocked / deliverables verified?", syncing `task.md` and the checkpoint table; never treat a sub-project's "build passed" as "requirement done."
- **Read the sub-project's own SDD artifacts for progress**. Sub-projects speak SDD too: the default (read-only) progress sources are `<sub>/specs/task.md` first, then specs/README + stage current.md, context/ + open-issues, the `docs/requirements/` inbox state (cleared = acknowledged), and docs deliverables (checkpoint-protocol §3b); ask the user only when artifacts are missing or stale.
- **No guessing external/sub-project behavior**. A sub-project's internal implementation details, third-party interfaces, and protocol fields must have a basis (contract / sub-agent deliverable / user confirmation); without one, mark `⚠️ 待确认` and ask.
- **Evidence grading, no bare PASS**. Integration/checkpoint conclusions carry L1–L5 (see [evidence-gate-protocol.md](references/evidence-gate-protocol.md)); delivery semantics never exceed the highest evidence.
- **Retro reflow, sediment hard standards**. Every orchestration with a lesson/highlight → `/sdd-retro` writes `orchestration/retro/`; a candidate that could rise to a framework hard standard lands in `evolution/` (see [reflow-evolution.md](references/reflow-evolution.md)).
- **A self-check before and after output**. See [self-check.md](references/self-check.md).
- **Default Simplified Chinese, files UTF-8**.

---

## Mode A: forward orchestration (six stages, orchestration viewpoint)

Six stages; on discovering a risk/inconsistency at any stage you may reflow back to requirements/contract-design to fix it (a reflow must tell the user why and sync `task.md`). **After every stage there is a gate — you must stop and await approval (red line 1).**

```
[root orchestration cognition README + context/ + task.md]
        ↓
constitution → requirements → contract-design → dispatch → integration-checkpoint → deliver
     ↑            (every → has a gate: stop · report · await approval)
     └──────────────── reflow (on discovering risk/inconsistency) ────────────────┘
```

Each stage **produces only content within its own remit**; overreach means stop.

| Stage | Duty (one line) | Minimal artifact | Key Gate items (details in orchestration-stages.md) |
|---|---|---|---|
| **constitution** (full-stack charter) | Project-level engineering constraints: tech-stack boundaries, sub-project split, **repo mode + sub-project registry (business vs supporting)**, contract discipline, isolation discipline, sub-skill mapping, no-go zones | `orchestration/1-constitution/current.md` | Common protocols + full-stack-specific protocols (front/back tech stack frozen, **repo mode detected/declared with pin inventory if submodule-aggregate**, sub-project registry classed, contract directory convention, sub-skill mapping table, the "main agent writes no code" red line confirmed) |
| **requirements** (full-stack grooming) | Define "what": top-level requirements, acceptance, split by module, initial front/back responsibility call; **stage end: land layered requirement files per business sub-project into `docs/requirements/<迭代>/` (`ORCH-G4` — overall→layered→dispatch-slice chain)** | `orchestration/2-requirements/current.md` + layered requirement files | Every requirement has acceptance criteria, boundary exceptions covered, split into modules, initial frontend/backend/shared call, **layered requirement files landed and consistent (`ORCH-G4`)**, key Clarify closed |
| **contract-design** (contract design) | Define "what the interface looks like": OpenAPI modular finalization (single source of truth) + integration points + cross-stack data models; **mandatory pre-step: sub-project capability probe (existing interfaces · reusability · owning service), report into `context/`** | `orchestration/3-contract-design/current.md` + `contracts/openapi/*` + capability probe report | **Capability probe report attached (gate fails without it)**, contract split modularly (no single-file bloat), `$ref` resolvable, bundle validation passes, version fixed, integration points and error conventions clear |
| **dispatch** (split & dispatch) | Cut requirement + contract into frontend/backend **dispatch packets**, assigning sub-skill + working root + acceptance points; **execution mode declared (handoff default)** | `orchestration/4-dispatch/current.md` + dispatch packets in each sub-project's `docs/requirements/` | Execution mode declared (handoff default / agent-drive only on explicit request); each packet has working root / sub-skill / contract version / acceptance points / pickup instructions; **sub-skill verified per mode, a blocker already reported**; the main agent has not overreached into coding; in handoff mode the iteration suspended after landing |
| **integration-checkpoint** (integration checkpoint) | Checkpoint sub-project output, contract consistency, joint debugging, end-to-end (**in handoff mode: resumes here on the user's report-back**) | `orchestration/5-integration-checkpoint/current.md` + checkpoint table | Checkpoint table covers all sub-projects; **`ORCH-G3` overreach check (`git status` read-only; out-of-scope business-code changes → 越界待处置, blocked, user asked — never auto-reverted) and G5 pairing check (code changes must pair with specs changes; code-without-specs = incomplete, fixes included) run per sub-project**; layered-requirement verification (`ORCH-G4` chain); contract consistency verified; joint/end-to-end debugging evidenced; each conclusion labeled L1–L5; blockers made explicit |
| **deliver** (delivery) | Version archiving, iteration record, ADR, trigger the retro reflow; **submodule-aggregate: gitlink pointer-reclaim checklist** | `orchestration/6-deliver/current.md` | Iteration record into `docs/iterations/`; contract version archived; `task.md` archived (to `orchestration/task/`, G2); full doc set synced; **G6 claim↔git pairing: `git status` verified against what this delivery claims — no "claimed changed but nothing changed", no unregistered incidental changes; the root `docs/requirements/` inbox cleared per claim (acknowledgment, not completion)**; **submodule-aggregate: sub-repo commits verified pushed (read-only) + pointer-reclaim command checklist written (user executes by default), delivery semantics state whether pins are reclaimed**; semantics do not exceed the evidence level; suggest `/sdd-retro` |

### The dispatch stage's hard actions (a frequent failure point)
Dispatch runs in **two phases** (mirroring the single-stack two-phase tasks): phase ① plan the packets → 🚦gate ① (show the dispatch list + **the declared execution mode** + mode-aware sub-skill verification, await approval) → phase ② land the packets → 🚦gate ② (handoff: suspend the iteration; agent-drive: await confirmation before integration-checkpoint). See [dispatch-protocol.md](references/dispatch-protocol.md).
0. **Declare the execution mode** (red line 8): **handoff（派单交接, DEFAULT）** unless the user explicitly asked for **agent-drive（子代理直驱）**; record it in `4-dispatch/current.md`, every packet, `task.md`, and the checkpoint table.
1. Verify each target sub-project's sub-skill **per the declared mode** (red line 3): agent-drive → must be triggerable in this environment, missing = block; handoff → the constitution mapping table must name one and the packet must carry it (no mapped skill at all = still a blocker).
1b. **Boundary intake** (dispatch-protocol §5a): read each target sub-project's `specs/context/modules.md` (docs layer only, never a `src/` dive); write the extracted boundary constraints into the packet's 「建议实现边界」.
2. Generate a **self-contained** dispatch packet for each sub-project: execution mode + requirement slice + contract version + working root path + acceptance points + evidence requirements + suggested implementation boundary + **parent-file downlink list (restrained absolute-path allowlist — the executor cannot see the parent folder; contract modules @ version mandatory; each entry: path + purpose + read-only/co-maintain)** + **specs-first requirements (`ORCH-G1`/`ORCH-G2`/G5: specs before code; the specs step forbids business-code edits; fixes also specs-first)** + pickup instructions incl. the clear-to-acknowledge convention (template in `assets/templates/dispatch-packet.md`).
2b. **agent-drive mode**: dispatch specs work and code work as **two separate sub-agent calls**; the code call is issued only after the user confirms the specs (dispatch-protocol §5b).
3. Land the packet into `<sub-project>/docs/requirements/` (legacy packets directly under `docs/` stay recognized read-only; no forced migration), for the executing side to run **inside its working root** with the corresponding sub-skill.
4. By mode — **handoff**: mark each sub-project 「已派单待外部开发」 and **suspend this iteration**; resume integration-checkpoint on the user's report-back. **agent-drive**: spawned sub-agents execute inside their working roots; checkpoint after they deliver.
5. The main agent **does not enter a sub-project to code** in either mode.

### `task.md` vs a stage `current.md` (red line 6 expanded)
- **`task.md`** = the main agent's global command deck: maintained for any orchestration task, a coarse-grained checklist (six stages as big steps + each sub-project's dispatch status), cross-iteration, user-visible.
- **`4-dispatch/current.md`** = a single iteration's dispatch blueprint: fine-grained down to "which sub-project, what was dispatched, what the acceptance point is."
- ✅ "Adopt the existing state" → only update task.md, do not build 4-dispatch.　✅ "Do a full-stack requirement via the six stages" → task.md records coarse progress **and** 4-dispatch does the fine dispatch.
- ❌ Stuffing a single sub-project's dispatch details into task.md; ❌ building 4-dispatch for a non-six-stage task. Details in [task-kanban-protocol.md](references/task-kanban-protocol.md).

Full per-stage requirements, interview examples, recommended diagrams, and self-check lists are in **[orchestration-stages.md](references/orchestration-stages.md)**.

---

## Mode B: adopt the existing state (existing monorepo → root-level orchestration cognition)

Goal: reverse an existing, non-standard monorepo (like this repository's current state) into `orchestration/context/` **root-level orchestration cognition**, as the memory base for later Mode A orchestration. **It is a bridge, not a destination; success is judged by "can it support disciplined dispatch and checkpointing afterward."**

Adoption artifacts (into `orchestration/context/`):
- **Repo mode + sub-project registry**: detect mono-repo vs submodule-aggregate (`.gitmodules`); class every sub-directory/sub-repo as business vs supporting; in submodule-aggregate mode parse `.gitmodules` + `git submodule status` into a **pin inventory** (path / remote / pinned commit) — never treat submodule directories as plain folders.
- **Full-stack architecture map**: an eagle-eye diagram and code map of root → each sub-project → tech stack → deployment form (only to the sub-project boundary, not down into each function inside a sub-project).
- **Module↔sub-project↔contract mapping**: which sub-project implements each business module, and its corresponding contract module.
- **Contract state inventory**: **reverse a modular contract draft** from the existing monolithic/scattered yaml into `contracts/openapi/` (splitting paths/ and components/schemas/); divergences and gaps go to `orchestration/open-issues.md`.
- **Sub-project state snapshot**: each sub-project's current iteration/stage, whether it has the corresponding single-stack sdd skill installed, and its existing deliverables.

**Three iron rules (inlined)**: ① **purity** — `context/` records only closed facts; doubts/conflicts go to `orchestration/open-issues.md`; ② **no guessing** — when reversing contracts, write per the actual state on a source/state conflict and log divergences to open-issues; never fill gaps with "usually/should/by convention"; ③ **boundary restraint** — the main agent's adoption reaches only the sub-project boundary; a sub-project's internal function-level twin is left to that sub-project's single-stack sdd skill Mode B, not rebuilt at the root.

Full workflow in **[mode-b-adopt.md](references/mode-b-adopt.md)**.

---

## Root standard structure (what a project managed by this skill should look like)

```
<project-root>/                 # mono-repo: one Git repo | submodule-aggregate: aggregate root + .gitmodules pins
├── docs/                       # root-level project docs
│   ├── requirements/           #   full-stack top-level requirement specs
│   ├── iterations/             #   iteration records (archived by date/version)
│   └── decisions/              #   architecture decision records (ADR)
├── contracts/openapi/          # modular OpenAPI3 contract (front/back single source of truth, extensible per project)
│   ├── openapi.yaml            #   root: info/servers/security/tags + $ref
│   ├── paths/                  #   path split by module
│   ├── components/schemas/     #   schema split by module (no single-file bloat)
│   └── README.md               #   contract module index + bundle/lint commands
├── orchestration/              # the main agent's SDD workbench
│   ├── README.md  context/     #   root orchestration cognition (architecture map, module↔sub-project↔contract mapping)
│   ├── task.md  task/          #   the main agent's task command deck + archive
│   ├── open-issues.md          #   global doubt/conflict governance inbox
│   ├── checkpoints/            #   checkpoint tables + past checkpoint records
│   ├── retro/                  #   retro ledger + topics (the retro-reflow intake)
│   └── 1-constitution … 6-deliver/ (current.md + history/)
├── frontend/                   # executor working root → sdd-web-frontend
│   └── docs/requirements/      #   dispatch-packet inbox (dispatch-YYYYMMDD-<slug>.md)
└── backend/                    # executor working root → sdd-web-backend-java / -python
    └── docs/requirements/      #   dispatch-packet inbox (dispatch-YYYYMMDD-<slug>.md)
```

> The current state is not best practice: when taking over a project like this repository ("scattered docs, monolithic yaml, no orchestration/"), first adopt it into the structure above with `/sdd-init`.

### Workbench memory and the date header

`specs/` is the project's long-term memory: "workbench current / history separated", auto-archived by hooks at key moments. **Iron rule: never overwrite or delete — archive first, then write** (red line 3). Every `current.md` and `task.md` carries a three-field date header `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->`, whose `状态` holds exactly one value of the frozen set (`就绪` / `进行中` / `已交付待归档`) defined in specs-lifecycle.md §3 — never an inline enumeration, since `|` is the field separator. Archive destinations: `task.md` → `specs/task/`; stages → `<stage>/history/`. Full mechanism: **[specs-lifecycle.md](references/specs-lifecycle.md)**.

**Class binding of the paragraph above (this skill)**: the wording is the frozen single-stack form and is quoted verbatim — never edited in place. This skill's `metadata.role` is `orchestration-skill` (F34), so its workbench root is `orchestration/`, not `specs/`, and the board's archive root resolves to **`orchestration/task/`** per [task-kanban-protocol.md](references/task-kanban-protocol.md) §4 (one file per iteration; there is no single-file archive form), with stage workbenches archiving to `orchestration/<stage>/history/` and contracts archiving by version. The archive-first obligation, the three-field header and the frozen status set are inherited unchanged — the six literals `迭代标识` / `迭代日期` / `状态` / `就绪` / `进行中` / `已交付待归档` are language-bound and are never translated (red line 7).

---

## Retro reflow → hard-standard loop (a first-class mechanism of this skill)

1. After each orchestration iteration / integration deliver, the main agent does a cross-stack retro in `orchestration/retro/` (lessons + highlights, no guessing on root cause).
2. Any "better-than-current-framework orchestration practice / pitfall lesson" → write a **self-contained experience package** into this skill's standalone **`evolution/experience-packages/`** (a reader relying on no conversation context can still see what to change, why, in which file, and how to verify).
3. You later feed `evolution/` back to me → I extract the necessary content → iterate it into the **hard standards** in `references/*` and SKILL.md, and append a row to the README iteration log.

Full loop and experience-package schema in **[reflow-evolution.md](references/reflow-evolution.md)** and `evolution/README.md`.

---

## Reference documents & templates

| Document | Content |
|---|---|
| [orchestration-stages.md](references/orchestration-stages.md) | Mode A six-stage detail (duty/interview/Gate/diagrams/self-check/the tasks-equivalent two-phase dispatch) |
| [gate-and-stages.md](references/gate-and-stages.md) | **Gate vocabulary**: the frozen universal `G1`–`G6` segment, the gate numbering namespace, and this skill's own `ORCH-`-prefixed domain gates (resolve a gate **ID** here; run a **stage** in orchestration-stages.md) |
| [contract-first-protocol.md](references/contract-first-protocol.md) | ★Contract-first: OpenAPI modular `$ref` split, versioning, two-way notification, bundle/lint validation, per-project extension |
| [dispatch-protocol.md](references/dispatch-protocol.md) | ★Sub-agent dispatch: packet format, working-root isolation, sub-skill mapping, missing = block |
| [checkpoint-protocol.md](references/checkpoint-protocol.md) | ★Checkpoint mechanism: checkpoint-table schema, checkpoint cadence, deliverable verification, blocker surfacing |
| [repo-management-protocol.md](references/repo-management-protocol.md) | ★Repo management: mono-repo vs submodule-aggregate, detection, sub-project registry & scope default, submodule one-way pointer flow, pointer-reclaim checklist |
| [reflow-evolution.md](references/reflow-evolution.md) | ★Retro reflow loop: `/sdd-retro` + `orchestration/retro/` + `evolution/` sediment → hard standard |
| [mode-b-adopt.md](references/mode-b-adopt.md) | Mode B adopt: existing monorepo → root orchestration cognition + reverse modular contract |
| [collaboration-protocol.md](references/collaboration-protocol.md) | Interview template (orchestration-domain bank), gate ritual, docs handling, self-check entry |
| [evidence-gate-protocol.md](references/evidence-gate-protocol.md) | L1–L5 evidence grading (orchestration wording) and deliver release |
| [specs-lifecycle.md](references/specs-lifecycle.md) | **Must read**: the archiving lifecycle of orchestration/ and contracts/, no-overwrite discipline, hooks |
| [task-kanban-protocol.md](references/task-kanban-protocol.md) | task.md global board, difference from 4-dispatch (pro/anti examples) |
| [self-check.md](references/self-check.md) | Pre-output chain-of-thought + post-output checklist (orchestration edition) |
| [requirement-inbox-protocol.md](references/requirement-inbox-protocol.md) | **F33 requirement inbox**: `docs/requirements/` intake semantics, the claim protocol (register → archive a copy → clear), claim boundary, and the reserved-name rule (F37) |
| [tidy-protocol.md](references/tidy-protocol.md) | **F35 `/sdd-tidy`**: gated scan → plan → execute structure tidy-up; moves/archives only, never deletes; sub-project interiors out of scope |
| [docs-binarification-adapter.md](references/docs-binarification-adapter.md) | `/sdd-docs`: standalone, swappable adapter for turning binary input documents into text |
| [commands.md](references/commands.md) | `/sdd-*` command-set definition + routing + skill meta-commands |

Templates live in `assets/templates/`: each stage's own current.md (with a date header), task.md, checkpoint table, dispatch packet, iteration record, ADR, root README, and the `assets/templates/openapi/` modular contract skeleton (with an ai-cms sample). These templates are seeds of **Chinese deliverables** and stay Chinese (red line 7).
