<!-- 迭代标识: <说明> | 迭代日期: <YYYY-MM-DD> | 状态: 进行中 -->
# 主代理任务总台（orchestration/task.md）

## 当前任务
- 类型：编排迭代 / 现状收编 / 契约维护 / 点检
- 一句话目标：<>
- 开始日期：<YYYY-MM-DD>

## 进度（粗粒度）
- [ ] constitution
- [ ] requirements
- [ ] contract-design
- [ ] dispatch
- [ ] integration-checkpoint
- [ ] deliver

## 子项目态势（粗粒度，明细见点检表）
| 子项目 | 阶段 | 契约对齐 | 阻塞 |
|---|---|---|---|
| frontend | <阶段（从子项目 specs/task.md 只读获知）；handoff：未接单「已派单待外部开发」→ 收件箱清空「已接单开发中」> | <> | <> |
| backend | <> | <> | <> |

## 当前状态 / 下一步
- 现在在做：<>
- 下一步：<>
- 阻塞：<>

## 备注
- 风险/外部依赖/待用户确认：<>
