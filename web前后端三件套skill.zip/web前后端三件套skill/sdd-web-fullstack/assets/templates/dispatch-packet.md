<!-- 模板：放到 <子项目>/docs/requirements/dispatch-YYYYMMDD-<slug>.md。机制见 references/dispatch-protocol.md -->
# 派发包 <DISP-迭代-子项目-序号>

| 字段 | 值 |
|---|---|
| 派发标识 | <DISP-...> |
| 执行模式 | <handoff（派单交接，默认）/ agent-drive（子代理直驱）> |
| 目标子项目 | <frontend/backend> |
| 执行方工作根 | <./frontend 或 ./backend> |
| 使用子 skill | <sdd-web-frontend / sdd-web-backend-...> |
| 依赖契约 | contracts/openapi/ @ v<版本>；模块：<paths/x.yaml, components/schemas/x.yaml> |
| 仓库上下文 | <单仓统管：无 / 聚合主仓+子模块：子仓远端 <URL>、工作分支 <branch>；提醒：submodule update 后为游离 HEAD，开发前先检出/新建分支；在子仓内提交并推送，根仓 gitlink 指针在交付阶段回收> |
| 阻塞/前置 | <如：需 backend 先实现 /auth/login> |

## 需求切片（本子项目本次要做的）
- <从全栈需求拆出的、归本子项目的需求子集。本包必须自包含：执行方没有编排会话的上下文，仅凭本包即可开工>

## 验收点（映射全栈需求验收点，含证据要求）
- [ ] <AC-1>（证据：<截图/接口响应/测试报告>）
- [ ] <AC-2>

## 集成约定（与另一侧对接）
- 端点：<>
- 错误模型：<统一错误 schema>
- 鉴权：<>
- 时间/单位口径：<>

## 建议实现边界（派发前从子项目 specs/context/modules.md 摄入，见 dispatch-protocol §5a）
- <如：新工位用独立路由前缀，不把工位逻辑硬编码进既有流程；复用既有服务 X>

## 上级文件下放清单（执行方 AI 窗口看不见上层全栈目录——除本包正文外，需读/需维护的上级文件用绝对路径下放；克制，只列必需项，见 §5c）
| 绝对路径 | 用途说明 | 访问方式 |
|---|---|---|
| <D:\...\basic\contracts\openapi\paths\xxx.yaml @ v1.2>（契约模块，必列并说明消费方式） | <本次接口的唯一事实源，按此实现/对接> | 只读参考 |
| <D:\...\basic\docs\requirements\<迭代>\<子项目>-requirements.md> | <本子项目分层需求> | 只读参考 |
| <确需子项目参与维护的上级文档> | <> | 应参与维护 |

## specs 先行要求（ORCH-G1/ORCH-G2/G5，执行方必须遵守）
- specs 先行、代码后写：先在本子项目 specs/ 完成任务登记与规格条目，经确认后再动业务代码（ORCH-G1）。
- specs 阶段只写 `<子项目>/specs/`，禁止触碰任何业务代码文件（ORCH-G2）。
- 修复/小功能增量同样先登记 specs（task.md 任务行、2-spec 条目、context 模块/功能映射）再改码，规模再小不豁免（G5）。
- 交付时业务代码改动须与 specs 改动成对出现，缺 specs 视为交付不完整（G5，主代理点检时核验）。
- 交付声称须与 `git status` 工作树一致：声称改了而工作树无对应改动、或工作树有改动而交付未声称，均视为交付不完整（G6，主代理点检时核验）。

## 接单说明（执行方按此开工）
- 在本子项目根目录（上表「执行方工作根」）打开会话，由对应子 skill 接管，以本包为需求输入走 spec 流程（如 `/sdd-iterate`）。
- **接单确认（清空即确认）**：接收本需求后，将本包从本目录（docs/requirements/ 收件箱）清除并按 sdd specs 范式开始迭代——上层编排方以收件箱清空知悉需求已被接收（权威副本已留存于主仓 orchestration/4-dispatch/，清除不丢失）。
- 进度回传：无需专门汇报——按子 skill 规范维护好本子项目 `specs/task.md` 与各阶段 current.md，上层编排方将只读读取它们了解进度。
- handoff（派单交接）：主代理只落单不开发，本包由后续外部会话取用；完成后回报编排方，由主代理在 integration-checkpoint 阶段点检。
- agent-drive（子代理直驱）：由主代理当场派生的子代理在工作根内执行；完成后同样回主代理点检。
- 无论哪种模式，主代理都不进本目录写码（红线 2）。
