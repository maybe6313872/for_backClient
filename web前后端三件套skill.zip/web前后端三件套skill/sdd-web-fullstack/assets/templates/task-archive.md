<!-- 已停用 · 指向说明：本文件不再作为模板使用，仅保留为路标；原件备份见 archive/F-09/task-archive.md.bak。 -->
# 已停用 —— task 归档去向指向说明
- 本 skill 的 `metadata.role` 为 `orchestration-skill`，工作台根是 `orchestration/`（不是 `specs/`），看板归档根为 `orchestration/task/`。
- `task.md` 归档形态：**一迭代一文件** `orchestration/task/YYYY-MM-DD-<说明>.md`，保留完整原文，不裁剪、不覆盖、不删除（红线 5）；无单文件滚动归档形态。
- 完整机制见 `references/specs-lifecycle.md` 与 `references/task-kanban-protocol.md`；归档动作由 `/sdd-update` 与迭代入口钩子触发，本文件不被任何正文引用。
