<!-- 模板：放到 docs/iterations/<YYYY-MM-DD>-<迭代名>.md。deliver 阶段产出。 -->
# 迭代记录：<迭代名>

- 日期：<YYYY-MM-DD>
- 契约版本：<v>
- 范围：<本迭代全栈需求范围>

## 完成内容
| 子项目 | 完成项 | 证据等级 |
|---|---|---|
| frontend | <> | L<> |
| backend | <> | L<> |

## 契约变更
- <新增/修改端点与 schema；破坏性变更标注>

## 遗留与风险
- <未联调边界/已知风险>

## 关联
- ADR：<docs/decisions/...>
- 复盘：<orchestration/retro/...>
