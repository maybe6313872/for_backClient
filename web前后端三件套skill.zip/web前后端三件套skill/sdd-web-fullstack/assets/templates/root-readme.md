<!-- 模板：放到项目 orchestration/README.md。每次会话入口认知。 -->
# <项目名> 全栈编排认知（orchestration/README.md）

## 1. 项目概览
- 项目名：<项目名>
- 形态：前后端分离 Web 全栈 monorepo
- 子项目：frontend（<前端栈>）/ backend（<后端栈>）/ <其他>
- 契约目录：contracts/openapi/
- 部署形态：<部署>

## 2. 全栈架构鹰眼图
```mermaid
flowchart LR
  U[用户/调用方] --> FE[frontend]
  FE -->|契约| BE[backend]
  BE --> EXT[(外部依赖)]
```
（节点≤10，到子项目边界，不进子项目逐函数）

## 3. 子项目代码地图
| 子项目 | 工作根 | 技术栈 | 对应子 skill | 职责 |
|---|---|---|---|---|
| frontend | ./frontend | <> | sdd-web-frontend | <> |
| backend | ./backend | <> | sdd-web-backend-<> | <> |

## 4. 模块 ↔ 子项目 ↔ 契约映射
| 业务模块 | 归属子项目 | 契约模块 | 状态 |
|---|---|---|---|
| <模块> | frontend/backend | paths/<>.yaml | <> |

## 5. 契约现状
- 版本：<>
- 模块化拆分：见 contracts/openapi/README.md

## 6. context/ 索引
- context/architecture.md：全栈架构地图
- context/module-map.md：模块↔子项目↔契约映射
- context/subprojects.md：子项目现状快照
- context/evidence-trace.md：证据出处（按需）

## 7. 参考文档索引（docs/）
| 原始路径 | 文本化路径 | 说明 |
|---|---|---|
| docs/requirements/... | docs/converted/... | <> |
