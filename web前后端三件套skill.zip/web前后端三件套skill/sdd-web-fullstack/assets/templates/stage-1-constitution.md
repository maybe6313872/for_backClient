<!-- 迭代标识: <说明> | 迭代日期: <YYYY-MM-DD> | 状态: 进行中 -->
<!-- 模板：放到 orchestration/1-constitution/current.md。阶段=constitution。详见 references/orchestration-stages.md -->
# 阶段：constitution（current）

## 本阶段目标
<一句话>

## 仓库管理模式（探测 .gitmodules 后声明，详见 references/repo-management-protocol.md）
- 模式：<mono-repo 单仓统管 / submodule-aggregate 聚合主仓+子模块>
- 聚合主仓模式锁定清单（.gitmodules + git submodule status）：
  | 子仓路径 | 远端 | 当前锁定提交 |
  |---|---|---|
  | <backend/> | <URL> | <hash> |

## 子项目登记表（业务子项目纳管；配套子仓默认只登记不派发不点检）
| 路径 | 类别 | 技术栈 | 子 skill（业务类） | 仓库形态 |
|---|---|---|---|---|
| <frontend/> | 业务子项目 | <> | <sdd-web-frontend> | <随根仓/子模块> |
| <toolchain-packaging/> | 配套子仓 | <> | —（默认不纳管） | <子模块> |

## 采访与确认
<结构化采访问卷的回复要点 / 从文档提取的确认题>

## 产出
<本阶段职责范围内的内容；越界内容移到对应阶段>

## Gate checklist
- [ ] <见 orchestration-stages.md 对应阶段 Gate 项，逐项标状态>

## 风险 / 待确认
- <无则写"暂无">
