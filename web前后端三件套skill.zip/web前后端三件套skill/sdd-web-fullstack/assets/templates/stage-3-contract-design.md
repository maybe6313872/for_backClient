<!-- 迭代标识: <说明> | 迭代日期: <YYYY-MM-DD> | 状态: 进行中 -->
<!-- 模板：放到 orchestration/3-contract-design/current.md。阶段=contract-design。详见 references/orchestration-stages.md -->
# 阶段：contract-design（current）

## 本阶段目标
<一句话>

## 子项目能力探查报告（强制前置，缺失门禁不过；报告存 orchestration/context/capability-probe-<迭代>.md）
| 子项目/服务 | 现有相关接口/能力 | 能否复用 | 归属服务/模块 | 依据 |
|---|---|---|---|---|
| <backend> | <> | <复用/需新增/需改造> | <> | <specs/接口文档/定向查证> |
- 疑点入 open-issues：<无则写"暂无">

## 采访与确认
<结构化采访问卷的回复要点 / 从文档提取的确认题>

## 产出
<本阶段职责范围内的内容；越界内容移到对应阶段>

## Gate checklist
- [ ] <见 orchestration-stages.md 对应阶段 Gate 项，逐项标状态>

## 风险 / 待确认
- <无则写"暂无">
