<!-- 迭代标识: <说明> | 迭代日期: <YYYY-MM-DD> | 状态: 进行中 -->
<!-- 模板：放到 orchestration/2-requirements/current.md。阶段=requirements。详见 references/orchestration-stages.md -->
# 阶段：requirements（current）

## 本阶段目标
<一句话>

## 分层需求沉淀（ORCH-G4，阶段末硬动作）
- 整体需求之外，按纳管业务子项目在主仓 `docs/requirements/<迭代>/` 落分层需求文件：
  - [ ] frontend-requirements.md
  - [ ] backend-requirements.md
  - [ ] <其他业务子项目>-requirements.md
- 三级链路：整体需求 → 分层需求 → 派发切片（集成点检按层核对）

## 采访与确认
<结构化采访问卷的回复要点 / 从文档提取的确认题>

## 产出
<本阶段职责范围内的内容；越界内容移到对应阶段>

## Gate checklist
- [ ] <见 orchestration-stages.md 对应阶段 Gate 项，逐项标状态>

## 风险 / 待确认
- <无则写"暂无">
