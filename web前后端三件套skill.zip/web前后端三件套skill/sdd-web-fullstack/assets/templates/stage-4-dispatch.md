<!-- 迭代标识: <说明> | 迭代日期: <YYYY-MM-DD> | 状态: 进行中 -->
<!-- 模板：放到 orchestration/4-dispatch/current.md。阶段=dispatch。详见 references/orchestration-stages.md -->
# 阶段：dispatch（current）

## 本阶段目标
<一句话>

## 执行模式（红线 8）
- 本轮执行模式：<handoff（派单交接，默认）/ agent-drive（子代理直驱，仅用户明确要求）>
- handoff：派发包落地后本迭代挂起为「已派单待外部开发」，等回报后恢复集成点检

## 采访与确认
<结构化采访问卷的回复要点 / 从文档提取的确认题>

## 产出
<本阶段职责范围内的内容；越界内容移到对应阶段>

## Gate checklist
- [ ] <见 orchestration-stages.md 对应阶段 Gate 项，逐项标状态>

## 风险 / 待确认
- <无则写"暂无">
