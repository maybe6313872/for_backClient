# contracts/openapi 模块化契约（前后端唯一事实源）

机制见上层 skill 的 references/contract-first-protocol.md。

## 结构
- openapi.yaml —— 根：info/servers/security/tags + $ref 装配（禁内联 path/schema 正文）
- paths/<模块>.yaml —— 按模块拆 path（禁单文件膨胀，~300 行内）
- components/schemas/<模块>.yaml —— 按模块拆 schema；通用放 common.yaml
- components/securitySchemes.yaml —— 鉴权方案

## 模块索引（样例，按项目维护）
| 模块 | paths | schemas | 说明 |
|---|---|---|---|
| auth | paths/auth.yaml | common.yaml | 登录/登出/健康，未登录 401 |
| usage | paths/usage.yaml | usage.yaml, common.yaml | 成员用量（工号+姓名独立列） |
| trace | paths/trace.yaml | trace.yaml, common.yaml | Trace session 检索 |
| keys | paths/keys.yaml | keys.yaml, common.yaml | Key 概览（脱敏） |
| cost | paths/cost.yaml | common.yaml | 成本只读预览（notify-only） |

## 版本化与变更（见 contract-first-protocol §4）
- info.version 语义化；非破坏性 minor+1，破坏性 major+1 且需评审。
- 变更前归档旧版本到 history/v<旧版本>/；变更后双向通知前后端派发包。

## bundle / lint（能力探测 + 降级）
```
# 任选项目已装的工具
redocly bundle openapi.yaml -o ../../_generated/openapi.bundled.yaml
redocly lint openapi.yaml
# 或
swagger-cli bundle openapi.yaml -o ../../_generated/openapi.bundled.yaml
swagger-cli validate openapi.yaml
```
无工具时 AI 手工核验：所有 $ref 目标文件/锚点存在、无悬空/循环引用、根 tags 与 paths 一致。
