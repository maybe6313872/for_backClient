<!-- 迭代标识: <说明> | 迭代日期: <YYYY-MM-DD> | 状态: 进行中 -->
<!-- 模板：放到 orchestration/5-integration-checkpoint/current.md。阶段=integration-checkpoint。详见 references/orchestration-stages.md -->
# 阶段：integration-checkpoint（current）

## 本阶段目标
<一句话>
<!-- 派单交接（handoff）模式：本阶段不紧随 dispatch，迭代挂起为「已派单待外部开发」，待用户回报或后续会话发现挂起派单后恢复 -->

## 入场核对（handoff 恢复时）
- 触发来源：<用户回报「某子项目完成/有进展」/ 后续会话从 task.md 发现挂起派单>
- 按派发包验收点逐项核验该子项目产出物，更新点检表

## ORCH-G3/G5/G6 核验（每子项目，先于任何点检结论；只读）
| 子项目 | ORCH-G3 越界核验（git status，超派发范围的业务代码改动） | G5 成对核验（代码改动↔specs改动） | G6 声称↔git 核验（交付声称与 git 工作树是否一致） | 处置 |
|---|---|---|---|---|
| <frontend> | <干净/越界待处置：文件清单> | <成对/缺specs：文件清单> | <一致/不一致：差异清单> | <通过/阻断并已征求用户处置（不擅自还原）> |

## 分层需求核对（ORCH-G4 链路）
- [ ] 各子项目产出物对照 docs/requirements/<迭代>/<子项目>-requirements.md 逐层核对

## 采访与确认
<结构化采访问卷的回复要点 / 从文档提取的确认题>

## 产出
<本阶段职责范围内的内容；越界内容移到对应阶段>

## Gate checklist
- [ ] <见 orchestration-stages.md 对应阶段 Gate 项，逐项标状态>

## 风险 / 待确认
- <无则写"暂无">
