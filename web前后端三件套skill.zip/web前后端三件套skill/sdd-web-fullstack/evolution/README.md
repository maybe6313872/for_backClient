# evolution —— 复盘回流沉淀文件夹（本 skill 可写）

> 本 skill 的**独立沉淀区**，复盘回流闭环的「框架候选」中转站。机制全貌见 [../references/reflow-evolution.md](../references/reflow-evolution.md)。

## 这个文件夹装什么
把所管理项目里 `orchestration/retro/` 复盘中、标 `[框架候选]` 且泛化性=本域通用/跨域通用的条目，蒸馏成**自包含经验包**放到 `experience-packages/`。后续用户把本文件夹反馈给维护者，维护者抽取必要内容迭代进 SKILL.md/references 的**硬性标准**。

## 闭环位置
```
项目 orchestration/retro/  ──筛 [框架候选]──▶  evolution/experience-packages/  ──用户反馈──▶  回灌 SKILL.md/references 硬标准
```

## 经验包 schema（自包含——读者不依赖任何对话上下文也能看懂）
每个 `experience-packages/<日期>-<主题>.md` 必含：
| 节 | 内容 |
|---|---|
| 背景 | 哪个项目、哪次编排、暴露什么问题或发现什么更优做法 |
| 现框架缺口 | 当前 SKILL.md/references 哪条没覆盖或覆盖不足（指到具体文件/小节） |
| 建议改动 | 改哪个文件、加/改哪条规则，给出拟定措辞 |
| 为什么更好 | 相对现做法的优势 + 泛化性判定（本域通用/跨域通用） |
| 验证方式 | 怎么确认改完有效（某类编排不再翻车的判据） |
| 来源 retro | 溯源到 orchestration/retro/ 的具体条目 |
| 状态 | 待沉淀 / 已沉淀（回灌后标记，保留不删） |

## 纪律
- 经验包必须**自包含**：禁止「按我们刚才说的那样改」这类依赖上下文的写法。
- 只对**本域（全栈编排）普遍更好**的落这里；若是**所有 SDD 域都更好**的范式，应进一步走母机 `/sdd-distill`+`/sdd-absorb` 升级框架核心。
- 已回灌的经验包标「已沉淀」并保留溯源，不删除。
