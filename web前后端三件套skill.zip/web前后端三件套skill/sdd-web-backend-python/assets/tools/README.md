# 可选工具：源码覆盖索引 + 迭代文档初筛

> **可选**。模式 B 的核心是 `specs/context/` 认知层，**不是**这两个脚本。没有 Python 或不想用脚本时直接跳过，由 AI 手工建源码清单/覆盖表、按门禁手工核对即可，效果对等（见 `references/mode-b-twin.md` §7、§8）。
>
> 两个脚本均**零第三方依赖**（仅 Python 3.11+ 标准库），不使用 SQLite、不生成 HTML、不依赖网络。

## build_source_index.py —— 基于 ast 的 .py 源码索引

用 Python 标准库 `ast` 解析 `.py`，比正则更准确地识别 FastAPI 后端结构：

- **函数与协程**：`def` 与 `async def` 都收（记录 `is_async`），限定名经作用域栈拼出，方法/嵌套函数可区分（如 `UserService.update_user`）。
- **类 / 装饰器**：类定义、装饰器解析为点号名（`router.get`、`app.post`）。
- **FastAPI 路由**：装饰器方法命中 `get/post/put/patch/delete/head/options/trace` 或 `*.api_route` 时，产出 `Route{method, path, handler, is_async, lineno}`；路径取首个位置字符串字面量或 `path=` 关键字，取不到则 `<dynamic>`。
- **import**：`import` / `from ... import ...` 均收，多行/括号/`as` 别名由 `ast` 原生处理（不会像正则那样漏掉）。
- **编码**：按 PEP 263 用 `tokenize.open` 读取（默认 UTF-8），并记录每个文件的实际编码；**不做 GBK/latin-1 静默回退**，解码失败记为 `encoding_error` 并跳过 + stderr 告警。
- **健壮性**：`SyntaxError` 记为 `parse_error`（含出错信息）+ stderr 告警，不静默丢弃。

### 用法
把脚本复制到项目 `specs/_tools/` 下运行：
```bash
python build_source_index.py --root <项目根> --out specs/_generated/source-index
```
产物（JSON + `summary.md`，含 `routes.json`、`summary.json`，摘要带 `route_count` 与 `async_function_count`）落在 `specs/_generated/source-index/`，**不要混入 `specs/context/` 正文**——它可重建、可丢弃。

### 边界（务必知道它看不到什么）
- **静态解析**：运行期动态注册的路由（`app.include_router(...)` 动态拼装、循环/工厂里注册、由变量决定的路径）**看不见**。
- 覆盖比对（文件/符号名是否出现在 `context/`）是**粗略线索**，不是精确调用图。
- 产物仅作 **AI 盘点辅助、非事实裁决源**。需要更细的依赖/调用图时用本域生态工具（mypy、pydeps、griffe 等）。

## check_iteration_docs.py —— 存在性/日期头机械初筛

只读，不改任何文件。它做的是**机械的存在性 + 日期头初筛**，用来快速发现「task.md 没建、没写迭代日期头、阶段 current.md 空着或残留占位符」这类低级遗漏。

- **CRITICAL（失败即退出码 1）**：`specs/task.md` 存在且非空；顶部约 12 行内有一个**日历有效**的 `YYYY-MM-DD`（含 `迭代日期:` 头本身的日期校验）。
- **WARN**：各已展开阶段目录 `1-constitution`..`6-deliver` 的 `current.md` 是否非空、是否残留占位符（`<!-- 待填 -->` / `TODO` / `FIXME` / Gate 段未勾选 `- [ ]`）、是否残留「状态: 已交付待归档」仍当 current.md；`task/` 是否已归档；`context/iteration-log.md` 是否就位。
- **INFO**：`open-issues.md`、`retro/README.md` 是否就位。
- 只按 UTF-8 读取；解码失败**报告文件名并跳过，不猜测编码**。

### 用法
```bash
python check_iteration_docs.py --root .
```

### 它不能代表 Gate 通过
**本工具只做机械存在性/日期头初筛，不能代表任何阶段 Gate 通过；Gate 需人工/AI 按 `gate-and-stages.md` 判定。** 退出码为 0 **不等于**任何阶段 Gate 通过——六阶段 Gate 完成、需求可追溯、测试证据、回滚策略、用户放行签字这些，脚本一律**无法**判定，必须人工/AI 依 `gate-and-stages.md` 逐项核对。无 Python 时全部手工核对，效果对等。
