#!/usr/bin/env python3
"""Iteration-boundary document existence / date-header mechanical screen (read-only, changes no file).

This tool only does mechanical existence / date-header screening; it can never
stand in for any stage gate — gates are judged by a human or the AI per
gate-and-stages.md.

What it can deterministically check:
- specs/task.md exists and is non-empty;
- the first ~12 lines of task.md carry a calendar-valid YYYY-MM-DD (including a
  `迭代日期:` header check);
- each stage dir 1-constitution..6-deliver has a non-empty current.md, free of
  leftover placeholders;
- the three-field date header (迭代标识/迭代日期/状态) on task.md and every
  present current.md is well-formed and its 状态 value is inside the frozen set;
- task/ archive, context/iteration-log.md, open-issues.md, retro/README.md are
  in place.

What it CANNOT judge (must be judged by a human/AI per gate-and-stages.md):
- whether each stage's gate has actually passed;
- requirement traceability;
- whether test evidence is sufficient and was actually run;
- whether the rollback strategy holds up;
- whether the user has signed off.

Exit codes: 0 = critical items pass; 1 = critical items fail.
Note: exit code 0 only means the mechanical screen passed — it does NOT mean
any stage gate has passed.

Usage (run at the project root):
  python check_iteration_docs.py --root .
"""
from __future__ import annotations

import argparse
import datetime
import json
import re
import sys
from pathlib import Path

# Date header: a YYYY-MM-DD appearing anywhere in the scanned head, with capture
# groups so the caller can rebuild y/m/d for calendar-validity checking.
DATE_RE = re.compile(r"(\d{4})-(\d{2})-(\d{2})")
# `迭代日期:` / `迭代日期：` header (half-width or full-width colon).
ITER_DATE_RE = re.compile(r"迭代日期\s*[:：]\s*(\d{4}-\d{2}-\d{2})")

STAGE_DIRS = [
    "1-constitution", "2-spec", "3-design", "4-tasks", "5-test", "6-deliver",
]
# Leftover placeholder markers.
PLACEHOLDER_MARKS = ["<!-- 待填 -->", "TODO", "FIXME"]
UNCHECKED_BOX_RE = re.compile(r"^\s*-\s*\[\s\]", re.MULTILINE)
STALE_DELIVERED_RE = re.compile(r"状态\s*[:：]\s*已交付待归档")

# Frozen three-field date-header contract (specs-lifecycle.md §3). These are
# language-bound literal values, not implementation — translating them would
# break the contract, so they stay in Chinese verbatim.
STATUS_SET = ("就绪", "进行中", "已交付待归档")
FIELD_NAMES = ("迭代标识", "迭代日期", "状态")
HEADER_RE = re.compile(r"^\s*<!--(?P<body>.+?)-->\s*$")


class DecodeError(Exception):
    """UTF-8 decoding failed; report only, never guess another encoding."""


def read_utf8(p: Path) -> str:
    """Read strictly as UTF-8; raise DecodeError on failure instead of guessing."""
    try:
        return p.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise DecodeError(str(exc)) from exc


def is_valid_calendar_date(y: int, m: int, d: int) -> bool:
    try:
        datetime.date(y, m, d)
        return True
    except ValueError:
        return False


def find_valid_date_in_head(head: str) -> str | None:
    """Find the first calendar-valid YYYY-MM-DD in the given head text."""
    for match in DATE_RE.finditer(head):
        y, m, d = int(match.group(1)), int(match.group(2)), int(match.group(3))
        if is_valid_calendar_date(y, m, d):
            return match.group(0)
    return None


def check_date_header(text: str, label: str) -> tuple[str, str]:
    """Grade the three-field date header (specs-lifecycle.md §3).

    Returns (level, detail) with level in "ok" / "warn" / "critical".

    Only an **out-of-set 状态 value** is critical. A legacy header written before
    the field set was frozen may still split into four fields (an inline status
    enumeration); such files are read under legacy tolerance — take field 3 and
    warn. Rationale: archived files are protected by F3 (no overwrite / delete),
    so a hard red light on a file the framework forbids editing could never be
    cleared. Never repairs, never guesses a value.

    `text` must already be UTF-8-decoded by the caller (see read_utf8); this
    function does no file I/O of its own, so a decode failure is reported once,
    at the read site, instead of being silently retried under another encoding.
    """
    if not text.strip():
        return "warn", f"{label}: file is empty, no date header"

    m = HEADER_RE.match(text.splitlines()[0])
    if not m:
        return "warn", f"{label}: first line is not a date-header comment"

    parts = [seg.strip() for seg in m.group("body").split("|")]
    if len(parts) < 3:
        return "warn", f"{label}: date header splits into {len(parts)} fields, expected exactly 3"

    legacy = ""
    if len(parts) > 3:
        legacy = (
            f"{label}: date header splits into {len(parts)} fields — legacy inline status "
            f"enumeration ('|' is the field separator); reading field 3 only"
        )
        parts = parts[:3]

    for got, want in zip(parts, FIELD_NAMES):
        if not got.startswith(f"{want}: "):
            return "warn", f"{label}: field '{got}' does not start with '{want}: '"

    status = parts[2].split(":", 1)[1].strip()
    if status not in STATUS_SET:
        return "critical", f"{label}: 状态 value '{status}' is outside the frozen set {'/'.join(STATUS_SET)}"

    return ("warn", legacy) if legacy else ("ok", "")


def main() -> int:
    ap = argparse.ArgumentParser(
        description="Iteration-boundary document existence / date-header mechanical screen (read-only; no gate implied)."
    )
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    specs = root / "specs"

    # (name, ok, level, detail)  level: critical|warn|info
    checks: list[tuple[str, bool, str, str]] = []
    decode_errors: list[str] = []

    def safe_read(p: Path) -> str | None:
        try:
            return read_utf8(p)
        except DecodeError as exc:
            rel = p.relative_to(root).as_posix() if p.is_relative_to(root) else str(p)
            decode_errors.append(f"{rel}: {exc}")
            print(f"[warning] UTF-8 decode failed, skipped without guessing another encoding: {rel} — {exc}", file=sys.stderr)
            return None

    # ---- CRITICAL: task.md exists, non-empty + calendar-valid date header ----
    task = specs / "task.md"
    task_txt = safe_read(task) if task.exists() else None
    has_task = bool(task_txt is not None and task_txt.strip() != "")
    checks.append(("specs/task.md exists and is non-empty", has_task, "critical", str(task) if not has_task else ""))

    date_ok = False
    date_detail = ""
    if has_task and task_txt is not None:
        head = "\n".join(task_txt.splitlines()[:12])
        iter_match = ITER_DATE_RE.search(head)
        if iter_match:
            # A `迭代日期:` header is present — validate it is itself calendar-valid.
            y, m, d = iter_match.group(1).split("-")
            date_ok = is_valid_calendar_date(int(y), int(m), int(d))
            date_detail = "" if date_ok else f"invalid date in 迭代日期 header: {iter_match.group(1)}"
        else:
            found = find_valid_date_in_head(head)
            date_ok = found is not None
            date_detail = "" if date_ok else "no calendar-valid YYYY-MM-DD or `迭代日期:` header found in the first 12 lines"
    else:
        date_detail = "task.md missing or empty, cannot check date header"
    checks.append(("task.md carries a calendar-valid date header (current iteration)", date_ok, "critical", date_detail))

    # ---- WARN: per-stage current.md; also collect texts for the date-header pass below ----
    stage_texts: dict[str, str | None] = {}
    for stage in STAGE_DIRS:
        stage_dir = specs / stage
        if not stage_dir.exists():
            continue  # stage not yet opened, nothing required
        cur = stage_dir / "current.md"
        cur_txt = safe_read(cur) if cur.exists() else None
        stage_texts[stage] = cur_txt
        cur_ok = bool(cur_txt is not None and cur_txt.strip() != "")
        detail = ""
        if not cur_ok:
            detail = f"{stage}/current.md missing or empty"
        else:
            problems: list[str] = []
            for mark in PLACEHOLDER_MARKS:
                cnt = cur_txt.count(mark)
                if cnt:
                    problems.append(f"{mark}×{cnt}")
            unchecked = len(UNCHECKED_BOX_RE.findall(cur_txt))
            if unchecked:
                problems.append(f"unchecked items - [ ]×{unchecked}")
            if STALE_DELIVERED_RE.search(cur_txt):
                problems.append("residual '状态: 已交付待归档' still used as current.md")
            if problems:
                cur_ok = False
                detail = "; ".join(problems)
        checks.append((f"{stage}/current.md is non-empty and free of placeholder residue", cur_ok, "warn", detail))

    # ---- WARN: task/ archive ----
    task_dir = specs / "task"
    archives = sorted(task_dir.glob("*.md")) if task_dir.exists() else []
    big_task = bool(task_txt and len(task_txt) > 4000)
    checks.append((
        "task/ has archives (archive first · no overwrite)", bool(archives),
        "warn" if big_task else "info",
        f"{len(archives)} archive(s)" if archives
        else ("no archives; a large task.md should be archived first" if big_task else "no archives (possibly no history yet)"),
    ))

    # ---- date header contract: 状态 within frozen set / three-field shape ----
    # Reuse already-decoded texts (task_txt, stage_texts) instead of re-reading files.
    header_targets: list[tuple[str, str]] = []
    if task.exists() and task_txt is not None:
        header_targets.append(("specs/task.md", task_txt))
    for stage, cur_txt in stage_texts.items():
        if cur_txt is not None:
            header_targets.append((f"specs/{stage}/current.md", cur_txt))

    graded = [check_date_header(text, label) for label, text in header_targets]
    fatal = [d for lvl, d in graded if lvl == "critical"]
    shaky = [d for lvl, d in graded if lvl == "warn"]
    checks.append((
        "date header: 状态 within the frozen set 就绪/进行中/已交付待归档",
        not fatal,
        "critical",
        "; ".join(fatal) if fatal else f"{len(header_targets)} document(s) checked",
    ))
    checks.append((
        "date header shape: exactly 3 fields 迭代标识/迭代日期/状态",
        not shaky,
        "warn",
        "; ".join(shaky) if shaky else f"{len(header_targets)} document(s) checked",
    ))

    # ---- INFO / WARN: supporting docs ----
    iteration_log = specs / "context" / "iteration-log.md"
    checks.append(("context/iteration-log.md exists", iteration_log.exists(), "warn", str(iteration_log)))
    open_issues = specs / "open-issues.md"
    checks.append(("open-issues.md exists (governance entry)", open_issues.exists(), "info", str(open_issues)))
    retro_readme = specs / "retro" / "README.md"
    checks.append(("retro/README.md exists (retro ledger available)", retro_readme.exists(), "info", str(retro_readme)))

    critical_fail = [c for c in checks if c[2] == "critical" and not c[1]]

    # ---- output ----
    print("# Iteration-boundary document existence / date-header mechanical screen\n")
    print("> This tool only does mechanical existence / date-header screening; it can never")
    print("> stand in for any stage gate — gates are judged per gate-and-stages.md. Exit code 0 != gate passed.\n")
    for name, ok, level, detail in checks:
        mark = "✓" if ok else ("✗" if level == "critical" else "•")
        tag = {"critical": "[critical]", "warn": "[advice]", "info": "[info]"}[level]
        line = f"{mark} {tag} {name}"
        if detail:
            line += f" — {detail}"
        print(line)
    if decode_errors:
        print("\n## UTF-8 decode failures (skipped, not guessed)")
        for item in decode_errors:
            print(f"✗ {item}")
    print()
    print(json.dumps({
        "root": str(root),
        "critical_pass": not critical_fail,
        "critical_failed": [c[0] for c in critical_fail],
        "decode_errors": decode_errors,
        "checked_at": datetime.date.today().isoformat(),
        "note": "critical_pass only means the mechanical screen passed, not that any stage gate has passed.",
    }, ensure_ascii=False, indent=2))
    return 1 if critical_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
