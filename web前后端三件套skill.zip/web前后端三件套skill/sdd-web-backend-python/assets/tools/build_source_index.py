#!/usr/bin/env python3
"""基于 Python 标准库 ast 的轻量源码覆盖索引；识别 def/async def/类/装饰器/FastAPI 路由/import（含多行与别名）。仅覆盖 .py；编码失败显式报告不静默回退；产物仅作 AI 盘点辅助、非事实裁决源。"""

from __future__ import annotations

import argparse
import ast
import json
import re
import sys
import tokenize
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterable

# 需要跳过的目录（虚拟环境、缓存、构建产物、生成物等）
SKIP_DIRS = {
    ".git", ".svn", ".hg", ".idea", ".vscode",
    "node_modules", "dist", "build", "out", "target",
    ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", "_generated",
}

# FastAPI / Starlette 路由装饰器方法名（decorator 末段方法）
HTTP_METHODS = {
    "get", "post", "put", "patch", "delete", "head", "options", "trace",
}
# router.api_route(...) / app.api_route(...) 也视为路由声明
API_ROUTE_METHODS = {"api_route"}


@dataclass
class Symbol:
    """源码符号：函数/协程/类。qualname 通过作用域栈拼出，可区分方法与嵌套。"""
    name: str          # 简单名
    qualname: str      # 限定名，如 UserService.get_user、outer.inner
    kind: str          # "function" | "async_function" | "class"
    line: int
    is_async: bool
    decorators: list[str] = field(default_factory=list)  # 解析出的点号名列表


@dataclass
class Route:
    """FastAPI 路由声明。"""
    method: str        # HTTP 方法（大写）或 API_ROUTE
    path: str          # 路由路径；无法静态求值时为 "<dynamic>"
    handler: str       # 处理函数限定名
    is_async: bool
    line: int
    decorator: str     # 原始点号装饰器名，如 router.get


@dataclass
class ImportItem:
    """import 记录，多行/括号/别名均由 ast 原生处理。"""
    module: str        # 模块路径（from x import y 时为 x；import a.b 时为 a.b）
    name: str          # 导入名（import a.b 时为 a.b；from x import y 时为 y；* 为 "*"）
    alias: str | None  # as 别名
    line: int


@dataclass
class PyFile:
    """单个 .py 文件的解析结果。"""
    path: str
    extension: str
    size: int
    lines: int
    encoding: str                       # tokenize.open 探测到的实际编码
    status: str                         # "ok" | "parse_error" | "encoding_error"
    error: str                          # 出错信息（status != ok 时非空）
    symbols: list[Symbol] = field(default_factory=list)
    routes: list[Route] = field(default_factory=list)
    imports: list[ImportItem] = field(default_factory=list)


def iter_py_files(root: Path) -> Iterable[Path]:
    """遍历项目根下的所有 .py 文件，跳过 SKIP_DIRS。"""
    for path in root.rglob("*.py"):
        if not path.is_file():
            continue
        parts = set(path.relative_to(root).parts)
        if parts & SKIP_DIRS:
            continue
        yield path


def decorator_to_dotted(node: ast.expr) -> tuple[str, ast.expr | None]:
    """把装饰器表达式解析成点号名，并返回被调用对象（若为 Call）。

    例：@router.get("/x") -> ("router.get", Call 节点)
        @app.post        -> ("app.post", None)
    返回 (dotted_name, call_node_or_None)。
    """
    call_node: ast.Call | None = None
    target: ast.expr = node
    if isinstance(node, ast.Call):
        call_node = node
        target = node.func

    parts: list[str] = []
    cur: ast.expr | None = target
    while isinstance(cur, ast.Attribute):
        parts.append(cur.attr)
        cur = cur.value
    if isinstance(cur, ast.Name):
        parts.append(cur.id)
    else:
        # 非普通点号链（如下标、调用结果），无法给出稳定名
        parts.append("<expr>")
    dotted = ".".join(reversed(parts))
    return dotted, call_node


def extract_route_path(call: ast.Call) -> str:
    """从路由装饰器调用里取路径：优先首个位置字符串字面量，其次 path= 关键字。"""
    for arg in call.args:
        if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
            return arg.value
        break  # 首个位置参数不是字符串字面量则不再猜测
    for kw in call.keywords:
        if kw.arg == "path" and isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
            return kw.value.value
    return "<dynamic>"


class SourceVisitor:
    """遍历 AST，维护作用域栈以拼出限定名，收集符号/路由/import。"""

    def __init__(self) -> None:
        self.symbols: list[Symbol] = []
        self.routes: list[Route] = []
        self.imports: list[ImportItem] = []
        self._scope: list[str] = []

    def _qual(self, name: str) -> str:
        return ".".join(self._scope + [name]) if self._scope else name

    def visit(self, node: ast.AST) -> None:
        for child in ast.iter_child_nodes(node):
            self._dispatch(child)

    def _dispatch(self, node: ast.AST) -> None:
        if isinstance(node, ast.ClassDef):
            self._handle_class(node)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self._handle_func(node)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                self.imports.append(ImportItem(
                    module=alias.name, name=alias.name,
                    alias=alias.asname, line=node.lineno,
                ))
            self.visit(node)
        elif isinstance(node, ast.ImportFrom):
            module = ("." * (node.level or 0)) + (node.module or "")
            for alias in node.names:
                self.imports.append(ImportItem(
                    module=module, name=alias.name,
                    alias=alias.asname, line=node.lineno,
                ))
            self.visit(node)
        else:
            # 其它节点继续下钻（覆盖函数体内的嵌套 def/class 等）
            self.visit(node)

    def _handle_class(self, node: ast.ClassDef) -> None:
        decorators = [decorator_to_dotted(d)[0] for d in node.decorator_list]
        self.symbols.append(Symbol(
            name=node.name, qualname=self._qual(node.name), kind="class",
            line=node.lineno, is_async=False, decorators=decorators,
        ))
        self._scope.append(node.name)
        self.visit(node)
        self._scope.pop()

    def _handle_func(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        is_async = isinstance(node, ast.AsyncFunctionDef)
        qual = self._qual(node.name)
        decorators: list[str] = []
        for dec in node.decorator_list:
            dotted, call = decorator_to_dotted(dec)
            decorators.append(dotted)
            method = dotted.rsplit(".", 1)[-1] if "." in dotted else ""
            if method in HTTP_METHODS or method in API_ROUTE_METHODS:
                if method in API_ROUTE_METHODS:
                    http = "API_ROUTE"
                    path = extract_route_path(call) if call else "<dynamic>"
                else:
                    http = method.upper()
                    path = extract_route_path(call) if call else "<dynamic>"
                self.routes.append(Route(
                    method=http, path=path, handler=qual,
                    is_async=is_async, line=node.lineno, decorator=dotted,
                ))
        self.symbols.append(Symbol(
            name=node.name, qualname=qual,
            kind="async_function" if is_async else "function",
            line=node.lineno, is_async=is_async, decorators=decorators,
        ))
        self._scope.append(node.name)
        self.visit(node)
        self._scope.pop()


def parse_py_file(path: Path, rel: str) -> PyFile:
    """按 PEP 263 用 tokenize.open 读取 .py，再用 ast 解析；错误显式记录不静默。"""
    size = path.stat().st_size
    # tokenize.open 依 PEP 263 处理编码声明，默认 UTF-8；不做 GBK/latin-1 静默回退。
    try:
        with tokenize.open(path) as fh:
            text = fh.read()
            encoding = fh.encoding
    except (UnicodeDecodeError, SyntaxError) as exc:
        # SyntaxError 可能来自非法编码声明；统一按编码错误处理
        msg = f"编码读取失败：{exc}"
        print(f"[警告] 跳过（编码错误）：{rel} — {msg}", file=sys.stderr)
        return PyFile(
            path=rel, extension=".py", size=size, lines=0,
            encoding="unknown", status="encoding_error", error=msg,
        )

    lines = text.count("\n") + 1
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        msg = f"语法解析失败：{exc.msg} (行 {exc.lineno})"
        print(f"[警告] 解析失败（记为 parse_error）：{rel} — {msg}", file=sys.stderr)
        return PyFile(
            path=rel, extension=".py", size=size, lines=lines,
            encoding=encoding, status="parse_error", error=msg,
        )

    visitor = SourceVisitor()
    visitor.visit(tree)
    visitor.symbols.sort(key=lambda s: (s.line, s.qualname))
    visitor.routes.sort(key=lambda r: r.line)
    visitor.imports.sort(key=lambda i: i.line)
    return PyFile(
        path=rel, extension=".py", size=size, lines=lines,
        encoding=encoding, status="ok", error="",
        symbols=visitor.symbols, routes=visitor.routes, imports=visitor.imports,
    )


def find_entrypoints(pf: PyFile) -> list[dict[str, object]]:
    """入口线索：优先来自发现的 FastAPI 路由，其次补充启发式命名的符号。"""
    entries: list[dict[str, object]] = []
    for route in pf.routes:
        entries.append({
            "path": pf.path, "name": route.handler, "kind": "route",
            "line": route.line, "reason": f"route:{route.method} {route.path}",
            "is_async": route.is_async,
        })
    route_handlers = {r.handler for r in pf.routes}
    for sym in pf.symbols:
        if sym.qualname in route_handlers:
            continue  # 已作为路由入口记录，避免重复
        lowered = sym.name.lower()
        if sym.name == "main":
            reason = "main"
        elif "handler" in lowered:
            reason = "handler"
        elif lowered.startswith("task") or lowered.endswith("task"):
            reason = "task"
        elif sym.kind == "class" and ("service" in lowered or "controller" in lowered):
            reason = "service-entry"
        else:
            continue
        entries.append({
            "path": pf.path, "name": sym.qualname, "kind": sym.kind,
            "line": sym.line, "reason": reason, "is_async": sym.is_async,
        })
    return entries


def collect_context_text(root: Path) -> str:
    """汇总 specs/context/*.md 文本，用于覆盖线索比对（读失败的文件跳过）。"""
    context_dir = root / "specs" / "context"
    if not context_dir.exists():
        return ""
    chunks: list[str] = []
    for path in context_dir.rglob("*.md"):
        try:
            chunks.append(path.read_text(encoding="utf-8"))
        except (UnicodeDecodeError, OSError):
            continue
    return "\n".join(chunks)


def build_coverage(files: list[PyFile], context_text: str) -> list[dict[str, object]]:
    """粗略覆盖线索：文件路径/符号名是否在 context 文本中出现（仅辅助，非事实裁决）。"""
    ctx_norm = context_text.replace("\\", "/")
    coverage: list[dict[str, object]] = []
    for pf in files:
        mentioned = [
            s.name for s in pf.symbols
            if s.name and re.search(rf"\b{re.escape(s.name)}\b", context_text)
        ]
        file_mentioned = pf.path.replace("\\", "/") in ctx_norm
        coverage.append({
            "path": pf.path,
            "status": pf.status,
            "file_mentioned": file_mentioned,
            "symbol_count": len(pf.symbols),
            "mentioned_symbol_count": len(mentioned),
            "mentioned_symbols": mentioned[:50],
        })
    return coverage


def write_json(path: Path, data: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def build_summary(
    files: list[PyFile],
    entrypoints: list[dict[str, object]],
    coverage: list[dict[str, object]],
) -> dict[str, object]:
    """构造 summary.json 内容。"""
    ok_files = [f for f in files if f.status == "ok"]
    parse_errors = [f for f in files if f.status == "parse_error"]
    encoding_errors = [f for f in files if f.status == "encoding_error"]
    symbol_count = sum(len(f.symbols) for f in files)
    async_count = sum(1 for f in files for s in f.symbols if s.kind == "async_function")
    route_count = sum(len(f.routes) for f in files)
    uncovered = [
        c for c in coverage
        if c["status"] == "ok" and not c["file_mentioned"] and c["mentioned_symbol_count"] == 0
    ]
    return {
        "file_count": len(files),
        "ok_file_count": len(ok_files),
        "parse_error_count": len(parse_errors),
        "encoding_error_count": len(encoding_errors),
        "symbol_count": symbol_count,
        "async_function_count": async_count,
        "route_count": route_count,
        "entrypoint_count": len(entrypoints),
        "uncovered_file_count": len(uncovered),
        "parse_errors": [{"path": f.path, "error": f.error} for f in parse_errors],
        "encoding_errors": [{"path": f.path, "error": f.error} for f in encoding_errors],
        "note": "产物仅作 AI 盘点辅助、非事实裁决源；运行期动态注册的路由无法被静态识别。",
    }


def write_summary_md(out_dir: Path, summary: dict[str, object], entrypoints: list[dict[str, object]], coverage: list[dict[str, object]]) -> None:
    uncovered = [
        c for c in coverage
        if c["status"] == "ok" and not c["file_mentioned"] and c["mentioned_symbol_count"] == 0
    ]
    lines = [
        "# 源码覆盖索引摘要（ast）",
        "",
        f"- .py 文件数：{summary['file_count']}（解析成功 {summary['ok_file_count']}）",
        f"- 解析失败：{summary['parse_error_count']}；编码失败：{summary['encoding_error_count']}",
        f"- 符号数：{summary['symbol_count']}（其中 async def：{summary['async_function_count']}）",
        f"- FastAPI 路由数：{summary['route_count']}",
        f"- 入口线索数：{summary['entrypoint_count']}",
        f"- 未在 context 中出现的文件线索：{summary['uncovered_file_count']}",
        "",
        "> 本索引静态解析，运行期动态注册的路由不可见；仅作 AI 盘点辅助，非事实裁决源。",
        "",
        "## 入口线索",
    ]
    for item in entrypoints[:80]:
        flag = " async" if item.get("is_async") else ""
        lines.append(f"- `{item['name']}`{flag} ({item['reason']}) -> `{item['path']}:{item['line']}`")
    lines.extend(["", "## 可能未覆盖文件"])
    for item in uncovered[:120]:
        lines.append(f"- `{item['path']}`")
    (out_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="基于 ast 的轻量 .py 源码覆盖索引（SDD 模式 B 辅助工具）。"
    )
    parser.add_argument("--root", default=".", help="项目根目录")
    parser.add_argument("--out", default="specs/_generated/source-index", help="输出目录")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    out_dir = (root / args.out).resolve()

    files: list[PyFile] = []
    for path in sorted(iter_py_files(root)):
        rel = path.relative_to(root).as_posix()
        files.append(parse_py_file(path, rel))

    entrypoints = [entry for pf in files for entry in find_entrypoints(pf)]
    context_text = collect_context_text(root)
    coverage = build_coverage(files, context_text)
    summary = build_summary(files, entrypoints, coverage)

    # 明细产物
    inventory = []
    for pf in files:
        d = asdict(pf)
        inventory.append(d)
    all_routes = [
        {**asdict(r), "file": pf.path}
        for pf in files for r in pf.routes
    ]
    dependencies = [
        {"path": pf.path, "imports": [asdict(i) for i in pf.imports]}
        for pf in files if pf.imports
    ]
    uncovered = [
        c for c in coverage
        if c["status"] == "ok" and not c["file_mentioned"] and c["mentioned_symbol_count"] == 0
    ]

    write_json(out_dir / "inventory.json", inventory)
    write_json(out_dir / "entrypoints.json", entrypoints)
    write_json(out_dir / "routes.json", all_routes)
    write_json(out_dir / "dependencies.json", dependencies)
    write_json(out_dir / "coverage.json", coverage)
    write_json(out_dir / "unresolved.json", uncovered)
    write_json(out_dir / "summary.json", summary)
    write_summary_md(out_dir, summary, entrypoints, coverage)

    print(json.dumps({
        "files": summary["file_count"],
        "ok_files": summary["ok_file_count"],
        "parse_errors": summary["parse_error_count"],
        "encoding_errors": summary["encoding_error_count"],
        "symbols": summary["symbol_count"],
        "async_functions": summary["async_function_count"],
        "routes": summary["route_count"],
        "entrypoints": summary["entrypoint_count"],
        "uncovered": summary["uncovered_file_count"],
        "out": str(out_dir),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
