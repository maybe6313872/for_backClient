<!-- 迭代标识: {简短说明} | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
# 5-test / current.md

## 当前测试版本
- 生效文件：`specs/5-test/YYYY-MM-DD-test-xxx.md`（可选）
- 生效日期：YYYY-MM-DD

## 测试环境
| 项目 | 配置 |
|------|------|
| 运行/测试环境 | <!-- 本域测试环境描述 --> |
| 程序/版本 | <!-- 版本标识 --> |
| 依赖/外部对象 | <!-- 被测系统依赖的外部对象/桩 --> |
| Python / 包管理 | Python 3.11+ / uv（或 pip） |
| 数据库 | 测试库或容器（PostgreSQL/MySQL）/ 事务回滚 fixture |
| ASGI 测试客户端 | httpx.AsyncClient + ASGITransport |

## Gate 自检
- [ ] 构建通过
- [ ] 测试用例覆盖 spec 验收点
- [ ] 执行记录与证据已归档
- [ ] 漏测风险已标注
- [ ] 每个测试结论均标注 L1-L5 证据等级
- [ ] 涉及代码修改时，编码一致性自检已完成

## 证据分级
| 测试项 | 结果 | 证据等级 | 证据路径 | 未测边界 |
|---|---|---|---|---|
| | PASS/FAIL/BLOCKED | L1/L2/L3/L4/L5 | | |

等级说明见 references/evidence-gate-protocol.md（本域措辞）。

## 编码一致性自检
本域源码默认 UTF-8、无 GBK 遗留，无需乱码扫描。仅自检：① 改动文件 UTF-8(无 BOM)、LF 行尾；② Ruff/格式化未引入编码问题；③ 中文字符串/注释显示正常。

## 本域专项测试清单
<!-- 以下每项 MUST 在 Gate 前逐一确认；按本域高频风险定制 -->
- [ ] 端到端用 httpx.AsyncClient 覆盖：正常路径 + 鉴权失败 + 校验失败(422) + 领域错误分支
- [ ] DB 用独立测试库/事务回滚隔离，未触碰生产/共享库
- [ ] Alembic 迁移在测试库验证 upgrade/downgrade
- [ ] 外部依赖（第三方 API/MQ/缓存）已用桩/mock，未臆测真实响应
- [ ] `mypy --strict` 与 `ruff check` 通过；OpenAPI 契约与实现一致
- [ ] 每条结论标 L1-L5，未测边界已列入风险

## 边界提醒
本阶段 MUST NOT：新增需求 → 回流 **spec**；设计变更 → 回流 **design**；新增功能。
