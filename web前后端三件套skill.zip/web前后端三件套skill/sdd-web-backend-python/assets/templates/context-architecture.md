# 架构上下文

> 用途：记录 FastAPI 后端项目的路由层、服务层、数据访问层、外部依赖之间的稳定关系。

## 1. 架构总览

```mermaid
flowchart TD
    A[客户端/网关] --> B[中间件]
    B --> C[路由层 router/APIRouter]
    C --> D[服务/领域层 service]
    D --> E[数据访问层 repository/ORM]
    E --> F[DB / 外部依赖]
    X[横切: DI·中间件·配置·日志] -.-> C
    X -.-> D
    X -.-> E
```

## 2. 分层职责

| 层级 | 职责 | 典型目录/文件 | 禁止事项 |
|---|---|---|---|
| 路由层 router | 入出参绑定、Pydantic 校验、依赖注入、状态码 | `app/api/routes/*.py` | 不写业务规则/直连 DB |
| 服务/领域层 service | 业务规则、事务编排、外部调用 | `app/services/*.py` | 不感知 HTTP/请求对象 |
| 数据访问层 repository/ORM | 持久化读写、查询封装 | `app/repositories/*.py`、ORM 模型 | 不写业务分支 |
| DB / 外部依赖 | 数据库、缓存、消息队列、第三方 API | | 不被上层绕过抽象直连 |
| 横切 | DI、中间件、配置、日志 | `app/core/*.py`、`app/deps.py` | 不散落隐式全局状态 |

## 3. 关键设计约束

| 约束 | 当前结论 | 证据来源 |
|---|---|---|
| 最小侵入策略 | | |
| async/sync 一致性模型 | | |
| 配置/密钥来源(pydantic-settings) | | |
| 构建与部署链路 | | |

