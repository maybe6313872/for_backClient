<!-- 迭代标识: {简短说明} | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
# 6-deliver / current.md

## 当前交付版本

- changelog：`specs/6-deliver/YYYY-MM-DD-changelog.md`
- release-note：`specs/6-deliver/YYYY-MM-DD-release-note.md`
- rollout：`specs/6-deliver/YYYY-MM-DD-rollout.md`

## 交付门禁（最小）

- [ ] changelog 已更新
- [ ] release-note 已更新
- [ ] rollout/回滚策略明确
- [ ] 证据齐全（日志/截图/制品）
- [ ] spec 中所有验收标准在 test 中有对应结果
- [ ] 无未关闭的 Fail 用例（或已决定豁免并记录理由）
- [ ] 已引用 test 阶段最高证据等级
- [ ] 交付语义未高于 test 最高证据等级
- [ ] `specs/task.md` 已更新(完成/未完成/阻塞/下一步)+5 行摘要，并归档到 `specs/task/YYYY-MM-DD-<说明>.md`（禁止直接覆盖）
- [ ] `specs/context/iteration-log.md` 已追加本迭代一行
- [ ] `specs/open-issues.md` 已闭合项收口、未闭合项进交付风险
- [ ] 复盘判定：本迭代有无犯错/亮点值得复盘？有 → `/sdd-retro` 写入 `specs/retro/`

## 交付等级判定

| 最高证据等级 | 可用交付语义 | 当前判定 |
|---|---|---|
| L1/L2 | 开发草案 / 提测候选 | |
| L3 | 阶段性参考包 | |
| L4 | 测试通过候选包 | |
| L5 | 可发布交付包 | |

## 已开发 / 未开发收口

| 模块 | 已开发内容 | 未开发内容 | 证据等级 | 后续处理 |
|---|---|---|---|---|
| | | | L1/L2/L3/L4/L5 | |

## 交付信息（可选）

- 版本号：
- 构建产物：
- 交付对象：

## 边界提醒

本阶段聚焦整理和记录，MUST NOT 出现以下内容：

- 新增功能实现 → 回流 **spec → tasks**
- 修改接口/架构 → 回流 **design**
- 补测试用例 → 回流 **test**

交付阶段发现的问题一律通过回流机制处理，不在交付文档中直接修复。
