# 项目认知 — {项目名称}

> 生成日期：YYYY-MM-DD | 维护人：@姓名
> 本文件是 spec 工作流的信息基础，进入任何阶段前 MUST 先阅读本文件。

## 项目概览
| 项目 | 说明 |
|------|------|
| 项目名称 | |
| 项目类型 | <!-- Python Web 后端服务 下的具体类型 --> |
| 技术栈 | <!-- Python 3.11+、FastAPI/Starlette/Uvicorn（ASGI，生产 Gunicorn+uvicorn worker）、Pydantic v2 + pydantic-settings、SQLAlchemy 2.0(async) + Alembic、asyncpg(PostgreSQL)/aiomysql·asyncmy(MySQL)、mypy(strict) + Ruff、pytest + pytest-asyncio + httpx.AsyncClient、uv 优先（pip 兜底） --> |
| 构建方式 | <!-- 本域构建命令 --> |
| 运行/部署方式 | <!-- 如何运行或部署 --> |
| 仓库地址 | <!-- git 仓库 URL（如有）--> |
| Python 版本 | <!-- 如 3.12 --> |
| 依赖/环境管理 | <!-- uv（优先）/ pip --> |
| 数据库 / ORM / 迁移 | <!-- 如 PostgreSQL + SQLAlchemy 2.0 async + Alembic --> |
| ASGI 服务器 | <!-- Uvicorn / Gunicorn --> |

## 非功能约束 / 运行契约
<!-- 本域关键非功能约束：并发/QPS 目标、P95 延迟、SLA、DB 连接上限、超时与重试、限流、资源配额、数据一致性级别 -->

## 目录结构
<!-- 项目源码目录树（2-3 层深度），标注关键目录和文件的用途 -->

## 已实现功能清单
<!-- 模式 B 必填：现状有哪些功能模块，各自入口 -->

## 模块 / context 索引
<!-- 指向 specs/context/* 各文档 -->

## 编码风格与约定
<!-- 命名、分层、本域源码默认 UTF-8、无 GBK 遗留，故不强制乱码自检；仅需保证文件 UTF-8(无 BOM)、LF 行尾。 -->

## 参考文档索引
<!-- 指向 docs/converted/README.md -->
