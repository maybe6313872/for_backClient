# 代码地图 — {项目名称}

> 项目的导航索引：文件 → 类/函数/协程 → 调用关系 → import 依赖 → 路由注册。
> **优先用脚本生成**：`python specs/_tools/build_source_index.py --root .`（基于 Python ast，产物落 `specs/_generated/source-index/`，不覆盖本文件）。
> 脚本跑不了时，按本模板手工填，至少完成「函数符号索引 + import 依赖」两项。
> 用途与边界见 references/code-map.md。更新日期：YYYY-MM-DD

## 概览

- 源文件：<!-- N -->
- 函数/协程定义：<!-- N（覆盖度自检的分母）-->
- 模块：<!-- M -->

## 函数符号索引

| 函数 | 文件 | 行 | 签名 |
|---|---|---|---|
| `get_user` | `app/api/routes/users.py` | 12 | `async def get_user(user_id: int) -> UserOut` |
| | | | |

## import 依赖（按文件）

- **`app/api/routes/users.py`** → 项目: `app.services.user_service`, `app.schemas.user`；三方: `fastapi`, `sqlalchemy`
- <!-- ... -->

## 路由注册（按需）

| 方法 | 路径 | 处理函数 | 所在文件 |
|---|---|---|---|
| GET | `/users/{user_id}` | `get_user` | `app/api/routes/users.py` |
| | | | |

## 调用关系（按需，能建多少建多少）

| 调用方 | 被调用 |
|---|---|
| `get_user` | `user_service.get_user`, `UserRepository.by_id` |
| | |

## 类型与 schema 索引（按文件，可选）

- **`app/schemas/user.py`**
  - Pydantic schema: `UserCreate`, `UserOut`
  - 枚举/类型: `UserStatus`
