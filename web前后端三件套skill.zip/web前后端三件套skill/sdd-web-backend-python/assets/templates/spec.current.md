<!-- 迭代标识: {简短说明} | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
# 2-spec / current.md

## 当前生效 Spec

- overall：`specs/2-spec/YYYY-MM-DD-overall.md`（或 `specs/2-spec/子功能A/YYYY-MM-DD-xxx.md`）
- 生效日期：YYYY-MM-DD
- 维护人：@姓名

## 范围与状态

- In Scope：
- Out of Scope：
- 当前状态：Draft / Clarifying / Frozen（冻结可进入 design/tasks）

## Clarify 状态（门禁）

- 关键澄清未关闭项：0 个（未关闭关键澄清 MUST NOT 进入 design（与 gate-and-stages.md 同强度））
- Clarify 记录：
    - `specs/2-spec/clarify-log.md`（可选）或写入 spec 文档内

## 本次迭代摘要（可选）

- 新增/变更需求：
- 影响面：
- 需要同步的干系人：

## Gate 自检

- [ ] 每条需求具备验收标准（可测试/可观察/可留证据）
- [ ] 覆盖边界与异常（超时/断链/重启/非法输入）
- [ ] 明确证据口径（日志/HTTP 响应/pytest 报告/OpenAPI 快照）
- [ ] 未混入设计方案（How）——如有，移到 design
- [ ] 图表仅展示需求视角（做什么），未展示设计视角（怎么做）
- [ ] 关键 Clarify 已关闭

## 边界提醒

<!-- 本阶段 MUST NOT 出现以下内容，如有请移到对应阶段 -->
<!-- - 具体技术方案（How）、接口定义、代码结构、模块划分 → design -->
<!-- - 任务拆解、修改文件清单 → tasks -->
<!-- - 测试用例 → test -->
