<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->

# 工程质量基线审计（模式 B · 本域）

> 用途：盘点存量 FastAPI 项目的**工程质量能力现状**，产出「现状 → 对应 RULE → 差距 → 本次处置」清单。不只建代码认知，更要暴露缺失的质量门禁。差距逐条挂 `open-issues.md`（未闭合）与 `task.md`（拟改进）。处置遵循 RULE-PROC-05（最小改动、推荐栈≠项目事实）。协议见 references/mode-b-twin.md §6a。

## 技术画像（先记录，再决定升级）
- Python 版本（证据：requires-python/锁/镜像/CI/语法）：<...>
- async/sync 栈：<async(asyncpg/…) | 同步驱动 | 混合>
- 数据访问方式：<SQLAlchemy 2.0 | 1.x | 原生 SQL | 其他 ORM>
- 迁移机制：<Alembic | 其他 | 无>
- 包管理：<uv | poetry | pip+requirements | 其他>
- 契约权威来源：<code-first | contract-first | 双向 | 未定>
- 错误载体：<problem+json | 既有业务信封 {code,message,data} | 各端点不一>

## 基线审计矩阵

| 维度 | 现状 | 对应 RULE | 是否满足 | 差距 | 本次处置(整改/记债/阻塞) |
|---|---|---|---|---|---|
| 类型检查 | <mypy?配置?范围?strict?> | RULE-TYPE | <是/部分/否> | <...> | <...> |
| Lint/格式化 | <Ruff?配置?命令?> | RULE-LINT | | | |
| 测试层级 | <单元/服务/集成/接口/迁移?可发现?> | RULE-TEST | | | |
| 覆盖率 | <coverage?基线?分支?不退化?> | RULE-CI | | | |
| 统一质量入口/CI | <make check?CI?阻断?产物?> | RULE-CI | | | |
| 依赖锁 | <锁文件?哈希?frozen?三分?> | RULE-DEP | | | |
| Python 版本闭环 | <各来源一致?CI 最低版本?> | RULE-DEP-03 | | | |
| 契约产物 | <openapi 快照?oasdiff?op_id 唯一?> | RULE-API-05/06 | | | |
| 迁移机制 | <可回滚?autogenerate 残差?> | RULE-DB-03 | | | |
| 配置/组合根 | <单一入口?启动校验?组合根?import-safe?> | RULE-CONF-02/RULE-DI | | | |
| 模块闭包 | <闭包 or 全塞 api.py/models.py?> | RULE-STRUCT | | | |
| i18n | <消息所有权?按模块?稳定键?完整性检查?> | RULE-I18N | | | |
| 错误模型 | <收口?一致?稳定标识?载体?> | RULE-ERR-03 | | | |
| vendor/legacy | <仓内遗留?只读边界?反腐层?工具排除?> | RULE-VENDOR | | | |

## 差距汇总（挂 open-issues / task）
- OPEN-<n>: <差距一句话> → open-issues.md
- TASK-<n>: <拟改进一句话> → task.md

> 处置不得静默略过；保持现状的项必须显式记债并说明原因与到期条件。
