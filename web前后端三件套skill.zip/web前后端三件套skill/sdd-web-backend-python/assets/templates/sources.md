<!--
模板：来源/新鲜度登记表（sources.md）——放在项目认知所依赖的外部输入登记处（通常 specs/context/sources.md，或某轮迭代的 specs/2-spec/inputs/sources.md）。

用途：登记「项目认知」所依赖的一切外部输入——需求规格书、上层派单包、跨仓 OpenAPI 契约、库表/接口约定、第三方 API 文档、外部规范等——并追踪它们的新鲜度，防止本项目基于已过期的上游信息继续开发。

与两个目录配对：
- 与 docs/requirements/ 需求收件箱配对：凡认领入库的外部输入（派单包/需求规格/契约变更通知）都在本表登记一行（见 references/requirement-inbox-protocol.md §6）。
- 与 docs/converted/ 文本化产物配对：二进制来源（xlsx/docx/pdf）经 /sdd-docs 文本化后，本表登记原始来源，converted/README.md 记文本化产物的 hash/日期映射（见 references/docs-binarification-adapter.md）。

规则：① 任何外部输入被本项目消费/认领即在本表登记一行；② 开迭代前巡检、或任何阶段消费该来源前，逐行核对源头当前版本/日期/哈希，不一致即把「新鲜度状态」改为「待复核/已过期」、上报用户、经确认后重取并更新本表；③ 源头不可达 → 标 ⚠️ 待确认 入 context/open-issues.md。
新鲜度状态取值：最新 / 待复核 / 已过期。
-->
# 来源/新鲜度登记表（sources.md）

| 来源名称 | 类型 | 位置或链接 | 版本或日期 | SHA或哈希(可选) | 最近核对日期 | 新鲜度状态 | 备注 |
|---|---|---|---|---|---|---|---|
| 用户中心需求规格书 | 需求规格书 | `docs/用户中心需求规格书.xlsx` | V1.6 / 2026-06-30 | `a1b2c3d4e5f6` | 2026-07-10 | 最新 | 已 /sdd-docs 文本化至 `docs/converted/用户中心需求规格书/` |
| 订单服务 OpenAPI 契约 | 跨仓契约 | `\\server\iot-cloud\order\openapi.yaml` | 2026-07-08 | `9f8e7d6c5b4a` | 2026-07-12 | 待复核 | 上游通知将新增字段，待核对后同步 Pydantic/SQLAlchemy 模型 |
| <来源名称> | <需求规格书/派单包/契约/API文档/规范/其他> | <路径或 URL> | <版本 / YYYY-MM-DD> | <sha256 前12位，可留空> | <YYYY-MM-DD> | <最新/待复核/已过期> | <备注> |
| <来源名称> | <> | <> | <> | <> | <> | <> | <> |
| <来源名称> | <> | <> | <> | <> | <> | <> | <> |
