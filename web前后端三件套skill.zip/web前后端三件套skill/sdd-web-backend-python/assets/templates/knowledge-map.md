# 知识地图 — {项目名称}

> `specs/` 的导航总台：想了解某件事，先查这张表去哪看。轻量维护，只放入口级指引。
> 用途与维护见 references/knowledge-map.md。更新日期：YYYY-MM-DD

## 项目认知
| 想了解什么 | 去哪看 | 最后更新 |
|---|---|---|
| 项目概览/技术栈/已实现功能 | `specs/README.md` | YYYY-MM-DD |
| 系统分层与数据流 | `context/architecture.md` | YYYY-MM-DD |
| 各模块职责与接口（孪生） | `context/modules.md` | YYYY-MM-DD |
| 数据模型/ORM | `context/data-model.md` | YYYY-MM-DD |
| 路由与端点契约 | `context/modules.md` | YYYY-MM-DD |
| 异步与并发模型 | `context/architecture.md` | YYYY-MM-DD |
| 外部触点 | `context/db-schema-and-config.md` | YYYY-MM-DD |
| 代码符号/调用关系 | `context/code-map.md` | YYYY-MM-DD |

## 当前迭代
| 想了解什么 | 去哪看 | 最后更新 |
|---|---|---|
| 当前在做什么 / 进度 | `specs/task.md` | YYYY-MM-DD |
| 本迭代需求 | `specs/2-spec/current.md` | YYYY-MM-DD |
| 本迭代设计 | `specs/3-design/current.md` | YYYY-MM-DD |
| 本迭代任务与执行进度 | `specs/4-tasks/current.md` | YYYY-MM-DD |

## 历史与归档
| 想了解什么 | 去哪看 |
|---|---|
| 历次迭代记录 | `context/iteration-log.md` |
| 历史需求/设计/任务版本 | 各阶段 `history/` 子目录 |
| 历史任务看板 | `specs/task/` |
| 输入文档与文本化映射 | `docs/converted/README.md` |
