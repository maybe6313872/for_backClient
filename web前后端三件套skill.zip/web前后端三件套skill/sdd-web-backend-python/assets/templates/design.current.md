<!-- 迭代标识: {简短说明} | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
# 3-design / current.md（可选汇总入口）

## 当前生效设计入口
- preliminary：`specs/3-design/preliminary/current.md`（可选）
- overall：`specs/3-design/overall/current.md`（可选）
- detailed：`specs/3-design/detailed/current.md`（可选）

## 状态
- Draft / Ready-for-Tasks / Iterating

## Gate 自检
- [ ] 构建/运行命令可复现（写入 overall 或 detailed）
- [ ] 关键接口/状态机/数据流明确（overall/detailed）
- [ ] 分层落点(router/service/repository)明确；Pydantic schema 与 ORM 模型边界清晰；DB session 注入与事务边界已定义；async/sync 一致；外部依赖有抽象与 mock 方案；迁移(Alembic)策略明确
- [ ] 可观测性（日志点/字段/开关）明确
- [ ] 未混入具体代码实现——如有，移到 tasks/编码
- [ ] 未混入任务拆解——如有，移到 tasks
- [ ] 技术方案均有 spec 需求依据，无"自行新增"的需求
- [ ] 已对照本域 coding-rules.md 的相关 RULE-*

## 推荐图表
- **状态机图**（stateDiagram-v2）：关键模块的状态转换
- **时序图**（sequenceDiagram）：模块/服务间交互时序
- **模块架构图**（flowchart）：应用层 → 抽象层 → 底层
- **数据流图**（flowchart LR）：输入 → 处理 → 输出
- **请求时序图**（sequenceDiagram）：client → router → service → repository → DB / 外部 API；**数据模型图**（erDiagram）：ORM 模型与关系

## 边界提醒
<!-- 本阶段 MUST NOT：完整函数体→tasks/编码；任务拆解(T1.1改xxx)→tasks；测试用例→test；新增需求→回流 spec -->
