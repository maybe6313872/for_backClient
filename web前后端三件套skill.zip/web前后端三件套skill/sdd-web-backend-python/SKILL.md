---
name: sdd-web-backend-python
description: 'Python Web 后端（FastAPI）的规格驱动开发 + 代码文档孪生工作流，两种一等模式。模式A（正向开发）：六阶段（宪章→需求→设计→任务→测试→交付）规范实现/迭代功能，每阶段门禁、停下等用户放行，任务阶段必须真写代码；维护 specs/README、context/、全局看板 task.md。模式B（代码孪生）：为存量项目逆向出与源码等价的文本文档（概要/详细设计+规格+代码地图+知识地图）。技术栈：Python 3.11+、FastAPI/Starlette/Uvicorn、Pydantic v2、SQLAlchemy 2.0 async+Alembic、mypy/Ruff、pytest、uv 优先(pip 兜底)。内置 RULE-TYPE/ASYNC/API/DB/SEC/CONF/ERR/DEP/PERF/OBS/TEST/PROC 编码刚性规则、L1-L5 证据分级、specs 归档生命周期与防偷懒门禁。当用户要实现/新增/修改/修复 FastAPI 后端功能、规范化 Python 后端开发流程、为存量后端做文档化/代码地图/知识地图时使用本 skill。当前项目命中本域签名（pyproject.toml 含 fastapi、app/main.py 含 FastAPI 实例、uv.lock 或 requirements.txt 含 fastapi、alembic.ini）时，项目命令 /sdd-init、/sdd-update、/sdd-docs、/sdd-iterate、/sdd-retro 由本 skill 处理；不命中则礼貌移交。技能元命令 /sdd-help、/sdd-custom 不受项目签名限制、随时可用。触发词：FastAPI、Python后端、Web后端、ASGI、Pydantic、SQLAlchemy、Uvicorn、async接口、REST API、后端服务、uv、mypy、Ruff、Alembic、pytest、覆盖率、i18n、模块闭包、CI、spec、规格驱动、web-backend-python、/sdd-iterate、/sdd-retro、/sdd-tidy、/sdd-help、/sdd-custom、代码地图、知识地图、存量项目梳理、逆向文档。'
metadata:
  owner: envicool
  version: 1.3.0
  domain: web-backend-python
  framework: SDD
  framework_baseline: sdd-skill-creator v2.3.0
  role: coding-skill
---

# SDD-web-backend-python —— Python Web 后端服务 规格驱动开发工作流

面向 **Python Web 后端服务** 的工作流。技术栈：Python 3.11+、FastAPI/Starlette/Uvicorn（ASGI，生产 Gunicorn+uvicorn worker）、Pydantic v2 + pydantic-settings、SQLAlchemy 2.0(async) + Alembic、asyncpg(PostgreSQL)/aiomysql·asyncmy(MySQL)、mypy(strict) + Ruff、pytest + pytest-asyncio + httpx.AsyncClient、uv 优先（pip 兜底）。典型架构：**分层架构 —— API 路由层(router) → 服务/领域层(service) → 数据访问层(repository/ORM)；横切为 依赖注入/中间件/配置/日志，Pydantic schema 作入出参边界**。

## 本域识别签名（多 skill 并存时的自动路由）

本 skill 负责 **Python Web 后端服务** 项目。**带权证据组合（非单一命中）**：**强证据（任一即接管）**＝依赖含 `fastapi`/`starlette`（pyproject.toml/uv.lock/requirements*/poetry.lock）、或源码出现 `FastAPI(...)`/`APIRouter(...)`（含应用工厂 `create_app`）；**弱证据（仅辅助）**＝`alembic.ini`、固定包路径（`app/`、`src/<pkg>/`）、ASGI 入口——不单独定域。**布局兼容**扁平根目录/`src/` 布局/自定义包名/应用工厂。**排除**：有 PyQt/PySide/tkinter 桌面 GUI 依赖且无 Web 强证据 → 非本域。收到 `/sdd-*` 项目命令先按此判：强证据命中即接管；命中别域则礼貌移交；仅弱证据/多域同命中/都不命中则一句话问用户。完整判据（含流程裁剪）见 [detection.md](references/detection.md)。

## 两种使用模式（互相依赖）

| | **模式 A — 正向规格驱动开发** | **模式 B — 代码文档孪生** |
|---|---|---|
| 解决什么 | 规范地实现新功能（0→1）或迭代演进（1→100） | 把存量/遗留代码逆向成与源码等价的文本文档 |
| 入口命令 | `/sdd-iterate`（或"实现/改某功能"） | `/sdd-init`（或"梳理这套代码"） |
| 主要产物 | 六阶段 specs/ 文档 + 实现代码 + 维护 README/context/task.md | README + context/ 全套孪生文档 + 代码地图 + 知识地图 |

**两者如何依赖**：模式 B 的产物（项目认知 + 代码地图 + 知识地图）是模式 A 每次迭代的"记忆基础"；模式 A 每次迭代结束回写更新模式 B 的文档，让孪生不腐化。**接手没有 specs/ 的存量项目，先 `/sdd-init`（模式 B）再 `/sdd-iterate`（模式 A）。**

---

## 🚦 门禁系统（硬规则 · 红线 · 必须遵守）

> 这些是本 skill 最重要的约束。把"丑话"说在最前面。**违反任何一条都是错误**，比少做点功能严重得多。

**1. 每个阶段之后必须停下、汇报、等用户放行。**
模式 A 六个阶段，每完成一个就**必须停**：展示该阶段 Gate 清单逐项状态 → 告诉用户"本阶段完成，请审阅" → **等用户明确说"通过/进入下一阶段"才继续**。
❌ 禁止从 constitution 一口气连跑到 deliver。❌ 禁止自行连推多个阶段。❌ 禁止跳过任何阶段。即便后续阶段"显而易见"，也**只准一次推进一个阶段**。

> **Frozen framework wording (inlined, red line 1)**: Mode A has six stages; after completing each one you **must stop**: show the stage's gate checklist item-by-item status → tell the user 「本阶段完成，请审阅」 → **wait for the user's explicit approval** (通过／进入下一阶段) before touching the next stage. Never chain-run from constitution to deliver, never advance several stages on your own, never skip one — every stage boundary is a stop-and-await-approval point.

**2. tasks 阶段必须真正写出代码 + 同步必要的自动化测试，不能只做计划。**
tasks 分两段：① 规划（拆任务 TODO → 过门禁让用户审核）② 执行（**写真实、可运行、可验证的代码，并与实现同步写必要的单元/自动化测试**；缺陷修复先写复现测试 → 过门禁让用户确认）。
❌ 只产出任务清单/计划就停手、把"待实现"当交付，**是错误的**。❌ 把"编写测试"一律推到 test 阶段、tasks 只写码不写测试，也**是错误的**（这会固化"实现后补测试"、把可测性问题拖到 test 才爆发）。**test 阶段仍保留独立验收职责**（独立验收、分层/覆盖率/契约、汇总分级证据）。计划通过后必须把代码与测试真正落地、跑通、留可复现证据。

> **Frozen framework wording (inlined, red line 2)**: tasks has **two phases** — ① planning (split into TODOs, **each TODO naming the tests it will land** → gate for user review and approval) ② execution (**write real, runnable, verifiable code and, inside the same task, the necessary unit/automated tests**; for a defect fix, **write the reproducing test first** → gate for user confirmation). Stopping after a task list and passing "to be implemented" off as delivery **is an error**; so is pushing all test writing to the test stage. Once the plan is approved, both the code and its tests must actually land, run, and leave reproducible evidence.

> **tasks and test do not overlap and neither replaces the other**: **tasks guarantees "it is testable as it is written"; test guarantees "it holds up before delivery."** Tests written during tasks are *not* a reason to shorten or skip the test stage, and the test stage is *not* the place to retrofit the unit tests tasks owed. See [gate-and-stages.md](references/gate-and-stages.md).

**3. `specs/` 下任何文档禁止直接覆盖或删除——先归档，再写。**
更新 `task.md` 或各阶段 `current.md` 前，若旧内容属于上一迭代 → 先归档（`task.md`→`specs/task/YYYY-MM-DD-说明.md`；阶段→`<阶段>/history/YYYY-MM-DD-说明.md`），抽取必要信息进新工作台，再写新内容。
❌ 直接覆盖 current.md、❌ 清空 task.md，都会丢失项目演进史，**是错误的**。见 [specs-lifecycle.md](references/specs-lifecycle.md)。

**4. `task.md` 与 `4-tasks/` 不是一回事，不许混淆。**
`task.md` = 全局指挥台（**任何任务**都维护，粗粒度 checklist）；`4-tasks/current.md` = **仅**六阶段迭代时的细粒度施工图。见下方 [模式 A](#模式-a正向规格驱动开发) 与 [task-kanban-protocol.md](references/task-kanban-protocol.md)。

**5. 不臆测外部行为；未授权不写代码；不写裸 PASS。**
不臆测第三方接口/协议字段/依赖行为；任何实现先出方案等用户放行；测试结论标 L1–L5 证据等级，交付语义不超最高证据。见 [核心协作原则](#核心协作原则) 与 [coding-rules.md](references/coding-rules.md) 的 `RULE-PROC-*`。

**6. 个性化偏好永远低于框架规则；skill 除偏好文件外全只读。**
用户偏好（`preferences/user-preferences.md` 与 `/sdd-custom`）只调表达的风格/语调/习惯，**绝不**改变门禁、tasks 必写码、归档、证据分级、采访等框架行为。**两道护栏（冻结）**：①**优先级护栏**——偏好权重低于本红线与全部框架规则，加载时凡冲突条目一律无效、忽略；`/sdd-custom` 对违规偏好（如"跳门禁/只计划不写码/免归档/写裸PASS/永远顺从"）**拒绝写入**；用户说法有误时**严正指出、坚持原则，不盲从讨好**。②**只读护栏**——本 skill 仅 `preferences/`（及项目内 `specs/retro/`）可写，**SKILL.md/references/assets/scripts 等其余位置一律只读、任何情况禁改**；要改框架走母机 `/sdd-distill`+`/sdd-absorb`+`/sdd-evolve`。详见 [custom-protocol.md](references/custom-protocol.md)。

> **Two frozen guards (inlined, red line 6)**: ① **precedence guard** — preferences rank below these red lines and all framework rules; conflicting entries are void and ignored at load; `/sdd-custom` **refuses to write** violating preferences (e.g. "skip gates / plan-only / no archiving / bare PASS / always comply"); when the user is factually wrong, **point it out and hold principles — no sycophancy**. ② **read-only guard** — only `preferences/` (and the project's `specs/retro/`) are writable; **SKILL.md / references / assets / scripts are read-only and are never modified under any circumstances**; framework changes go through the mother skill's `/sdd-distill` + `/sdd-absorb` + `/sdd-evolve`.

**7. Language protocol (frozen): implementation in English, interaction in Simplified Chinese.**
This skill's implementation content (SKILL.md body, references/ protocols, scripts) is written in English for AI-execution reliability. But **everything user-facing defaults to Simplified Chinese**: conversation, gate reports, interview questions, all generated project documents (specs/, context/, docs/), and code comments in project code. Language-bound content stays Chinese by design: the Chinese trigger phrases, style-enum names, the frozen date-header literals (`迭代标识` / `迭代日期` / `状态` and the `就绪` / `进行中` / `已交付待归档` value set), the evidence-ladder level names, the deliverable templates under `assets/templates/`, and the preference file. ❌ Replying to the user in English, ❌ generating an English spec/design doc for the project (unless the user explicitly asks) — both are errors.

- **Gate ID vocabulary (universal G1–G6, frozen and identical across every sdd-xx)**: G1 stage responsibility boundary · G2 archiving discipline · G3 evidence grading · G4 progress transparency · G5 specs-first at every grain · G6 claim↔git pairing. In daily terms: any code fix or small increment, no matter how small, first registers in `specs/` (task.md row + spec entry + context mapping) and only then touches business code, and every business-code change pairs with a specs change (G5); before delivery `git status` must also match what the delivery claims (G6) — code-without-specs or claim-without-change = incomplete: block, report, backfill (or obtain the user's explicit waiver); never auto-revert — ask the user for disposition. Definitions and enforcement points: [gate-and-stages.md](references/gate-and-stages.md) §Gate numbering namespace. **This skill's own domain gates take the `BE` prefix and never consume a `G` number.**

---

## 入口行为（每次触发本 skill，按顺序）

0. **加载用户偏好**：读 `preferences/user-preferences.md`，在**不违背门禁红线与框架规则**的前提下应用其风格/习惯；文件为空则默认基本风格＝**「专业可靠」**。**任何与框架规则冲突的偏好条目无效、直接忽略**（偏好优先级低于框架，见红线 6）。若用户打 `/sdd-help` 或 `/sdd-custom` → 走对应技能元命令（见 [指令集](#指令集-sdd-命令)），不依赖项目。
1. **读现状**：先读 `specs/README.md` 与 `specs/task.md`（跨会话记忆基础）。都不存在 → 还没建立认知：**有存量代码** → 先 `/sdd-init`（模式 B）；**全新 0→1 项目** → 直接进模式 A 从 constitution 开始。
2. **路由 + 命令**：先按 [本域识别签名](#本域识别签名多-skill-并存时的自动路由) 确认归属；若打了 `/sdd-*` 命令 → 按 [commands.md](references/commands.md) 直达；否则按模式判定。
3. **开迭代前巡检（归档 hook）**：开新迭代/新任务前，巡检 `task.md` 与各 `current.md`，凡属上一迭代的先归档（红线 3 与 specs-lifecycle.md）；**查 `docs/requirements/` 收件箱**：有上游派单/投放需求先登记进 specs 再动手（认领＝登记→归档副本→清空签收，见 [requirement-inbox-protocol.md](references/requirement-inbox-protocol.md)）。
4. **处理 docs/**：若 `docs/` 有二进制文档，按 [docs 文本化](#docs-文本化摘要) 先文本化再引用。
5. **进入对应模式**：模式 A 走六阶段并先做场景澄清采访；模式 B 走孪生工作流。

---

## 指令集 `/sdd-*` 命令

> Slash commands are hard to memorize; each carries **Chinese equivalents** (frozen, F9) that trigger the same action. The Chinese trigger phrases are language-bound and never translated.

| 命令 | Chinese equivalents 中文自然语言等价触发（也命中） | 职责 | 落到 |
|---|---|---|---|
| `/sdd-init` | 「给这个后端项目做 SDD 初始化」「接手这套 FastAPI 老服务」「梳理后端代码建认知」 | 为存量项目**建立/重建项目认知**（+工程基线审计+建收件箱） | 模式 B |
| `/sdd-update` | 「整理工作台」「归档上一迭代」 | **工作台维护**：巡检并归档 `task.md`、各 `current.md` | specs 生命周期 |
| `/sdd-docs` | 「把文档文本化」「处理规格书」 | **文档治理**：巡检 `docs/`、按需文本化、维护索引 | 文本化适配器 |
| `/sdd-iterate` | 「新增/改一个接口」「按需求做后端功能」「开始新迭代」 | **正向迭代**：按六阶段实现/演进功能，逐阶段门禁 | 模式 A |
| `/sdd-retro` | 「复盘这次」「总结教训」 | **复盘沉淀**：把本次犯错/亮点结构化写入 `specs/retro/`（只读代码） | 复盘闭环 |
| `/sdd-tidy` | 「整理目录结构」「文件放乱了归位」 | **目录规整**：非标/错位文档按 structure.md 归位（只移动/归档，禁删、禁碰源码） | [tidy-protocol.md](references/tidy-protocol.md) |
| `/sdd-help` | 「怎么用」「有什么命令」「门禁啥意思」 | **使用引导**（技能元命令）：交互式讲解用法、逐步答疑（只读、不拉起流程） | [help-protocol.md](references/help-protocol.md) |
| `/sdd-custom` | 「设置我的偏好」「记住我的习惯」 | **个性化偏好**（技能元命令）：交互式设定风格语调与使用习惯，写入唯一可写偏好文件 | [custom-protocol.md](references/custom-protocol.md) |

> **两类命令**：**项目命令** `/sdd-init|update|docs|iterate|retro` 只在**当前项目命中本域签名**时由本 skill 处理（见路由）；**技能元命令** `/sdd-help`、`/sdd-custom` 面向"怎么用本 skill / 按我的习惯用"，**不受项目签名限制、无项目也能用**，多 sdd-xx 并存且归属不明时一句话问用户。完整定义见 [commands.md](references/commands.md)。

### 模式判定规则

- `/sdd-iterate` 或"实现/新增/修改/修复/优化某功能" → **模式 A**。README 不存在且有存量代码 → 建议先 `/sdd-init`；纯新项目直接从 constitution 开始。
- `/sdd-init` 或"给项目做文档/接手老项目/梳理代码/生成代码地图" → **模式 B**。
- `/sdd-update` → 工作台维护；`/sdd-docs` → docs 治理；`/sdd-tidy` 或"整理目录/文件放乱了" → **目录结构规整**（只移动/归档、禁删、禁碰源码，见 [tidy-protocol.md](references/tidy-protocol.md)）。
- `/sdd-retro` 或"复盘这次/总结教训/这次做得好" → **复盘闭环**：结构化写入 `specs/retro/`，只读代码不改实现（见 [retro-protocol.md](references/retro-protocol.md)）。
- 纯工具诉求 → 直接用对应工具，不拉起整套流程。
- 不确定 → 一句话问："新做/改功能（A），还是把现有代码整理成文档（B）？"

---

## 核心协作原则

> 贯穿两种模式。理解 why 就能在条文没覆盖时也做对。详见 [collaboration-protocol.md](references/collaboration-protocol.md)。

- **采访优先、先澄清场景再动手**。Python Web 后端服务 需求里藏着大量隐含上下文。进入一个阶段先用 3–5 个结构化问题问清场景；场景没闭合前只输出澄清问题或草案。优先级：选择题 > 带建议值填空题 > 确认题 > 开放题。
- **先方案后编码，未经授权不写代码**。任何实现先输出方案（问题理解、影响范围、改哪些文件/函数、风险点、验证方式），等用户明确"同意/实施"再落代码（RULE-PROC-01/02）。
- **文档先行**。代码会腐化，文档是跨会话协作的唯一持久记忆。deliver 阶段文档同步是硬门槛。
- **迭代前后文档门禁（强制）**。开新迭代前过**入口门禁**（读 task.md / 先归档上一迭代 / 写新迭代头 / 查 retro 账本）；交付前过**出口门禁**（task.md 更新+归档 / history 追加 / open-issues 收口 / 复盘判定）。见 [gate-and-stages.md](references/gate-and-stages.md)。
- **复盘沉淀、本地复用**。犯错或做得好时用 `/sdd-retro` 把教训/亮点结构化写入 `specs/retro/`（根因禁臆测、对事不对人、正反都记）；开相关迭代前查账本避免重复。见 [retro-protocol.md](references/retro-protocol.md)。
- **不臆测外部行为**。第三方接口/协议字段/依赖语义/数据库(PostgreSQL/MySQL)、Redis/缓存、消息队列、第三方 HTTP API、对象存储、鉴权/SSO 服务 必须有依据（文档/源码/用户确认）；没依据就标 `⚠️ 待确认` 并提问，不要用"通常/一般/默认如此"兜底。
- **最小改动**。满足需求前提下尽量小改、复用已有逻辑与结构，不引入不兼容的重量级依赖。
- **证据分级，不写裸 PASS**。测试结论标 L1–L5（见 [evidence-gate-protocol.md](references/evidence-gate-protocol.md)），交付语义不超最高证据等级。
- **产出前后各做一次自检**。见 [self-check.md](references/self-check.md)。
- **进度透明、不夸大**。每阶段 Gate 前输出已开发/未开发/阻塞/下一步并同步 task.md（见 [development-progress-protocol.md](references/development-progress-protocol.md)）；不得把构建通过说成功能完成。
- **图表按需、聚焦、图文一致**。见 [diagram-guidelines.md](references/diagram-guidelines.md)。
- **默认简体中文、文件 UTF-8**。本域源码默认 UTF-8、无 GBK 遗留，故不强制乱码自检；仅需保证文件 UTF-8(无 BOM)、LF 行尾。

---

## 模式 A：正向规格驱动开发

六阶段，可在任意阶段发现风险/不一致时回流到 spec/design 修正（回流需告知用户原因并同步 task.md）。**每个阶段后都有门禁，必须停下等放行（红线 1）。**

```
[项目认知 README + context/ + task.md]
        ↓
constitution → spec → design → tasks → test → deliver
     ↑           （每个 → 处都有门禁：停下·汇报·等放行）
     └────────── 回流（发现风险/不一致）──────────┘
```

每个阶段**只产出本阶段职责内的内容**，越界就停下。自检口诀：*"这段内容属于哪个阶段？不属于当前阶段就移走。"*

| 阶段 | 职责（一句话） | 最小产物 | Gate 关键项（详见 gate-and-stages.md） |
|---|---|---|---|
| constitution | 项目级工程约束，少而精 | `1-constitution/current.md` | 通用协议 + 项目专属协议（如 Python 版本下限、async/sync 栈、ORM 与迁移工具、包管理(uv/pip)、类型检查严格度、Lint/格式化、部署形态、密钥/配置来源） |
| spec | 定义"做什么"，可验收 | `2-spec/current.md` | 每条需求有验收标准、覆盖边界异常、证据口径明确、关键 Clarify 关闭 |
| design | 定义"怎么做" | `3-design/current.md` | 分层落点明确 + **业务模块闭包**（每能力自持 router/schema/service/repo/errors/messages/tests，聚合入口只注册）；Pydantic/ORM 边界；session 注入与**事务边界归属**；async/sync 一致；**组合根+生命周期+import-safe**；**配置单一入口+启动期校验**；**i18n 边界**（若启用）；**契约权威来源**（code-first/contract-first）与错误载体（problem+json/既有信封）；**技术画像**（不变量/默认/存量）；迁移(Alembic)策略 |
| tasks | 拆任务**并写码+同步测试** | `4-tasks/current.md` | ①规划过门禁 → ②代码真正实现**并同步写必要测试**并自验过门禁；每任务映射验收点、标 RULE-*、列该任务要落的测试；Gate 前出进度澄清表 |
| test | 独立验收 + 可复现证据 | `5-test/current.md` | 质量入口(ruff/mypy)通过；按测试金字塔分层（纯业务/高风险有单元）；`httpx.AsyncClient` **进程内接口测试(非真E2E)且显式驱动 lifespan**；DB 测试库/事务回滚隔离；每接口过最小验证矩阵(2xx/422/401/403/领域/边界)；**覆盖率 --cov-branch 达基线且不退化**；契约 oasdiff 无破坏；i18n 完整性；测试稳定性；每条结论标 L1–L5 **且绑定命令/退出码/用例数/产物/版本** |
| deliver | 变更/发布/回滚 | `6-deliver/current.md` | changelog/release-note/回滚可执行、文档全套同步、task.md 归档、语义不超证据等级；**G5 各粒度 specs-first**、**G6 交付与 git 配对**、收件箱已签收清空、统一质量入口全绿+CI 产物齐全 |

### tasks 阶段＝两段式（务必照做，这是高频翻车点）

- **第①段 规划**：依据 design+spec 拆出可执行任务 TODO（每条映射 R*/AC*、列改动文件、**列该任务要落的测试**、写验证与证据、标 RULE-*），写入 `4-tasks/current.md`，并在 `task.md` 反映粗粒度进度。**🚦门禁①**：展示清单，等用户批准计划，**未批准不写代码**。
- **第②段 执行**：计划获批后**逐条写真实代码、同步写必要的单元/自动化测试、跑通、留可复现证据**（缺陷修复先写复现测试）。⚠️ **只产出计划就停手是错误的**；⚠️ **只写码不写测试、把测试一律推到 test 阶段也是错误的**（test 阶段仍独立验收与汇总证据，二者不矛盾）。**🚦门禁②**：实现并自验后展示证据，等用户确认再进 test。

### `task.md` vs `4-tasks/`（红线 4 展开）

- **`task.md`** = 全局指挥台：对**任何任务**（迭代/修 bug/写文档/重建 context）都维护，粗粒度 checklist，跨迭代、对用户可见。
- **`4-tasks/current.md`** = 单次迭代施工图：**仅**走六阶段迭代时才用，细粒度任务拆解与执行追踪。
- ✅ "重建 context/" → 只更新 task.md，**不建 4-tasks**。　✅ "按 spec 迭代加 X 功能" → task.md 记粗进度 **且** 4-tasks 做细拆解。
- ❌ 把 T1.1/T1.2 细任务塞进 task.md。　❌ 给非六阶段任务建 4-tasks。详见 [task-kanban-protocol.md](references/task-kanban-protocol.md)。

各阶段详细要求、采访示例、推荐图表、自检清单见 **[gate-and-stages.md](references/gate-and-stages.md)**；编码对照 **[coding-rules.md](references/coding-rules.md)**。

---

## 模式 B：代码 → 认知层（含代码孪生）

目标：把存量代码 + 散落资料，逆向成 `specs/context/` **结构化认知层**，用来反推需求规格书/概要设计/详细设计/测试用例与后续迭代依据。**`context/` 是桥梁，不是终点；成败标准是「能否支撑下游正式文档补写」，不是 specs/ 有多大。** 代码孪生（modules/architecture/data-model）是其中一层并保留；代码图谱是**可选辅助**，不是核心。

`context/` 按**项目认知 / 架构 / 模块 / 场景 / 证据**五层组织（非源码目录平铺）。孪生粒度仍按 L0–L4 落盘（详见 [mode-b-twin.md](references/mode-b-twin.md)）：L0 `README.md` / L1 `context/architecture.md` / L2 `context/modules.md` / L3 模块内逐函数条目 / L4 `context/code-map.md`（**可选**源码索引，Python 标准库 ast / 随附零依赖 build_source_index.py（基于 Python ast，静态识别 async def/装饰器 FastAPI 路由/import；可选外部工具 pydeps/import-linter 补依赖图） 或 AI 手工）。**场景层 `context/scenarios/` 是一等公民**——跨模块业务链路单独成文。

**三条铁律（内联）**：①**文档纯净度**——`context/` 只写已闭合事实，疑点/冲突进 `specs/open-issues.md`（全局治理入口），在办任务进 `task.md`，三者不混写；②**不臆测**——资料与源码冲突时正文按源码写、分歧进 open-issues，禁用「通常/应该/按经验」补空，证据出处记 `context/evidence-trace.md`；③**机器产物分离**——自动索引进 `_generated/`、脚本进 `_tools/`，绝不混入 `context/`。

**工作流概要**：① 确认源码编码（本域默认 UTF-8、无 GBK 遗留，无需乱码扫描，仅核对无 BOM/LF） ② 结构扫描（可选生成源码索引） ③ 按 L0→L3 分层撰写认知、逐条标证据强度（静态可见/资料互证/运行佐证） ④ 梳理场景链路 ⑤ **工程质量基线审计**（盘点类型/Lint/测试分层/覆盖率/CI/依赖锁/契约/迁移/配置/模块闭包/i18n，产出"现状→RULE→差距"清单 `context/engineering-baseline.md`，见 mode-b-twin §6a） ⑥ 覆盖度自检 ⑦ 与用户确认 ⑧ 增量同步。完整标准见 **[mode-b-twin.md](references/mode-b-twin.md)**。**模式 B 不能只建代码认知，缺工程门禁必须被系统识别并记债。**

**反推上游文档（详细设计/概要设计/需求规格书草稿）**：认知层可进一步反推存量项目缺失的上游文档，产物落 `docs/reverse/*.draft.md`（与正向六阶段隔离，待人确认）。**第一性原则（内联红线）**：源码反推能力**天然递减**（详细设计 > 概要设计 > 需求规格书），**源码通常不含完整需求场景/非功能阈值/业务动机/验收标准，故无法反推出"完整的需求规格书"**。按可达性三级处理——可反推直接成文；部分可反推出 `[草稿:]`；**不可反推只给 `[待澄清:]`/`[缺口:]`，禁止臆测**，每条挂 `open-issues.md`。有缺口时**禁称"完整需求规格书"**，须为"草稿（含 N 处待澄清/缺口）"。完整协议见 **[mode-b-reverse.md](references/mode-b-reverse.md)**。

---

## specs 生命周期与归档纪律（摘要）

`specs/` is the project's long-term memory: "workbench current / history separated", auto-archived by hooks at key moments. **Iron rule: never overwrite or delete — archive first, then write** (red line 3). Every `current.md` and `task.md` carries a three-field date header `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->`, whose `状态` holds exactly one value of the frozen set (`就绪` / `进行中` / `已交付待归档`) defined in specs-lifecycle.md §3 — never an inline enumeration, since `|` is the field separator. Archive destinations: `task.md` → `specs/task/`; stages → `<stage>/history/`. Full mechanism: **[specs-lifecycle.md](references/specs-lifecycle.md)**.

---

## docs 文本化（摘要）

`docs/` 放用户输入的原始文档（需求规格书、协议、规范等，常为 xlsx/pdf/docx）。文本化由 `/sdd-docs` 驱动，**遵循 [docs-binarification-adapter.md](references/docs-binarification-adapter.md) 的契约，当前由 公司 binary-doc-converter 承载**。产物统一进 `docs/converted/`，用 `docs_index` 做 SHA-256 哈希快检。**转换器是基础设施相关、可换的独立模块**，变更只改适配器一处。

---

## 项目认知底座（两种模式共享）

| 文件 | 定位 | 读取时机 |
|---|---|---|
| `specs/README.md` | 项目全局视角与模块/代码索引 | 每次会话开始必读 |
| `specs/context/*` | 详细认知（features/domain-model/architecture/data-model/db-schema-and-config/**engineering-baseline**/modules/scenarios/evidence-trace/code-map/knowledge-map/…） | 按需读 |
| `specs/context/engineering-baseline.md` | 模式 B 工程质量基线审计（现状→RULE→差距，见 mode-b-twin §6a） | 接手/评估存量项目时读 |
| `specs/sources.md` | 来源/新鲜度登记表（外部输入依赖，配合 docs/requirements） | 认领需求/核对来源时读 |
| `docs/requirements/` | 需求收件箱：上游派单/投放需求先落此，认领＝登记进 specs→归档副本→清空签收 | 开迭代前必查 |
| `specs/context/scenarios/` | 场景链路（跨模块业务链路，一等公民） | 维护跨模块问题时必读 |
| `specs/context/knowledge-map.md` | 知识地图（导航总台：主题→去哪看） | 不知道读哪个文件时先看它 |
| `specs/open-issues.md` | 全局治理入口：疑点/冲突/待验证（纯净度规则） | 模式 B 反推、deliver 前必读 |
| `specs/task.md` | 全局任务看板 | 每次会话第 2 步必读；执行中持续更新 |
| `specs/task/` | task.md 历史归档目录 | 换任务/迭代时归档 |
| `specs/retro/` | 复盘账本+各主题文件（教训/亮点，供本地复用与汇集回灌） | 开相关迭代前查账本；复盘时写入 |
| `specs/_generated/`、`specs/_tools/` | 机器索引产物 / 项目脚本（可重建、可丢弃） | 仅作辅助，不当事实源 |

task.md 协议见 [task-kanban-protocol.md](references/task-kanban-protocol.md)。

---

## 工具与运行环境

本域多跑在 Linux/容器（CI/CD 流水线），默认具备 Python 3.11+；包与环境管理优先 uv（uv sync / uv run / uv.lock），无 uv 时 pip 兜底（pip install -e .[dev] 或 -r requirements.txt）。 工具遵循**能力探测 + 降级**：零依赖优先 → 脚本兜底 → AI 手工。

| 任务 | 首选 | 兜底 |
|---|---|---|
| 初始化 specs/ 骨架 | AI 直接创建文件 | 脚手架脚本（若有） |
| 检测当前阶段 | 列目录人工判断 | 检测脚本（若有） |
| 生成源码索引（可选） | 随附零依赖 `build_source_index.py`（**基于 Python 标准库 ast**，识别 `def`/`async def`/类/装饰器/FastAPI 路由/import 含多行与别名；编码失败显式报告不静默回退；仅作盘点辅助、非事实裁决源） | AI 按 code-map 约定手工建（效果对等） |
| docs 文本化 | 公司 binary-doc-converter（见适配器） | 内置脚本 / AI 自行实现 |
| docs 哈希快检 | `docs_index`（若携带） | AI 手填 converted/README.md |

详见 [environment-and-tools.md](references/environment-and-tools.md)。

---

## 编码刚性规则（概要）

design / tasks / test 阶段对照执行，详见 **[coding-rules.md](references/coding-rules.md)**。

| 主题 | 前缀 | 防的是 |
|---|---|---|
| 类型与校验 | RULE-TYPE | 弱类型/裸 dict/Pydantic v1 残留、strict 无配置无范围无增量 |
| 模块结构 | RULE-STRUCT | 只有横向分层无纵向业务闭包、router/schema 塞公共热点文件 |
| 异步一致性 | RULE-ASYNC | async 端点阻塞事件循环、async/sync 混栈、session 跨任务 |
| 接口契约 | RULE-API | 隐式状态码、错误夹 200、手解请求、缺分页/幂等、契约权威不明、误用弃用 on_event |
| 数据访问 | RULE-DB | 1.x/全局 session、N+1、惰性加载、手改库结构、service/repository 职责不分 |
| 依赖注入/组合根 | RULE-DI | 无组合根、router 自造依赖、生命周期不清、导入期副作用、测试难替换 |
| 安全鉴权 | RULE-SEC | 鉴权遗漏、密钥入码、注入、弱哈希 |
| 配置 | RULE-CONF | 硬编码配置/密钥、不分环境、无归属/无启动校验/散落 os.getenv |
| 国际化 | RULE-I18N | 文案散落各层、无稳定键、语言资源不按模块拆分、缺失键裸奔 |
| 异常与日志 | RULE-ERR | 吞异常、错误语义不统一、载体绝对化破坏既有契约、print/泄敏 |
| 静态质量 | RULE-LINT | Ruff check/format 无配置、命令/范围漂移 |
| 注释/文档字符串 | RULE-DOC | 公开面缺 docstring、端点无 summary 喂 OpenAPI、注释复述代码/过时/死代码 |
| 依赖与环境 | RULE-DEP | 不锁定、不可复现、uv/requirements 完成定义不清、Python 版本无闭环 |
| 质量入口/CI | RULE-CI | 无统一入口、无最低 CI、覆盖率退化不阻断、跨平台命令漂移 |
| 遗留隔离 | RULE-VENDOR | vendor/legacy 无只读边界、阻塞/不稳定返回直穿业务层 |
| 性能 | RULE-PERF | 连接池耗尽、热点无索引/缓存、大响应不分页 |
| 可观测性 | RULE-OBS | 无健康检查、无日志/追踪/指标、错误不可定位、裸 uvicorn 上生产 |
| 测试 | RULE-TEST | 打生产库、缺隔离、缺分层、lifespan 绕过、覆盖率无门禁、证据脱钩、裸 PASS |
| 流程纪律 | RULE-PROC | 未授权改码、跳门禁、臆测外部、裸 PASS、推荐栈伪装成项目事实（框架自带） |

> 完整反例/正例与每条细则见 [coding-rules.md](references/coding-rules.md)；工程闭环方法论见 [module-architecture.md](references/module-architecture.md)、[testing-strategy.md](references/testing-strategy.md)、[quality-gate-and-ci.md](references/quality-gate-and-ci.md)、[i18n-and-messages.md](references/i18n-and-messages.md)、[stack-profile.md](references/stack-profile.md)。

---

## 参考文档与模板

| 文档 | 内容 |
|---|---|
| [collaboration-protocol.md](references/collaboration-protocol.md) | 采访模板、门控仪式、统一自检入口 |
| [commands.md](references/commands.md) | `/sdd-*` 指令集定义 + 路由 |
| [help-protocol.md](references/help-protocol.md) | `/sdd-help` 交互式使用引导协议（技能元命令，禁灌输） |
| [custom-protocol.md](references/custom-protocol.md) | `/sdd-custom` 用户偏好机制 + 风格枚举 + 偏好优先级/只读双护栏 |
| [specs-lifecycle.md](references/specs-lifecycle.md) | **必读**：specs 领域模型、生命周期、归档 hooks |
| [gate-and-stages.md](references/gate-and-stages.md) | 模式 A 各阶段详细要求（含 tasks 两段式、每阶段门禁） |
| [task-kanban-protocol.md](references/task-kanban-protocol.md) | task.md 全局看板、与 4-tasks 区别（正反例） |
| [mode-b-twin.md](references/mode-b-twin.md) | 模式 B 认知层五层、纯净度规则、场景层、证据强度、源码索引可选、下游反推映射 |
| [mode-b-reverse.md](references/mode-b-reverse.md) | 模式 B 反推上游文档：可达性三级、缺口标记法、完整度声明、反推自检（禁臆测） |
| [retro-protocol.md](references/retro-protocol.md) | 复盘与经验沉淀：`/sdd-retro` + `specs/retro/`、复盘 schema、本地复用、汇集回灌 |
| [coding-rules.md](references/coding-rules.md) | 全部 RULE-* 编码刚性规则 |
| [module-architecture.md](references/module-architecture.md) | 业务模块闭包（纵向模块化）+ ORM 无关的 service/repository 职责边界（RULE-STRUCT） |
| [stack-profile.md](references/stack-profile.md) | 工程不变量 vs 推荐默认 vs 存量事实；技术画像先行、Python 版本闭环、契约权威来源 |
| [testing-strategy.md](references/testing-strategy.md) | 测试金字塔/分层矩阵/ASGI lifespan/覆盖率不退化/最小 API 验证矩阵/测试稳定性 |
| [quality-gate-and-ci.md](references/quality-gate-and-ci.md) | 统一质量入口 + 最低 CI 流水线 + uv/requirements 完成定义（RULE-CI/RULE-LINT） |
| [i18n-and-messages.md](references/i18n-and-messages.md) | i18n：四类信息分离、按模块拥有稳定键、翻译完整性门禁（RULE-I18N） |
| [requirement-inbox-protocol.md](references/requirement-inbox-protocol.md) | 需求收件箱 docs/requirements/：认领＝登记→归档副本→清空签收（F33） |
| [tidy-protocol.md](references/tidy-protocol.md) | `/sdd-tidy` 目录结构规整：只移动/归档、禁删、禁碰源码（F35） |
| [openapi-and-api-docs.md](references/openapi-and-api-docs.md) | OpenAPI/接口文档方法论（先定契约权威来源 + 代码优先喂饱 + oasdiff 破坏性变更门禁） |
| [error-model.md](references/error-model.md) | 统一错误模型：语义(不变量) + 载体(Problem Details 默认 / 存量既有信封) |
| [observability-and-production.md](references/observability-and-production.md) | 可观测性与生产化（结构化日志/追踪/指标/健康检查/多worker/优雅停机/容器） |
| [evidence-gate-protocol.md](references/evidence-gate-protocol.md) | L1–L5 证据分级与 deliver 放行 |
| [self-check.md](references/self-check.md) | 产出前思维链 + 产出后核对清单 |
| [diagram-guidelines.md](references/diagram-guidelines.md) | 图表规范 |
| [knowledge-map.md](references/knowledge-map.md) | 知识地图用途、格式、维护 |
| [detection.md](references/detection.md) | 模式与阶段检测（含路由签名） |
| [structure.md](references/structure.md) | specs/ 与 docs/ 标准目录结构与命名约定 |
| [development-progress-protocol.md](references/development-progress-protocol.md) | 开发进度澄清（已开发/未开发/阻塞/下一步） |
| [troubleshooting.md](references/troubleshooting.md) | 故障排查 + 中文/长路径优先直建原则 |
| [environment-and-tools.md](references/environment-and-tools.md) | 运行环境能力探测与降级 |
| [docs-binarification-adapter.md](references/docs-binarification-adapter.md) | docs 文本化契约 + 当前实现（可换） |

模板在 `assets/templates/`：六阶段各自 current.md（带日期头）、全局看板 task.md、知识地图、项目 README、docs 索引。
