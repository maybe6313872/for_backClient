# 指令集（`/sdd-*` 命令）+ 路由

> 项目命令 `/sdd-init|update|docs|iterate|retro` 由本 skill 处理，**但仅当当前项目命中本域签名**（pyproject.toml 含 fastapi/starlette 依赖、app/main.py 含 FastAPI() 实例、uv.lock 或 requirements.txt 含 fastapi、alembic.ini、ASGI 应用入口（且无 PyQt/PySide/tkinter 等桌面 GUI 依赖，以与 Python 上位机区分），见 detection.md 与 SKILL.md 本域识别签名）。命令是入口，最终落到模式 A/B 与 specs 生命周期 hooks。

| 命令 | 中文自然语言等价触发（也命中） | 一句话职责 | 落到 |
|---|---|---|---|
| `/sdd-init` | 「给项目做文档」「接手这套代码」「梳理/生成代码地图」 | 为存量项目建立/重建项目认知（README + context/ + 代码地图 + 知识地图 + 工程基线 + 建收件箱） | 模式 B |
| `/sdd-update` | 「整理工作台」「归档上一迭代」「清理 specs」 | 工作台维护：巡检并归档 `task.md`、各 `current.md`，保持整洁 | specs 生命周期"开迭代前巡检"hook |
| `/sdd-docs` | 「把这些文档文本化」「处理 docs 里的规格书」 | 文档治理：巡检 `docs/`、按需文本化、维护 `docs/converted/README.md` 索引 | docs 文本化适配器 |
| `/sdd-iterate` | 「实现/新增/修改/修复某功能」「按这个需求做」 | 正向迭代：按六阶段实现/演进功能，逐阶段门禁 | 模式 A |
| `/sdd-retro` | 「复盘这次」「总结教训」「这次做得好」 | 复盘沉淀：把本次犯错/亮点结构化写入 `specs/retro/`（只读代码） | 复盘闭环 |
| `/sdd-tidy` | 「整理目录结构」「文件放乱了归位」「按标准结构规整」 | 目录结构规整：把非标/错位文档按 structure.md 归位（只移动/归档，禁删、禁碰源码） | [tidy-protocol.md](tidy-protocol.md) |
| `/sdd-help` | 「怎么用这个 skill」「有什么命令」「这个门禁啥意思」 | 使用引导（技能元命令）：交互式讲解用法、逐步答疑 | 使用引导协议 |
| `/sdd-custom` | 「设置我的偏好」「自定义风格」「记住我的习惯」 | 个性化偏好（技能元命令）：交互式设定风格语调与习惯 | 用户偏好协议 |

## `/sdd-init`
前置：源码编码检查（本域源码默认 UTF-8、无 GBK 遗留，故不强制乱码自检；仅需保证文件 UTF-8(无 BOM)、LF 行尾。）；是否已有 README（有则自检更新而非从零重建）。
动作：结构扫描 → 生成/刷新代码地图（Python 标准库 ast / 随附零依赖 build_source_index.py，识别 async def/装饰器路由/import）→ 按 L0–L4 写孪生 → **工程质量基线审计**（写 `context/engineering-baseline.md`，见 mode-b-twin.md §6a）→ 生成/刷新知识地图 → 建立 `docs/requirements/` 收件箱与 `specs/sources.md` → 覆盖度自检并报告缺口。

## `/sdd-update`
工作台维护，**不是正向开发本身**（正向开发由 `/sdd-iterate` 承载）。动作：巡检日期头与状态 → 凡"已交付待归档"或属上一迭代的按 specs-lifecycle 归档 → 抽取必要信息到干净 current.md → 报告。

## `/sdd-docs`
遵循 [docs-binarification-adapter.md](docs-binarification-adapter.md) 契约：`docs_index --check` 找需转的 → 用 公司 binary-doc-converter 文本化 → 产物入 `docs/converted/` → `docs_index --write` 记账 → 报告。

## `/sdd-iterate`
前置：先读 README+task.md；README 不存在且有存量代码→建议先 `/sdd-init`。启动触发"开迭代前巡检"。动作：严格按 constitution→spec→design→tasks→test→deliver，**每阶段后停下过 Gate 等放行**；tasks 两段式。

## `/sdd-retro`
触发：用户"复盘这次/总结教训/这次做得好"，或 deliver 出口门禁建议，或周期复盘。
**只读代码与产出、只写 `specs/retro/`**（零爆炸半径）。动作：① 走结构化复盘 schema（发生了什么[逐字记录借口]→期望→根因[禁臆测]→哪条门禁本应拦住→改进动作[标[框架候选]]→泛化性→状态）→ ② 写/追加 `specs/retro/retro-YYYY-MM-DD-<主题>.md` → ③ 更新 `specs/retro/README.md` 账本。完整协议见 [retro-protocol.md](retro-protocol.md)。

## `/sdd-tidy`
触发：用户"整理目录结构 / 文件放乱了 / 按标准结构规整"，或巡检发现非标布局。
**门禁式、只移动/归档，绝不删除、绝不触碰源码**：只读扫描（对照 [structure.md](structure.md) 找错位/非标文件）→ 展示移动/归档计划等用户放行 → 执行（仅 move/archive，先归档再写）→ 报告。完整协议见 [tidy-protocol.md](tidy-protocol.md)。

## `/sdd-help`（技能元命令，不受项目签名限制）
触发：用户"怎么用 / 帮我介绍下这个 skill / `/sdd-help` / 有什么命令 / 这个门禁啥意思"。
**只读、纯对话**：不改任何项目或 skill 文件、不拉起六阶段/孪生流程。动作：交互式引导——先一句话欢迎 + 选择题定位用户想了解什么，再一次一问一答按需展开，**禁止一上来甩长文/复述整篇 SKILL.md**。完整协议见 [help-protocol.md](help-protocol.md)。

## `/sdd-custom`（技能元命令，不受项目签名限制）
触发：用户"设置我的偏好 / 自定义风格 / `/sdd-custom` / 记住我的习惯：……"。
动作：交互式设定基本风格语调（5 档枚举，默认「专业可靠」）与使用习惯 → 对每条拟写入项过**写入前合规校验**（与框架冲突即拒写并说明）→ 用户确认 → **仅写入** `preferences/user-preferences.md`。**两道护栏（红线 6）**：偏好优先级永远低于框架规则；skill 除偏好文件/沉淀文件夹外全只读、禁改。完整协议见 [custom-protocol.md](custom-protocol.md)。

## 命令与自然语言
命令是快捷入口，不输命令时按 SKILL.md 模式判定路由到等价流程。**项目命令**（init/update/docs/iterate/retro）受路由签名约束并受 specs 生命周期 hooks 与门禁约束；**技能元命令**（help/custom）面向"怎么用/按我的习惯用"，无需项目、不受签名限制，多 skill 并存归属不明时一句话问用户。
