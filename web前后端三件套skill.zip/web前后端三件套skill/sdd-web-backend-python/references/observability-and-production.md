# 可观测性与生产化（本域增强）

> 目标：服务在生产**可观测、可定位、可平滑发布**。三支柱——结构化日志、分布式追踪、指标——加生产化运行（多 worker、优雅停机、容器）。对应编码规则 `RULE-OBS-01..04`。落阶段：design 设计观测点与部署形态、tasks 落地、test 验证、deliver 随发布同步。

---

## 1. 结构化日志 + trace 关联（RULE-OBS-02）
- 用 `structlog`（或标准 `logging` + JSON formatter）输出**JSON 结构化日志**，禁 `print`。
- 每条日志带请求上下文：`request_id`（入站中间件生成/透传 `X-Request-ID`）、以及 **trace 关联**字段 `trace_id`/`span_id`（从 OpenTelemetry 当前 span 注入），实现"日志 ↔ 链路"互跳。
- **不泄敏**：密钥、令牌、密码、完整请求体等敏感信息不入日志；异常栈进日志、不进响应体（错误响应见 [error-model.md](error-model.md)）。

## 2. 分布式追踪 + 指标（RULE-OBS-03）
- **追踪**：用 OpenTelemetry `FastAPIInstrumentor.instrument_app(app)` 自动埋点（完整支持 async 端点、后台任务、并发请求的上下文传播）；对 DB/HTTP 客户端用对应 instrumentor（SQLAlchemy、httpx）。关键业务用 `tracer.start_as_current_span(...)` 加自定义 span。导出走 OTLP 到后端（Jaeger/Tempo/SigNoz/Uptrace 等）。
- **指标**：用 `prometheus-client`（或 `prometheus-fastapi-instrumentator`）暴露 RED 指标（请求率/错误率/延迟 P50·P95·P99）于 `/metrics`；或经 OTel metrics + Prometheus exporter。
- **多 worker 注意**：每个 uvicorn worker 是独立进程，指标需用多进程模式（`PROMETHEUS_MULTIPROC_DIR`）或由采集端聚合；追踪 exporter 各 worker 各自初始化。

## 3. 健康检查（RULE-OBS-01）
- `/health`（liveness，进程存活，**不依赖**外部）与 `/ready`（readiness，**依赖**就绪：DB 可连、迁移到位、关键下游可达）分开；容器/编排据此探活与摘流。

## 4. 生产化运行与发布（RULE-OBS-04）
- **服务方式**：生产用 Gunicorn 管多 `uvicorn.workers.UvicornWorker`（或 `uvicorn --workers`）；worker 数按 CPU 与负载调，配合连接池上限（见 `RULE-PERF-01`）避免 DB 连接被 worker×pool 放大耗尽。
- **优雅停机**：资源生命周期用 `lifespan`（见 `RULE-API-04`）——启动建引擎/池/客户端，停机 `await engine.dispose()`、flush 日志/追踪、停止接新请求后再退出；依赖编排发 `SIGTERM` 给宽限期。
- **容器化**：用 uv 官方镜像分层（先 `COPY pyproject.toml uv.lock` → `uv sync --frozen --no-dev` → 再 `COPY` 源码），最大化缓存、可复现（见 `RULE-DEP-01`）。
- **配置**：所有观测后端地址、采样率、日志级别走环境变量（`RULE-CONF-01`）。

## 5. 阶段映射（不改冻结门禁）

| 阶段 | 动作 |
|---|---|
| design | 定日志字段约定、追踪埋点边界、指标清单、健康检查语义、部署形态与 worker/池关系 |
| tasks | 落 logging/OTel/metrics/health/lifespan；按 `RULE-OBS-*` 标注 |
| test | 验证 `/health`·`/ready`、日志为结构化且无敏感信息、关键路径有 span/指标；证据标 L1–L3（L4 可在 staging 看真实链路） |
| deliver | 随发布同步部署配置/容器/环境变量；交付语义不超证据等级 |

## 6. 反模式
- 用 `print` 调试、明文日志泄敏、日志无 trace 关联导致跨服务排障困难。
- 单进程裸 `uvicorn` 上生产、无优雅停机导致发布丢请求。
- worker×pool 连接数超过 DB 上限 → 高并发下连接耗尽。
