# 模式与阶段检测逻辑

> 两层检测：先判**用哪种模式**（正向开发 / 代码孪生），模式 A 再判**处于哪个阶段**。先做**路由判定**（本项目是否属本域，见 SKILL.md 本域识别签名）。

## 0. 路由 + 模式检测（先做）

**路由（带权证据组合，非单一命中 · P2-01）**：本域是 FastAPI Web 后端。证据分强弱，避免误移交合法 FastAPI 项目、也避免错误接管非 FastAPI 项目：

| 证据 | 权重 | 说明 |
|---|---|---|
| 依赖含 `fastapi`/`starlette`（pyproject.toml / uv.lock / requirements*.txt / poetry.lock） | **强（任一即强命中）** | 最可靠指纹 |
| 源码出现 `FastAPI(...)` 实例或 `APIRouter(...)`（`app/main.py` 或应用工厂 `create_app`） | **强** | 直接证据 |
| ASGI 应用入口（`uvicorn`/`gunicorn ... -k uvicorn.workers`/`asgi.py`） | 中 | 佐证 |
| `alembic.ini`、固定包路径（`app/`、`src/<pkg>/`） | **弱（可选指纹）** | 仅辅助，不单独定域 |

**判定**：任一**强证据**命中 → 本域接管；只有弱证据（如仅有 `alembic.ini`）→ 不足以定域，继续找强证据或问用户。**布局覆盖**：兼容 扁平根目录、`src/` 布局、自定义包名、应用工厂 `create_app()` —— 不因布局非 `app/main.py` 而漏判。**排除**：出现 PyQt/PySide/tkinter 等桌面 GUI 依赖（且无 Web 强证据）→ 非本域（Python 上位机）。命中别域→礼貌移交；都不命中/多域同命中→一句话问用户。

**流程裁剪判定（小修是否走完整六阶段 · P2-02）**：小型修复**默认仍归模式 A**，但可按风险裁剪，**不可裁剪底线**恒定：

| 维度 | 可精简（轻量路径） | 必须走完整六阶段 |
|---|---|---|
| 风险/影响面 | 局部、单模块、无外部契约变化 | 跨模块、影响面大、触及鉴权/资金/数据一致性 |
| 契约变化 | 无 API/schema/迁移变化 | 改 API 契约/response schema/DB 迁移 |
| 可逆性 | 易回滚 | 难回滚/有数据迁移 |

轻量路径可**不建 `4-tasks/`**、合并 spec/design 要点为一段说明，但**不可裁剪底线**：① 仍先出方案等放行（RULE-PROC-01）② 仍写复现/回归测试并绑定证据（RULE-TEST-03）③ 仍过 deliver 出口门禁的归档/回写/证据分级 ④ 仍禁臆测外部、禁裸 PASS。相同风险的修复在不同会话必须走一致流程，判据以本表为准，不凭手感。

**模式**（命中本域后）。Chinese natural-language equivalents count exactly like their commands (F9):

| 信号 | 判定 |
|---|---|
| `/sdd-iterate`，或"实现/新增/修改/修复/优化某功能"、"按这个需求做" | **模式 A**（六阶段） |
| `/sdd-init`，或"给项目做文档/接手老项目/梳理代码/生成代码地图" | **模式 B**（代码孪生） |
| `/sdd-update` | 工作台维护（开迭代前巡检 hook） |
| `/sdd-docs` | docs 治理与文本化 |
| `/sdd-tidy`, or 「规整项目目录」「收拾项目结构」「整理目录结构」 | structure tidy-up (gated plan; moves/archives only, never deletes — see tidy-protocol.md) |
| `/sdd-retro`, or 「复盘本次对话」「总结这次的教训」 | retro loop (write `specs/retro/` only) |
| `/sdd-help`、`/sdd-custom` | **技能元命令**：不扫项目指纹、无项目也直达（help=交互式讲用法；custom=设定个人偏好）。多 sdd-xx 并存归属不明→一句话问用户 |
| 纯工具诉求 | 直接用对应工具，不拉起整套流程 |
| 模式 A 但 `specs/README.md` 不存在，且有存量代码 | 先走一轮模式 B（`/sdd-init`），再回模式 A |
| 模式 A 但 README 不存在，且是全新 0→1 项目 | 直接进模式 A 从 constitution 开始 |
| 判断不了 | 一句话问用户：新做/改功能（A），还是把现有代码整理成文档（B）？ |

`specs/README.md` 与 `specs/task.md` 是两种模式共享的记忆基础，每次会话开始先读。

## 1. 阶段检测（模式 A 内部）

固定顺序检测，README 前置：
1. `specs/README.md` 不存在 → 提示"需先建立项目认知"
2. constitution → 未就绪则进入
3. spec → 4. design → 5. tasks → 6. test → 7. deliver（依次，未就绪则进入该阶段）
8. 全部就绪 → complete

**就绪条件（可执行语义，非"文件存在即就绪" · P0-02）**：对应阶段判为就绪须满足 [gate-and-stages.md](gate-and-stages.md)「阶段就绪判定」的确定性事实——`current.md` 存在**且**日期头合法、状态值有效、必填章节有实质内容、无残留占位符（`<!-- 待填 -->`/`TODO`/空 `<…>`）。空模板、历史文件、纯占位文档**不算就绪**。design 可在 `preliminary/`、`overall/`、`detailed/` 任一子目录就绪（同样按实质内容判）。

**Hollow state (not "stage not entered")**: a stage directory holding a `history/` but no `current.md` is **not** evidence that the stage was never entered — it is a hollow state left by an incomplete archive. Report and repair it per specs-lifecycle.md §4 **before** inferring the current stage, and never conclude from it that the stage's work must be redone.

**兜底**：AI 直接列 `specs/` 目录，按上表逐阶段核对 `current.md` 是否存在**且**是否满足上述就绪判定，得出当前阶段；可用 `check_iteration_docs.py` 做机械初筛（占位符/日期头），但它**不能代表 Gate 通过**。
