# 标准目录结构

> `specs/` 与 `docs/` 的标准结构与命名约定。核心：每阶段 `current.md` + `history/` 归档；`task.md` 归档到 `specs/task/`；`docs/` 文本化产物进 `docs/converted/`。归档纪律见 specs-lifecycle.md，**禁止直接覆盖/删除**。

## specs/ 标准结构
```
specs/
  README.md                    ← 项目认知文档（两种模式共享，所有阶段的信息基础）
  task.md                      ← 全局任务看板/指挥台（每次会话第 2 步必读，带日期头）
  task/                        ← task.md 历史归档目录
    YYYY-MM-DD-<说明>.md
  sources.md                   ← 来源/新鲜度登记表（外部输入依赖，模板见 templates/sources.md；配合 docs/requirements/）
  open-issues.md               ← 全局治理入口：疑点/冲突/待验证（纯净度规则，模板见 templates/context-open-issues.md）
  retro/                       ← 复盘与经验沉淀（/sdd-retro 写入；账本+各主题文件）
    README.md                  ←   复盘账本/索引（模板见 templates/retro-readme.md）
    retro-YYYY-MM-DD-<主题>.md ←   每主题一篇（模板见 templates/retro-entry.md）
  context/                     ← 项目认知层（按「项目认知/架构/模块/场景/证据」组织，非源码目录平铺）
    features.md                ← 项目级：功能范围（按需建）
    domain-model.md            ← 项目级：领域术语/模型（按需建）
    architecture.md            ← 架构级：分层/运行单元模型/数据流/关键控制逻辑（L1）
    data-model.md              ← 架构级：关键数据模型（按需建）
    db-schema-and-config.md     ← 本域全局状态/数据模型（DB schema 与配置项清单）
    engineering-baseline.md     ← 模式 B 工程质量基线审计（现状→RULE→差距，模板见 templates/context-engineering-baseline.md）
    modules.md                 ← 模块级：模块索引与接口（L2/L3）
    modules/                   ← 模块级：单模块详文（按需，00-xxx.md）
    scenarios/                 ← 场景级（一等公民）：跨模块业务链路
      README.md                ←   场景索引（一句话/链路一行）
      <xxx-chain>.md           ←   单条链路（模板见 templates/context-scenarios.md）
    evidence-trace.md          ← 证据级：关键结论的源码/资料/测试出处与证据强度
    code-map.md                ← 代码地图/源码索引入口（可选，模式 B 的 L4）
    knowledge-map.md           ← 知识地图（导航总台：主题→去哪看）
    iteration-log.md           ← 迭代记录（日期管理，原名 history.md）
    <本域按需补充>             ← 如：外部接口清单、并发模型、配置项清单（见 S6 EXTERNAL_TOUCHPOINTS）
  _tools/                      ← 项目级脚本（可选，如 build_source_index.py）；允许存在但非强制
  _generated/                  ← 机器产物（可重建/可清理/可不提交），如 source-index/；禁混入 context/
  1-constitution/current.md + history/ + increments/
  2-spec/current.md + history/ + <子功能>/ + clarify-log.md(可选) + increments/
  3-design/current.md + history/ + preliminary|overall|detailed/(可选) + increments/
  4-tasks/current.md + history/        ← 两段式：规划→门禁→执行→门禁；+ increments/
  5-test/current.md + history/ + increments/ + evidence/<迭代>/
  6-deliver/current.md + history/ + increments/ + artifacts/
```

## docs/ 结构（用户输入文档与文本化产物）
```
docs/
  <原始输入文档：需求规格书/协议/规范，可能是二进制>
  requirements/                ← 需求收件箱（/sdd-init 建立）：上游派单/人工投放需求/契约变更通知落此；认领=登记进 specs→归档副本→清空（签收，见 requirement-inbox-protocol.md）
  product-specs/               ← 长期存续的需求规格 / 产品基线（跨认领存活，永不清空）。**绝不**放进 requirements/——那个目录认领时会被清空（F37）
  converted/                   ← 文本化产物统一放这里（见 docs-binarification-adapter.md）
    README.md                  ←   索引与映射 + hash/日期
    manifest.json              ←   机器可读校验记账
    <同名文件夹>/              ←   二进制→同名文件夹，一个工作簿/一节一个文件
    <同名文本文件>             ←   无需转换的文本→同名文件
  reverse/                     ← 模式 B 上游反推草稿（逆向自源码，待人确认，与正向六阶段隔离）
    README.md                  ←   索引 + 反推日期 + 整体可达性分布 + 未闭合缺口数
    detailed-design.draft.md   ←   详细设计草稿（大部可反推）
    high-level-design.draft.md ←   概要设计草稿（结构可反推、意图部分可反推）
    srs.draft.md               ←   需求规格书草稿（功能骨架 + 明确缺口，禁臆测）
```
> 反推草稿一律带 `.draft`、带"反推完整度声明"头；**未经用户确认前是草稿，不得当真相源**。协议见 references/mode-b-reverse.md。

## 命名约定
- **工作台 vs 历史**：每阶段工作台 `current.md`（带日期头），历史进同阶段 `history/YYYY-MM-DD-<说明>.md`；`task.md` 历史进 `specs/task/`。**禁止覆盖/删除，先归档再写。**归档目录自身在长大后要分层（≤30 平铺 / >30 按年 / 某年 >60 按月，每层各带一份 `INDEX.md`）——见 specs-lifecycle.md §10；搬迁由 `/sdd-tidy` 在计划门禁下执行。同日同说明的冲突用从 `-02` 起的两位序号消歧（`YYYY-MM-DD-<说明>-02.md`，第一份不带后缀）——见 specs-lifecycle.md §11。
- **`history` 这个名字只保留给阶段日期归档（F37）**：`<阶段>/history/` 装的是工作台文档的 `YYYY-MM-DD-<说明>.md` 快照，仓库里不得有第二个同名却语义不同的目录。两个刻意**不叫** `history` 的邻居：只追加的迭代记录是 `context/iteration-log.md`（**文件**，不是归档目录；原名 `context/history.md`，刻意改名以避开 `history` 这个保留名），按语义版本索引的契约快照走 `contracts/openapi/versions/v<version>/`（按版本索引而非按日期，编排类专用）。判别口诀：**按日期归档 → `history/`；按版本快照 → `versions/`；只追加的流水记录 → 单个文件**。
- **日期头**：每个 current.md 与 task.md 顶部带 `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->`，作为归档命名与陈旧检测依据。**Exactly three ` | `-separated fields**; the third holds **exactly one** member of the frozen closed set (`就绪` / `进行中` / `已交付待归档`) defined in specs-lifecycle.md §3. **Never write the enumeration inline** — inside the header `|` is the field separator and nothing else, so an inline enum makes a three-field header parse as four and silently breaks every consumer. The three field names are frozen; scripts must grep these literals.
- **README/context**：`specs/README.md` 进入任何阶段前先读；`context/` 拆分过长内容，含**代码地图**与**知识地图**两张导航图。
- **文档纯净度（模式 B）**：`context/` 正文只写已闭合事实；疑点/冲突进 `open-issues.md`；在办任务进 `task.md`。三者不得混写（见 mode-b-twin.md §3）。
- **机器产物分离**：自动生成物进 `_generated/`（可重建/可丢弃），项目脚本进 `_tools/`，**绝不混入 `context/` 正文**；`context/` 可引用 `_generated/` 作辅助索引入口，但事实源仍是源码、资料和测试记录。
- **阶段工作台在位**：当前迭代已进入的每个阶段都必须有自己的 `current.md`；尚未进入的阶段没有（"没有"就是"未进入"的诚实信号——**绝不预建空阶段文件**）。只有 `history/` 却没有 `current.md` 的阶段是空壳态，必须按 specs-lifecycle.md §4 修复。
- **阶段增量容器（F4/F19 元规则）**：每个阶段声明自己的**阶段内小增量**落点——本域取 `<阶段>/increments/` 子目录，一条增量一个文件或一行条目（日期 · 触发来源 · 一句话内容 · 归属阶段 · 状态）。每条增量**同时**登记进容器与 `specs/task.md` 的粗粒度行；增量绝不承载属于别的阶段的内容（该回流的回流）；容器随所属阶段一起归档。完整协议见 specs-lifecycle.md §12。

## 证据落点（F7 元规则 — 本表必填）

每类证据**有且只有一个**权威位置。结论只引用这里的路径，证据文件**绝不跨位置复制**。

| 证据类 | 权威路径 | 由谁写入 | 归档/保留 |
|---|---|---|---|
| 测试执行记录（pytest 终端记录、退出码、收集/通过用例数） | `specs/5-test/evidence/<迭代>/` | test 阶段 | 随 5-test 归档 |
| 构建产物 / 构建日志（`uv sync`、镜像构建日志） | `specs/6-deliver/artifacts/` | tasks / deliver 阶段 | 随 6-deliver 归档 |
| 覆盖率 / 压测 / 审计报告（`reports/junit.xml`、`reports/coverage.xml`） | 项目根 `reports/`（工具直写） | test 阶段 | 归档时**迁移**进 `specs/5-test/evidence/<迭代>/`，不复制 |
| 截图与抓包（接口响应截图、抓包文件） | `specs/5-test/evidence/<迭代>/captures/` | test / deliver 阶段 | 随 5-test 归档 |
| 机器生成索引 | `specs/_generated/` | 项目脚本（`specs/_tools/`） | 可重建，不归档 |

规则：① 本表未声明的证据类**不得写到任何地方**——先在这里声明再写；② 同一份证据文件**不得存两份**（引路径，不复制）；③ `5-test/current.md` 每条结论都带一个指向上表位置的项目相对路径。完整协议见 evidence-gate-protocol.md §7。

## 归档说明词表（`<说明>` 受控词表 — 必填）

归档文件名是 `YYYY-MM-DD-<说明>.md`。`<说明>` **必须以下表词条开头**，其后可选接 `-<自由补充>` 增加区分度。这让 `specs/task/` 与各 `history/` 目录可以按语义检索，而不必逐个打开文件。词条是**与语言绑定的内容，恒为中文原文**（F32），不得翻译。

**通用词条（冻结——每个 sdd-xx 全量继承；本域可追加行，不得删任何一行）：**

| 词条 | 适用场景 |
|---|---|
| `需求澄清` | 需求访谈、澄清轮次、验收点确认的归档 |
| `设计定稿` | 概要/详细设计定稿、架构决策的归档 |
| `任务执行` | 任务拆解与编码执行过程的归档 |
| `测试验收` | 测试用例、执行记录、证据与验收结论的归档 |
| `交付发布` | changelog/release-note/回滚方案、发布记录的归档 |
| `复盘` | 复盘结论、经验沉淀的归档 |
| `契约变更` | 接口/协议/契约版本变更的归档 |
| `派单` | 需求投放、任务派发、跨项目交接的归档 |
| `缺陷修复` | bug 修复迭代的归档 |
| `结构规整` | `/sdd-tidy` 整理动作产生的归档 |

**本域词条（本 skill 追加）：** `迁移变更`（Alembic 迁移方案与执行记录的归档）、`依赖升级`（FastAPI/Pydantic/SQLAlchemy 等依赖版本升级的归档）

规则：① 日期后第一个连字符之前的前缀**必须与某个词条完全一致**；② `-<自由补充>` 可选且自由（迭代名、模块、缺陷号）；③ `/sdd-tidy` 只报告不符合词表的文件名，**绝不重命名**——重命名归档文件由用户决定（tidy-protocol.md §3）。
