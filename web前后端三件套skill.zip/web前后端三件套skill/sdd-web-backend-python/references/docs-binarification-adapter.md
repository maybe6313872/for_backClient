# docs 文本化适配器(独立 · 可换)

> **本模块刻意独立**：把"二进制输入文档(需求规格书 xlsx、协议 pdf、脑图 emmx…)→ 文本"这件**与公司基础设施强相关、会变动**的能力，从框架其余部分隔离出来。所有 sdd-xx 都**只引用本文件定义的契约**，不在各自正文里硬写转换器细节。**基础设施一变(服务地址/工具更替)，只改这一处，全部 sdd-xx 自动跟随。**
>
> 业务插槽 S8 的 `公司 binary-doc-converter` 指向"公司 binary-doc-converter"，落点就是本文件。

---

## 1. 适配器契约(框架级，稳定不变)

任何文本化实现都必须满足这份契约，子 skill 的 docs 流程只依赖契约、不依赖具体实现：

| 契约项 | 要求 |
|---|---|
| 输入 | `docs/` 下任意二进制/文本输入文档 |
| 探测 | 能判断哪些文档需转换、哪些已是文本可直接读 |
| 转换 | 二进制 → 文本(xlsx→CSV/MD 一工作簿一文件；pdf/docx→MD/文本；脑图→层级 CSV) |
| 产物去向 | 统一进 `docs/converted/`：需转的进 `<同名文件夹>/`，无需转的同名文件 |
| 索引 | 维护 `docs/converted/README.md`(源↔产物映射 + 每文件 SHA-256/日期 + 聚合 hash) + `manifest.json` |
| 快检 | 能 `--check` 出"哪些源文档变了需重转"、`--write` 记账刷新索引 |
| 幂等 | 源文档 hash 未变则跳过，保证产物与源一一对应 |

> `specs/README.md` 与知识地图的"参考文档索引"都应指向 `docs/converted/README.md`。

---

## 2. 当前公司实现(⚠️ 基础设施相关，会变动 —— 改动只改本节)

> 以下是**当前**落地方式。公司基础设施变更(如转换服务迁移、换工具)时，**只修改本节**，契约(§1)与各 sdd-xx 引用保持不变。

**能力优先级(探测 + 降级)**：
1. **首选：公司 `binary-doc-converter`**——专做二进制文档文本化的内部能力。
   - 当前承载：内部服务 **`192.168.1.39`**(占位，请按实际确认是 HTTP 服务/共享脚本/独立 skill)。
   - 调用方式：`<待确认 · 按实际基础设施填写：skill 调用 / HTTP 接口 / 命令行>`。
2. **次选：本域内置脚本**——若子 skill 携带了 `xlsx_to_csv.py` 之类零依赖脚本则用之；pdf 调内置 pdf/pdf-reading skill，docx 调 docx skill。
3. **兜底：AI 按需自行文本化**——不禁止，但优先复用上面的能力，避免重复造轮子与不一致。

**索引与快检工具(当前)**：随子 skill 携带的 `docs_index.py`(零依赖)或 `docs_index.ps1`(PowerShell 兜底)：
```bash
python scripts/docs_index.py docs --check   # 退出码1=有需转的
python scripts/docs_index.py docs --write    # 记账并刷新 README.md/manifest.json
```

---

## 3. `/sdd-docs` 标准流程(契约驱动，实现无关)

```
巡检 docs/ → docs_index --check 找出需转的 → 调当前转换器(§2 优先级)文本化
→ 产物入 docs/converted/<同名文件夹>/(一工作簿一文件) → docs_index --write 记账
→ 报告:新增/变更/需重转清单
```

---

## 4. 给"造 skill"时的填法(S8)

- 子 skill 的 SKILL.md / document-tools 章节**只写一句**："docs 文本化遵循 [docs-binarification-adapter.md] 的契约，当前由公司 binary-doc-converter 承载。" 然后把本文件复制进该子 skill 的 references/(或在团队共享位置统一引用)。
- **不要**把 `192.168.1.39` 或具体调用方式散写进子 skill 正文——那会让基础设施变更时被迫改 N 个 skill(business-slots S8 的留空风险)。

---

## 5. 维护提示

- 本节(§2)的变更应记入本 skill 的 README 迭代记录(注明"S8 适配器:旧→新")。
- 若公司把转换能力标准化成稳定接口，可把 §2 收敛成一行接口说明，进一步降低耦合。
- `192.168.1.39` 当前为**占位待确认**——请在首次使用本 skill 时核对真实地址/形态并在此更新。
