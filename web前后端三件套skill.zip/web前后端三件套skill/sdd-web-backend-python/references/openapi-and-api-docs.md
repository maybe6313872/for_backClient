# OpenAPI / 接口文档方法论（本域增强）

> 本域**默认** FastAPI 代码优先（code-first），但**必须先判定契约权威来源**再选流程。对应编码规则 `RULE-API-05`/`RULE-API-06`。落阶段：constitution/认知定权威来源、design 定契约、tasks 落注解、test 校验、deliver 同步并做破坏性变更门禁。

## 0. 先判定契约权威来源（P1-10 · 冻结）

选导出/生成/差异/测试流程**之前**，先在 constitution 或项目认知中确定权威来源，否则会出现"服务端自动文档覆盖已评审契约"或"多份权威文件互相漂移"：

| 模式 | 权威来源 | 同步方向 | 适用 |
|---|---|---|---|
| **code-first**（默认） | FastAPI `app.openapi()` 产物 | 代码 → 导出 `openapi.json` → 下游 | 单团队、后端主导 |
| **contract-first** | 跨仓库/契约仓库/design-first OpenAPI 文件 | 契约 → 生成 Pydantic 骨架 → 实现 → 契约测试校验 | 前后端分离、多团队先定契约 |
| **双向校验** | 契约文件为准 + 代码导出比对 | 双向 diff，冲突以契约为权威 | 已有契约仓库又需服务端演进 |

多份契约冲突时**定优先级**（谁为权威）与**同步方向**；契约权威来源变化属重大决策，记入 constitution/`context`。契约权威来源与技术画像一并确定，见 [stack-profile.md](stack-profile.md) §4。

> 下文以 **code-first** 展开（本域默认）；contract-first 见 §3。

---

## 1. 代码优先：把自动文档"喂饱"（首选路径）

端点声明时补齐以下元信息，让生成的 OpenAPI 可用、可读、可生成客户端：

- **分组与标识**：`APIRouter(tags=[...])`、每端点 `summary`/`description`（docstring 即 description）、稳定的 `operation_id`（客户端方法名依赖它，勿随意改）。
- **响应契约**：`response_model=` + 显式 `status_code=`；**按状态码声明** `responses={401: {"model": ProblemDetails}, 404: {...}, 422: {...}}`，让错误响应也进文档（错误体见 [error-model.md](error-model.md)）。
- **示例**：在 Pydantic 模型用 `model_config = ConfigDict(json_schema_extra={"examples": [...]})` 或字段 `Field(examples=[...])`，让 Swagger UI/客户端有样例。
- **弃用与演进**：过期端点标 `deprecated=True`，不直接删（先标弃用一个版本周期）。
- **安全方案**：鉴权用 `Security(...)`/`OAuth2PasswordBearer` 等，OpenAPI 会生成 `securitySchemes`，文档体现鉴权要求。
- **服务器与元信息**：`FastAPI(title, version, description, servers=[...], contact, license_info)`；`info.version` 表示 **API 版本**，与包版本独立、随发布而非每次提交变动。

## 2. 把 OpenAPI 当契约管起来（CI 产物 + 破坏性变更门禁）

1. **导出为产物**：用脚本调用 `app.openapi()` 导出 `openapi.json`（不必起服务），提交进仓库 `schemas/openapi.json`，作为"当前 API 表面"的快照。
   ```python
   # scripts/export_openapi.py
   import json
   from app.main import app
   json.dump(app.openapi(), open("schemas/openapi.json", "w"), ensure_ascii=False, indent=2)
   ```
2. **破坏性变更检测**：CI 用 **oasdiff**（支持 OpenAPI 3.0/3.1，CLI + GitHub Action）比对基线与改动后规格：
   - `oasdiff changelog base.yaml revision.yaml`（人读变更）
   - `oasdiff breaking base.yaml revision.yaml`（**仅破坏性变更，非空即门禁失败**）
   破坏性变更（删端点、改必填、收窄类型、改状态码语义等）必须显式评审/版本升级，不得静默合入。
3. **版本化**：破坏性变更 → API 大版本（路径前缀 `/api/v2` 或 `info.version` 升级），旧版保留弃用周期。

## 3. 契约优先（design-first，跨团队协作时可选）

当多团队需先定契约再各自实现时：先写/评审 OpenAPI YAML → 用 `datamodel-code-generator` 生成 Pydantic 模型骨架 → 实现 → 用 **schemathesis** 拿 schema 跑契约/属性测试（自动生成用例打实际服务，校验实现与规格一致）。本域默认仍以代码优先为主，契约优先按需启用。

## 4. 阶段映射（与六阶段/门禁衔接，不改冻结门禁）

| 阶段 | 与本主题相关的动作 |
|---|---|
| spec | 明确对外契约形态、错误语义、版本与兼容要求（采访题已含） |
| design | 定 router 分组/tags、response_model 与错误响应矩阵、安全方案、版本策略 |
| tasks | 端点按 `RULE-API-05` 补齐注解；加 `scripts/export_openapi.py` |
| test | 校验 OpenAPI 可导出；如启用契约优先，跑 schemathesis；证据标 L1–L3 |
| deliver | 走冻结 deliver Gate 的"文档全套同步"：导出最新 `openapi.json` + 跑 `oasdiff breaking` 无破坏性变更（或已评审/升版） |

## 5. 反模式
- 端点只有路径、无 `summary`/`response_model`/错误 `responses` → 文档空洞、客户端生成退化为 `any`。
- 随意改 `operation_id`/删端点不标弃用 → 静默破坏下游客户端。
- 把 `info.version` 跟包版本绑死、每次提交乱跳 → 失去 API 版本语义。
