# 统一自检协议（产出前思维链 + 产出后核对）

> 两种模式共用。SKILL.md「核心协作原则」与 collaboration-protocol.md 都指向这里。撰写阶段产出前先过"思维链"，交给用户前逐项过"核对清单"。

## 产出前思维链（撰写阶段产出前先过一遍）

```
## 🧠 开始前梳理
- 当前阶段/模式：{阶段名 或 模式B 的哪一步}
- 输入依据：用户采访要点 / README / task.md 当前状态 / docs 参考 / 上一阶段产出
- 本次产出目标：{一句话}
- 内容边界：本阶段允许 {…}；本阶段禁止 {…}
- 风险/不确定项：{列举，标"待确认"；无则写"暂无"}
```

## 产出后核对清单

撰写完成、交给用户之前逐项核对：

### 1. 越界检查
- 逐段对照当前阶段"内容边界"。发现属于其他阶段的内容 → 移走并标注"此内容属于 {阶段}，后续处理"。
- 高频越界：spec 写了实现方案→移 design；design 写了任务拆解→移 tasks；tasks 重定义需求→回流 spec。

### 2. 图文一致检查
- 每个图的节点名/箭头方向与正文一致；图中无正文未提及的节点；图节点 ≤15，超出拆分。

### 3. 幻觉检查
- 每个技术细节（接口签名、协议字段、依赖行为、数值参数）是否有明确来源（用户文档/项目代码/采访回复/README）？无来源 → 标"**待确认**"并提问。

### 4. 引用检查
- 是否与 `specs/README.md` 已知信息矛盾？是否正确引用了已有模块/风格/功能？

### 5. 对齐检查
- 是否回应了用户采访里的每个回答？是否遗漏某需求/约束？用户明确说"不做"的是否出现在产出里？

### 6. 场景闭合检查
- 是否记录了触发场景、输入、输出、成功标准、异常边界？是否把用户文档转成确认题并获确认？场景不清是否暂停编码继续澄清？

### 7. 编码与一致性检查（涉及代码修改时）
- 改动文件是否符合本域编码规则集（见 coding-rules.md）？（本域 UTF-8，仅核对无 BOM/LF，无需乱码扫描）

### 8. 开发进度检查
- 是否列出已开发/未开发/阻塞/下一步？是否同步写入 `specs/task.md`？是否用 5 行内摘要告知用户？

### 9. 模式 B 反推自检（产出 docs/reverse/ 草稿时）
- 反推文档每个函数/接口/数据流，能在 `context/modules*`、`code-map`、`architecture/data-model` 找到对应？找不到 → 标 `[待澄清]`，**不得臆造**。
- 纯推断的需求/场景/阈值/验收标准 → 必须标 `[缺口]`/`[待澄清]`，**禁止**用顺滑文字写成貌似完整的需求。
- 有缺口时**禁称"完整需求规格书"**，须为"草稿（含 N 处待澄清/缺口）"；"反推完整度声明"的可达性分布/未闭合缺口与正文标记数是否一致？
- 每个缺口标记是否在 `specs/open-issues.md` 有对应条目？完整规则见 [mode-b-reverse.md](mode-b-reverse.md)。

### 10. 迭代边界与复盘自检
- 开新迭代前：是否过了**迭代入口门禁**（读 task.md / 先归档上一迭代 / 写新迭代头 / 读 retro 账本）？见 [gate-and-stages.md](gate-and-stages.md)。
- 交付前：是否过了**迭代出口门禁**（task.md 更新+归档 / history 追加 / open-issues 收口 / 复盘判定）？
- 是否查过 `specs/retro/README.md` 账本、命中相关教训并复用/规避？本迭代若有犯错或亮点 → 是否走了 `/sdd-retro`？见 [retro-protocol.md](retro-protocol.md)。
- Date header integrity: does every workbench document written this session start with the canonical header, using exactly `迭代标识` / `迭代日期` / `状态` and a single in-set `状态` value? If any project script (phase detection, index generation, gate backstop) reads the header, does its pattern match these three literals? A renamed field fails **silently** — check the pattern, not the script's exit code. `check_iteration_docs.py` grades this: an out-of-set `状态` is a critical failure, a legacy 4-field split is a warning.
- Stage presence: after any archive performed this session, does the stage still have a `current.md` with a valid date header? Did the archive and the replacement happen in **one** action? Is there any stage with `history/` but no `current.md` (hollow state → repair per specs-lifecycle §4, reconstructing from the newest archive, never inventing content)?

### 11. 用户偏好护栏自检（每次产出通用）
- 本次表达是否已按 `preferences/user-preferences.md` 的风格/习惯调整（空则默认「专业可靠」）？
- 是否守住**偏好优先级护栏**——没有为迎合偏好而弱化任何门禁/证据/采访/归档纪律？用户说法有误时是否坚持原则而非盲从？
- 是否守住**只读护栏**——本次除 `preferences/`（及项目 `specs/retro/`）外，**未改动**任何 skill 文件？见 [custom-protocol.md](custom-protocol.md)。

### 12. 工程闭环自检（design/tasks/test 涉及代码时）
- **模块闭包**：新功能是否按 `app/<feature>/` 闭包落地，聚合入口只注册？没把 router/schema 塞公共热点文件？（RULE-STRUCT）
- **类型/Lint/CI**：mypy/Ruff 有配置且命令进统一质量入口？覆盖率有基线且不退化？（RULE-TYPE-04/RULE-LINT/RULE-CI）
- **配置/组合根**：配置单一入口+启动期校验？依赖在组合根装配、import-safe？（RULE-CONF-02/RULE-DI）
- **测试分层与证据**：纯业务/高风险分支有单元测试？接口测试显式驱动 lifespan？每条测试结论绑定命令/退出码/用例数/产物/版本？（RULE-TEST、evidence-gate §1a）
- **契约与错误**：契约权威来源已定、每接口过最小验证矩阵、oasdiff 无破坏？错误语义统一、载体符合项目契约（新项目 problem+json / 存量既有信封）？（RULE-API-06/RULE-ERR-03）
- **i18n**（若启用）：消息按模块拥有稳定键、缺失键/占位一致性检查？（RULE-I18N）
- **推荐栈≠事实**：是否先记录技术画像、区分不变量/默认/存量事实，本次升级是有依据的最小改动？（RULE-PROC-05、stack-profile.md）

### 13. 需求收件与各粒度 specs-first 自检
- `docs/requirements/` 有无未认领需求？认领是否走"登记进 specs→归档副本→清空签收"？（requirement-inbox-protocol.md）**And did the clear touch nothing outside `docs/requirements/`** — `docs/product-specs/`, `docs/iterations/`, `docs/decisions/` must be byte-identical before and after the claim (F37).
- **G5**：本次每处实质改动是否在 specs 有对应记录，无"改码无痕"？
- **G6**：交付声称的产物/证据是否与 `git status`/实际文件配对，无虚报、无意外未登记改动？On a mismatch: block, report, and ask the user for disposition — never auto-revert. Gate IDs follow the frozen namespace in [gate-and-stages.md](gate-and-stages.md) §Gate numbering namespace; a domain gate never borrows a `G` number.
- Were all external input copies consumed this session verified against their `sources.md` registration (stale → reported, re-copied on approval)?

### 14. Evidence landing-point self-check (F7 §7)
- Does every evidence file produced this session sit at the **single authoritative landing point** declared in this skill's `structure.md`? Was any evidence class written to a location the table does not declare (→ declare it first, do not improvise)?
- Does every conclusion in `5-test/current.md` carry a resolvable project-relative path to its evidence file? Any conclusion tagged L1–L5 **without** such a path → strip the level and fix the link before output.
- Was any evidence file **copied** into a second location this session (forbidden — reference the path instead)? External input copies are exempt and follow `sources.md`（specs-lifecycle.md §9）。

### 15. In-stage increment self-check (specs-lifecycle.md §12)
- Did any small increment appear this session (hotfix note, corrected acceptance point, inserted small requirement, re-run case)? If yes: is it registered in **both** this stage's increment container **and** `specs/task.md`? An increment living only in the conversation, or in a file outside `specs/`, is unregistered → register it before output (G5).
- Does every increment's content actually belong to **this** stage? Anything belonging elsewhere → move it out / flow it back; the container is not a place to park out-of-stage content.
- Does any registered increment touch an acceptance point, an interface, or a test conclusion? If yes, was the corresponding gate item re-opened rather than left ticked?

## 回流协议
发现需回流（修正 spec/design）时：停止当前产出 → 向用户说明回流原因 → 等确认 → 回流修正 → 重走目标阶段 Gate → 通过后回原阶段继续。
