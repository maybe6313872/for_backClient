# specs 生命周期与归档机制（必读）

> 这是一个**必读模块**。它定义 `specs/` 工作区的领域模型、文档的生命周期、归档纪律，以及在什么时机触发什么动作（hooks）。核心铁律：**`specs/` 下任何文档都不许被直接覆盖或删除——要更新就先归档旧版本，再写新的工作台版本。** 违反这条会丢失项目演进史，是严重错误。

---

## 1. 为什么要这套机制

`specs/` 是项目的长期记忆。如果 AI 在新迭代里直接覆盖 `2-spec/current.md`、或换任务时直接清空 `task.md`，历史就没了——没人能回溯"上个版本的需求是什么、为什么这么改"。所以我们把 `specs/` 建模成一个**有状态、有归档纪律的工作区**：每类文档都分"工作台(current/活动)"与"历史(history/归档)"，更新走"先归档后新建"，并由固定的 hooks 在关键时机自动执行归档与刷新。

---

## 2. 领域模型：工作台 vs 历史

每类文档都有**一个工作台版本**（当前活动、可读可写）和**一组历史版本**（只读、按日期归档）。

| 工作台（活动文档） | 历史归档位置 |
|---|---|
| `specs/task.md` | `specs/task/YYYY-MM-DD-<说明>.md` |
| `specs/1-constitution/current.md` | `specs/1-constitution/history/YYYY-MM-DD-<说明>.md` |
| `specs/2-spec/current.md` | `specs/2-spec/history/YYYY-MM-DD-<说明>.md` |
| `specs/3-design/current.md` | `specs/3-design/history/YYYY-MM-DD-<说明>.md` |
| `specs/4-tasks/current.md` | `specs/4-tasks/history/YYYY-MM-DD-<说明>.md` |
| `specs/5-test/current.md` | `specs/5-test/history/YYYY-MM-DD-<说明>.md` |
| `specs/6-deliver/current.md` | `specs/6-deliver/history/YYYY-MM-DD-<说明>.md` |

> 注意命名差异（与既定约定一致）：`task.md` 归档到 **`specs/task/`** 目录；六个阶段的 `current.md` 归档到各自的 **`history/`** 子目录。**`<说明>` 不是自由文本**：它必须以本 skill `structure.md` 声明的归档说明词表条目开头，其后可选接一个连字符与自由补充——`YYYY-MM-DD-<词表条目>[-<自由补充>].md`。✅ `2026-06-02-需求澄清-新功能X`、`2026-06-15-测试验收`。❌ `2026-06-15-登录重构`（迭代名不是词表条目）、`2026-06-20-2026-06-19`（日期）、`2026-07-02-归档`（零信息量）。词表与语言绑定，恒为中文。
>
> 设计阶段的可选子目录（`preliminary/`、`overall/`、`detailed/`）若使用，其历史同样进各自的 `history/`；`current.md` 始终是该阶段的最小工作台入口。

---

## 3. current.md 日期头（陈旧检测与归档命名的依据）

每个 `current.md` 顶部必须带一行**日期头**注释，作为归档命名与"是否就绪"判断的依据：

```
<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
```

- **迭代标识**：本工作台当前服务的任务，如"新功能X"。
- **迭代日期**：本轮迭代开始日期；归档时用它命名历史文件。
- **状态**：冻结闭集 `就绪` / `进行中` / `已交付待归档` 中的**恰好一个**成员（唯一定义见下方状态枚举表）；**绝不行内罗列备选项**——`|` 是字段分隔符。deliver Gate 通过后，把相关 current.md 标为 `已交付待归档`，提示下次开工前需先归档。

**六个阶段的 `current.md` 加上 `specs/task.md`——七份工作台文档都必须以恰好一行日期头作为首行。** 它是工作台的机器可读把手：§5 用它拼归档文件名、开迭代前巡检用它判陈旧、入口/出口门禁查它、归档 `INDEX.md` 从它复制两个字段。缺合法日期头的工作台文档是缺陷，先修再继续任何阶段工作（§4）。

**规范形态（与语言绑定的字面量——逐字节照抄，绝不翻译）：**

```
<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->
```

**冻结字段集——恰好这三个名字、这个顺序，无同义词、无附加字段：**

| 字段 | 含义 | 取值规则 |
|---|---|---|
| `迭代标识` | 本工作台当前服务的任务 | 简短中文短语，如 `新功能X`；同一迭代的七份文档取值一致 |
| `迭代日期` | 本轮迭代开始日期 | `YYYY-MM-DD`；§5 原样用作归档文件名前缀 |
| `状态` | 工作台状态 | 下方冻结集合中的**恰好一个**成员——绝非自由文本，绝非枚举罗列 |

**状态枚举（冻结闭集）：**

| `状态` 取值 | 含义 | 由谁置位 |
|---|---|---|
| `就绪` | 工作台干净，可以承接新迭代输入 | 归档完成后，或 `/sdd-init` 搭骨架时 |
| `进行中` | 本迭代正在填充 | 新迭代启动时 |
| `已交付待归档` | 内容属于已完成的迭代 | deliver Gate 通过后 |

**本表是状态枚举的唯一定义处。** 任何其他文件都不得重述合法取值集合，只能引用本表。

**解析契约（冻结）**：字段间分隔符是 ` | `（空格、竖线、空格）；字段名与取值间是 `: `（冒号、空格）；`状态` 取值是**单个**枚举成员。因此日期头恰好切成**三段**——`header.strip('<!- >').split('|')` 得 3 段，`segments[2].split(':', 1)[1].strip()` 得冻结集合中的一个成员。

**具体日期头的取值规则（旧缺陷正是出在这里）**：真实日期头只记录**该文档当前的状态**。写成 `状态: 进行中|已交付待归档` 这种把备选项罗列出来的形态是不合规的。备选项只在上面的表里记录，别处一律不写；本框架任何位置的示例日期头都不得出现一个以上的状态值——因为 `|` 是字段分隔符，行内枚举会让三字段日期头被解析成四段。两个尾部片段还都长得像合法状态值，于是解析**不会报错**，只会静默给出错误结果，这比直接崩溃更糟。

**硬规则：**

1. **不得改名。** `迭代编号`、`迭代ID`、`日期`、`iteration-id` 等任何其他拼法都**不合规**。子技能不得重定义这些名字——这是框架冻结的、与语言绑定的字面量内容（F32），不是业务槽位。
2. **不得加字段。** 额外元数据写进正文或 `task.md`，绝不写进日期头——追加第四个字段会打破所有消费方的位置假设。
3. **脚本按字面量 grep。** 任何检测器、门禁脚本或索引生成器都必须逐字匹配上面三个名字。grep 其他名字的脚本无论看起来返回什么都是缺陷：它**静默失效**，匹配不到任何东西然后回退到默认值。脚本写完或评审时，都要拿它的模式对照本表核一遍。
4. **`状态` 迁移。** 新迭代启动时 `就绪` → `进行中`；deliver Gate 通过后 `进行中` → `已交付待归档`（这是"下轮开工前该归档了"的信号，§4/§6）；`已交付待归档` → `就绪` 只能经由一次完整的 §5 归档，由它写入全新的日期头。`状态` 缺失、为空或落在冻结集合之外的日期头一律按**未就绪**处理并上报用户——绝不猜、绝不取默认值。

---

## 4. 文档的生命周期状态

一个 `current.md` 在三种状态间流转：

```
就绪（空/全新，可迎接新迭代输入）
   │  新迭代输入 + 用户放行
   ▼
进行中（本迭代正在填充）
   │  本迭代 deliver 通过
   ▼
已交付待归档（内容属于已完成的迭代）
   │  开新迭代前巡检 / 用户明确迭代完成
   ▼
（归档到 history/，抽取必要信息 → 回到"就绪"的干净 current.md）
```

**"就绪"判定**：current.md 为空、或仅含模板占位、或日期头状态为"就绪"。**非就绪而要开新迭代** → 必须先归档（见 §5）。

**Out-of-set handling (frozen).** A header whose `状态` field is **missing, empty, unparseable, or outside the frozen set of §3** is judged **not ready**, and the condition is **reported to the user with the file path**. Never guess the value, never default it to `就绪`, and never proceed as if the workbench were clean — an unreadable status is exactly the case where the archive filename cannot be safely composed either (§5 step 1).

**Presence rule (frozen).** While an iteration is in flight:

1. **Every stage this iteration has already entered MUST have its `current.md`.** "Entered" = the stage was worked on in this iteration, or its gate was passed — regardless of whether its content was later archived. A stage with a `history/` but no `current.md` is a **hollow state**: an illegal, transient-only condition, never a resting shape of the workspace.
2. **Stages not yet reached MUST NOT be faked.** Do not pre-create empty `current.md` files for stages this iteration has not started: absence is the honest signal that the stage has not been entered, and detection (detection.md) reads it that way. Creating them would make detection report progress that does not exist.
3. **Archiving is atomic with respect to presence.** The §5 archive is not complete until the replacement `current.md` exists with a valid date header (§3). "Moved the old content into `history/`" and "wrote the new `current.md`" are one indivisible action; never end a turn, a session, or a gate between them.
4. **Repairing a hollow state.** On finding a stage with `history/` but no `current.md`: report it, read the newest archive in that `history/` (its date-header `迭代标识` tells which iteration it served), and reconstruct a minimal `current.md` — **date header + a carry-forward section holding the still-valid conclusions extracted from that archive, plus an explicit line stating it was reconstructed from `history/<file>` on `<date>`**. Never silently invent stage content, and never re-run the stage as if it had never been done: what actually happened is recorded in the archive, and open questions go to `open-issues.md`. A placeholder-only reconstruction (header + `[待澄清] 本阶段结论待从归档回填`) is acceptable and honest; a fabricated one is not.
5. `specs/task.md` follows the same rule: it always exists while an iteration is in flight, is archived per §5, and its replacement is written in the same action.

---

## 5. 归档操作（标准动作）

当某工作台文档需要让位给新迭代，或被要求更新已有内容时，执行以下步骤（**绝不直接覆盖**）：

1. **读日期头**，取得 `迭代日期` 与 `迭代标识`，组合出归档文件名 `YYYY-MM-DD-<说明>.md`。**随后在归档目录的所有层级（§10）里检查这个名字是否已存在，按 §11 消歧**——冲突则从 `-02` 起追加最小可用的两位序号；绝不覆盖、绝不用时刻、绝不临场自创后缀。
2. **移动**当前 `current.md` 内容到对应历史位置（阶段 → `<阶段>/history/`，task → `specs/task/`）。即在历史目录新建该文件并写入旧内容（保留完整原文，不裁剪）。
3. **抽取必要信息到新的干净 `current.md`——强制，且在同一个动作里完成**：新文件不存在，归档就没完成。把仍然有效、下一迭代需要承接的结论（如稳定的约束、未关闭的待确认项、对外接口现状）提炼进新 current.md，并写好新的日期头；其余细节留在历史文件里可回溯即可。日期头状态在新迭代真正启动前写 `就绪`，启动后写 `进行中`。若确实没有任何可承接内容，也仍要把文件建出来——日期头 + 一行占位，**绝不让某个阶段没有 `current.md`**（§4 在位规则）。
4. **保持工作台整洁**：新 current.md 只装"当前迭代相关"的内容，不堆历史。

> 抽取多少信息是工程判断：原则是"让下一迭代不必翻历史也能正确起步"，但不要把整段历史复制进新 current.md。

---

## 6. Hooks：触发时机 → 动作

这是机制的执行核心。在以下时机，按表执行对应动作。`/sdd-*` 命令是这些 hooks 的显式入口（见 commands.md）。

| Hook | 触发时机 | 动作 |
|---|---|---|
| **开迭代前巡检** | 用户提出新需求要开始新迭代；或执行 `/sdd-update`；或 `/sdd-iterate` 启动时 | 巡检 `task.md` 与所有 `current.md`：凡状态=`已交付待归档`、或内容明显属于上一迭代 → 先执行 §5 归档；旧 `task.md` 归档到 `task/` 并新建本迭代看板；确认所有工作台"就绪"后再开工 |
| **Input-copy freshness（外部副本新鲜度）** | 开迭代前巡检；或任何阶段消费外部副本文件之前 | 按 §9 逐行比对副本与其 `sources.md` 登记；过期 → 上报用户，获批后重取——绝不静默沿用过期副本 |
| **阶段门禁通过** | 用户明确"通过/进入下一阶段" | 定稿该阶段 `current.md`（更新日期头）；更新 `task.md` 的粗粒度进度 checklist；给一份开发进度澄清 |
| **迭代交付完成** | 用户明确"本迭代完成"；或 deliver Gate 通过 | 把本迭代 `task.md` 归档到 `task/` 并准备/清空看板；按需把各阶段 `current.md` 标记/归档；**刷新代码地图与知识地图**；在 `context/iteration-log.md` 追加一行迭代记录 |
| **禁覆盖守则** | 任何要覆盖或删除 `specs/` 下既有文档的动作——including the routine case "this stage's `current.md` still belongs to the previous iteration and I am about to write the new one" | **拦截**：禁止直接覆盖/删除 → 改走 §5 先归档再写。**Archive in place, then continue — do not stop and report an error.** Sequence: ① read the existing document's date header → ② perform the full §5 archive (compose `YYYY-MM-DD-<说明>.md`, move the content into the archive location at its currently deepest level per §10, resolve any name collision per §11, write the `INDEX.md` row) → ③ create the clean `current.md` with the new date header and the extracted carry-forward conclusions → ④ write the intended new content → ⑤ tell the user, in one line, what was archived and where. Only stop and ask when the date header is missing or unreadable and the archive name cannot be determined (§4). ❌ Never report "cannot overwrite" and leave the archiving to the user; ❌ never append the new iteration's content below the old content in the same file |
| **Structure tidy-up（结构规整）** | `/sdd-tidy` 运行（F35） | 在已放行的计划内：按 §5 归档扫描发现的陈旧工作台（状态 `已交付待归档` 或内容属上一迭代）；对越过 §10 阈值的归档目录做重新分层；创建/刷新每一层的 `INDEX.md`。**门禁化且只移动**——未获放行不归档、不移动，任何情况下不删除（tidy-protocol.md） |
| **docs 变化** | `docs/` 有新增/更新；或 `/sdd-docs` | 重算源文档 hash/日期，对照 `docs/converted/README.md`，按需重新文本化并更新索引（见 [docs-binarification-adapter.md](docs-binarification-adapter.md)） |
| **代码结构变化** | 代码改动；或模式 A 的 deliver | 重跑源码索引（可选 `build_source_index.py`），diff 出变化，更新受影响模块的孪生文档与知识地图（见 [code-map.md](code-map.md)、[mode-b-twin.md](mode-b-twin.md)） |
| **需求收件** | `docs/requirements/` 有上游派单/投放需求；或 `/sdd-iterate` 启动 | 登记进 specs（对应 spec/迭代）→ 归档副本 → 清空收件箱（＝签收，非完成）；更新 `sources.md` 新鲜度（见 [requirement-inbox-protocol.md](requirement-inbox-protocol.md)） |

**Archive trigger whitelist (frozen, closed).** Archiving fires at exactly these five moments and nowhere else: ① pre-iteration inspection (incl. `/sdd-iterate` kickoff) · ② `/sdd-update` invoked directly · ③ `/sdd-tidy`, inside its approved plan · ④ **a no-overwrite interception hit** · ⑤ the deliver exit gate / "iteration delivered". **Map to the table above**: ① and ② are the two entry points of the same first table row (开迭代前巡检), which is why five whitelist moments come from nine table rows; ③ is **Structure tidy-up**; ④ is **禁覆盖守则**; ⑤ is **迭代交付完成**. The remaining rows (Input-copy freshness, 阶段门禁通过, docs 变化, 代码结构变化, 需求收件) do **not** fire a §5 archive. Two consequences follow. **No other moment archives spontaneously** — an archive firing outside this list is an unrequested side effect. And **every moment on this list archives without being asked** — encountering one of these five and not archiving is the omission this whitelist exists to prevent. Trigger ④ is the one most often skipped: it is a normal, expected, in-flow action, not an error path.

---

## 7. 与命令、与两种模式的关系

- `/sdd-update` = 显式触发"**开迭代前巡检**"hook（工作台维护：巡检+归档+整洁），详见 commands.md。
- `/sdd-init` = 重建项目认知（Mode B），完成后刷新代码地图与知识地图。
- `/sdd-docs` = 触发"docs 变化"hook。
- `/sdd-iterate` = 启动 Mode A 全流程，内部在开工时触发"开迭代前巡检"，每阶段触发"阶段门禁通过"，结束触发"迭代交付完成"。

无论走哪种模式、哪条命令，**禁覆盖守则始终生效**。

---

## 8. 反例与纠正

**反例 1：直接覆盖**
❌ 新迭代来了，直接在 `2-spec/current.md` 上改写需求。
✅ 先把旧 `current.md` 归档到 `2-spec/history/2026-06-02-旧需求.md`，抽取仍有效的约束到新 current.md，写新日期头，再开始写新需求。

**反例 2：换任务清空 task.md**
❌ 上个 bug 修完，直接把 `task.md` 清空写新任务。
✅ 旧 `task.md` 归档到 `specs/task/2026-06-02-修复某缺陷.md`，再新建本任务看板。

**反例 3：迭代前不巡检就开工**
❌ 上一迭代的 `4-tasks/current.md` 还满是上次的任务，直接往里加新任务。
✅ 开工前巡检发现它状态=已交付待归档 → 先归档 → 在干净的 current.md 里做本迭代拆解。

**反例 4：归档时把历史全搬进新 current.md**
❌ 归档后又把旧内容整段复制进新 current.md，工作台依旧臃肿。
✅ 只抽取下一迭代需要承接的结论，其余留在历史文件可回溯。

**反例 5：把 task.md 归档成一个滚动追加的单文件**
❌ 迭代结束，把 `task.md` 的小结追加到 `specs/task-archive.md`，下个迭代再往后追加，如此往复。
✅ 把整份 `task.md` 归档为 `specs/task/2026-06-02-任务执行-新功能X.md`（保留完整原文，不裁剪），再新建看板。归档目的地是**一个目录、一迭代一文件**，不存在单文件形态（task-kanban-protocol.md §4）。名为 `task-archive.md` 的文件即便存在，也只是约定说明，永远不是归档目的地。

---

## 9. 外部输入副本：`sources.md` 登记表 + 新鲜度核对

存放**外部资料副本**的目录（如 `specs/2-spec/inputs/`、`docs/requirements/<迭代>/inputs/`——需求规格快照、脚本副本、协议摘录）不走上面的归档纪律，但有自己的失效模式：源头更新了，副本静默腐烂，随后某阶段消费了过期副本。

**登记表**：每个这类目录维护一份 `sources.md`（模板：`assets/templates/sources.md`），一份副本一行：副本文件名 · 源路径/URL · 取用时间 · 取用时的源版本/mtime/内容哈希 · 备注。

**新鲜度核对（开迭代前巡检、以及任何阶段消费副本之前的硬动作）**：
1. 对 `sources.md` 的每一行，比对源头当前的 mtime / 版本 / 内容哈希与登记的取用值（只读）。
2. 不一致 → **上报用户，获批后重取**（随即更新登记行）；源头不可达 → 标 `⚠️ 待确认` 进 `open-issues.md`。
3. ❌ 绝不静默把已知过期的副本带进 spec/design；❌ 绝不新增未在 `sources.md` 登记的副本。

---

## 10. 归档目录分层（F36）

归档目录只增不减——禁覆盖铁律保证了这一点。放任平铺，一个归档根迟早堆上几百个长相一样的文件名，从此不可读，本机制要保护的长期记忆就这么静默死掉了。下面的规则是**冻结的元规则**：钉死的是机制、阈值与强制索引，**不是**任何域的路径名、层级命名格式或索引排版风格——那些留在本 skill 的 `structure.md`。

**R1 —— 每个归档目录都必须有分层规则。** 适用范围：`specs/task/`、每个 `<阶段>/history/`（含 design 阶段可选的 `preliminary|overall|detailed/history/`），以及本域在 `structure.md` 里声明的任何其他归档目录。没有声明规则的目录是缺陷，由 `/sdd-tidy` 报告。

**R2 —— 阈值（按目录计数，只数归档 `.md` 文件；`INDEX.md` 永不计入）：**

| 情形 | 布局 |
|---|---|
| ≤ 30 个归档文件 | 平铺，直接放在归档根下 |
| > 30 个归档文件 | 一年一个子目录：`<归档根>/YYYY/` |
| 任一年份 > 60 个归档文件 | 该年内再按月分：`<归档根>/YYYY/MM/` |

`YYYY` 与 `MM` 取自归档文件名自带的日期前缀（`YYYY-MM-DD-<说明>.md`），**绝不取文件系统 mtime**。越过阈值不触发立即搬迁：它把该目录标记为**待分层**，由 R5 执行。只重新分层越阈的那个目录，兄弟目录保持现状。目录一旦分层，即便日后文件被合并也不再退回平铺。

**R3 —— 只按年、按月，绝不按周、按天。** 按天的目录把平铺问题原样下移一层——一个目录一个文件不叫分层。按周的目录跨月/跨年含混（ISO 第 1 周可能包含 12 月的日期），且人眼无法把日期映射到周数。其他任何粒度（按季度、按迭代、按作者）都不在契约内。

**R4 —— 每一层都带 `INDEX.md`。** 归档根恒有一份；分层之后每个 `YYYY/`（以及每个 `YYYY/MM/`）各有自己的一份。字段集（表头与语言绑定，恒为中文）：

```
| 文件名 | 迭代标识 | 日期 | 一句话摘要 | 状态 |
```

- **文件名**：归档文件名，写成相对链接。
- **迭代标识 / 日期**：从该文件的日期头（§3）复制；日期头不可读 → 记 `⚠️ 待确认` 并进 `open-issues.md`，**绝不猜**。
- **一句话摘要**：一行说清这一版定下了什么——归档当时写，不是事后回忆重建。
- **状态**：默认 `已归档`；从未交付就被取代的版本记 `已废弃`。

按日期倒序排列，最新在前。父层的 `INDEX.md` 不重复子层的行——它按子目录列出日期区间与文件数。写 `INDEX.md` 行**是 §5 归档动作的一部分**：归了档却没有索引行，等于归档没做完。

**存量豁免（冻结）**：本规则落地**之前**归档的文件属 `pre-R4` 存量，**绝不追溯判为不完整**——"归档没做完"只针对规则生效**之后**的归档动作。`/sdd-tidy` 在某项目首次运行时，**在计划门禁内**逐行提议回填缺失的 `INDEX.md` 行，由用户逐条放行；它绝不把 pre-R4 归档根报成缺陷，也绝不未经放行就写索引行。经过一次已放行回填的目录，永久脱离存量状态。

**R5 —— 分层由 `/sdd-tidy` 以计划方式执行，绝不静默进行。** 扫描报告分层欠账，计划表逐行列出 `当前路径 → 目标路径`，🚦 门禁等放行，只执行已放行的行（tidy-protocol.md）。约束：**只移动——绝不删除、绝不改名**（`YYYY-MM-DD-<说明>.md` 文件名逐字保留，只换目录）；`INDEX.md` 在同一份已放行计划内创建/刷新；会覆盖既有文件的移动改走 §5 归档纪律与 §11 冲突规则。日常的 §5 归档动作总是写进归档根**当前最深的适用层级**——它自己绝不新建层级。

---

## 11. 归档文件名冲突（同日同说明）

同日冲突是常态而非例外：`迭代日期` 是迭代的**开始**日期，`迭代标识` 在整个迭代里稳定，所以同一迭代的每次归档都会拼出同一个名字。迭代中途的一次回流、第二次 `/sdd-update`、或再一次禁覆盖拦截（§6 触发点 ④），都会带着一个已存在的名字走到 §5 步骤 1。

**规则（冻结、确定性）**：写归档文件之前，先查这个拼出来的名字是否已存在——**在归档目录的任意层级**（§10：根、`YYYY/`、`YYYY/MM/`）；分层后的兄弟目录里存在同名，同样算冲突。

- 不存在 → 原样写 `YYYY-MM-DD-<说明>.md`。**同名的第一份归档永不带后缀。**
- 冲突 → 追加两位序号，从 `02` 起：`YYYY-MM-DD-<说明>-02.md`，然后 `-03`、`-04`……
- 序号取该 `YYYY-MM-DD-<说明>` 词干下**最小的未使用**两位数（≥ 02）；早先移动留下的空缺要回填，不跳号。超过 `-99`（实践中未见）就停下问用户，不得静默扩到三位。
- 形态恒为 `YYYY-MM-DD-<说明>[-NN].md`。`<说明>` 仍是简短中文说明，日期前缀位置不变，这样 §10 分层与 `INDEX.md` 生成才继续解析得动。

**禁止：**

- ❌ **绝不覆盖既有归档文件。** 归档目录是只追加的；这就是禁覆盖铁律作用在归档自身上，在这里违反它，等于在"归档"这个动作里亲手销毁历史。
- ❌ **绝不在文件名里放时刻**（`-1432`、`-143207`、ISO 时间戳）。不可读、破坏既定日期前缀形态，而且编了一个没人需要的信息——区分两份同日归档的是顺序，不是钟点。
- ❌ **绝不临场自创** `-v2` / `-new` / `-final` / `-old` / `-fix` 或英文后缀。同词干的两个文件只以序号相区别。
- ❌ **绝不为腾位置去改名或重排既有归档文件。** 既有名字不可变，§10 分层搬迁期间同样如此。

**`INDEX.md`（§10）** 把带序号的文件当普通行列出；它的一句话摘要要说清这一份与当天早先那份的区别（例如 `回流修正后二次归档`）。

---

## 12. 阶段内增量：增量容器（冻结元规则）

§2 的模型只有两个位置——工作台与历史。真实迭代还会产出第三类内容：**阶段内小增量**，中途冒出来的一条热修说明、一处修订的验收点、一个插进来的小需求、一条重跑的用例。没有地方放，它们要么被追加进阶段 `current.md`，直到工作台不再描述一个连贯的迭代（违反 §5.4）；要么彻底活在 `specs/` 之外——聊天记录里、项目根下的散文件里——下次会话就没了。

框架冻结的是机制，**不是它的形态**：

1. **每个阶段都必须提供一个增量容器。** 一个声明过的、属于该阶段的位置，阶段内小增量落在那里。具体形态——子目录、`current.md` 里的固定小节、还是独立文件——由本域的 `structure.md` 定义。不可省的是：它存在，且 `structure.md` 点名了它。没有声明容器，该阶段就不能接收增量。
2. **登记是强制的；没有任何东西飘在 specs 之外。** 落一条增量意味着**两件事同时做**：容器里一条条目（日期 · 触发/来源 · 一句话内容 · 归属哪个阶段 · 状态），**以及** `specs/task.md` 里一条粗粒度行。只在对话里说过、或丢在 `specs/` 之外某个文件里的增量，**就是没登记**，在 G5 下等同于"有业务代码却无 specs 记录"的未完成改动。
3. **容器绝不挪动阶段边界。** 一条增量能被接收，前提是它的内容本来就为该阶段所允许（见 gate-and-stages.md 的逐阶段允许/禁止表）。属于别的阶段的内容**照样移走或回流**——容器不是绕开阶段边界、回流协议或门禁的口子。❌「它很小，就留在 test 吧」正是这条规则要挡的失败。
4. **容器随所属阶段一起归档。** 归档时容器内容与该阶段的 `current.md` 一并归档（§5），保留完整原文。归档时仍未闭合的条目，或者带进新迭代的容器，或者上升进 `open-issues.md`——绝不静默丢弃，绝不孤零零留在陈旧归档里。
5. **增量在门禁上被重新审。** 该阶段门禁运行时要复核累积的增量；触及验收点、接口或测试结论的增量**重新打开**对应的门禁条目。增量不会因为"小"就绕过门禁。

> 与 §9 的关系：`sources.md` 管的是*外部输入的副本*（新鲜度）。增量容器管的是*本项目自己迭代中途的增量*（登记）。两套不同的机制，不要合并。

---

## 13. 需求收件箱与各粒度 specs-first（G5/G6）

- **需求收件箱** `docs/requirements/`：上游派单包 / 人工投放需求 / 跨仓库契约变更通知先落这里；认领＝登记进 specs → 归档副本 → **清空收件箱**（清空＝对上游签收，不代表完成）。完整协议见 [requirement-inbox-protocol.md](requirement-inbox-protocol.md)；来源新鲜度登记在 `sources.md`（模板 `assets/templates/sources.md`）。
- **G5 各粒度 specs-first**：任何实质改动（代码/接口/迁移/配置）在动手前都应在 specs 有对应记录（阶段文档或 task.md），杜绝"改了代码但 specs 无痕"。deliver 出口门禁逐条核验。
- **G6 交付与 git 配对**：交付时声称的产物与测试证据必须与 `git status`/实际文件配对，无"声称已改工作区却无变更"、无未登记的意外改动文件。
- **`/sdd-tidy`**：目录结构规整命令，把 AI 继承/造成的非标布局按 [structure.md](structure.md) 归位，**只移动/归档、绝不删除、绝不触碰源码**，与本文件"先归档再写"一致。协议见 [tidy-protocol.md](tidy-protocol.md)。
