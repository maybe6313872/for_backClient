# Python Web 后端服务 编码刚性规则

> 本文件定义 Python Web 后端服务 开发中 AI 必须遵守的编码规则。**这些规则来源于本域实际项目高频出现的 bug 与设计缺陷**，是 design / tasks / test 阶段的强制约束。每条以 `RULE-{主题}-{编号}` 命名，在 tasks 阶段标注、test 阶段逐条验证。
>
> 典型架构：分层架构 —— API 路由层(router) → 服务/领域层(service) → 数据访问层(repository/ORM)；横切为 依赖注入/中间件/配置/日志，Pydantic schema 作入出参边界。

---

## 规则概览（本域）

| 主题 | 前缀 | 防的是 |
|---|---|---|
| 类型与校验 | RULE-TYPE | 弱类型/裸 dict/Pydantic v1 残留、strict 无配置无范围无增量策略 |
| 模块结构 | RULE-STRUCT | 只有横向分层、无纵向业务模块闭包；router/schema/消息挤公共热点文件 |
| 异步一致性 | RULE-ASYNC | async 端点里阻塞事件循环、async/sync 混栈、session 跨任务 |
| 接口契约 | RULE-API | 隐式状态码、错误夹在 200、手解请求、缺分页/幂等、误用弃用的 on_event、文档/契约失守、契约权威来源不明 |
| 数据访问 | RULE-DB | 1.x 风格/全局 session、N+1、惰性加载、手改库结构、service/repository 职责不分 |
| 依赖注入/组合根 | RULE-DI | 无组合根、router 自造基础设施依赖、生命周期不清、测试替换困难、导入期副作用 |
| 安全鉴权 | RULE-SEC | 鉴权遗漏、密钥入码、注入、弱口令哈希 |
| 配置 | RULE-CONF | 硬编码配置/密钥、不分环境、配置无归属/无启动期校验/散落 os.getenv |
| 国际化 | RULE-I18N | 文案散落各层、无稳定消息键、语言资源不按模块拆分、缺失键裸奔 |
| 异常与日志 | RULE-ERR | 吞异常、错误语义不统一、print/日志泄敏 |
| 静态质量 | RULE-LINT | Ruff check/format 无配置、命令/范围会话间漂移、import 未排序 |
| 注释与文档字符串 | RULE-DOC | 公开面缺 docstring、端点无 summary/description 喂 OpenAPI、注释复述代码/过时/死代码 |
| 依赖与环境 | RULE-DEP | 依赖不锁定、不可复现、污染全局、uv/requirements 完成定义不清、Python 版本无闭环 |
| 质量入口/CI | RULE-CI | 无统一质量入口、无最低 CI、覆盖率退化不阻断、跨平台命令语义漂移 |
| 遗留隔离 | RULE-VENDOR | vendor/legacy 源码只读边界缺失、历史对象/阻塞/不稳定返回直穿业务层 |
| 性能 | RULE-PERF | 连接池耗尽、热点无索引/缓存、大响应不分页 |
| 可观测性 | RULE-OBS | 无健康检查、无日志/追踪/指标、错误不可定位、裸 uvicorn 上生产 |
| 测试 | RULE-TEST | 打生产库、缺隔离、缺分层、lifespan 绕过、覆盖率无门禁、证据脱钩、裸 PASS、臆测外部响应 |

> **推荐栈 = 有条件默认，不是通用硬前提**：下列多数规则以「新项目推荐默认栈」（Python 3.11+、FastAPI、Pydantic v2、SQLAlchemy 2.0 async、Alembic、uv、mypy strict、Ruff、pytest）举例；但**工程不变量**（类型可判定、事务边界显式且有归属、测试隔离、依赖可复现、配置单一入口、错误语义统一、async 一致、契约可验证）与**具体栈无关**，存量项目用等价方式满足即可。区分与落地见 [stack-profile.md](stack-profile.md)。

---

## RULE-TYPE 类型与校验

### RULE-TYPE-01：全量类型注解 + mypy strict，禁裸 Any / 隐式 Optional
所有函数签名、参数、返回值带类型；启用 `mypy --strict`。
- ❌ `def get_user(id): ...`　❌ `def f(x: list): ...`
- ✅ `async def get_user(user_id: int) -> User | None: ...`
> **类型检查器选型（按当前生态）**：`mypy --strict` 为默认——对 SQLAlchemy/Pydantic 的插件与生态最成熟、最稳；pyright 可作替代（spec conformance 高、IDE 集成好）。`ty`(Astral)/`pyrefly`(Meta) 为新晋 Rust 检查器、速度极快但仍处 beta、对 ORM/Pydantic 插件支持尚未就绪，**暂不建议作为唯一 CI 门禁**，可与 mypy 并跑用于编辑器快反馈。选型属 constitution 决策，定了就在 design/test 一致执行。

### RULE-TYPE-02：入出参用 Pydantic v2 模型，路由声明 response_model，禁裸 dict
请求体/响应体一律 Pydantic 模型；路由显式 `response_model`（或返回类型）+ `status_code`。
- ❌ `@app.post("/users")`　`async def create(data: dict): return {"ok": 1}`
- ✅ `@router.post("/users", response_model=UserOut, status_code=201)`　`async def create(payload: UserCreate) -> UserOut: ...`

### RULE-TYPE-03：用 Pydantic v2 API，禁 v1 残留
用 `model_config = ConfigDict(...)`、`field_validator`、`model_validator`、`model_dump()`；禁 `class Config`、`@validator`、`.dict()`、`.parse_obj()`。
- ❌ `class S(BaseModel):`　`    class Config: orm_mode = True`　`obj.dict()`
- ✅ `class S(BaseModel):`　`    model_config = ConfigDict(from_attributes=True)`　`obj.model_dump()`

### RULE-TYPE-04：strict 类型有配置、有范围、有增量策略（禁口号化）
`mypy --strict`（或 pyright）不是一句口号，必须在项目层面落定：**配置位置**（`pyproject.toml [tool.mypy]` / `mypy.ini`）、**目标 Python 版本**（`python_version` 与 `requires-python` 一致）、**检查包范围**（业务包纳入；测试代码是否纳入需明确）、**Pydantic/ORM 插件**（`pydantic.mypy`、SQLAlchemy stubs/插件）、**第三方 stub**、**排除**（`vendor`/`generated`/`migrations`）。`Any` 的合法边界须显式（边界解析层可窄用，业务层禁裸 `Any`/隐式 Optional）；`# type: ignore` 必须带错误码且登记到期条件。**存量项目无法一次 strict** 时：建立基线（`mypy` 现状清单）、**禁止新增类型债**、逐目录逐步收紧，不得用大范围 ignore 骗过门禁。选型属 constitution 决策，命令与 CI 证据见 [quality-gate-and-ci.md](quality-gate-and-ci.md)。
- ❌ 只在文档写"启用 mypy strict"，无配置、无范围、无 CI；或用 `ignore_errors = true` 整包放行
- ✅ `[tool.mypy]` 明确 `strict=true`、`python_version`、`plugins`、`exclude`；存量给基线 + 增量收紧计划

---

## RULE-STRUCT 模块结构（业务模块闭包）

### RULE-STRUCT-01：纵向业务模块闭包，聚合入口只负责注册
一个业务能力**共同拥有**自己的 router / schemas / service / repository(或 adapter) / errors / messages(i18n) / tests，落在 `app/<feature>/` 包内；**聚合层只做注册**（`app/api/__init__.py` 只 `include_router`，`app/main.py` 只组装）。有三层不等于有模块闭包——把全部 router 塞一个 `api.py`、全部 schema 塞一个 `models.py` 仍是反模式。完整规范见 [module-architecture.md](module-architecture.md)。
- ❌ `api.py` 汇总所有模块路由；`models.py` 汇总所有模块 schema；新增功能改多个公共热点文件
- ✅ `app/user/{router,schemas,service,repository,errors,messages,tests}.py`；`app/api/__init__.py` 仅注册各模块 router

### RULE-STRUCT-02：模块公开面窄、跨模块依赖向下、共享代码有准入
模块只暴露窄公开面（router + service/facade + 公共 schema）；内部实现（repository/SQL/行映射）模块私有。跨模块**只向下依赖共享内核**（config/db/logging/errors 基类），禁横向依赖彼此内部、禁循环依赖；复用需 ≥2 模块真正稳定复用才升到 `app/core`/`app/shared`，避免过早抽象。存量扁平项目按最小改动渐进抽取，差距记 `open-issues.md`。

---

## RULE-ASYNC 异步一致性

### RULE-ASYNC-01：async 端点内禁阻塞事件循环
async 路由/依赖里禁同步阻塞调用（`requests`、`time.sleep`、同步 DB 驱动、阻塞文件 IO、CPU 密集）；用异步库或 `await run_in_threadpool(...)` / `await asyncio.to_thread(...)`。
- ❌ `async def h(): r = requests.get(url); time.sleep(1)`
- ✅ `async def h():`　`    async with httpx.AsyncClient() as c: r = await c.get(url)`

### RULE-ASYNC-02：不混 async/sync 栈，session 不跨任务共享
async 端点配 async 引擎/`AsyncSession`/async 驱动；`AsyncSession` 随请求创建与释放，禁跨请求/跨任务共享。sync 端点不得 `await`。
- ❌ 全局单例 `session = Session()` 在多个 async 端点复用
- ✅ 依赖注入按请求 yield 一个 `AsyncSession`（见 RULE-DB-01）

### RULE-ASYNC-03：并发与后台任务受控
并发用 `asyncio.gather`/`TaskGroup`；轻量后台用 `BackgroundTasks`，重任务交专用队列（Celery/ARQ）。禁裸 `create_task` 不留引用导致任务被回收/异常吞没。

---

## RULE-API 接口契约

### RULE-API-01：显式状态码 + 统一错误体，禁 200 夹错误
成功/失败状态码显式；领域错误转 `HTTPException` 或经全局异常处理器收口为统一错误结构；禁返回 200 里塞 `{"error": ...}`。

### RULE-API-02：用 APIRouter + 版本前缀，参数显式声明，禁手解请求
路由用 `APIRouter` 分组 + 版本前缀（如 `/api/v1`）；路径/查询/体参数显式声明类型与校验；禁手动 `await request.json()` 再自校验。

### RULE-API-03：列表分页 + 写接口幂等
列表接口带分页（limit/offset 或 cursor）并设上限；写接口考虑幂等（幂等键/唯一约束），避免重复提交产生脏数据。

### RULE-API-04：应用生命周期用 lifespan，禁用已弃用的 on_event
启动/关闭资源（DB 引擎与连接池、Redis/HTTP 客户端、缓存预热）用 `lifespan`（`@asynccontextmanager`）管理；`@app.on_event("startup"/"shutdown")` 已弃用，禁新写。
- ❌ `@app.on_event("startup")`　`async def startup(): ...`
- ✅ `@asynccontextmanager`　`async def lifespan(app: FastAPI):`　`    engine = create_async_engine(...); yield; await engine.dispose()`　`app = FastAPI(lifespan=lifespan)`

### RULE-API-05：文档即契约（OpenAPI 喂饱 + 破坏性变更门禁）
FastAPI 代码优先生成 OpenAPI 3.1：端点必须有 `tags`/`summary`、`response_model` + 显式 `status_code`、按状态码声明错误 `responses=`（错误体用 problem+json，见 RULE-ERR-03）；过期端点标 `deprecated` 不直接删。CI 导出 `openapi.json` 作契约产物，用 `oasdiff breaking` 检出破坏性变更并门禁，破坏性变更须评审/升 API 版本。完整方法论见 [openapi-and-api-docs.md](openapi-and-api-docs.md)。
- ❌ 端点只有路径、无 summary/response_model/错误 responses
- ✅ `@router.get("/items/{id}", response_model=ItemOut, responses={404: {"model": ProblemDetails}}, summary="获取条目")`

### RULE-API-06：先定契约权威来源，每个接口过最小验证矩阵
**契约权威来源必须先判定**（constitution/认知记录）：**code-first**（FastAPI `app.openapi()` 为权威，默认）/ **contract-first**（跨仓库 OpenAPI、契约仓库、design-first 文件为权威）/ **双向校验**；多份契约冲突时定优先级与同步方向，禁用服务端自动生成文档覆盖已评审契约。每个新增/变更接口至少验证：正常 2xx + 实际响应 schema、输入校验 422、未认证 401、无权限 403、领域失败（404/409…）、分页/幂等边界；`operation_id` 唯一、oasdiff 无破坏性（或已评审升版）。矩阵详见 [testing-strategy.md](testing-strategy.md) §5、权威来源见 [stack-profile.md](stack-profile.md) §4。
- ❌ 只测 happy path；契约权威来源不明、两份"权威文件"互相漂移
- ✅ 先记录权威来源；每接口覆盖 2xx/422/401/403/领域失败/边界；CI 跑 oasdiff breaking

---

## RULE-DB 数据访问（SQLAlchemy 2.0 + Alembic）

### RULE-DB-01：2.0 风格 + 注入式 AsyncSession + 显式事务边界
用 SQLAlchemy 2.0 风格（`Mapped`/`mapped_column`/`select()`）；`AsyncSession` 经依赖注入随请求开关；事务边界显式（`async with session.begin():`）。禁全局共享 session、禁 1.x `query()` 全表风格、禁裸 SQL 字符串拼接。
- ❌ `session.query(User).filter(...)`（1.x/全局）
- ✅ `engine = create_async_engine(url, pool_pre_ping=True)`　`async_session = async_sessionmaker(engine, expire_on_commit=False)`
- ✅ `async def get_session() -> AsyncIterator[AsyncSession]:`　`    async with async_session() as s: yield s`　（驱动：PostgreSQL 用 `postgresql+asyncpg://`、MySQL 用 `mysql+asyncmy://` 或 `aiomysql`）

### RULE-DB-02：防 N+1，async 下禁惰性加载
关系预加载用 `selectinload`/`joinedload`；async 引擎设 `expire_on_commit=False` 并显式加载，避免提交后惰性触发 `MissingGreenlet`。
- ❌ 循环里逐条 `user.orders`（触发 N 次查询/惰性加载）
- ✅ `select(User).options(selectinload(User.orders))`

### RULE-DB-03：schema 变更一律走 Alembic，可回滚
表结构变更用 Alembic 迁移；`autogenerate` 后人工核对（类型/索引/枚举易漏）；提供可执行的 `downgrade`。禁手改库结构或在生产 `create_all`。

### RULE-DB-04：service/repository 职责边界（与 ORM 无关）
职责边界对**原生 SQL / 同步驱动 / 非 ORM** 项目同样成立，不靠文件命名判定：`service` 负责领域校验、编排与**事务边界所有权**；`repository`/`adapter` 负责持久化细节（SQL/驱动/行映射/查询构造）；运行期 DDL 禁在业务路径（走迁移）。一个 `Service` 同时做领域校验+连接管理+DDL+SQL+行映射+重试+响应组装即违规。职责表见 [module-architecture.md](module-architecture.md) §5。
- ❌ `class UserService:` 里直接拼 SQL、开连接、建表、映射行、组响应——"文件名叫 service 就算有服务层"
- ✅ service 只编排并持有事务边界；repository 只 `select/insert`+行→模型映射；DDL 全在 Alembic

---

## RULE-DI 依赖注入与组合根

### RULE-DI-01：组合根集中装配，router 不自造基础设施依赖
service / repository / 外部 API client / 配置 / 时钟 / 消息组件在**组合根**（应用工厂 + `lifespan` + FastAPI `Depends` provider）统一创建与装配；router 只声明 `Depends(...)`，禁自行 `create_engine`/`httpx.Client()`/读环境变量。明确三类生命周期：**应用级**（引擎/连接池/HTTP 客户端，`lifespan` 建立与释放）、**请求级**（`AsyncSession`、`current_user`，按请求 yield）、**瞬时**（无状态工具）。完整规范见 [module-architecture.md](module-architecture.md) 与 RULE-API-04(lifespan)。
- ❌ router 内 `engine = create_async_engine(...)`；重复创建客户端/连接池
- ✅ `lifespan` 建池、`Depends(get_session)` 注入；统一 provider 便于 `app.dependency_overrides` 测试替换

### RULE-DI-02：应用工厂 import-safe，禁导入期副作用
提供 `create_app(settings=...)` 应用工厂，支持传入测试配置与依赖替换。**模块导入期禁止**执行目录创建、配置解析、建连接、网络/文件 I/O、启动后台任务——这些归 `lifespan` 或工厂内。保证测试收集、CLI、迁移脚本、多 worker 导入不触发副作用或重复初始化。
- ❌ 模块顶层 `settings = Settings()` 触发校验/连库；顶层 `os.makedirs(...)`
- ✅ `def create_app(settings: Settings | None = None) -> FastAPI:` 内组装；副作用进 `lifespan`

---

## RULE-SEC 安全鉴权

### RULE-SEC-01：鉴权/授权集中、端点显式声明
鉴权（OAuth2/JWT）经依赖注入校验，受保护端点显式依赖 `current_user`/权限；禁在业务逻辑里散落手写 token 解析。

### RULE-SEC-02：密钥走配置，禁硬编码/入日志/入响应
密钥、凭据、连接串走环境变量/密钥管理（pydantic-settings）；禁硬编码、禁进 git、禁打日志、禁随响应返回。

### RULE-SEC-03：防注入 + 强哈希 + CORS/限流
SQL 用 ORM/参数化绑定，输入用 Pydantic 校验；密码用 argon2/bcrypt（passlib），禁明文/弱哈希；CORS 配白名单、按需限流。
- ❌ `text(f"SELECT * FROM u WHERE name='{name}'")`
- ✅ `select(User).where(User.name == name)`

---

## RULE-CONF 配置

### RULE-CONF-01：pydantic-settings + 环境变量 + 分环境
配置走 `pydantic-settings` 读环境变量（12-factor），区分 dev/staging/prod；禁硬编码 URL/端口/密钥；提供 `.env.example`。

### RULE-CONF-02：配置唯一入口、按域归属、启动期校验、fail-fast
环境变量**只在 `Settings` 一处读取**，业务模块禁散落 `os.getenv`；`Settings` 按域组织（`DBSettings`/`RedisSettings`/…）并经依赖注入取用，默认值单点定义、禁多份重复；配置在**应用启动期**（工厂/`lifespan`）完成校验，错误配置**立即 fail-fast**，不拖到某条业务路径才炸。配合 RULE-DI-02 保证导入期不解析配置。
- ❌ service 里 `os.getenv("DB_URL")`；同一参数多处各写一份默认值；错配到调用时才暴露
- ✅ `get_settings()` 单例注入；启动即校验缺失/非法项并拒绝启动

---

## RULE-I18N 国际化与消息所有权

### RULE-I18N-01：四类信息分离，消息按业务模块拥有稳定键
严格区分：**机器稳定错误码/消息键**（进契约、不翻译）、**用户可见本地化文案**（随 locale 变）、**内部诊断/日志**（开发者向、不本地化、不进响应）、**第三方原始异常原文**（留日志、不透传用户）。每个业务模块**自持**消息资源与命名空间化稳定键（如 `app/<module>/messages/{locale}.json`，键 `user.not_found`），禁全局单一语言大文件成为跨模块耦合热点，禁文案散落 router/service/异常处理器。启用条件、locale 优先级与回退、参数插值、Pydantic/FastAPI 校验错误本地化边界见 [i18n-and-messages.md](i18n-and-messages.md)。
- ❌ 文案硬编码在各层；`raise HTTPException(404, "用户不存在")` 散落；缺失键返回空串/键名裸奔
- ✅ 模块自带 catalog + 稳定键；异常携带 `message_key`，边界处按 locale 渲染

### RULE-I18N-02：翻译完整性是门禁
新增模块或语言时，必须能检查**缺失键 / 冗余键 / 占位参数不一致**（跨 locale 比对键集与占位集），纳入 CI，缺失即失败。校验方法见 [i18n-and-messages.md](i18n-and-messages.md) §6。

---

## RULE-ERR 异常与日志

### RULE-ERR-01：领域异常与 HTTP 异常分离，统一收口，禁吞异常
领域异常独立类型，边界处转 `HTTPException` 或由全局 `exception_handler` 收口为统一错误体；禁 `except: pass` 静默吞异常。

### RULE-ERR-02：结构化日志，禁 print，禁泄敏
用 `logging`/structlog 输出结构化日志，带请求/trace 上下文；禁用 `print`；日志/错误体不得包含密钥、令牌、密码等敏感信息。

### RULE-ERR-03：统一错误语义（不变量）+ 错误载体（项目契约决策）
**要分清两件事**：①**统一错误语义是工程不变量**——错误必须由全局 `exception_handler` 收口（校验 422/HTTP/领域异常/兜底 500）、结构在全 API 一致、错误类型标识跨版本稳定作契约一部分、禁每端点各拼一套、禁 200 里塞错误。②**错误载体是项目契约决策**——**新项目推荐默认 Problem Details（RFC 9457 `application/problem+json`）**；但已发布业务信封、稳定业务码、版本化接口、跨系统兼容要求是合法的既有契约，**不得为套用 Problem Details 而制造破坏性接口变更**，须走兼容性评审（最小改动、既有契约优先）。载体形态与迁移见 [error-model.md](error-model.md)。
- ❌ 200 里塞 `{"error": "..."}`、各端点错误结构不一（违反不变量）；❌ 无视已发布信封强行替换为 problem+json 破坏下游（违反契约优先）
- ✅ 新项目：`JSONResponse(problem_body, status_code=404, media_type="application/problem+json")`；存量：保留既有信封但收口统一、评审后再演进

---

## RULE-DEP 依赖与环境

### RULE-DEP-01：依赖锁定、可复现、优先 uv
依赖锁定（`uv.lock` 优先；pip 用锁/约束）；CI/生产用锁文件可复现安装，禁未固定版本上生产。优先 uv（`uv add` / `uv sync --frozen` / `uv run`），无 uv 时 pip 兜底。

### RULE-DEP-02：虚拟环境隔离 + pyproject 声明
用虚拟环境隔离；依赖与可选组（dev/test）在 `pyproject.toml` 声明；禁全局装包污染环境。

### RULE-DEP-03：uv 与 requirements 各有完成定义；Python 版本成闭环
两条路径都不得降低可复现性：**uv 路径**＝`pyproject.toml` + 依赖分组(main/dev/test) + 提交 `uv.lock` + CI/生产 `uv sync --frozen`；**requirements 兜底路径**＝用 `uv pip compile`/`pip-compile` 生成含哈希的完整 `requirements.txt`（锁定传递依赖）+ 区分 runtime/dev/test 三份 + `pip install --require-hashes`。**仅固定直接依赖版本 ≠ 完整锁定**；工具缺失不是降低锁定标准的理由。**Python 版本闭环**：证据优先级 `requires-python` > 锁文件 > 容器基础镜像 > CI matrix > 部署环境 > 源码语法，据此确认真实支持范围；低于推荐版本时明确 保持兼容/升级/阻塞 三选一并记录；CI 必须在**最低支持版本**验证。详见 [quality-gate-and-ci.md](quality-gate-and-ci.md) 与 [stack-profile.md](stack-profile.md)。
- ❌ 只写死几个直接依赖版本当"已锁定"；无 uv 就退回裸 `pip install`；模板 3.11+ 直接当项目事实
- ✅ 锁文件 + frozen 安装；requirements 兜底也含哈希与三分；CI 跑最低支持 Python 版本

---

## RULE-LINT 静态质量（Ruff）

### RULE-LINT-01：Ruff check 与 format 各司其职、配置入库、命令可复现
`ruff check`（Lint/import 排序，`--fix` 边界受控）与 `ruff format --check`（格式）**职责分开**、都要跑；配置集中在 `pyproject.toml [tool.ruff]`：目标版本(`target-version`)、规则集(`select`/`ignore`)、`isort` 设置、排除目录（`vendor`/`generated`/`migrations`）、逐文件例外(`per-file-ignores`)。constitution 必须对是否采用、规则集、命令形成明确决策；不同会话/平台必须用同一命令与范围。命令矩阵见 [quality-gate-and-ci.md](quality-gate-and-ci.md)。
- ❌ 只零散 `ruff check`、无配置、会话间命令/范围漂移；把 format 当 lint 一把梭
- ✅ `[tool.ruff]` 入库；`ruff check .` + `ruff format --check .` 双命令进统一质量入口与 CI

---

## RULE-DOC 注释与文档字符串范式

### RULE-DOC-01：公开面写 docstring，端点 docstring 喂 OpenAPI，注释解释 why
**类型提示是主契约**，注释与 docstring 是补充。公开面（router 端点、service/facade 公共方法、Pydantic 模型、领域异常）**必须写 docstring**；FastAPI 端点用 `summary=` + docstring（docstring 即 OpenAPI `description`，联动 RULE-API-05）；docstring 风格全项目统一（Google 或 NumPy 二选一，constitution 决策），首行一句祈使句概括。行内注释只解释**为什么/权衡/边界**，不复述"代码在做什么"。**禁**过时注释、**禁**注释掉的死代码（交给版本控制）、**禁**用注释替代类型；`TODO/FIXME` 必带责任人或关联 issue，不留裸 `TODO` 当交付。
- ❌ `# 把 user_id 转成 int`（复述代码）；成片注释掉的旧实现；端点无 summary/docstring 使 OpenAPI description 空洞
- ✅ `async def get_user(...) -> UserOut:`　`    """按 ID 获取用户；不存在抛 UserNotFound(404)。"""`（Google 风格、喂饱 OpenAPI）

---

## RULE-CI 质量入口与持续集成

### RULE-CI-01：统一质量入口（单一事实源）
项目必须提供**一个可复现质量入口**（`make check` / `uv run poe check` / `nox` 等），按固定顺序、失败即阻断依次执行：frozen 安装 → `ruff format --check` → `ruff check` → 类型(mypy/pyright) → 单元测试 → 接口/集成测试 → 覆盖率门禁 → OpenAPI 导出+oasdiff → Alembic upgrade/downgrade 往返。Windows/Linux/CI 执行**同一语义命令**，避免三处漂移。"本地偶尔跑某一项"不算完成。
- ❌ 分散手动跑某几项就宣称完成；三个平台命令语义不一致
- ✅ 单入口串起全部门禁，本地与 CI 复用

### RULE-CI-02：最低 CI 流水线 + 覆盖率不退化
主分支有最低 CI（镜像质量入口）、失败即阻断、产物保存（coverage/openapi/junit），并在最低支持 Python 版本运行。覆盖率：项目决策基线（不固化统一百分比）、**变更覆盖率不低于基线、覆盖率下降即阻断**。详见 [quality-gate-and-ci.md](quality-gate-and-ci.md) 与 [testing-strategy.md](testing-strategy.md)。

---

## RULE-VENDOR 遗留/第三方源码隔离

### RULE-VENDOR-01：vendor/legacy 只读边界 + 反腐层
仓内 vendor/legacy 源码视为**只读外部依赖**：业务代码只面向本项目定义的适配接口，不直接依赖其历史对象/不稳定返回结构；在反腐层完成数据转换、异常转换（第三方异常→领域异常）、同步阻塞行为的隔离（`run_in_threadpool`）；vendor/legacy 目录纳入质量工具**排除**并单独登记补丁归属，禁其阻塞/不稳定行为直穿核心业务层。
- ❌ 业务层直接 import legacy 模块、直接用其裸返回；把第三方异常原样抛给用户
- ✅ `app/<module>/adapter.py` 反腐层封装；legacy 目录 mypy/ruff 排除 + 记 open-issues 治理

---

## RULE-PERF 性能

### RULE-PERF-01：连接池合理、热点优化、大响应分页
DB 连接池（`pool_size`/`max_overflow`/`pool_pre_ping=True`）按并发配置并确保 session 关闭，避免连接耗尽与失效连接；热点查询加索引/缓存；大结果集分页或流式返回。

---

## RULE-OBS 可观测性

### RULE-OBS-01：健康检查 + 关键路径埋点
暴露 `/health`（存活）与 `/ready`（依赖就绪）；关键路径有指标/日志（可选 OpenTelemetry tracing），保证错误可定位、可回溯请求链路。

### RULE-OBS-02：结构化日志 + trace 关联
用 structlog/JSON logging，每条日志带 `request_id` 与 `trace_id`/`span_id`（从当前 OTel span 注入），实现日志 ↔ 链路互跳；敏感信息不入日志、异常栈进日志不进响应。

### RULE-OBS-03：分布式追踪 + 指标
用 OpenTelemetry `FastAPIInstrumentor.instrument_app(app)` 自动埋点（支持 async/后台任务/并发上下文），DB/httpx 配对应 instrumentor；`/metrics` 暴露 RED 指标（请求率/错误率/延迟 P50·P95·P99）。多 worker 下指标用多进程模式或采集端聚合。

### RULE-OBS-04：生产化运行与优雅停机
生产用 Gunicorn 管多 uvicorn worker；worker×连接池不得超 DB 连接上限（配合 RULE-PERF-01）；资源生命周期用 `lifespan`（RULE-API-04）做启动建池/停机 `engine.dispose()` 与平滑收尾，依 `SIGTERM` 宽限期停机不丢请求。容器用 uv 分层构建（RULE-DEP-01）。完整指引见 [observability-and-production.md](observability-and-production.md)。

---

## RULE-TEST 测试

### RULE-TEST-01：进程内接口/集成测试 + DB 隔离（不是真 E2E）+ 显式 lifespan
用 `pytest` + `pytest-asyncio`（或 anyio）+ `httpx.AsyncClient` 跑**进程内接口/集成测试**；客户端用当前写法 `AsyncClient(transport=ASGITransport(app=app), base_url="http://test")`（`app=` 简写已弃用）。**明确**：`ASGITransport` 进程内测试**不是真实端到端**（真 E2E 需真实进程+网络+依赖），勿混称。**lifespan 不会被自动执行**：DB 池/HTTP 客户端/缓存若在 `lifespan` 初始化会被绕过——必须**显式驱动 lifespan**（`asgi-lifespan` 的 `LifespanManager(app)` 或进入应用 `lifespan` 上下文的 fixture），并对 startup/shutdown 有断言。DB 依赖与鉴权依赖用 `app.dependency_overrides` 覆盖为测试库/桩；DB 用独立测试库或事务回滚 fixture 隔离，禁打生产/共享库。见 [testing-strategy.md](testing-strategy.md) §1、§3。
- ❌ `AsyncClient(app=app)`（弃用）／直连真实数据库／`ASGITransport` 假设资源已就绪、把它叫端到端
- ✅ `async with LifespanManager(app):` + `AsyncClient(transport=ASGITransport(app=app), ...)`；`app.dependency_overrides[get_session] = override_get_test_session`

### RULE-TEST-02：测试分层 + 覆盖率不退化 + 稳定性 + 外部用桩
按测试金字塔选层（单元/服务/repository 集成/接口/适配器契约/迁移/系统 E2E）；**纯业务逻辑与高风险分支的单元测试是最低强制**，显式豁免须记理由。覆盖率用 `pytest-cov --cov-branch`，项目决策基线、变更覆盖率不低于基线、覆盖率下降即阻断（仅映射验收点发现不了未执行的防御/异常/权限分支）。稳定性：固定随机种子、注入时钟(禁 `datetime.now`)、固定 tz/locale、用例间无共享可变状态、`pytest-timeout`、flaky 必须定位根因不得"重跑即过"当高等级证据。外部依赖（第三方 API/MQ/缓存）用桩/mock，不臆测真实响应（呼应 RULE-PROC-03）。分层矩阵与稳定性细则见 [testing-strategy.md](testing-strategy.md)。

### RULE-TEST-03：测试证据必须绑定可复现资产（禁自然语言脱钩）
测试结论标 L1-L5、禁裸 PASS，且**每条结论绑定**：可重放命令、退出码、收集用例数、结果产物路径（junit/coverage 报告）、版本标识（commit/tag）。禁用自然语言表格记录"pytest 通过 N 例"却无真实、可发现、可重放的测试资产；历史终端结论、人工勾选、已删除测试不得当交付证据。见 [evidence-gate-protocol.md](evidence-gate-protocol.md) §1a。
- ❌ 文档写"pytest 全绿 12 例"，但仓库无测试文件/无法发现/无产物
- ✅ `pytest -q → exit 0, 收集 12 项, 报告 reports/junit.xml, commit abc1234`

---

## 流程纪律（RULE-PROC · 框架自带，所有域通用，勿删）

### RULE-PROC-01：未经用户授权不写代码
任何实现类任务先输出方案（问题理解、影响范围、改哪些文件/函数、风险点、验证方式），等用户明确"同意/实施/写入"再落代码。

### RULE-PROC-02：不跳过方案/测试/评审/门禁
六阶段每阶段后停下过 Gate 等放行；tasks 必须真正写出代码而非只给计划；禁止从 constitution 连跑到 deliver。

### RULE-PROC-03：不臆测外部行为、不写裸 PASS
第三方接口/协议字段/依赖语义/数据库(PostgreSQL/MySQL)、Redis/缓存、消息队列、第三方 HTTP API、对象存储、鉴权/SSO 服务 必须有依据；测试结论标 L1–L5，不混写成 PASS。

### RULE-PROC-04：specs 禁覆盖、先归档再写
更新 current.md/task.md 前先按 specs-lifecycle 归档旧版本。

### RULE-PROC-05：先记录技术画像，再决定是否升级（推荐栈≠项目事实）
接手或迭代前先记录项目**技术画像**（Python 版本、async/sync、数据访问方式、迁移机制、包管理、类型/lint 现状、契约权威来源），区分 **工程不变量 / 新项目推荐默认 / 存量当前事实**（见 [stack-profile.md](stack-profile.md)）。禁把推荐默认栈伪装成项目事实；是否替换数据访问/包管理/迁移栈是**有依据的决策**，最小改动优先，不强制大范围替换，也不容忍长期形式违规——差距记 `open-issues.md` 与工程基线差距清单。
