# 模式 A 各阶段详细要求与门禁

> SKILL.md 模式 A 表格的展开。每个阶段：职责 → **内容边界(允许/禁止)** → 越界正反例 → 采访要点 → Gate 条目 → 自检。**每阶段后必须停下过 Gate 等放行（门禁红线 1）。** tasks 两段式是高频翻车点，单列。

## 门控执行流程（每阶段通用）
```
产出完成 → 过 self-check.md 自检 → 展示产出摘要 → 展示 Gate checklist 逐项状态 → 等用户确认"通过" → 进入下一阶段
```
Gate 展示格式：
```
## Gate 检查 — {阶段名称}
- [x] 条目1：已通过
- [ ] 条目2：部分通过（说明原因）
以上为本阶段 Gate 检查结果。请确认是否通过，或指出需修正的问题。
```
- **Increment sweep before the gate**: check this stage's increment container (specs-lifecycle.md §12). Every entry is either folded into the stage's `current.md` conclusions, or explicitly carried forward with a stated reason. An increment touching an acceptance point / interface / test conclusion **re-opens** the corresponding gate item — it is never waved through because it is small.

## Gate numbering namespace (frozen)

Gate IDs are a **shared vocabulary across every sdd-xx**: an orchestrator writes a gate ID into a dispatch packet and the executor — running a different skill, in a different window, with no shared context — must resolve it to the same obligation. That only works if the numbering is governed. Two frozen rules:

1. **The bare `G1`–`Gn` segment is reserved for cross-skill universal gates.** Every sdd-xx, whatever its domain or class, defines these identically, byte for byte. A skill may not add to, remove from, renumber, or locally reinterpret this segment. Changing it is a mother-skill action (`/sdd-distill` → `/sdd-absorb` → `/sdd-evolve`), never a local edit.
2. **A domain-specific or class-specific gate MUST take its own prefix and MUST NOT consume a `G` number.** A new domain registers its prefix in the table below when its skill is created. ❌ Writing a domain gate as `G7` is an error. ❌ Reusing a `G` number with a different local meaning is an error.

> **Why**: `G6` once meant "code↔specs pairing" in the orchestrator and "claim↔git pairing" in the executor. A packet saying "comply with G6" made the two sides verify different things, and the union of what neither checked shipped.

> **Scope of this namespace**: it governs **gate IDs only**. Question numbers in an interview/profile question bank (`G1 Which converter? …`) are ordinals of a questionnaire, not gates; they live outside this namespace and are neither renumbered nor prefixed by this rule.

### The universal segment (frozen — identical in every sdd-xx)

| ID | Gate | Obligation | Where it is enforced |
|---|---|---|---|
| G1 | Stage responsibility boundary | Content belongs to exactly one stage; the allowed/forbidden table of the current stage governs. Out-of-stage content flows back (spec/design) instead of being written here. | Every stage gate (F19) |
| G2 | Archiving discipline | Nothing under `specs/` is overwritten or deleted; the previous iteration is archived first (`task.md` → `specs/task/YYYY-MM-DD-说明.md`; stage → `<stage>/history/YYYY-MM-DD-说明.md`), then written. | Iteration entry gate + every write (F4, red line 3) |
| G3 | Evidence grading | Every test/run conclusion carries an L1–L5 level bound to a reproducible asset; delivery semantics never exceed the highest level reached in test. | test gate + deliver gate (F7) |
| G4 | Progress transparency | Before each gate, output the developed / not-developed / blocked / next-step clarification table and sync `task.md`; "it builds" is never reported as "it works". | Every stage gate (F16) |
| G5 | specs-first at every grain | Any code fix or small increment, however small, registers in `specs/` (task.md row + spec entry + context mapping) **before** business code is touched, and every business-code change of this iteration has a paired specs change. Fix-scale work is not exempt. | tasks + deliver gate (F2/F5) |
| G6 | Claim↔git pairing | Before delivery, verify against `git status` that the claimed artifacts and test evidence match the actual working tree — no "claimed changed but no change present", no unregistered incidental changes; the `docs/requirements/` inbox is cleared per claim (acknowledgment, not completion). | deliver gate (F5/F33) |

> G1–G4 give IDs to mechanisms that were already frozen (F19 / F4 / F7 / F16); they introduce **no new obligation**. G5 and G6 keep their existing meanings and are here separated for the first time: G5 is "specs paired with code", G6 is "claims paired with the working tree" — two different checks that must both run.

### Registered domain/class prefixes

| Prefix | Owner | Scope |
|---|---|---|
| `ORCH-*` | orchestration-class skills (F34) | root-side dispatch/checkpoint gates; never appear in a single-stack skill |
| `FE-*` | `sdd-web-frontend` | web front-end domain gates |
| `BE-*` | `sdd-web-backend-python` | web back-end domain gates |

This skill's own domain gates are defined in this file under its registered prefix and never consume a `G` number.

## 迭代入口门禁（开新迭代实质工作前·冻结）
开任何新迭代/新任务的实质工作**之前**必须完成，否则不得动手：
- [ ] 读 `specs/task.md`（会话第 2 步必读）
- [ ] **先归档**上一迭代 task 状态到 `specs/task/YYYY-MM-DD-<说明>.md`（先归档·禁覆盖）
- [ ] 写新迭代头（迭代ID/目标/范围/关联需求/起始日期）到 `task.md`
- [ ] 上一迭代未回写的事实先回写 `README`/`context`，不在过期文档上起新迭代
- [ ] 读 `specs/retro/README.md` 账本，命中相关教训→提醒避免重复、复用亮点（无 retro/ 则跳过）
- [ ] **日期头检查**：在办的所有工作台文档（`task.md` + 已进入阶段的每个 `current.md`）都带合法日期头，字段恰为 `迭代标识` / `迭代日期` / `状态` 三项，且本迭代的 `迭代标识` / `迭代日期` 在各文档间一致（specs-lifecycle §3）
- [ ] **阶段工作台在位**：没有任何阶段目录只有 `history/` 而缺 `current.md`（specs-lifecycle §4 空壳态）——先修复再动实质工作；也没有为尚未进入的阶段预建空 `current.md`
- [ ] 查 `docs/requirements/` 收件箱：有上游派单/投放需求先登记进 specs 再动手（见 [requirement-inbox-protocol.md](requirement-inbox-protocol.md)）
> **机械初筛（非门禁通过证明）**：`python specs/_tools/check_iteration_docs.py --root .` 只做 task.md 存在性/日期头初筛，**不能代表任何阶段 Gate 通过**；Gate 仍须按下方「阶段就绪判定」人工/AI 判定。

---

## 阶段就绪判定（可执行语义 · 冻结 · P0）

> **红线**：阶段"就绪/完成"**不等于**目录下有个 `.md` 文件。空模板、历史文件、未填占位符文档**不算就绪**。判定必须可由确定性事实支撑，缺一不可：

一个阶段判定为**已建立/已完成**，须同时满足：
1. **结构完整**——本阶段 `current.md` 存在，且带合法日期头 `<!-- 迭代标识: <简短说明> | 迭代日期: YYYY-MM-DD | 状态: 进行中 -->`，状态值有效。Exactly three ` | `-separated fields; `状态` holds **exactly one** member of the frozen closed set (`就绪` / `进行中` / `已交付待归档`) defined in [specs-lifecycle.md](specs-lifecycle.md) §3 — never an inline enumeration, because `|` is the field separator and an inline enum makes a three-field header parse as four, silently.
2. **必填章节闭合**——本阶段 Gate 清单各必填章节均有实质内容，非占位。
3. **无残留占位符**——无 `<!-- 待填 -->`/`TODO`/`FIXME`/空 `<…>` 占位；Gate 勾选项 `- [x]` 与实际一致（未完成的诚实标 `- [ ]` 并说明）。
4. **需求追溯闭合**——spec 起每条需求可追到 design/tasks/test（追溯矩阵，见 [evidence-gate-protocol.md](evidence-gate-protocol.md) §4）。
5. **证据存在**（test/deliver）——引用的测试/运行结论绑定真实可回放资产（§1a 证据资产绑定），非自然语言脱钩。
6. **用户放行已记录**——该阶段 Gate 已展示且用户明确放行，记录在 `task.md`/阶段文档（红线 1）；未记录放行的阶段**不得视为通过**。

> 判据同时用于**阶段检测**（[detection.md](detection.md)）：检测某阶段是否"就绪"用上述 1–3 的确定性事实，而非"文件存在即就绪"。

---

> **核心反越界自检口诀**：「这段内容属于哪个阶段？不属于当前阶段就移走。」每阶段都列了允许/禁止，产出后逐段对照。

---

## constitution（项目级工程约束，少而精）
| 允许 | 禁止 |
|---|---|
| 工程约束条目、决策优先级、禁区清单、参考文档索引 | 具体需求描述、设计方案、代码、任务拆解、测试用例 |

- **结构**：两段——通用协议（个人/团队层面，通常很少甚至为空）+ 项目专属协议（平台/构建/运行/禁区，少而精）。
- **采访要点**：见 collaboration-protocol.md constitution 题库。
- **Gate**：
  - [ ] 包含通用协议条目
  - [ ] 包含项目专属协议条目（如 Python 版本下限、async/sync 栈、ORM 与迁移工具、包管理(uv/pip)、类型检查严格度、Lint/格式化、部署形态、密钥/配置来源）
  - [ ] 条目少而精、未混入需求/设计/实现

## spec（定义"做什么"，可验收）
| 允许 | 禁止 |
|---|---|
| 需求(What/Why)、验收标准、边界异常、Clarify Q/A、非功能需求 | 具体技术方案(How)、接口定义、模块划分、任务拆解、测试用例 |

- **越界正反例**：❌「用状态机实现，状态含 IDLE/RUNNING/FAULT」→ design；❌「修改 src/x 的 yyy 函数」→ tasks；✅「系统应在<条件>时触发<结果>」→ spec。
- **Clarify 循环**：每轮最多 5 个澄清点，写「问题 + 答案/决策」；**未关闭关键歧义前 MUST NOT 进入 design**（记在 `2-spec/clarify-log.md` 或并入 spec）。
- **Gate**：
  - [ ] 每条需求有验收标准（checklist / Given-When-Then / EARS）
  - [ ] 边界与异常已覆盖
  - [ ] 每条需求证据口径明确
  - [ ] 关键 Clarify 已关闭

## design（定义"怎么做"）
| 允许 | 禁止 |
|---|---|
| 接口/数据流/状态机/资源/可观测性方案 | 任务拆解、完整函数体代码、测试用例、新增需求 |

- **Gate**：
  - [ ] 构建/运行命令可复现
  - [ ] 关键接口/状态/数据流已定义
  - [ ] 分层落点(router/service/repository)明确；Pydantic schema 与 ORM 模型边界清晰；DB session 注入与事务边界已定义；async/sync 一致；外部依赖有抽象与 mock 方案；迁移(Alembic)策略明确
  - [ ] **业务模块闭包**已定：每业务能力自持 router/schema/service/repository/errors/messages/tests，聚合入口只注册（[module-architecture.md](module-architecture.md)）；service/repository 职责边界可判定（与 ORM 无关）
  - [ ] **组合根与生命周期**已定：依赖在组合根装配、应用/请求/瞬时生命周期清晰、import-safe 应用工厂（RULE-DI）
  - [ ] **配置所有权**已定：唯一入口、按域归属、启动期校验 fail-fast（RULE-CONF-02）
  - [ ] **i18n 边界**已定（若启用）：消息按模块拥有、稳定键、校验错误本地化边界（[i18n-and-messages.md](i18n-and-messages.md)）
  - [ ] **契约权威来源**已定：code-first/contract-first/双向；错误载体（Problem Details 或既有信封）与兼容策略已定（[stack-profile.md](stack-profile.md) §4、[error-model.md](error-model.md)）
  - [ ] **技术画像**已记录：区分工程不变量/推荐默认/存量事实，本次升级决策明确（[stack-profile.md](stack-profile.md)）
  - [ ] 可观测性（日志/监控/调试通道）已设计
  - [ ] 技术方案均有 spec 依据，无"自行新增"的需求

## tasks（拆任务**并写出代码 + 同步必要自动化测试**）＝两段式
| 允许 | 禁止 |
|---|---|
| 任务拆解、按计划写真实代码、**与实现同步写单元/必要自动化测试**、缺陷修复先写复现测试、留验证证据、更新进度 | 新增需求(→回流 spec)、新增设计决策(→回流 design)、**独立验收汇总与跨模块回归证据（→test）** |

> **务必照做。只产出计划不写代码是错误的（门禁红线 2）。**

> **P0 澄清（测试先行不再被禁）**：tasks **允许且要求**在实现同一任务内同步写必要的自动化测试（单元优先、可测试性先行、缺陷修复先写复现测试）；这样实现 Gate 不能仅凭"导入/启动通过"或手工运行糊弄，可测性问题不拖到 test 阶段才爆发。**test 阶段仍保留独立职责**：独立验收、补齐分层/覆盖率/契约、汇总与分级证据（见 [testing-strategy.md](testing-strategy.md) §8）。二者不矛盾——tasks 写"随实现落地的测试"，test 做"独立验收与证据汇总"。

- **第①段 规划**：依据 design+spec 拆 TODO（每条映射 R*/AC*、列改动文件、**写该任务要落的测试**、写验证与证据、标 RULE-*）写入 `4-tasks/current.md`，task.md 反映粗进度。**🚦门禁①**：展示清单等用户批准，未批准不写代码。
- **第②段 执行**：计划获批后逐条写真实代码**并同步写测试**、跑通、留证据。**🚦门禁②**：实现并自验后展示证据，等用户确认再进 test。
- **门禁②追加条目**：每个改动了业务逻辑的任务都落了它计划中的测试；测试跑得起来、退出码为 0 且收集数 > 0（缺陷修复要展示复现测试修复前失败、修复后通过）。
- **越界正反例**：❌「新增一个<某>功能」→回流 spec；❌「把<接口>从方案A改为方案B」→回流 design；✅「T1.2 修改 `app/user/service.py`，实现 R3/AC1 的业务逻辑，遵循 RULE-<主题>-NN，同步 `app/user/tests/test_service.py`，证据：mypy/ruff 通过 + `pytest tests/user` exit 0 收集 6 项」。
- **进度澄清**：本阶段 Gate 前必须输出开发进度澄清表（已开发/未开发/阻塞/下一步），见 [development-progress-protocol.md](development-progress-protocol.md)。

## test（可复现测试与证据）
| 允许 | 禁止 |
|---|---|
| 测试用例、执行记录、证据、漏测风险 | 改需求(→回流 spec)、改设计(→回流 design)、新增功能 |

- **Gate**：
  - [ ] 统一质量入口跑通：`ruff format --check` + `ruff check` + 类型(mypy/pyright) + 应用可导入/启动（[quality-gate-and-ci.md](quality-gate-and-ci.md)）
  - [ ] 测试用例覆盖 spec 验收点，并按测试金字塔分层（单元/服务/repository 集成/接口/契约/迁移），纯业务与高风险分支有单元测试（[testing-strategy.md](testing-strategy.md)）
  - [ ] 用 `httpx.AsyncClient + ASGITransport` 跑**进程内接口/集成测试**（非真 E2E）且**显式驱动 lifespan**；DB 以测试库/事务回滚隔离；覆盖鉴权与错误分支；每接口过最小验证矩阵（2xx/422/401/403/领域失败/边界）
  - [ ] 覆盖率（`--cov-branch`）达项目基线且**不退化**、变更覆盖率达标；契约 oasdiff 无破坏性（或已评审升版）；必要时属性测试(schemathesis)/并发/压测
  - [ ] i18n（若启用）：缺失键/冗余键/占位一致性检查通过，本地化 detail 有断言
  - [ ] 测试稳定性：确定性（固定种子/注入时钟/固定 tz·locale）、顺序独立、无 flaky 蒙混
  - [ ] 每个测试结论标注 L1-L5 且**绑定可复现资产**（命令/退出码/用例数/产物/版本，见 evidence-gate-protocol.md §1a）
  - [ ] 涉及代码修改时，本域编码一致性自检已完成

## deliver（变更/发布/回滚）
| 允许 | 禁止 |
|---|---|
| changelog/release-note/回滚、交付证据、文档同步 | 新增需求/设计/功能；声明高于证据等级的语义 |

- **Gate**（迭代出口门禁·冻结）：
  - [ ] changelog 已更新
  - [ ] release-note 已更新
  - [ ] 回滚策略可执行
  - [ ] 交付证据齐全、文档全套同步（README/context/孪生回写）
  - [ ] 交付语义未高于 test 最高证据等级
  - [ ] `task.md` 已更新（已完成/未完成/阻塞/下一步）+ 5 行摘要，并按生命周期归档（禁直接覆盖）——这一条**就是**"迭代交付完成"钩子，即 specs-lifecycle §6 归档触发白名单的触发点 ⑤
  - [ ] `context/iteration-log.md` 已追加本迭代一行
  - [ ] `open-issues.md` 已闭合项收口、未闭合项进交付风险
  - [ ] **G5 各粒度 specs-first**：本迭代每处实质代码/接口/迁移改动都在 specs（阶段文档/task.md）有对应记录，无"改了代码但 specs 无痕"
  - [ ] **G6 交付与 git 配对核验**：声称的产物与测试证据同 `git status`/实际文件配对——无"声称已改但工作区无对应变更"，无未登记的意外改动文件；`docs/requirements/` 收件箱已按认领清空（签收，非完成）
  - [ ] 统一质量入口全绿、CI 产物齐全（coverage/openapi/junit，见 [quality-gate-and-ci.md](quality-gate-and-ci.md)）
  - [ ] **复盘判定**：本迭代有无犯错/亮点值得复盘？有 → 走 `/sdd-retro` 写入 `specs/retro/`（见 [retro-protocol.md](retro-protocol.md)）
  - [ ] 本迭代触及的每个 `current.md` 以及 `task.md` 都带合规日期头，且 `状态` 已置为 `已交付待归档`（specs-lifecycle §3）——字段被改名或缺失的日期头不得带过交付

---

## 回流
任意阶段发现风险/不一致 → 停止 → 说明回流原因 → 等用户确认 → 回 spec/design 修正 → 重走 Gate → 通过后回原阶段。回流要同步 task.md 并标注受影响模块。

**Flow-back vs increment container (do not confuse them)**: flow-back handles content that **belongs to another stage** — it moves out, no exceptions. The increment container handles content that **belongs to this stage but arrived mid-iteration** — it stays, registered. Using the container to keep out-of-stage content is a boundary violation (F19), not a shortcut.
