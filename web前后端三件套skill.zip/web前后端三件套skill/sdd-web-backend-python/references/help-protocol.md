# 使用引导协议（/sdd-help · F29）

> **定位**：`/sdd-help` 是本 skill 的**技能元命令**——不针对某个项目，而是**面向使用者本人**，交互式讲解"本 skill 怎么用"，并逐步解答使用过程中的任何疑问。它让新人/偶尔使用者无需通读 SKILL.md 与 references 就能上手。
>
> **零副作用**：`/sdd-help` **只读不写**——不改任何项目文件、不改 skill 文件、不拉起六阶段/孪生流程；它只对话。

## 1. 核心原则（冻结）——交互式，禁单方面灌输

- **先问后讲**：进入 `/sdd-help` 先用**一句话欢迎 + 一道选择题**定位用户想了解什么，**不得**一上来甩出大段说明或把 SKILL.md 复述一遍。
- **一次一问、一次一答**：每轮只聚焦一个主题，讲清后再问"还想了解什么"，把节奏交给用户。沿用框架采访优先级（F6）：**选择题 > 带建议值填空 > 确认题 > 开放题**。
- **按需深入**：用户问什么答什么；只在被需要时才链到对应 reference，避免信息过载。
- **贴本域举例**：举例优先用**本域**场景（见 §4 本域引导种子），让讲解可感。
- **承认边界**：超出本 skill 范围的问题（如纯业务实现）如实说明并引导到正确入口（如直接 `/sdd-iterate`）。

❌ 反例：用户打 `/sdd-help`，AI 立刻输出一篇涵盖六阶段+模式B+所有命令的长文。
✅ 正例：AI 说"想先了解哪块？① 怎么从零做需求 ② 怎么梳理老项目 ③ 命令速查 ④ 门禁/归档为什么这么严 ⑤ 设置我的使用偏好 ⑥ 其它"，等用户选了再展开那一块。

## 2. 引导流程

```
/sdd-help
  → ① 一句话欢迎 + 选择题定位（给 4–6 个常见主题选项 + "其它"）
  → ② 用户选定/提问 → 针对该主题简明讲解（必要时配 1 个本域例子）
  → ③ 收尾一问："这块清楚了吗？还想了解：[相邻主题选项] / 没有了"
  → ④ 循环②③直至用户结束；结束时给一句"随时再 /sdd-help"
```

## 3. 可引导的主题清单（按用户选择展开，勿一次全讲）

| 主题 | 一句话讲解要点 | 深入指引 |
|---|---|---|
| 两种模式 | 模式 A 正向开发（`/sdd-iterate`）／模式 B 代码孪生（`/sdd-init`）；老项目先 B 再 A | SKILL.md §两种使用模式 |
| 从零做需求 | 六阶段：宪章→需求→设计→任务→测试→交付，每阶段停下等放行 | references/gate-and-stages.md |
| 梳理老项目 | `/sdd-init` 逆向成 `context/` 认知层 + 代码/知识地图，可反推上游文档草稿 | references/mode-b-twin.md / mode-b-reverse.md |
| 命令速查 | 项目命令 init/update/docs/iterate/retro + 技能元命令 help/custom | references/commands.md |
| 门禁为什么严 | 防 AI 连跑/跳阶段/只计划不写码/覆盖历史/臆测/裸 PASS | SKILL.md §门禁系统 |
| 归档纪律 | specs 禁覆盖先归档、current/history、日期头 | references/specs-lifecycle.md |
| 复盘沉淀 | `/sdd-retro` 把教训/亮点写入 `specs/retro/`，可汇集回灌框架 | references/retro-protocol.md |
| 设置个人偏好 | `/sdd-custom` 设定风格语调与习惯（默认"专业可靠"） | references/custom-protocol.md |
| 出错怎么办 | 故障排查、中文/长路径优先直建、能力降级 | references/troubleshooting.md |

## 4. 本域引导种子（装配时按 S20 采访填，可选）

> 列出**本域**最值得先讲的上手要点与高频疑问，让 `/sdd-help` 的举例与答疑更贴身。留空则用通用主题清单。

**本域上手要点（举例答疑时优先用这些）**：
- 新人最容易卡在：async/sync 混用（async 端点里误调同步 IO）、AsyncSession 生命周期与事务边界、Pydantic v2 与 ORM 模型的边界转换、Alembic 迁移与 autogenerate 漏检。
- 最该先讲：一个端点如何走 spec→design→tasks（schema→service→repository→路由装配→迁移→测试）；uv 优先的依赖与运行（uv sync / uv run），pip 兜底。
- 高频疑问：response_model 与 mypy strict 如何配合；如何用 httpx.AsyncClient 跑端到端并隔离数据库；PostgreSQL/MySQL 在 SQLAlchemy async 下的差异点。

## 5. 与 /sdd-custom 的关系
`/sdd-help` 讲"怎么用"，`/sdd-custom` 设"按我的习惯用"。在 `/sdd-help` 里介绍到"设置个人偏好"主题时，可引导用户转 `/sdd-custom`，但二者都受同一套门禁红线与只读护栏约束（见 custom-protocol.md）。
