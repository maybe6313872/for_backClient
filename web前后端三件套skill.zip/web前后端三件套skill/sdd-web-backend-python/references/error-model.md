# 统一错误模型：语义（不变量）+ 载体（项目契约决策）（本域增强）

> 目标：全 API 的错误响应**机器可读、结构一致、可演进**。对应编码规则 `RULE-ERR-03`，与 [openapi-and-api-docs.md](openapi-and-api-docs.md) 的"按状态码声明 responses"配套。

## 0. 先分清「语义」与「载体」（P1-02 · 冻结）

| 维度 | 性质 | 要求 |
|---|---|---|
| **错误语义** | **工程不变量**（所有项目） | 全局收口、全 API 结构一致、错误类型标识跨版本稳定、禁 200 夹错误、禁每端点各拼一套 |
| **错误载体** | **项目契约决策** | **新项目推荐默认 Problem Details（RFC 9457 `application/problem+json`）**；存量已发布业务信封/稳定业务码/版本化接口是合法既有契约 |

**存量项目优先级**：不得为套用 Problem Details 而制造破坏性接口变更。已有稳定信封（如 `{code,message,data}`）的项目——保持载体、先满足"语义不变量"（收口+一致+稳定标识），错误载体的演进走**兼容性评审 + API 版本化**（新版可切 problem+json，旧版保留弃用周期）。载体是决策、语义是红线，二者不可混为一谈。

下文 §1–§4 描述**推荐默认载体 Problem Details** 的规范；存量项目按上表取"语义"部分、载体按既有契约执行。

---

## 1. 标准信封（RFC 9457）

响应体核心字段（均可选，但应稳定）：

| 字段 | 含义 |
|---|---|
| `type` | 标识问题类型的 URI（可指向文档/IANA 注册项；无则用 `about:blank`） |
| `title` | 该类型的简短人读标题（同一 `type` 下应稳定） |
| `status` | HTTP 状态码（与响应状态一致） |
| `detail` | 本次发生的具体说明（面向调用方，**不泄敏**） |
| `instance` | 标识本次发生的 URI（如请求 id/资源路径），便于排障关联 |
| 扩展成员 | 业务自定义键（如 `errors`、`trace_id`、`code`），同一 `type` 下结构稳定 |

响应头 `Content-Type: application/problem+json`。

## 2. 实现方式（择一，均可）

- **手写全局 handler（零额外依赖，推荐起步）**：为 `RequestValidationError`(422)、`StarletteHTTPException`、领域异常、兜底 `Exception`(500) 各注册 `app.exception_handler`，统一返回 problem+json。422 把 Pydantic 的错误列表整形进扩展成员 `errors`。
- **现成插件**：`fastapi-problem-details`（`problem.init_app(app)` 自动接管校验/HTTP/未处理异常）或 `fastapi-problem`（异常类按类名派生 `type`）。引依赖前按 `RULE-DEP-01` 锁定版本。

```python
# 手写示例（要点：领域异常 → problem+json）
from fastapi import Request
from fastapi.responses import JSONResponse

class DomainError(Exception):
    def __init__(self, status: int, title: str, detail: str, type_: str = "about:blank"):
        self.status, self.title, self.detail, self.type_ = status, title, detail, type_

async def domain_error_handler(request: Request, exc: DomainError) -> JSONResponse:
    body = {"type": exc.type_, "title": exc.title, "status": exc.status,
            "detail": exc.detail, "instance": str(request.url)}
    return JSONResponse(body, status_code=exc.status, media_type="application/problem+json")
```

## 3. 纪律（呼应 RULE-ERR）
- **领域异常与传输异常分离**：业务层抛领域异常，边界处由 handler 统一翻译为 problem+json；禁在路由里散落手拼错误体。
- **不吞异常、不泄敏**：禁 `except: pass`；`detail`/扩展字段不得含密钥、令牌、内部栈细节（栈进日志不进响应，见 [observability-and-production.md](observability-and-production.md)）。
- **进文档**：每端点用 `responses={4xx/5xx: {"model": ProblemDetails}}` 把错误体纳入 OpenAPI，调用方可预期。
- **type 稳定**：同一错误类型的 `type`/`title` 跨版本稳定，作为契约的一部分；新增错误类型属向后兼容。

## 4. 反模式
- 200 里塞 `{"error": ...}`（状态码不表达失败）。
- 每个端点各自一套错误结构 → 调用方无法统一处理。
- 把校验细节、异常栈、SQL 原文直接回给客户端 → 泄敏 + 不稳定契约。
