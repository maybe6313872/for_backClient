# `/sdd-tidy` —— 项目结构规整协议（F35）

> **由来（为什么要有这条命令）**：现场经验表明，AI 编码工具在接手项目、或经自己长期维护后，会把文件/目录结构搞得非标准：文档散落在根目录、specs 产物落错文件夹、没人登记的陈旧副本、收件箱被误用、归档纪律被违反、孤儿临时文件遍地。`/sdd-tidy` 就是把这些收拾干净的标准、门禁化动作。它是**冻结的框架机制（F35）**：下面命令的语义、门禁与安全规则被每个 sdd-xx 继承；**本域的目标布局本身不在这里定义**——它来自本 skill 自己的 `structure.md`（各 sdd-xx 填入的本域最佳实践布局），`/sdd-tidy` 只负责按那份布局做校对与规整。

---

## 1. 场景与范围

在以下情况用 `/sdd-tidy`（或「规整项目目录」「收拾项目结构」「整理目录结构」）：
- 接手一个 docs/specs 布局与本域 `structure.md` 不符的项目；
- 长期迭代漂移之后：文件落错文件夹、临时/试验文件堆积、跳过了归档；
- 某个 AI 会话（本次或上一次）把结构搞乱了，用户要求收拾。

**范围（in scope）**：`specs/`、`docs/`，以及散落在项目根的项目管理类文件（README 碎片、游离的需求文档、临时笔记）。

**不在范围（out of scope）**：
- **业务源码布局**——对 FastAPI 服务即 `app/`（`app/main.py`、`app/api/`、`app/models/`、`app/schemas/`、`app/services/` 等）与 `alembic/`（迁移脚本）；调整它们是重构，属模式 A 的任务，绝不由 tidy 静默进行。
- **工具链治理的构建/缓存残留**——如 `.venv/`、`__pycache__/`、`.mypy_cache/`、`.ruff_cache/`、`.pytest_cache/`、`dist/`、`*.egg-info/` 等。tidy **不搬不删**这些，至多在报告里列出、建议交由 `.gitignore`/工具链处理。
- `.git/` 下的任何内容。

## 2. 三步流程（门禁化，先出计划再动手）

1. **扫描（只读）**：把实际布局对照本域 `structure.md` 找**错位/非标文件**；同时检查日期头/归档状态（specs-lifecycle）、未登记的外部副本（对照 `sources.md`）、收件箱误用（`docs/requirements/` 里塞了非需求的杂物）、机器产物混进 `context/` 正文（应在 `_generated/`/`_tools/`）。**此步只读，绝不改动任何文件。** 扫描清单还包括：
   - **Reserved-name and same-name violations (F37)**: long-lived specifications parked in `docs/requirements/` — the next claim clears that directory and destroys them, so propose moving them to `docs/product-specs/`; plus any two directories that share one name while carrying different semantics, lifetimes or naming rules anywhere in the repo.
   - **Archive stratification debt (specs-lifecycle §10)**: for every archive directory (`specs/task/`, each `<stage>/history/`, any archive root declared in `structure.md`) count its archive files against the §10 thresholds, and check that every level carries an `INDEX.md` covering all of its entries.
   - **Evidence single landing point**: the same evidence file present in two locations, or an evidence class written outside the `structure.md` landing-point table; plus broken conclusion→evidence links in `5-test/current.md` (evidence-gate-protocol.md §7).
   - **Archive filename vocabulary**: archive filenames whose `<说明>` prefix misses the archive-description vocabulary declared in this domain's `structure.md` (reported only — never renamed).
2. **计划**：产出一张**规整计划表**——每项一行：当前路径 → 目标路径（或"归档到 …"）→ 原因（违反了哪条约定）→ 风险。无法归类的文件列为 `⚠️ 待确认` 行并附一个问题，**绝不臆测去向**。**🚦 门禁**：展示完整计划并等待用户明确放行；允许部分放行（只执行被放行的行）。
3. **执行 + 报告**：执行已放行的移动/归档，然后重新扫描，展示前/后对照小结。把本次规整作为一条粗粒度条目记入 `task.md`。`/sdd-tidy` is trigger ③ of the specs-lifecycle §6 archive whitelist: archiving stale workbenches and restratifying archive directories happen **here**, inside the approved plan — never as an improvised side effect during the scan.

## 3. 安全规则（冻结，每违反一条都是错误）

- **绝不删除**：tidy 只做移动、重命名、归档。看似过时的内容按 specs-lifecycle 归档（先归档），**绝不删除**。
- **绝不触碰业务源码与构建残留**：移动/重命名 `app/`、`alembic/` 下的源码/迁移是重构而非规整——请作为独立的模式 A 任务提出；`.venv/`、`__pycache__/`、`.mypy_cache/`、`.ruff_cache/` 等一律不动。
- **不臆测去向**：正确归属无法由 `structure.md` 判定、又问不出来的文件 → 原地不动，列为 `⚠️ 待确认`。
- **归档纪律照旧生效**：任何会覆盖既有文件的移动，都改走"先归档再写"（与 specs-lifecycle.md 一致，禁覆盖/删除）。If the collision is between two archive filenames, resolve it with the specs-lifecycle §11 ordinal suffix — **never** overwrite, and never rename the file already in place.
- **尊重收件箱**：`docs/requirements/` 里待处理的需求文件绝不被"规整掉"——它们按 requirement-inbox-protocol.md 认领，或原地保留。
- **一份门禁计划，无静默副作用**：门禁通过前不动任何文件；执行途中新发现的问题进入下一份计划，而非临场即兴移动。
- **Evidence: consolidate, never repair silently**: duplicated evidence is consolidated to the declared landing point by *moving* the authoritative copy and archiving the rest (never deleting); a **broken conclusion→evidence link is reported only** — tidy never rewrites a conclusion's evidence path, because deciding which file a conclusion meant is a judgment for the test stage, not for tidy.
- **Archive filenames: report, never rename**: an archive file whose `<说明>` misses the controlled vocabulary is listed as a `⚠️ 待确认` row together with the suggested entry — `/sdd-tidy` **MUST NOT rename it**. Renaming an archived file breaks every inbound link (task.md, history.md, knowledge-map, retro entries), and re-authoring someone else's archive label is a judgment call, not a tidy-up. The user renames it, or leaves it; either is acceptable.
- **Stratification moves preserve names**: when executing archive stratification (specs-lifecycle §10), files move between levels only — the `YYYY-MM-DD-<说明>.md` filename is never rewritten, files are never merged, and the level's `INDEX.md` is refreshed in the same approved plan. A stratification plan that also renames or prunes files is rejected and re-planned.

## 4. 与母技能的分工（给 sdd-xx 维护者）

本协议（命令语义、三步流程、安全规则）是冻结的、跨所有 sdd-xx 一致。每个 sdd-xx 提供的是**目标布局**：它自己的 `structure.md`（以及值得加进扫描的本域"已知杂物模式"，如本技术栈典型的构建残留 `.venv/`/`__pycache__/`/`.mypy_cache/`/`.ruff_cache/`——可选的散文种子）。当母技能蓝图的 `structure.md.tmpl` 演进时，`/sdd-tidy` 在回灌后自动按新布局校对——本文件无需改动。

## 5. 冻结说明

`/sdd-tidy` 的命令语义、扫描/计划/执行/报告四段、以及第 3 节全部安全规则，是**冻结的框架机制 F35**，本域不得改写。本域只提供目标布局（`structure.md`）与本域已知杂物模式。当母技能演进 F35 时，本文件经 `/sdd-evolve` 回灌更新。
