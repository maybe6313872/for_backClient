# 国际化与消息文案（i18n / messages）（本域增强）

> 目标：把"错误码/文案/日志/第三方原文"四类文本**分清所有权、分清是否本地化、分清是否进响应**，避免"翻译污染契约""日志变成用户文案""缺键裸奔"这类高频缺陷。对应编码规则 `RULE-I18N`（rules 落在 [coding-rules.md](coding-rules.md)）。落阶段：constitution 定启用与语言策略、design 定资源布局与回退链、tasks 落资源与加载、test 跑翻译完整性门禁、deliver 同步语言产物。
>
> 与 [error-model.md](error-model.md)（Problem Details）、[openapi-and-api-docs.md](openapi-and-api-docs.md)（契约）配套：**机器可读的稳定量进契约、不翻译；人读的可见量才本地化**。

---

## 1. 概念分离（核心）

四类文本各有所有权、各有归宿，**禁止互相串用**。这是本主题第一红线。

| # | 概念 | 例子 | 是否本地化 | 是否进响应 | 是否进契约 | 稳定性要求 |
|---|---|---|---|---|---|---|
| a | 机器稳定错误码 / message key | `user.not_found`、`code="USER_NOT_FOUND"`、Problem `type` | ❌ 不翻译 | ✅ 进（作机器字段） | ✅ 进契约 | **冻结**：跨版本稳定，改动=破坏性变更 |
| b | 用户可见本地化文案 | `detail`/`title`：`用户不存在` / `User not found` | ✅ 本地化 | ✅ 进 | 结构进、文本不进 | 文本可随译文变，键不变 |
| c | 内部诊断 / 日志 | `user 4711 lookup miss on shard=3` | ❌ 不本地化 | ❌ 不进响应 | 不进契约 | 面向工程师，可自由改写 |
| d | 第三方原始异常原文 | 上游 `SQLSTATE 23505`、`stripe: card_declined raw msg` | ❌ 不本地化 | ❌ 不透传 | 不进契约 | 留日志佐证，映射为本地键后再对外 |

**对照 Problem Details**：`type` / `code` = (a)，机器稳定进契约；`title` / `detail` = (b)，按 locale 渲染；栈、SQL 原文、上游报文 = (c)(d)，进日志不进响应（呼应 `RULE-ERR-02` 不泄敏、`RULE-ERR-03`）。

- ❌ 把上游 `IntegrityError` 的英文原文直接塞进 `detail` 回给用户（(d) 当 (b) 用，既泄实现又不稳定）。
- ❌ 用翻译后的文案当去重/告警分组的 key（(b) 当 (a) 用，换语言即失效）。
- ✅ 领域层抛 `DomainError(code="user.not_found")`，边界处按 locale 渲染 `detail`，原始异常 `logger.exception(...)` 入日志。

---

## 2. 启用条件（constitution 决策）

是否引入完整 i18n 管道是 **constitution 决策**，定了在 design/test 一致执行；但"消息所有权集中"对**单语言服务同样强制**。

| 场景 | 是否建 locale 翻译目录 | 消息所有权是否集中 |
|---|---|---|
| 单语言服务（仅一种可见语言） | 可跳过多 locale 目录 | ✅ 仍强制：消息键集中、文案不散落在路由里 |
| 多语言 / 面向多区域 | ✅ 建 `messages/{locale}.json` | ✅ 强制 |
| 纯内部 / 机器对机器 API | 可只保留 (a) 机器码，(b) 可省 | ✅ 键仍集中 |

> 关键判断：**"要不要翻译"和"要不要集中消息所有权"是两件事。** 单语言不代表可以把裸字符串写死在 `HTTPException(detail="用户不存在")` 里——键仍要集中，便于统一口径、后续加语言零改动业务层。

---

## 3. locale 来源与优先级

单次请求的 locale 按**固定优先级**解析，越靠前越优先：

```
显式参数(?lang= / X-Lang 头)  >  用户偏好(账户设置)  >  Accept-Language 协商  >  服务默认
```

- **Accept-Language 协商**：解析 `q` 权重，与服务支持集求最佳匹配（如 `zh-CN` 落到 `zh`），不硬相等。
- **回退链（渲染某个键时）**：`请求 locale → 默认 locale → key 本身`。逐级找译文，找到即止。
- **缺失键处理**：显式回退 + 记日志告警，**禁静默返回空串、禁把键名裸露给用户**。

| 情形 | ❌ 错误做法 | ✅ 规范做法 |
|---|---|---|
| 请求 locale 无此键 | 返回 `""` 空串 | 回退默认 locale 文案 + `logger.warning("i18n miss", key=..., locale=...)` |
| 默认 locale 也无此键 | 直接把 `user.not_found` 当文案返回给用户 | 显式兜底文案（如通用错误提示）+ 告警；该键进翻译完整性门禁（见 §6）失败项 |
| 不支持的 locale | 报 500 / 抛异常 | 协商回退到默认 locale，正常响应 |

> **缺失键=显式回退+日志**，绝不静默。缺键裸奔（键名直接出现在用户界面）是本主题第二红线。

---

## 4. 按业务模块拆分语言资源（强制）

语言资源**按业务模块自持**，不做全局大文件。

- **布局**：每模块 `app/<module>/messages/{locale}.json`（如 `app/user/messages/zh.json`、`app/order/messages/en.json`），**禁**单个 `app/messages/all.json` 巨文件。
- **命名空间稳定键**：键带模块前缀、语义稳定，如 `user.not_found`、`order.payment.declined`；键属 (a) 类**冻结**量，改键=破坏性变更。
- **参数插值一致**：同一键在各 locale 的占位参数集必须**完全一致**（如 `zh` 与 `en` 都用 `{username}`），命名占位优先于位置占位，避免 `{0}` 顺序漂移。
- **启动期 import-safe 加载**：资源在应用启动期一次性加载并缓存（供 lifespan / 依赖注入取用），加载失败即启动失败（fail-fast）；**禁**每次请求读盘、禁 import 时产生副作用或 IO 抖动（cross-ref `RULE-DEP`/`RULE-DI` 依赖注入与 import 安全）。

```jsonc
// app/user/messages/zh.json
{ "user.not_found": "用户 {username} 不存在", "user.forbidden": "无权访问该用户" }
// app/user/messages/en.json
{ "user.not_found": "User {username} does not exist", "user.forbidden": "Access to this user is forbidden" }
```

- ❌ 路由里 `raise HTTPException(404, detail="用户不存在")`（文案散落、无键、无法翻译）。
- ❌ 全局 `messages.json` 数千行、跨模块耦合、合并冲突高发。
- ✅ 模块自持 `messages/{locale}.json` + 稳定键 + 启动期加载，业务层只引键。

---

## 5. Pydantic / FastAPI 校验错误本地化边界

422 校验错误的**机器结构必须稳定，只有面向人的文本可本地化**。

| 字段 | 类别 | 本地化？ |
|---|---|---|
| `type`（错误分类 URI/标识） | (a) 机器稳定 | ❌ 冻结 |
| `loc`（字段定位路径） | (a) 机器稳定 | ❌ |
| 错误 `code`（如 `value_error.missing`） | (a) 机器稳定 | ❌ |
| `detail` / `title`（人读说明） | (b) 可见文案 | ✅ 可本地化 |

- 校验错误经全局 handler 融入 **Problem Details**（`RULE-ERR-03`）：把 Pydantic 错误列表整形进扩展成员 `errors`，其中 `type`/`loc`/`code` 原样保留、**不翻译**；仅对外层 `title`/`detail`（及可选每条的人读 `message`）按 locale 渲染。
- **禁**为了"翻译"去改 `loc` 或吞掉 `type`/`code`——那会破坏调用方按字段定位错误的能力（cross-ref [error-model.md](error-model.md)）。

- ❌ 把 422 的 `loc: ["body","email"]` 改成"邮箱字段"这类本地化文本（机器量被翻译，契约失守）。
- ✅ `errors:[{loc, type, code, message:"<按 locale 渲染>"}]`，外层 `detail` 本地化，`type`/`loc`/`code` 稳定。

---

## 6. 翻译完整性检查门禁

新增模块 / 新增语言时，必须跑**确定性可跑校验**，检出三类问题：

| 检查项 | 定义 | 判定 |
|---|---|---|
| 缺失键 | 某 locale 相对基准 locale 键集缺少的键 | ❌ 门禁失败 |
| 冗余键 | 某 locale 多出、基准无的键 | ❌ 门禁失败（或告警，按 constitution） |
| 占位参数不一致 | 同一键在各 locale 的占位集不同（如 `zh` 有 `{username}`、`en` 无） | ❌ 门禁失败 |

- 实现为一个可跑脚本（如 `scripts/check_i18n.py`）：扫描各模块 `messages/*.json`，**跨 locale 比对键集 + 占位集**，有差异非零退出。
- 进 **CI**，作 test 阶段证据（可复现命令 + 退出码 + 差异清单，cross-ref [evidence-gate-protocol.md](evidence-gate-protocol.md)、`RULE-TEST`）。

```python
# scripts/check_i18n.py（要点：键集 + 占位集跨 locale 比对，有差异即非零退出）
import json, re, sys
from pathlib import Path

PLACEHOLDER = re.compile(r"\{(\w+)\}")
BASE = "zh"  # 基准 locale，属 constitution 决策

def placeholders(text: str) -> set[str]:
    return set(PLACEHOLDER.findall(text))

problems: list[str] = []
for msg_dir in Path("app").glob("*/messages"):
    locales = {p.stem: json.loads(p.read_text("utf-8")) for p in msg_dir.glob("*.json")}
    base = locales.get(BASE, {})
    base_keys = set(base)
    for loc, data in locales.items():
        if loc == BASE:
            continue
        keys = set(data)
        if missing := base_keys - keys:
            problems.append(f"{msg_dir}/{loc}: 缺失键 {sorted(missing)}")
        if extra := keys - base_keys:
            problems.append(f"{msg_dir}/{loc}: 冗余键 {sorted(extra)}")
        for k in base_keys & keys:
            if placeholders(base[k]) != placeholders(data[k]):
                problems.append(f"{msg_dir}/{loc}:{k} 占位不一致")

if problems:
    print("\n".join(problems)); sys.exit(1)
print("i18n check ok")
```

---

## 7. 阶段映射（与六阶段/门禁衔接，不改冻结门禁）

| 阶段 | 与本主题相关的动作 |
|---|---|
| constitution | 定是否启用多 locale、支持语言集、默认 locale、基准 locale；确认"消息所有权集中"为项目约束 |
| spec | 明确哪些文本对外可见、需要哪些语言、错误文案的验收口径 |
| design | 定资源布局（模块自持 `messages/{locale}.json`）、locale 解析优先级与回退链、校验错误本地化边界、启动期加载方案 |
| tasks | 落各模块语言资源与稳定键、locale 解析依赖、渲染函数；加 `scripts/check_i18n.py`；业务层只引键（遵 `RULE-I18N`） |
| test | 跑翻译完整性门禁（缺键/冗余/占位）；验证回退链与缺失键告警；校验 422 机器字段不被翻译；证据标 L1–L3 |
| deliver | 语言产物随交付同步；新增语言/键的破坏性判定（改键=破坏性）；缺译项进交付风险 |

---

## 8. 反模式

- 裸字符串文案写死在路由 / service（无键、无法翻译、口径分散）。
- 用本地化后的文案当 (a) 机器码：去重、告警分组、契约字段——换语言即失效。
- 第三方异常原文（SQL/上游报文）直接透传进 `detail`（泄实现 + 契约不稳定 + 可能泄敏）。
- 缺失键静默返回空串或把键名裸露给用户。
- 全局巨型 `messages.json`：跨模块耦合、合并冲突、加载慢。
- 各 locale 占位参数不一致却不校验（运行期插值报错或错位）。
- 为"翻译"改 422 的 `loc`/`type`/`code`，破坏机器可定位性。
- 每次请求读盘加载语言文件，而非启动期一次性加载缓存。

---

## 附：coding-rules.md 中的 RULE-I18N 条目（供落库）

> 以下条目落入 [coding-rules.md](coding-rules.md) 的 `RULE-I18N` 家族，本文件为其深展开。

### RULE-I18N-01：四类文本分离，机器量进契约不翻译，可见量才本地化
机器稳定码 / message key（进契约、`冻结`）、用户可见文案（本地化）、内部诊断日志（不本地化、不进响应）、第三方原文（留日志、不透传）四类分清所有权；禁互相串用。
- ❌ 上游异常原文塞 `detail` 回用户；❌ 本地化文案当去重 key
- ✅ 领域码 `code="user.not_found"` 进契约，`detail` 按 locale 渲染，原文入日志

### RULE-I18N-02：消息所有权集中，禁裸字符串文案散落
所有可见文案经稳定键引用；单语言服务亦强制集中，禁 `HTTPException(detail="…")` 写死。
- ❌ `raise HTTPException(404, detail="用户不存在")`
- ✅ 引 `user.not_found` 键，边界处渲染

### RULE-I18N-03：locale 解析按固定优先级 + 回退链，缺键显式回退加日志
优先级 显式参数 > 用户偏好 > Accept-Language 协商 > 默认；渲染回退 请求→默认→key；缺键禁静默空串 / 键名裸奔，须显式兜底 + 告警。

### RULE-I18N-04：语言资源按模块自持 + 命名空间稳定键 + 启动期 import-safe 加载
每模块 `app/<module>/messages/{locale}.json`，键带模块前缀且冻结，占位参数跨 locale 一致；启动期一次性加载缓存，禁请求期读盘、禁 import 副作用（cross-ref RULE-DI）。

### RULE-I18N-05：校验错误只本地化人读文本，机器字段稳定
422 的 `type`/`loc`/`code` 机器稳定不翻译，仅 `detail`/`title`/人读 `message` 本地化，融入 Problem Details（cross-ref RULE-ERR-03、error-model.md）。

### RULE-I18N-06：翻译完整性门禁进 CI
新增模块 / 语言时跑确定性校验（缺失键 / 冗余键 / 占位不一致，跨 locale 比对键集 + 占位集），如 `scripts/check_i18n.py`，非零退出即门禁失败，作 test 证据（cross-ref RULE-TEST、evidence-gate-protocol.md）。
