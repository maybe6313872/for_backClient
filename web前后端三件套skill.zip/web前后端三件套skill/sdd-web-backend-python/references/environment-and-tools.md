# 运行环境与工具

> 本域多跑在 Linux/容器（CI/CD 流水线），默认具备 Python 3.11+；包与环境管理优先 uv（uv sync / uv run / uv.lock），无 uv 时 pip 兜底（pip install -e .[dev] 或 -r requirements.txt）。 所有工具按"能力探测 + 降级"设计：零依赖/最稳优先，没有合适运行时就逐级退。

## 1. 能力探测（开工前）
判断手头有什么运行时（Python 3.11+、FastAPI/Starlette/Uvicorn（ASGI，生产 Gunicorn+uvicorn worker）、Pydantic v2 + pydantic-settings、SQLAlchemy 2.0(async) + Alembic、asyncpg(PostgreSQL)/aiomysql·asyncmy(MySQL)、mypy(strict) + Ruff、pytest + pytest-asyncio + httpx.AsyncClient、uv 优先（pip 兜底） 相关）；涉及跑脚本时先探测，从报错推断或让用户在终端跑一句确认。

## 2. 各工具降级链
| 任务 | 首选 | 次选 | 兜底 |
|---|---|---|---|
| 初始化 specs/ 骨架 | AI 直接创建文件（最稳） | 脚手架脚本（若携带） | — |
| 检测当前阶段 | AI 列 `specs/` 目录人工判断 | 检测脚本（若携带） | — |
| 生成源码覆盖索引（可选） | Python 标准库 ast / 随附零依赖 build_source_index.py（基于 Python ast，静态识别 async def/装饰器 FastAPI 路由/import；可选外部工具 pydeps/import-linter 补依赖图） / `_tools/build_source_index.py` | 本域生态工具 | AI 按 code-map.md 手工建源码清单（效果对等） |
| docs 二进制文本化 | 公司 binary-doc-converter（见 docs-binarification-adapter.md） | 内置脚本 | AI 按需自行实现 |
| docs 哈希快检/索引 | `docs_index`（若携带） | — | AI 手填 converted/README.md |
| 源码编码处理 | Python 源码默认 UTF-8；Ruff/编辑器保证编码一致 | — | AI 直接以 UTF-8 读写并核对无 BOM |

## 3. 宿主环境差异（本地 vs Claude.ai）
本地：直接读写工程目录、能跑脚本。Claude.ai：通常临时沙箱、无持久工程目录 → 优先 AI 直接处理，产物以可下载文件交付由用户落地。判断不了环境时先用"AI 直接做"，需要批量处理时再尝试脚本并按报错降级。
