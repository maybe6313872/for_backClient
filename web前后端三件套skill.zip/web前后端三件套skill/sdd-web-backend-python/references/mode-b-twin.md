# 模式 B：代码 → 认知层（含代码孪生）

> **定位（冻结）**：模式 B 的核心**不是**把源码机械转成 Markdown，也**不是**堆一张代码图谱。核心是：
>
> ```text
> 存量代码 + 散落资料
>   → specs/context/ 结构化认知层
>   → 反推需求规格书、概要设计、详细设计、测试用例和后续迭代依据
> ```
>
> `context/` 是**桥梁层**，不是终点；它的成败标准是「能否稳定支撑下游正式文档补写」，不是 `specs/` 有多大。代码孪生（modules/architecture/data-model 的实现事实）是认知层里的一层，**保留**；代码图谱是**可选辅助工具**，见 §7。
>
> **孪生粒度 L0–L4、覆盖度自检、增量同步是框架冻结的；「保留/省略」重点、本域全局状态模型、场景链路种子、证据互证资料源是本域插槽（见 business-slots S6）。**

## 1. 省什么、留什么（本域 · 占位符）
孪生不是贴源码，而是把意图、结构、行为用结构化文本重新表达，使没读过源码的人/新会话 AI 能据此安全续作。

| | 内容 |
|---|---|
| **保留** | 路由表与端点契约（方法/路径/入出参 schema/状态码/鉴权依赖）、Pydantic 模型与校验规则、ORM 模型与关系/约束、DB 迁移历史与当前 schema、依赖注入装配（session/鉴权/配置）、事务与 session 边界、中间件与全局异常处理链、外部触点（DB/Redis/MQ/第三方 API）、配置项与来源 |
| **省略** | 局部变量名、逐行语句、纯样板 CRUD getter、可由 OpenAPI/类型自动得到的描述、第三方库内部实现 |

> 默认通用对照（未填则用）：
> - **省略**：局部变量名、逐行语句、纯样板、可由代码地图机械得到的索引细节。
> - **保留**：每个模块职责与边界、每个对外/关键函数的签名/用途/参数/返回/副作用、调用与依赖关系、关键数据结构、状态机/控制逻辑、数据库(PostgreSQL/MySQL)、Redis/缓存、消息队列、第三方 HTTP API、对象存储、鉴权/SSO 服务。

## 2. 认知层 `context/` 五层组织（冻结）
`context/` **按「项目认知 / 架构 / 模块 / 场景 / 证据」组织，不按源码目录平铺**。

| 层级 | 解决的问题 | 典型产物 |
|---|---|---|
| 项目级 | 项目是什么、功能范围、领域术语 | `features.md`、`domain-model.md` |
| 架构级 | 怎么分层、数据怎么流、关键运行模型 | `architecture.md`、`data-model.md` |
| 模块级 | 单个功能域/页面/服务/控制对象如何工作 | `modules.md`、`modules/*.md` |
| 场景级 | 多个模块如何串成业务链路 | `scenarios/*.md` |
| 证据级 | 结论来自哪些源码/资料/测试 | `evidence-trace.md` |

> **场景层是一等公民**：模块文档解释「某一块怎么实现」，场景文档解释「真实业务链路怎么跑」。跨模块链路是维护问题高发区，不能只写模块说明。`scenarios/` 模板见 `assets/templates/context-scenarios.md`。

孪生粒度仍按 L0–L4 落盘：
- **L0 项目级 → `specs/README.md`**：概览、技术栈、构建运行、**已实现功能清单**、模块/context 索引、编码风格、参考文档索引。
- **L1 架构级 → `context/architecture.md`（+ `data-model.md`）**：分层职责、运行单元/任务模型、主要数据流、关键控制逻辑、稳定设计约束。
- **L2 模块级 → `context/modules.md`（+ `modules/*.md`）**：每模块职责、公共接口表、关键数据结构、依赖、内部逻辑叙述、已知限制。
- **L3 函数级 → 模块文档内逐函数条目**：签名、用途、参数取值、返回/错误、副作用、被谁调用/调用谁、关键分支与状态、触碰的 数据库(PostgreSQL/MySQL)、Redis/缓存、消息队列、第三方 HTTP API、对象存储、鉴权/SSO 服务。
- **L4 代码地图/源码索引 → `context/code-map.md`（可选，见 §7）**。

本域**全局状态/数据模型**落在 `context/db-schema-and-config.md`。

## 3. 文档纯净度规则（冻结 · 本次重点）
`context/` 正文**只写已闭合事实**，不写过程语言。三类内容必须分开放：

| 类型 | 放置位置 |
|---|---|
| 已确认的项目事实、设计事实、源码行为 | `specs/context/` |
| 冲突、疑点、待验证项、资料不一致 | `specs/open-issues.md` |
| 当前正在推进的任务、下一步、TODO | `specs/task.md` |

这条比格式更重要：模式 B 最常见的翻车是把「我正在分析什么 / 还缺什么 / 可能有风险」混进交付正文，导致后续 AI 把未确认内容当事实继续扩写。`open-issues.md` 是**全局治理入口**，模板见 `assets/templates/context-open-issues.md`，其「处理口径」必须写清正文该怎么表述、哪些暂时不写，不要只写「待确认」。

## 4. 证据强度标注 + 冲突规则（冻结）
模式 B 必须区分结论的证据强度。**为避免与交付门禁的 L1–L5 数字混淆，模式 B 用文字标注，不用数字编号**：

| 标注 | 含义 | 示例 |
|---|---|---|
| **静态可见** | 当前源码静态可见 | 函数定义、调用点、数据结构、配置文件 |
| **资料互证** | 静态可见 + 项目资料互证 | PRD、规格书、参数表、接口文档、设计稿 |
| **运行佐证** | 静态可见 + 资料 + 运行/测试证据 | 构建日志、测试记录、生产日志、压测/联调记录 |

**冲突规则**：资料与源码冲突时，`context/` 正文**按源码事实写**，冲突进 `open-issues.md`。**禁止**用「通常 / 应该 / 按经验」补齐没有证据的行为。证据来源汇总落在 `context/evidence-trace.md`。

## 5. 工作流（冻结）
Step0 确认源码编码（本域默认 UTF-8、无 GBK 遗留，无需乱码扫描，仅核对无 BOM/LF） → Step1 结构扫描（可选生成源码索引）→ Step2 模块识别与边界 → Step3 分层撰写认知（每个技术细节标证据强度，没把握进 open-issues 不进正文）→ Step4 场景链路梳理 → Step5 覆盖度自检 → Step6 与用户确认 → Step7 增量同步。

## 6. 覆盖度自检（量化，冻结）
- 函数覆盖率 = 已文档化函数 ÷ 源码索引函数总数；模块覆盖率、数据结构覆盖率同理。无源码索引时用人工源码清单做分母。
- 产出**未覆盖清单**，每项二选一：①补齐 ②显式标「暂不展开+原因」。**不允许静默遗漏。**
- 一致性自检：抽查文档里的函数签名/接口语义与源码是否一致；不一致进 `open-issues.md`。

## 6a. 工程质量基线审计 + 规则适用性矩阵（本域 · P0-05 · 硬要求）

> 模式 B **不能只建代码认知**。存量项目最大的风险不是"看不懂代码"，而是"缺基本质量门禁却无人发现"。除模块/场景/证据外，模式 B 必须盘点本域工程能力现状，产出**现状 → 规则**的差距清单，否则后续局部迭代会继续沿用缺失状态。

盘点维度（逐项记"现状 / 是否满足对应 RULE / 差距 / 建议"）：

| 维度 | 盘点什么 | 对应规则 |
|---|---|---|
| 类型检查 | 有无 mypy/pyright、配置、范围、strict 程度、`Any` 边界 | RULE-TYPE |
| Lint/格式化 | 有无 Ruff 配置、check/format 命令、排除 | RULE-LINT |
| 测试层级 | 有无单元/服务/集成/接口/迁移测试、可发现可重放 | RULE-TEST、[testing-strategy.md](testing-strategy.md) |
| 覆盖率 | 有无 coverage、基线、分支覆盖、不退化门禁 | RULE-CI |
| 统一质量入口/CI | 有无 `make check`/CI、失败阻断、产物 | RULE-CI、[quality-gate-and-ci.md](quality-gate-and-ci.md) |
| 依赖锁 | uv.lock/requirements 哈希锁、frozen 安装、可复现 | RULE-DEP |
| Python 版本 | requires-python/锁/镜像/CI 是否一致、最低版本是否验证 | RULE-DEP-03、[stack-profile.md](stack-profile.md) |
| 契约产物 | 有无 openapi 快照、oasdiff、operation_id 唯一、权威来源 | RULE-API-05/06 |
| 迁移机制 | Alembic 或其他、可回滚、autogenerate 无残差 | RULE-DB-03 |
| 配置/组合根 | 配置单一入口、启动期校验、组合根、import-safe | RULE-CONF-02、RULE-DI |
| 模块闭包 | 模块是闭包还是全塞公共热点文件 | RULE-STRUCT、[module-architecture.md](module-architecture.md) |
| i18n | 消息所有权、按模块拆分、稳定键、完整性检查 | RULE-I18N、[i18n-and-messages.md](i18n-and-messages.md) |
| 错误模型 | 收口/一致/稳定标识、载体（problem+json 或既有信封） | RULE-ERR-03、[error-model.md](error-model.md) |
| vendor/legacy | 有无仓内遗留、只读边界、反腐层、质量工具排除 | RULE-VENDOR |

产物落 `context/engineering-baseline.md`（模板 `assets/templates/context-engineering-baseline.md`），并把每条差距挂 `open-issues.md`（未闭合）与 `task.md`（拟改进）。**规则适用性矩阵**：对不满足项标注"本次是否整改 / 保持现状并记债 / 阻塞"，遵循 RULE-PROC-05 最小改动与"推荐栈≠项目事实"；差距清单是后续迭代的输入，不得静默略过。

## 7. 代码图谱 = 可选的源码覆盖索引（冻结其「可选」属性）
> 源码覆盖索引是模式 B 的**可选**辅助工具，用于帮 AI 盘点源码库存、入口、依赖和潜在遗漏。它**不是交付正文、不是事实裁决源、不要求数据库、不要求可视化、不要求所有项目启用、可随时重建丢弃**。

**硬边界**：①**可选**——没有 Python/工具环境照样做模式 B；②**轻量**——优先 JSON/Markdown，不用 SQLite 做默认；③**辅助**——只帮 AI 少漏文件/入口/影响面；④**不裁决事实**——结论以源码、原始资料、测试证据、人工复核为准；⑤**不追求可视化**——人类读 `context/`，不读图谱页面。目录名用 `source-index`，**不要**默认叫 `code-graph`（`graph` 易诱导扩成重型平台）。

它只回答三个问题：项目里有哪些源码文件/入口/符号；哪些已被 `context/` 覆盖、哪些可能遗漏；某模块/场景反推时该回看哪些源码证据。超出这三问的交互式图谱、图数据库、HTML 工作台、MCP 服务，都不进本框架默认实践。

**生成（能力探测 + 降级，与 F11 一致）**：首选 Python 标准库 ast / 随附零依赖 build_source_index.py（基于 Python ast，静态识别 async def/装饰器 FastAPI 路由/import；可选外部工具 pydeps/import-linter 补依赖图）（扫描后缀 .py）或随附的可选零依赖脚本 `assets/tools/build_source_index.py`（复制到项目 `specs/_tools/` 运行）；无 Python/工具时 **AI 按 code-map.md 手工建源码清单与覆盖表**，效果对等。机器产物进 `specs/_generated/source-index/`，**绝不混入 `context/` 正文**（见 §8）。

## 8. 机器产物与人工正文分离（冻结）
任何自动生成物放 `specs/_generated/`，可重建/可清理/可不提交；项目级脚本放 `specs/_tools/`；人工可交付正文放 `specs/context/`，必须可读/可审/可引用。`context/` 可引用 `_generated/` 作为「辅助索引入口」，但事实源仍是源码、资料和测试记录。

## 9. 下游正式文档反推关系（成功判据）
`context/` 的颗粒度以**能反推下游文档**为准：

| 下游文档 | 主要依赖的 context 素材 |
|---|---|
| 需求规格书 | `features.md`、`domain-model.md`、`scenarios/*.md`、`evidence-trace.md`、`open-issues.md` |
| 概要设计 | `architecture.md`、`data-model.md`、`modules.md`、`scenarios/*.md` |
| 详细设计 | `modules/*.md`、关键接口/协议/数据结构契约 |
| 测试用例 | `scenarios/*.md`、`open-issues.md`、证据强度标注 |

> **真正反推出这些文档**（详细设计/概要设计/需求规格书草稿）走 [mode-b-reverse.md](mode-b-reverse.md)：源码反推能力递减，需求规格书**必然不完整**，缺口给占位符/草稿、**禁止臆测**，产物落 `docs/reverse/`。

## 10. 增量同步（防腐化，冻结）
触发：存量代码被改 / 模式 A 一次 deliver 通过。步骤：重跑源码索引（或人工 diff）→ 定位受影响模块/场景 → 只更新受影响处 → `context/iteration-log.md` 追加一行 → 未闭合项进 `open-issues.md`。每轮 deliver 前对照一次覆盖度。

## 11. 与模式 A 衔接
从 B 切 A：认知层覆盖「对外接口 + 关键逻辑 + 主要场景链路」后即可开始模式 A 迭代，边迭代边补全。A 回写 B：deliver Gate 的「文档同步」就是把本次成果增量回写 README/context，并把已闭合的 open-issues 收口。文档没更新 Gate 不放行。
