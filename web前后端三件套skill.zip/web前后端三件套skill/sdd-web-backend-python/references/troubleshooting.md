# 故障排查

> 框架级可复用排查原则（冻结）+ 本域工具排查项（占位）。

## 1. 路径与文件创建（冻结原则）
**首选"AI 直接创建文件"而非命令行工具**：项目路径可能含中文或很长，命令行工具在这类路径上易出问题。直接写文件会自动建目录、兼容性最好，是初始化 specs/ 骨架与各 current.md 的**首选**；脚本是批量/离线场景的备选。
- 中文路径/长路径报错 → 改用"直接建文件"；或迁移到英文短路径；或（Windows）启用长路径支持。
- 记得同时建各阶段 `history/` 与 `specs/task/` 归档目录。

## 2. 能力探测与降级（冻结原则）
脚本跑不起来时，按 environment-and-tools.md 的降级链退一级：零依赖 → 本域生态工具 → AI 手工。不要假设运行时存在；先探测（`Python 3.11+、FastAPI/Starlette/Uvicorn（ASGI，生产 Gunicorn+uvicorn worker）、Pydantic v2 + pydantic-settings、SQLAlchemy 2.0(async) + Alembic、asyncpg(PostgreSQL)/aiomysql·asyncmy(MySQL)、mypy(strict) + Ruff、pytest + pytest-asyncio + httpx.AsyncClient、uv 优先（pip 兜底）` 相关）或从报错推断。

## 3. 代码地图局限（冻结原则）
代码地图多为启发式抽取，不是完整语言解析器：可能漏检（宏/动态生成/特殊语法）、调用关系按名字近似。把它当导航线索而非定论，关键路径以源码确认；漏检的在孪生里人工补一条即可。

## 4. docs 文本化问题（见适配器）
转换失败、编码乱码、格式不兼容等，按 docs-binarification-adapter.md 的降级链处理。

## 5. 本域专项排查（占位 · 按本域常见坑填）
- **uv / pip 环境**：锁文件不一致 → `uv sync --frozen` 校验；无 uv → `pip install -e .[dev]`；找不到包多为虚拟环境未激活。
- **async 事件循环**：`event loop is closed` 或请求卡死 → 检查是否在 async 端点里调用了同步阻塞 IO（RULE-ASYNC-01）。
- **Pydantic v1→v2**：`class Config`/`@validator`/`.dict()` 报弃用或行为变化 → 迁到 `ConfigDict`/`field_validator`/`model_dump()`（RULE-TYPE-03）。
- **SQLAlchemy async**：`MissingGreenlet`/惰性加载报错 → 用 `selectinload` 预加载、`expire_on_commit=False`（RULE-DB-02）；连接池耗尽 → 调 `pool_size` 并确保 session 关闭。
- **Alembic**：autogenerate 漏检（类型/索引/枚举）→ 人工核对迁移；多 head → `alembic heads` 后 merge。
- **CORS / 反向代理**：浏览器跨域失败 → 配置 `CORSMiddleware` 白名单；`uvicorn --reload` 仅限开发。
