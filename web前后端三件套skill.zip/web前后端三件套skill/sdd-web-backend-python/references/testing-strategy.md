# 测试策略（testing strategy）（本域增强）

> 目标：定清"测什么层、变更选哪层、怎么保证测试可信、结论如何绑证据"，避免"只有一层端到端测""ASGI 资源没起真跑了假测""覆盖率悄悄下滑""flaky 重跑即过当证据"这类高频缺陷。对应编码规则 `RULE-TEST`（rules 落在 [coding-rules.md](coding-rules.md)）。落阶段：tasks 与实现同步写单元与必要测试、test 独立验收并汇总证据。
>
> 与 [evidence-gate-protocol.md](evidence-gate-protocol.md)（L1–L5 证据）、[openapi-and-api-docs.md](openapi-and-api-docs.md)（契约测试）、[error-model.md](error-model.md)（错误分支）配套。

---

## 1. 测试金字塔

从下到上，隔离边界收窄→放开，成本升高、数量减少。**底层强制、上层按需。**

| 层 | 测什么 | 隔离边界 | 工具 | 成本 | 定位 |
|---|---|---|---|---|---|
| 单元 | 纯函数 / 领域逻辑 / 校验规则 | **无 IO**，不碰 DB/网络/时钟 | pytest（纯内存） | 最低 | **强制底座**，数量最多 |
| 服务 / 组件 | service 编排逻辑 | 依赖（repo/外部客户端）替换为桩/mock | pytest + `dependency_overrides`/fake | 低 | 领域编排正确性 |
| repository 集成 | ORM 查询 / 事务 / 约束 | **真实 / 容器化 DB** 或事务回滚 | pytest + testcontainers / 事务回滚 fixture | 中 | SQL 与 schema 真行为 |
| API 接口 | 路由 → 响应契约 | **进程内** `httpx.AsyncClient + ASGITransport` | pytest-asyncio + httpx | 中 | 状态码/schema/鉴权/错误 |
| 外部适配器契约 | 第三方 API 客户端 | 录制/契约桩（pact/vcr/schema） | pytest + 契约桩 | 中 | 适配层与上游约定一致 |
| 迁移 | Alembic 脚本 | 真实 DB，`upgrade`/`downgrade` 往返 | alembic + pytest | 中 | 迁移可正反执行、无漂移 |
| 系统 E2E | 全链路 | **真实进程 + 网络 + 依赖** | 起真服务 + 外部客户端 | 最高 | 生产近似行为 |

> **关键辨析（勿混称）**：`httpx.AsyncClient + ASGITransport` 是**进程内**调用 ASGI app，属**接口 / 集成测试**，**不是**真 E2E——它不经过真实网络栈、不起独立进程、通常也不拉起真实外部依赖。称其为 "E2E" 会高估证据强度。真 E2E 必须**真实进程 + 网络 + 依赖**。

---

## 2. 按变更类型选层（最低适用矩阵）

每种变更**至少**覆盖对应层；"强制"必须有、"建议"应有、"可豁免"须写显式豁免条件。**纯业务逻辑与高风险分支的单元测试最低强制，不可豁免。**

| 变更类型 \ 测试层 | 单元 | 服务 | repo 集成 | API 接口 | 迁移 |
|---|---|---|---|---|---|
| 纯业务 / 领域逻辑 | **强制** | 建议 | — | 可豁免¹ | — |
| service 编排 | 建议 | **强制** | 建议 | 建议 | — |
| repository / 查询 | 建议 | — | **强制** | 建议 | — |
| 新增 / 改动 API 端点 | 建议 | 建议 | 建议 | **强制** | — |
| DB schema 变更 | — | — | **强制** | 建议 | **强制** |
| 高风险分支（金额/权限/幂等/状态机） | **强制** | **强制** | 视依赖 | **强制** | — |
| 纯文档 / 注释 | 可豁免 | 可豁免 | 可豁免 | 可豁免 | — |

- ¹ **显式豁免条件**：仅当该逻辑已被更低成本的单元测试完全覆盖、且端点无新增分支时，方可豁免 API 层；豁免须在 tasks/test 记一行理由，不得默认省略。
- 高风险分支（金额计算、鉴权/授权、幂等、状态迁移）**单元 + API 双强制**，无豁免。

---

## 3. ASGI lifespan 管理

`AsyncClient + ASGITransport` **默认不执行 startup/shutdown lifespan**。若 DB 连接池、HTTP 客户端、缓存在 `lifespan`（`RULE-API-04`）里初始化，这些资源在测试中**会被绕过**——要么用到未初始化的全局、要么静默走了另一条路径，测出"假绿"。

规范做法：用 `LifespanManager(app)`（`asgi-lifespan` 库）或进入应用 `lifespan` 上下文的 fixture 显式拉起，并**对 startup/shutdown 有断言**（如池已建、客户端可用、停机已 dispose）。

```python
# ✅ 显式 lifespan fixture：真正跑 startup/shutdown
import pytest
from asgi_lifespan import LifespanManager
from httpx import AsyncClient, ASGITransport
from app.main import app

@pytest.fixture
async def client():
    async with LifespanManager(app):            # 触发 lifespan startup/shutdown
        transport = ASGITransport(app=app)
        async with AsyncClient(transport=transport, base_url="http://test") as c:
            yield c
    # 退出时 shutdown 已执行；可对 engine.dispose() 等收尾加断言
```

- ❌ `ASGITransport(app=app)` 直接用，**假设**池 / 客户端 / 缓存已就绪（lifespan 未跑，资源实为 None 或走旁路）。
- ✅ 显式 lifespan fixture（`LifespanManager` 或应用 lifespan 上下文），对 startup/shutdown 有断言。

---

## 4. 覆盖率与不退化门禁

用 `coverage.py` / `pytest-cov`，开 **`--cov-branch`**（分支覆盖，非仅行覆盖）。

- **统计范围与排除**：只统计 `app/` 业务源码；排除 `migrations/`（Alembic 生成）、`*generated*`、`tests/`、以及构建产物；排除项写进 `.coveragerc` / `pyproject.toml` 明示。
- **基线由项目决策**：不固化统一数字（不同项目风险不同），基线写入 constitution/test 决策。
- **不退化三条门禁**：
  1. 总覆盖率 **不低于基线**；
  2. **变更覆盖率（diff coverage）不低于基线**（本次改动的新增/改动行须被测到，防"老代码撑高、新代码裸奔"）；
  3. **覆盖率下降即失败**（相对上次基线回退即门禁 fail）。

```toml
# pyproject.toml（要点：分支覆盖 + 排除范围）
[tool.coverage.run]
branch = true
source = ["app"]
omit = ["app/**/migrations/*", "**/*generated*", "tests/*"]
```

---

## 5. 最小 API 验证矩阵

每个接口**至少**覆盖下列用例，缺一即验证不完整：

| 用例 | 断言要点 |
|---|---|
| 正常 2xx | 状态码 + **实际响应 schema**（按 `response_model` 校验字段/类型，非仅状态码） |
| 422 校验失败 | Problem Details 结构，`type`/`loc`/`code` 机器稳定（cross-ref error-model.md） |
| 401 未认证 | 缺/坏凭据被拒 |
| 403 无权限 | 有身份但越权被拒 |
| 领域失败 404/409 | 资源不存在 / 冲突（唯一约束、幂等重复）走统一错误体 |
| 分页 / 幂等边界 | 分页上限、cursor/offset 边界；写接口重复提交幂等（`RULE-API-03`） |
| 契约行 | OpenAPI 可导出、`operation_id` 唯一、`oasdiff breaking` 无破坏、（可选）`schemathesis` |

**Checklist**（每端点逐项）：

- [ ] 正常 2xx + 响应 schema 断言
- [ ] 422 校验失败
- [ ] 401 未认证
- [ ] 403 无权限
- [ ] 领域失败 404/409
- [ ] 分页 / 幂等边界
- [ ] 契约：OpenAPI 导出 + operation_id 唯一 + oasdiff 无破坏（可选 schemathesis）

---

## 6. 测试稳定性最低规范

- **固定随机种子**：`random`/`faker`/`hypothesis` 用固定 seed，可复现。
- **注入时钟**：禁 `datetime.now()` 裸调；用可注入的时钟依赖 / `freezegun`，时间可控。
- **固定 tz / locale**：显式设时区与 locale，禁依赖运行机环境（cross-ref [i18n-and-messages.md](i18n-and-messages.md)）。
- **顺序独立**：用例互不依赖执行顺序（可 `pytest-randomly` 打乱验证）。
- **并行安全**：`pytest-xdist` 下无共享可变态 / 端口 / 库冲突（每 worker 独立库或事务隔离）。
- **超时**：`pytest-timeout` 兜底防挂死。
- **慢测试标记**：`@pytest.mark.slow` 分级，本地快集 / CI 全集。
- **flaky 必须定位根因**：**禁把"重跑即过"当高等级证据**——flaky 说明存在竞态/时序/共享态缺陷，须定位根因修复；未定位的 flaky 结论不得标高于其真实证据等级（cross-ref evidence-gate-protocol.md）。

- ❌ `assert created_at == datetime.now()`（时钟未注入、必然 flaky）
- ✅ 注入固定时钟，`assert created_at == fixed_now`

---

## 7. 证据绑定

每条测试结论**绑定可复现凭据**，禁自然语言脱钩（禁裸 "PASS"）：

| 绑定项 | 内容 |
|---|---|
| 可重放命令 | 如 `uv run pytest tests/api -q --cov=app --cov-branch` |
| 退出码 | `0` / 非 0 |
| 收集用例数 | `collected N items` / passed·failed·skipped 计数 |
| 结果产物路径 | `report.xml`（junit）、`coverage.xml`/`htmlcov/`、日志路径 |
| 版本标识 | commit sha / 依赖锁（`uv.lock`）/ 镜像 tag |

- 结论按 [evidence-gate-protocol.md](evidence-gate-protocol.md) 标 **L1–L5**：进程内 pytest（httpx.AsyncClient + 测试库/事务回滚）属 **L3**；staging 联调/契约(schemathesis)/压测属 **L4**。
- ❌ "接口测试通过"（无命令、无退出码、无产物）
- ✅ "`pytest tests/api` exit=0，collected 42，coverage.xml 覆盖率 87%（≥基线 85%），junit report.xml，sha `abc1234` — L3"（cross-ref `RULE-TEST`）

---

## 8. 阶段映射（与六阶段/门禁衔接，不改冻结门禁）

| 阶段 | 与本主题相关的动作 |
|---|---|
| constitution | 定测试框架、DB 隔离方式（容器化/事务回滚）、覆盖率基线、并行策略 |
| spec | 明确验收点与错误/边界口径，供后续用例对齐 |
| design | 定测试层分布、依赖抽象与 mock 方案、lifespan fixture 策略、契约测试是否启用 |
| tasks | **与实现同步写单元与必要测试**（纯逻辑/高风险分支单元最低强制）；补 fixture 与桩 |
| test | 独立验收：跑各层测试 + 汇总证据（命令/退出码/用例数/产物/版本）+ 覆盖率不退化门禁 + API 验证矩阵 + 契约（oasdiff/schemathesis）；每结论标 L1–L5 |
| deliver | 交付证据引 test 最高证据等级（不得高于）；未测边界进交付风险；覆盖率产物随交付同步 |

---

## 附：coding-rules.md 中的 RULE-TEST 条目（供落库）

> 以下条目落入 [coding-rules.md](coding-rules.md) 的 `RULE-TEST` 家族，本文件为其深展开。既有 `RULE-TEST-01`/`RULE-TEST-02` 保留，以下为扩充。

### RULE-TEST-03：分层测试，底层强制，勿把进程内接口测当 E2E
按金字塔分层（单元/服务/repo 集成/API 接口/外部契约/迁移/系统 E2E）；纯业务逻辑与高风险分支单元最低强制；`httpx.AsyncClient + ASGITransport` 属进程内接口/集成测试，禁混称真 E2E。

### RULE-TEST-04：ASGI 测试显式管理 lifespan
`AsyncClient + ASGITransport` 默认不跑 startup/shutdown；lifespan 初始化的 DB 池/HTTP 客户端/缓存必须经 `LifespanManager(app)` 或应用 lifespan 上下文 fixture 拉起并对 startup/shutdown 断言。
- ❌ `ASGITransport(app=app)` 假设资源就绪
- ✅ 显式 lifespan fixture

### RULE-TEST-05：覆盖率不退化门禁
`--cov-branch`；统计限 `app/`、排除 migrations/generated/tests 与产物；项目决策基线（不固化统一数字）；变更覆盖率不低于基线、覆盖率下降即失败。

### RULE-TEST-06：最小 API 验证矩阵 + 契约行
每接口至少 正常2xx（断响应 schema）/422/401/403/领域失败(404/409)/分页幂等边界；契约：OpenAPI 导出 + operation_id 唯一 + oasdiff 无破坏（可选 schemathesis）。

### RULE-TEST-07：测试稳定性最低规范
固定随机种子、注入时钟（禁 `datetime.now()`）、固定 tz/locale、顺序独立、并行安全、`pytest-timeout`、慢测试标记；flaky 必须定位根因，禁"重跑即过"当高等级证据。

### RULE-TEST-08：结论绑证据，禁自然语言脱钩
每条结论绑 可重放命令 + 退出码 + 收集用例数 + 结果产物路径 + 版本标识，并标 L1–L5（cross-ref evidence-gate-protocol.md）；禁裸 PASS。
