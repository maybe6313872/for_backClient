# 统一质量门禁与 CI（单一事实源）

> 本域"质量能不能过"必须由**一个可复现入口**说了算，本地、CI、任何人执行**同一条命令、同一套语义、同一失败判定**。禁止 CI 与本地各跑各的、靠人记步骤。对应编码规则 `RULE-CI`（门禁入口）、`RULE-LINT`（格式/静态检查）、`RULE-TYPE`（类型可判定，详见 [coding-rules.md](coding-rules.md)）。落阶段：constitution 定入口与门禁项、design 定阶段命令、tasks 落脚本、test 逐项验证、deliver 出口复跑。栈画像与最低 Python 版本见 [stack-profile.md](stack-profile.md)；覆盖率细节见 [testing-strategy.md](testing-strategy.md)。

---

## 1. 统一质量入口（单一事实源）

**一个入口、固定顺序、快速失败（fail-fast）**：任一阶段非零退出立即阻断，不继续跑后续。入口三选一，本地/CI 一致：

- `make check`（Makefile 编排，最通用）
- `uv run poe check`（poethepoet 任务，uv 项目首选）
- `nox -s check` / `nox`（跨 Python 版本矩阵时首选）

入口内部固定执行顺序（前一步过才进下一步）：

| # | 阶段 | 命令示例 | 失败即阻断 | 产物 |
|---|---|---|---|---|
| 1 | 冻结安装（frozen） | `uv sync --frozen`（兜底 `pip install --require-hashes -r requirements.txt`） | 是（锁不一致即停） | — |
| 2 | 格式检查 | `ruff format --check .` | 是 | — |
| 3 | 静态检查/lint | `ruff check .` | 是 | — |
| 4 | 类型检查 | `mypy .`（或 `pyright`） | 是 | — |
| 5 | 单元测试 | `pytest tests/unit` | 是 | `junit-unit.xml` |
| 6 | 接口/集成测试 | `pytest tests/integration`（httpx.AsyncClient + 测试库/事务回滚，见 RULE-TEST-01） | 是 | `junit-integration.xml` |
| 7 | 覆盖率门禁 | `coverage report`（不退化判定，见 §5） | 是 | `coverage.xml` |
| 8 | OpenAPI 导出 + 破坏性变更 | `python scripts/export_openapi.py` + `oasdiff breaking base revision` | 是（破坏性非空即停） | `openapi.json` |
| 9 | 迁移往返 | `alembic upgrade head` 后 `alembic downgrade -1`（再 `upgrade`）验可逆 | 是 | 迁移日志 |

- **格式/lint 用 check 模式**：门禁里跑 `--check`/只读检查，**不在门禁里自动改文件**（自动修复是开发者本地 `ruff format` / `ruff check --fix` 的事）。
- **同一语义、跨平台**：Windows / Linux / CI 执行的是**同一入口的同一语义命令**。用 `make`/`poe`/`nox` 抹平 shell 差异，禁止把关键步骤只写在某平台的脚本或 CI YAML 里、本地无法复跑。
- **顺序即成本梯度**：先快后慢（安装→格式→lint→类型→单元→集成→覆盖率→契约→迁移），让最便宜的检查最早暴露问题。

❌ CI YAML 里手抄一串步骤、本地只能凭记忆复现　❌ 门禁里 `ruff format .` 直接改文件后"通过"
✅ 本地 `make check` 与 CI 调的是同一入口，红就是红

---

## 2. 最低 CI 流水线

CI 是**统一入口的镜像执行器**，不是第二套规则：

- **镜像 check 入口**：CI 作业核心就一行 `make check`（或 `uv run poe check` / `nox`），不重新拼步骤。
- **失败阻断合并**：任一步骤非零退出→流水线失败→阻断 PR 合并（配保护分支必需检查）。
- **产物保存（artifacts）**：上传 `coverage.xml`、`openapi.json`、`junit-*.xml`，供人读与趋势对比；破坏性变更报告随产物留存。
- **最低支持 Python 版本验证**：CI 至少在**项目声明的最低支持版本**上跑门禁（矩阵可加更高版本）；最低版本的确定走 [stack-profile.md](stack-profile.md) 的证据链（`requires-python` 优先），**禁止模板预填**。
- **服务依赖**：集成测试需要的 DB 用 CI service 容器（如 Postgres），连测试库而非任何共享/生产库。

---

## 3. uv 路径 · 完成定义（DoD）

uv 为本域默认包管理，"依赖做完了"= 满足全部：

- [ ] `pyproject.toml` 声明依赖，**分组隔离**：运行时（`[project].dependencies`）+ 开发（`dev`）+ 测试（`test`），用 dependency-groups / optional-dependencies 划清。
- [ ] 提交 `uv.lock`（含全解析图与哈希）进 git，作为可复现事实源。
- [ ] CI/生产一律 `uv sync --frozen`（锁与声明不一致即失败），禁止 CI 里 `uv add`/隐式升级。
- [ ] 应用运行走 `uv run ...`，环境由 uv 管理、不污染全局。

---

## 4. requirements 兜底 · 完成定义（不得降低可复现性）

无 uv 时用 pip 兜底，**可复现性标准不降级**：

- [ ] 用 `uv pip compile`（或 `pip-compile`）从声明源生成**含哈希的完整** `requirements.txt`，配 `constraints.txt` 钉传递依赖。
- [ ] 分三份：`requirements/runtime.txt`、`dev.txt`、`test.txt`（对应 uv 的分组）。
- [ ] 安装用 `pip install --require-hashes -r requirements.txt`，哈希校验全量依赖。
- [ ] CI/生产装的是编译产物（全量钉版本+哈希），不是手写的宽松清单。

> **仅固定直接依赖 ≠ 完整锁定**：手写只钉直接依赖、放任传递依赖漂移，不算可复现，不满足 DoD。**工具缺失不是降级理由**——没有 uv 就用 pip-compile 达到等价锁定；达不到就在 `open-issues.md` 记差距，不得当作已完成。

---

## 5. 覆盖率不退化门禁

见 [testing-strategy.md](testing-strategy.md) 完整口径，此处只定门禁语义：

- **基线是项目决策**：覆盖率**基线（baseline）由项目在 constitution 决定并记录**，不由本 skill 固化统一百分比。
- **不退化判定**：总覆盖率不得低于基线；**diff 覆盖率**（本次改动行）不低于基线要求；低于即阻断。
- **只涨不落**：基线随质量提升可上调，不因图省事下调（下调需评审记录）。
- **禁裸达标**：靠删测试/排除文件凑数视为违规。

---

## 6. 阶段映射

| 阶段 | 与本主题相关的动作 |
|---|---|
| constitution | 定统一入口（make/poe/nox）、门禁项与顺序、覆盖率基线、最低 Python 版本、包管理路径（uv/requirements） |
| design | 明确各阶段命令与产物、CI 作业如何镜像入口、DB service 与测试隔离方案 |
| tasks | 落地 `Makefile`/`noxfile.py`/poe 任务、`scripts/export_openapi.py`、requirements 编译脚本；按 `RULE-CI/RULE-LINT/RULE-TYPE` 标注 |
| test | 本地跑通统一入口，逐阶段留证据（L1–L3）；验证冻结安装、覆盖率不退化、oasdiff、迁移往返 |
| deliver | 出口复跑统一入口全绿；保存 coverage/openapi/junit 产物；破坏性变更已评审/升版 |

---

> 本文件展开 `RULE-CI`（统一门禁入口与 CI 镜像）、`RULE-LINT`（ruff 格式+静态检查）、`RULE-TYPE`（类型可判定门禁）在质量门禁维度的落地；规则原文见 [coding-rules.md](coding-rules.md)，依赖锁定见其 `RULE-DEP`，契约门禁见 `RULE-API-05` 与 [openapi-and-api-docs.md](openapi-and-api-docs.md)。
