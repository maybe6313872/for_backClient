# 技术栈画像与工程不变量

> 本文件治一个高频错误：**把"新项目推荐默认栈"当成"所有项目的事实"**。本域要区分三件事——哪些是**必须成立的工程不变量**（与栈无关）、哪些是**新项目推荐默认**（greenfield 的选择，非普适事实）、哪些是**存量项目的当前事实**（可能合法地不用推荐栈）。对应 [coding-rules.md](coding-rules.md) 的 `RULE-PROC`（栈画像先行）、`RULE-DEP`（可复现锁定）、`RULE-API`（契约权威）。落阶段：constitution 记画像与决策、design 依画像定方案、test 在最低版本验证。门禁入口见 [quality-gate-and-ci.md](quality-gate-and-ci.md)，契约方法见 [openapi-and-api-docs.md](openapi-and-api-docs.md)。

---

## 1. 三层区分（核心）

**(a) 工程不变量（stack-agnostic，MUST hold）**——不管什么栈都必须成立：

- 全量类型可判定
- 事务边界显式且有归属
- 测试隔离（不打共享/生产库）
- 依赖可复现锁定
- 配置单一入口
- 错误语义统一
- async 一致（不混阻塞）
- 契约可验证

**(b) 新项目推荐默认（DEFAULTS for greenfield，非普适事实）**：Python 3.11+、FastAPI、Pydantic v2、SQLAlchemy 2.0 async + Alembic、uv、mypy strict、Ruff、pytest。

**(c) 存量项目当前事实（可合法存在）**：同步驱动、原生 SQL、其他迁移机制、较早 Python 版本、requirements 管理——这些不是"错"，是既有事实，须先如实记录。

**不变量 × 栈**——同一不变量在推荐栈与存量栈上的满足方式：

| 工程不变量 | 推荐栈上如何满足 | 存量栈上的等价满足 |
|---|---|---|
| 全量类型可判定 | mypy strict + Pydantic v2 | 至少对新增/接触面加注解 + 类型门禁；差距记录 |
| 事务边界显式有归属 | `async with session.begin()`，service 拥有 | 手动 `begin/commit/rollback` 在 service 层显式包裹 |
| 测试隔离 | 测试库/事务回滚 + dependency_overrides | 独立测试库/事务回滚；桩掉外部依赖 |
| 依赖可复现锁定 | `uv.lock` + `uv sync --frozen` | 含哈希 requirements + `--require-hashes`（见 [quality-gate-and-ci.md](quality-gate-and-ci.md) §4） |
| 配置单一入口 | pydantic-settings | 单一 settings 模块统一读环境变量 |
| 错误语义统一 | Problem Details 全局 handler | 统一错误信封 + 收口中间件 |
| async 一致 | async 驱动 + AsyncSession | 若同步栈，则全链路同步、不半途 await；不混栈 |
| 契约可验证 | `app.openapi()` 导出 + oasdiff | 导出规格 + 破坏性变更比对（工具等价即可） |

> 记忆点：不变量不可放弃；默认栈可替换；替换时须给出**等价满足方式**并记差距，不得以"没用推荐栈"为由跳过不变量。

---

## 2. 技术画像先行（升级前先记录）

动任何"升级/替换"念头前，先如实记录当前画像（作为 Mode-B / constitution 工件）：

- Python 版本
- async / sync 栈
- 数据访问方式（ORM / 原生 SQL / 混合）
- 迁移机制（Alembic / 其他 / 无）
- 包管理（uv / pip / poetry / …）
- 类型与 lint 现状（有无 mypy/pyright、Ruff/flake8）
- 契约来源（code-first / 契约仓库 / 无）

**记录之后再决定本次是否升级**：最小改动优先，不为"对齐推荐栈"强制替换整栈。升级与否都写入决策记录。

---

## 3. Python 版本：发现 → 决策 → 验证 闭环

**发现（证据优先级，高→低）**：

`requires-python`（pyproject）＞ 锁文件（uv.lock / requirements 标注）＞ 容器基础镜像（Dockerfile `python:X.Y`）＞ CI matrix ＞ 部署环境实测 ＞ 源码语法特征

**决策**：若当前低于推荐版本，三选一并记录理由——

| 决策 | 适用 |
|---|---|
| 保持兼容 | 代码需在旧版本跑，新增功能不用高版本特性 |
| 升级 | 有明确收益且部署环境可跟随 |
| 阻塞 | 版本约束与需求冲突，须先解版本再继续 |

**验证**：CI 在**最低支持版本**上跑门禁（见 [quality-gate-and-ci.md](quality-gate-and-ci.md) §2）。

❌ 模板预填 "Python 3.11+" 当作项目事实
✅ 按证据链确认真实版本 + CI 在最低支持版本验证

---

## 4. API 契约权威来源：先判定再定流程

多份契约并存时，先定**谁是权威**，避免自动文档覆盖已评审契约：

| 模式 | 说明 |
|---|---|
| code-first（默认） | 契约由 `app.openapi()` 从代码生成；代码是权威 |
| contract-first | 跨仓库/契约仓库/design-first：先评审 OpenAPI，代码据其实现 |
| 双向校验 | 两边都有，靠 schemathesis/oasdiff 对齐一致性 |

- **多份契约冲突**：先定优先级与同步方向（谁改动谁为准），写入 constitution/context。
- cross-ref [openapi-and-api-docs.md](openapi-and-api-docs.md) 完整方法。

❌ 服务端自动生成的文档**覆盖**了已评审的契约仓库
✅ 先定权威来源，再定生成/校验流程

---

## 5. 依赖与迁移的栈无关表述

- **不变量**：事务、隔离、可测试、可复现——这些是必须成立的，与实现无关。
- **默认实现**：SQLAlchemy / Alembic / uv 是推荐栈里满足上述不变量的具体手段。
- **非默认栈**：给出**等价满足方式**（如手动事务包裹、含哈希 requirements、非 Alembic 迁移工具），并把与推荐栈的差距记入 `open-issues.md`。不变量不因换实现而豁免。

---

## 6. 阶段映射

| 阶段 | 与本主题相关的动作 |
|---|---|
| constitution | 记录技术画像（版本/栈/访问/迁移/包管理/类型/契约来源）；定最低支持版本、契约权威、升级与否 |
| spec | 明确契约形态与兼容要求；不写栈细节 |
| design | 依画像定方案；非默认栈标注不变量的等价满足方式与差距 |
| tasks | 按决策落地；CI 最低版本矩阵、契约导出脚本到位 |
| test | 在最低支持版本跑门禁；验证不变量（类型/隔离/可复现/契约）成立 |
| deliver | 画像与决策已回写 context；差距进 `open-issues.md` |

---

> 本文件支撑 [coding-rules.md](coding-rules.md) 的 `RULE-PROC`（栈画像先行、不臆测栈事实）、`RULE-DEP`（依赖可复现锁定，实现可换、不变量不换）、`RULE-API`（契约权威先判定）；门禁与最低版本验证见 [quality-gate-and-ci.md](quality-gate-and-ci.md)。
