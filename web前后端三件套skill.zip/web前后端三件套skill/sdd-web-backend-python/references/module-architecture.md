# 模块架构与业务闭包（RULE-STRUCT 展开）

> 本文件展开 `RULE-STRUCT`：**有分层不等于有结构**。一个项目有 router/service/repository 层，仍可能把所有路由、所有 schema、所有文案塞进一个巨型文件——那不是分层，是"分层壳 + 大泥球"。本域要求的是**纵向业务模块化**：每个业务能力自成闭包。对应 [coding-rules.md](coding-rules.md) 的 `RULE-STRUCT` 条目。落阶段：design 定模块边界、tasks 按闭包落地、deliver 校验闭包完整。i18n 文案见 [i18n-and-messages.md](i18n-and-messages.md)，栈无关性见 [stack-profile.md](stack-profile.md)。

---

## 1. 横向分层 vs 纵向业务模块化（核心区分）

| 维度 | 横向分层（必要但不充分） | 纵向业务模块化（本域要求） |
|---|---|---|
| 组织轴 | 按技术角色分（所有 router 一处、所有 schema 一处） | 按业务能力分（一个能力自带各层） |
| 典型症状 | `api.py` 装全部路由、`models.py` 装全部 schema | `app/orders/` 装订单的全部 |
| 改一个功能 | 要横跨多个巨文件、互相踩 | 集中在一个模块目录内 |
| 能否阻止大泥球 | **不能**——分层存在不妨碍单文件膨胀 | 能——模块边界即改动边界 |

> 结论：分层是"每层做什么"，模块化是"每个功能的东西住在一起"。**两者都要**，本域强制后者。

---

## 2. 业务模块闭包（强制）

一个业务能力（feature）**共同拥有**它需要的全部构件，同住一个目录：

- `router` — 该能力的路由
- `schemas` — 入出参 Pydantic 模型
- `service` — 领域编排 + 事务边界
- `repository` / `adapter` — 持久化/外部访问细节
- `errors` — 该能力的领域异常
- `messages` — i18n 文案（见 [i18n-and-messages.md](i18n-and-messages.md)）
- `tests` — 该能力的测试

标准布局：

```
app/<feature>/
  __init__.py
  router.py          # 只声明路由，委托 service
  schemas.py         # 入出参边界模型
  service.py         # 领域编排 + 事务边界所有权
  repository.py       # 持久化细节（SQL/驱动/行映射）；外部则 adapter.py
  errors.py          # 领域异常
  messages.py        # i18n 文案键
  tests/             # 该 feature 的单元/接口测试
```

---

## 3. 公开入口 vs 内部实现

模块要有**窄公开面**，内部实现私有：

- **公开**：`router` + `service`/facade + 公共 `schemas`。跨模块只准依赖这些。
- **内部**：`repository`、原生 SQL、行映射、驱动细节——模块私有，外部不得直接引用。
- **聚合入口只注册、不含逻辑**：`app/api/__init__.py` 只 `include_router(...)`；`app/main.py` 只组装应用（挂中间件、lifespan、路由聚合），不写业务。

❌ 所有 router 挤进 `api.py`　❌ 所有 schema 挤进 `models.py`　❌ `main.py` 里写业务分支
✅ 每模块闭包，聚合入口只做装配

---

## 4. 跨模块依赖方向

- **向下依赖共享内核**：模块可依赖 `app/core`/`app/shared`（config、db 引擎/session 工厂、logging、错误基类），方向单一向下。
- **禁横向依赖彼此内部**：模块 A 不得 import 模块 B 的 `repository`/内部；确需协作，走 B 的公开 service/schema。
- **禁循环依赖**：A↔B 相互依赖是设计信号，须上提共享或重划边界。
- **共享代码准入（防过早抽象）**：一段代码**被 ≥2 个模块稳定复用**才升 `app/core`/`app/shared`；只有一个用处就留在模块内。宁可暂时局部重复，也不过早造抽象。

---

## 5. ORM 无关的数据访问边界

**本节结论对 SQLAlchemy 与 原生 SQL / 同步驱动 / 非 ORM 一律成立**——是否用 SQLAlchemy 不改变职责划分。

违规信号：`service` 一职多能——领域校验 + 建连接 + 跑 DDL + 拼 SQL + 行映射 + 重试 + 组装响应全塞一个函数。

拆分职责：

| 职责 | service | repository / adapter |
|---|---|---|
| 领域校验、业务规则 | ✅ | ❌ |
| 编排多步骤、决定调用顺序 | ✅ | ❌ |
| **事务边界所有权**（begin/commit/rollback 归谁） | ✅ | ❌（在给定连接/session 上执行） |
| 拼 SQL / 调 ORM 查询 / 参数绑定 | ❌ | ✅ |
| 驱动细节、游标、行→对象映射 | ❌ | ✅ |
| 连接/session 获取 | ❌（经依赖注入拿，不自己建） | ✅ 使用注入的连接 |
| 响应 schema 组装 | ✅（或路由层） | ❌ |

- **运行期 DDL 禁在业务路径**：建表/改表走迁移（Alembic 或等价机制），不在请求处理里 `create_all`/`CREATE TABLE`。
- **职责边界可判定**，不依赖是否用了 SQLAlchemy。

❌ 文件名叫 `service.py` 就当"有服务层"（内部却什么都干）
✅ 按上表能逐条判定每段代码属于哪个职责

---

## 6. 存量项目适配

- **不强制大爆炸重构**：扁平 legacy（单 `api.py` / 单 `models.py`）不要求一次推倒重组。
- **新功能按闭包落地**：新增业务能力直接建 `app/<feature>/` 闭包，不再往巨文件里加。
- **存量按接触面渐进抽取**：改到哪块、就把哪块从巨文件里抽成模块，逐步收敛。
- **记差距**：未完成的模块化差距写入 `open-issues.md`，作为持续改进项，不假装已达标。

---

## 7. 模式 B / deliver 对模块闭包的检查

- **模式 B（代码孪生）**：逆向时按业务能力而非按文件平铺组织 `context/modules.md`，标出哪些能力已闭包、哪些仍散落在巨文件，散落项进 `open-issues.md`。
- **deliver Gate**：新增/改动的业务能力应满足闭包（该有的 router/schemas/service/repository/errors/messages/tests 到位、公开面窄、无横向内部依赖、无循环、无运行期 DDL）；不满足则记差距并说明原因，不得静默交付。

---

> 本文件展开 [coding-rules.md](coding-rules.md) 的 `RULE-STRUCT`（业务模块闭包、窄公开面、依赖方向、ORM 无关的 service/repository 职责边界）；数据访问规则见其 `RULE-DB`，文案见 [i18n-and-messages.md](i18n-and-messages.md)。
