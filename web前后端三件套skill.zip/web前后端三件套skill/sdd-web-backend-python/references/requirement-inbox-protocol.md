# 需求收件箱协议（`docs/requirements/`）——F33

> 每个 sdd-xx 项目都在 `docs/requirements/` 维护一个**需求收件箱**。上层编排类 skill（如全栈编排 sdd-web-fullstack）把派单包投递到这里；人类也可以把需求规格/资料直接丢进来。本文件定义收件箱约定、认领协议与签收信号。收件箱是**冻结的框架机制（F33）**，所有 sdd-xx 一律继承，语义、认领流程与"清空=签收"信号不可改写；本域只做落地，不改语义。

---

## 1. 为什么要收件箱

需求从两个方向进来：一是上层 AI 编排把大需求拆分后，把属于本项目的那一片派下来；二是人类把需求规格丢过来。两者都需要①一个标准、可预测的落地点，②一个明确无歧义的"已接收"信号。没有这套约定，需求包会散落在 `docs/` 各处，谁也分不清"已收到"与"被忽略"。

对 FastAPI 后端服务，典型收件内容有三类：
- **上层派单包**：编排层把一个跨仓需求切成本服务的一片（新增/修改若干接口、库表、后台任务等），连同验收点、集成约定与需读的父层绝对路径一起投递。
- **人类丢入的需求规格**：需求规格书、接口需求、变更单等，可能是二进制（xlsx/docx/pdf，走 docs 文本化，见 docs-binarification-adapter.md）。
- **跨仓契约变更通知**：上下游对 OpenAPI 契约、库表结构、消息格式等的变更通知（新增字段、字段语义变更、弃用接口等），需要本服务同步跟进。

## 2. 收件箱约定

- **位置**：`<项目>/docs/requirements/`。文件命名通常为 `dispatch-YYYYMMDD-<slug>.md`（编排派单）、或人类丢入的任意需求规格文件名。历史上直接放在 `docs/` 下的需求文件仍可读，**不强制迁移**。
- **`docs/requirements/` is a RESERVED directory name (F37)**: within any repository governed by an sdd-xx skill, this exact path may carry **inbox semantics only** — a short-lived queue that gets cleared on claim. **Never** use it to store long-lived requirement specifications, product baselines, or anything else that must survive a claim. Long-lived requirement artifacts belong in `docs/product-specs/` (see structure.md). Rationale: the claim protocol below **deletes** whatever sits in the inbox; a directory that means two things means the AI cannot tell which files are safe to delete.
- **Claim boundary**: "clear the inbox" removes **only** the claimed packet files inside `docs/requirements/`. It never touches `docs/product-specs/`, `docs/iterations/`, `docs/decisions/`, or any other `docs/` subtree.
- **建立时机**：`/sdd-init` 在建立 `specs/` 结构的同时创建 `docs/` 与 `docs/requirements/`，使收件箱在有人需要之前就已存在（见 structure.md 的 `docs/` 结构、commands.md 的 `/sdd-init`）。
- **单向**：收件箱只进不出，**永远不是进度看板**——本 skill 绝不把进度写回收件箱。上层要看进度请读 `specs/task.md`（见 task-kanban-protocol.md）。

## 3. 入口行为钩子（每次触发都要检查收件箱）

每次触发时，在读完 `specs/README.md` + `specs/task.md` 之后，**检查收件箱**。非空 → 有待认领的需求：用一句话向用户概述它，并确认是否认领（点名本项目的派单包通常直接认领；含糊的丢入件先问一个澄清问题）。此钩子与 specs 生命周期的"开迭代前巡检"衔接（见 specs-lifecycle.md §6）。

## 4. 认领协议（登记进 specs → 归档副本 → 清空收件箱）

认领一条需求是一个三步硬动作，缺一不可：

1. **登记进 specs**：向 `task.md` 追加一行看板条目，并按需求内容创建/扩写对应的 `2-spec` 条目（对应到某个 spec 或某轮迭代），随后从合适阶段进入正常的六阶段流程。
2. **在本项目内归档一份副本**：把需求内容保存到本项目自己的 specs 区（如 `specs/2-spec/inputs/`），使得即便上游没有权威副本，清空收件箱也不会丢任何信息。（编排层在根仓保留自己的权威副本；本地副本让本项目无论如何都能自足。）**先归档再写**，遵守 specs-lifecycle.md 的禁覆盖守则——同名副本不得直接覆盖，先归档旧版本。同时在 `sources.md` 来源/新鲜度登记表登记这份外部输入（见 assets/templates/sources.md 与本文件 §6）。
3. **从收件箱清空已认领项。** 清空后的收件箱就是给上层的**签收信号**："需求已收到、迭代已启动"。这是一个**签收/取件信号，NOT 完成信号**——完成与否仍由门禁与证据判定（见 gate-and-stages.md、evidence-gate-protocol.md）。

❌ 反例：拿着收件箱里的文件就直接开写代码，不先登记进 specs；清空收件箱却没归档本地副本；把已认领的包"留着当参考"继续放在收件箱里（上层会读成"尚未接收"）；往收件箱里写状态/进度批注。

✅ 正例：一句话概述 → 用户放行 → task.md 追加一行 + 建 2-spec 条目 → 副本落 `specs/2-spec/inputs/` 并登记 `sources.md` → 清空收件箱 → 进入六阶段。

## 5. 处理来自编排层的派单包

派单包是在"本会话**看不到**上层项目文件夹"的假设下写成的。它承载：本服务的需求切片、验收点、集成约定，以及一份克制的、指向父层文件的**绝对路径**清单（接口/契约文档优先，如上层 OpenAPI 契约、库表约定）。把这些下行路径当作只读引用（或被明确标记为共同维护的文件）；路径损坏/不可达时，把 `⚠️ 待确认` 写入 `context/open-issues.md` 并发问——**绝不臆测缺失内容**。跨仓契约变更通知同理：以契约文档为唯一真相源，本服务据此调整 Pydantic 模型、SQLAlchemy 映射与 Alembic 迁移，任何不一致先上报。

## 6. 与 specs 生命周期、归档纪律、sources.md 的衔接

- **与 specs 生命周期/归档纪律**：认领第 2 步落副本严格走 specs-lifecycle.md 的"**先归档再写**"——`specs/2-spec/inputs/` 下已有同名副本时先归档旧版本再写新副本，绝不直接覆盖/删除。
- **与 `sources.md` 新鲜度登记表**：凡认领入库的外部输入（派单包、需求规格、契约通知）都要在项目的来源/新鲜度登记表登记一行（来源名称/类型/位置/版本或日期/最近核对日期/新鲜度状态等，见 assets/templates/sources.md）。开迭代前巡检或任何阶段消费该副本前，按登记表逐行核对源头当前版本/日期/哈希；不一致即标"待复核/已过期"、上报用户、确认后重取并更新登记表。
- **阶段映射**：`/sdd-init` **建立**收件箱（连同 `docs/`）；`/sdd-iterate`（或用户提出新需求开启新迭代）时**认领**收件箱内的待处理需求，走上面的三步认领协议。

## 7. 冻结说明

本协议（收件箱位置约定、单向语义、入口检查钩子、三步认领协议、"清空=签收非完成"信号、派单包处理规则）是**冻结的框架机制 F33**，跨所有 sdd-xx 一致，本域不得改写其语义。本域可落地的只是与 FastAPI 域相关的表述（收件类型举例、契约同步落到 Pydantic/SQLAlchemy/Alembic 等）。当母技能蓝图演进 F33 时，本文件经 `/sdd-evolve` 回灌更新。
