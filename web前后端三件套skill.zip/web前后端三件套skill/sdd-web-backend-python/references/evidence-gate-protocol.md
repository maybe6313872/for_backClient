# 证据分级与交付门禁协议

> 目标：解决 build pass / review pass / 测试 pass 被混写成 `PASS` 的问题。**阶梯的五个级别名、级别顺序、May claim 列与 deliver 语义约束均由框架冻结，在每个 sdd-xx 中逐字一致；每个域唯一可调的是「本域证据」这一列。**

## 1. L1-L5 证据等级（阶梯冻结，仅本域证据列可调）

| Level | Name (frozen, language-bound) | Domain evidence (slot) | May claim (frozen) |
|---|---|---|---|
| L1 | 构建通过/静态可见 | `uv sync` 成功、`mypy --strict` 通过、`ruff check` 通过、应用可 import/启动；代码审查、lint、diff 审查、OpenAPI 契约审查通过（这些是 L1 的强制前置条件，不单独成级） | it builds; the artifact/structure exists and is type-self-consistent |
| L2 | 单元测试通过 | `uv run pytest` 单元层通过（纯业务逻辑 + 高风险分支），退出码 0，收集/通过数记录在案（如 `collected 18, passed 18`），junit/coverage 产物（`reports/junit.xml`、`reports/coverage.xml`）存在且用例可被 `pytest --collect-only` 发现 | the unit-level logic is verified by executable tests |
| L3 | 受控集成通过 | `pytest` 集成层通过：测试库 + 真实依赖、`httpx.AsyncClient` 进程内接口测试、事务回滚隔离、显式驱动 lifespan；本地运行验证 | the components integrate and behave correctly in a controlled environment |
| L4 | 预生产环境验证 | staging/预发联调、集成回归、灰度小流量、契约(schemathesis)/压测 | it passes in a near-real environment |
| L5 | 生产环境验证 | 全量生产运行、SLA/监控达标、长稳记录 | it passes in the real production environment |

> **Single source of truth (frozen)**: this table is the **only** definition of the L1–L5 ladder. No other file — in this skill or in any skill that consumes its reports — may restate the ladder as an inline shorthand, an abbreviated list, or a parenthetical gloss (e.g. "L1 build / L2 review / L4 joint debugging"). A shorthand that drifts is indistinguishable from a redefinition, and readers obey whichever copy they hit first. Where another document must mention the ladder, it **links here** and names levels by ID only.
>
> **Frozen items (never changed by a child skill)**: the five level **names**, their **order**, and the "May claim" column. The five names are Chinese language-bound literals (F32) and are reproduced byte for byte; translating them is a violation, not a localisation. A child skill that wants different wording has misread the slot — the slot is the **Domain evidence** column, nothing else.
>
> **Why frozen**: orchestration-class skills (F34) aggregate the L values reported by every sub-project into one checkpoint table **with no conversion layer**. A per-domain ladder makes `L3` mean "it builds" in one sub-project and "front and back are integrated" in another, systematically overstating readiness and breaking the deliver exit gate.
>
> **Review/lint is not a level.** Static review, lint and diff review are a **mandatory precondition of L1**, not a rung: a reviewed-but-unbuilt change claims nothing. Do not re-introduce a "review passed" level under any number.
>
> **Domain evidence may not weaken a level.** Each `{{EVIDENCE_Lx}}` lists what *this domain* accepts as proof **of that level's frozen meaning**; it may not redefine the meaning. Filling L3 with "the build passes" is a violation — that is L1 evidence.
>
> **Mode B is a separate system — see §5 and the Mode B annotation clause later in this file (the "do not reuse the L1–L5 numbers" constraint).** Mode B conclusions use the textual strength labels 静态可见 / 资料互证 / 运行佐证 and **never** reuse the L1–L5 numbers. That clause is unchanged by this section and is not superseded by the table above; the two annotation systems stay disjoint.

> **This table does not restate the ladder.** The level **names**, their **order** and the "May claim" column are defined **only** in [§1 above](#1-l1-l5-证据等级阶梯冻结仅本域证据列可调) — the single source of truth. Nothing below re-states them; levels are referenced **by ID only**. What remains here is the generic evidence a domain may fall back on when it has not tuned §1's "Domain evidence" column.
>
> | 级（ID · 名称与 May claim 见 §1） | 通用证据（未微调时沿用） |
> |---|---|
> | L1 | 编译/构建/类型检查日志；静态审查、lint、diff 审查（L1 的强制前置条件） |
> | L2 | 单元测试执行记录（可发现的用例、退出码、收集/通过数） |
> | L3 | 集成测试、仿真、脚本验证 |
> | L4 | 联调、预发/staging、灰度小流量 |
> | L5 | 现场/全量/长稳/批量运行记录 |

## 1a. 测试证据资产绑定（本域 · 硬门禁）

L1–L5 只约束**交付措辞强度**，不保证证据真实存在。**证据等级不等于证据资产**：凡引用测试/运行结论，必须绑定可复现、可回放、与当前版本对应的真实资产，否则该结论**不成立、不得进 deliver**。

| 绑定项 | 要求 |
|---|---|
| 可重放命令 | 写出确切命令（如 `uv run pytest -q tests/user -k not_slow`），他人可原样重跑 |
| 退出码 | 记录实际退出码（0/非0），非 0 不得标"通过" |
| 收集/执行数量 | pytest 收集与通过用例数（如 `collected 18, passed 18`） |
| 结果产物 | 真实产物路径（junit `reports/junit.xml`、coverage `reports/coverage.xml`），路径必须存在 |
| 版本标识 | 关联 commit/tag，证明证据对应**当前**代码而非历史 |
| 可回放资产 | 测试文件存在、可被发现（`pytest --collect-only` 命中），非人工勾选/已删除测试 |

**禁止**：用自然语言表格记"pytest 通过、N 例、Lx"却无上述资产；沿用历史终端截图/结论当本次证据；引用已删除或无法发现的测试。呼应 `RULE-TEST-03`。deliver 出口门禁 G6 会把测试证据与 `git status`/产物配对核验（见 [gate-and-stages.md](gate-and-stages.md)）。

## 2. deliver 语义约束（冻结）

| 最高证据 | 可用交付语义 | 禁止语义 |
|---|---|---|
| L1/L2 | 开发草案、提测候选 | 正式交付、可发布 |
| L3 | 阶段性参考包 | 现场稳定、批量发布 |
| L4 | 测试通过候选包 | 无需监控、最终完成 |
| L5 | 可发布交付包 | — |

## 3. Gate 要求（冻结）
- test 阶段必须给每个测试结论标注证据等级。
- deliver 引用 test 阶段最高证据等级；**06 deliver 不得高于 05 test 的最高证据等级**。
- 未测试边界必须写入 deliver 风险，不得隐藏。

## 4. 追溯矩阵
| REQ | DESIGN | TASK | TEST | 证据等级 | 状态 |
|---|---|---|---|---|---|
| REQ-001 | DES-001 | T-001 | TC-001 | L1/L2/L3/L4/L5 | 未开始/进行中/通过/阻塞 |

## 5. 模式 B 证据强度标注（与 L1–L5 分开，避免数字混淆）
模式 B 反推认知时，结论按**文字标注**证据强度，**不复用 L1–L5 数字**（L1–L5 是模式 A 交付门禁语义）：

| 标注 | 含义 | 示例 |
|---|---|---|
| 静态可见 | 当前源码静态可见 | 函数定义、调用点、数据结构、配置 |
| 资料互证 | 静态可见 + 项目资料互证 | PRD、规格书、参数表、接口文档 |
| 运行佐证 | 静态可见 + 资料 + 运行/测试证据 | 构建日志、测试记录、压测/联调/生产记录 |

**冲突与不臆测规则（冻结）**：资料与源码冲突时，`context/` 正文**按源码事实写**，分歧进 `open-issues.md`；**禁止**用「通常 / 应该 / 按经验」补齐没有证据的行为。标「运行佐证」必须有真实日志/记录依据。证据出处汇总落 `context/evidence-trace.md`。

## 6. 模式 B 上游反推可达性（冻结，配合 mode-b-reverse.md）
从认知层反推上游文档（详细设计/概要设计/需求规格书）时，源码反推能力**天然递减**，按可达性三级决定表述：

| 可达性 | 含义 | 允许表述 | 禁止表述 |
|---|---|---|---|
| 可反推 | 源码静态可见即足 | 直接成文 + 证据强度 | — |
| 部分可反推 | 需资料佐证 | `[草稿:…]` + 缺资料处 `[待澄清:…]` | 把推断写成既定事实 |
| 不可反推 | 源码本质不含（完整需求场景/非功能阈值/业务动机/验收标准） | `[缺口:…]`/`[待澄清:…]` | **臆测补全**、删标记蒙混、称「完整需求规格书」 |

有缺口时交付语义**禁称"完整需求规格书"**，必须为"需求规格书**草稿**（含 N 处待澄清/缺口）"。完整规则与缺口标记法见 [mode-b-reverse.md](mode-b-reverse.md)。

## 7. Evidence single landing point (frozen meta-rule)

Evidence rots into "several copies, none authoritative" when every stage keeps its own duplicate. The framework freezes the **meta-rule, not the paths** — concrete directories belong to this domain's `structure.md`.

1. **One authoritative landing point per evidence class.** Each evidence class (test execution records, build artifacts, coverage/benchmark/audit reports, screenshots and captures, machine-generated indexes) has exactly one authoritative location in the project. Two locations for one class is a defect, not a choice.
2. **Landing points MUST be declared explicitly.** This domain's `structure.md` carries an "evidence landing points" table — one row per class: class · authoritative path · who writes it · archive/retention rule. An evidence class not declared there MUST NOT be written anywhere: declare first, then write. Silence is not permission.
3. **Conclusions link back to evidence.** Every conclusion entry in `5-test/current.md` — and every stage that cites evidence — MUST carry a project-relative path to its evidence file at the declared landing point. **A conclusion with no resolvable evidence path MUST NOT be tagged with an L1–L5 level**, and the deliver stage MUST NOT cite it as the highest level.
4. **No duplicate copies.** The same evidence file MUST NOT exist in two locations. When another document needs it, write the path — never copy the file. (Copies of *external inputs* are a different mechanism and remain governed by specs-lifecycle.md §9 `sources.md`.)
5. **Archiving moves evidence, never clones it.** When a stage `current.md` is archived, iteration-scoped evidence moves with it and the conclusion links are rewritten to the archived location; project-scoped evidence stays put and the links keep pointing at it. Either way exactly one copy remains.

**Enforcement**: `/sdd-tidy` reports duplicated evidence files and broken conclusion→evidence links as tidy-plan rows (move/archive only — a broken link is reported, never auto-repaired); post-output self-check item 13 checks the same three points before every stage output.
